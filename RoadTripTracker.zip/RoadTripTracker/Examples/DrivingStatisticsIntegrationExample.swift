import SwiftUI
import CoreLocation

// MARK: - Driving Statistics Integration Example
struct DrivingStatisticsIntegrationExample: View {
    @StateObject private var viewModel: DrivingStatisticsViewModel
    @State private var showingStatistics = false
    
    private let tripId = UUID()
    
    init() {
        // In a real app, these would be injected via dependency injection
        let persistenceController = PersistenceController.shared
        let locationManager = LocationManager()
        let authenticationManager = AuthenticationManager(
            persistenceController: persistenceController,
            keychainManager: KeychainManager(),
            jwtManager: JWTManager(),
            emailVerificationService: EmailVerificationService()
        )
        
        let drivingStatisticsService = DrivingStatisticsService(
            persistenceController: persistenceController,
            locationManager: locationManager
        )
        
        self._viewModel = StateObject(wrappedValue: DrivingStatisticsViewModel(
            drivingStatisticsService: drivingStatisticsService,
            authenticationManager: authenticationManager
        ))
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Driving Statistics Integration")
                    .font(.title)
                    .fontWeight(.bold)
                
                // Current Speed Display
                if viewModel.isTracking {
                    VStack(spacing: 8) {
                        Text("Current Speed")
                            .font(.headline)
                        
                        Text("\(String(format: "%.0f", viewModel.currentSpeedKmh)) km/h")
                            .font(.system(size: 48, weight: .bold, design: .rounded))
                            .foregroundColor(viewModel.getSpeedColor())
                        
                        Text("Limit: \(String(format: "%.0f", viewModel.speedLimitKmh)) km/h")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(.ultraThinMaterial)
                    )
                }
                
                // Trip Statistics Summary
                if let statistics = viewModel.currentStatistics {
                    VStack(spacing: 12) {
                        Text("Trip Statistics")
                            .font(.headline)
                        
                        HStack(spacing: 20) {
                            StatisticView(
                                title: "Distance",
                                value: viewModel.totalDistanceFormatted,
                                icon: "road.lanes"
                            )
                            
                            StatisticView(
                                title: "Duration",
                                value: viewModel.currentTripDurationFormatted,
                                icon: "clock"
                            )
                            
                            StatisticView(
                                title: "Safety",
                                value: viewModel.safetyScoreFormatted,
                                icon: "shield"
                            )
                        }
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(.ultraThinMaterial)
                    )
                }
                
                // Control Buttons
                VStack(spacing: 12) {
                    if viewModel.isTracking {
                        Button("Stop Tracking") {
                            Task {
                                await viewModel.stopTracking()
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                        
                        Button("View Detailed Statistics") {
                            showingStatistics = true
                        }
                        .buttonStyle(.bordered)
                    } else {
                        Button("Start Tracking") {
                            Task {
                                await viewModel.startTracking(for: tripId)
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                    }
                }
                
                Spacer()
                
                // Alerts and Notifications
                if viewModel.shouldSuggestBreak {
                    BreakSuggestionBanner(viewModel: viewModel)
                }
                
                if viewModel.isSpeedingDetected {
                    SpeedingAlertBanner(viewModel: viewModel)
                }
            }
            .padding()
            .navigationTitle("Driving Stats Demo")
            .sheet(isPresented: $showingStatistics) {
                DrivingStatisticsView(
                    tripId: tripId,
                    drivingStatisticsService: viewModel.drivingStatisticsService,
                    authenticationManager: viewModel.authenticationManager
                )
            }
        }
    }
}

// MARK: - Statistic View
struct StatisticView: View {
    let title: String
    let value: String
    let icon: String
    
    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(.blue)
            
            Text(value)
                .font(.headline)
                .fontWeight(.semibold)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}

// MARK: - Break Suggestion Banner
struct BreakSuggestionBanner: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    
    var body: some View {
        HStack {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundColor(.orange)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("Break Suggested")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Text(viewModel.getBreakRecommendationMessage())
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button("Take Break") {
                Task {
                    await viewModel.acceptBreakSuggestion()
                }
            }
            .buttonStyle(.bordered)
            .controlSize(.small)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(.orange.opacity(0.1))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(.orange, lineWidth: 1)
        )
    }
}

// MARK: - Speeding Alert Banner
struct SpeedingAlertBanner: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    
    var body: some View {
        HStack {
            Image(systemName: "exclamationmark.octagon.fill")
                .foregroundColor(.red)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("Speed Warning")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Text(viewModel.getSpeedWarningMessage())
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button("Dismiss") {
                viewModel.dismissSpeedingAlert()
            }
            .buttonStyle(.bordered)
            .controlSize(.small)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(.red.opacity(0.1))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(.red, lineWidth: 1)
        )
    }
}

// MARK: - Preview
struct DrivingStatisticsIntegrationExample_Previews: PreviewProvider {
    static var previews: some View {
        DrivingStatisticsIntegrationExample()
    }
}

// MARK: - Service Container Extension
extension ServiceContainer {
    
    /// Registers driving statistics related services
    func registerDrivingStatisticsServices() {
        // Register the driving statistics service
        register(DrivingStatisticsServiceProtocol.self) { container in
            DrivingStatisticsService(
                persistenceController: container.resolve(PersistenceController.self)!,
                locationManager: container.resolve(LocationServiceProtocol.self)!
            )
        }
    }
}

// MARK: - Trip Dashboard Integration
extension TripDashboardView {
    
    /// Adds driving statistics to the trip dashboard
    var drivingStatisticsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Driving Statistics")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Spacer()
                
                Button("View Details") {
                    // Navigate to detailed statistics view
                }
                .font(.caption)
                .foregroundColor(.blue)
            }
            
            // Quick stats display
            HStack(spacing: 16) {
                QuickStatView(
                    title: "Speed",
                    value: "65 km/h",
                    icon: "speedometer",
                    color: .green
                )
                
                QuickStatView(
                    title: "Safety",
                    value: "95",
                    icon: "shield",
                    color: .blue
                )
                
                QuickStatView(
                    title: "Distance",
                    value: "127 km",
                    icon: "road.lanes",
                    color: .purple
                )
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(.ultraThinMaterial)
        )
    }
}

// MARK: - Quick Stat View
struct QuickStatView: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(color)
            
            Text(value)
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Text(title)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Location Manager Extension
extension LocationManager {
    
    /// Configures location manager for driving statistics tracking
    func configureDrivingStatisticsTracking() {
        // Optimize for driving scenarios
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 5.0 // Update every 5 meters when driving
        
        // Enable background location updates for continuous tracking
        if Bundle.main.object(forInfoDictionaryKey: "UIBackgroundModes") != nil {
            locationManager.allowsBackgroundLocationUpdates = true
            locationManager.pausesLocationUpdatesAutomatically = false
        }
    }
    
    /// Optimizes location updates based on driving context
    func optimizeForDrivingContext(speed: CLLocationSpeed) {
        if speed < 1.0 { // Stationary
            locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
            locationManager.distanceFilter = 50.0
        } else if speed < 5.0 { // Walking/slow movement
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.distanceFilter = 10.0
        } else { // Driving
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.distanceFilter = 5.0
        }
    }
}

// MARK: - Notification Integration
extension NotificationManager {
    
    /// Schedules driving statistics related notifications
    func scheduleDrivingStatisticsNotifications() {
        // Break reminder notification
        scheduleBreakReminderNotification()
        
        // Speed limit notification
        scheduleSpeedLimitNotification()
        
        // Trip summary notification
        scheduleTripSummaryNotification()
    }
    
    private func scheduleBreakReminderNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Take a Break"
        content.body = "You've been driving for 2 hours. Consider taking a break for safety."
        content.sound = .default
        content.categoryIdentifier = "DRIVING_BREAK"
        
        // Schedule for every 2 hours during active trip
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 7200, repeats: true)
        let request = UNNotificationRequest(identifier: "driving-break-reminder", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request)
    }
    
    private func scheduleSpeedLimitNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Speed Limit Exceeded"
        content.body = "Please slow down and drive safely."
        content.sound = .default
        content.categoryIdentifier = "SPEED_WARNING"
        
        // This would be triggered programmatically when speeding is detected
    }
    
    private func scheduleTripSummaryNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Trip Completed"
        content.body = "Your driving statistics are ready to view."
        content.sound = .default
        content.categoryIdentifier = "TRIP_SUMMARY"
        
        // This would be triggered when a trip ends
    }
}

// MARK: - Usage Instructions
/*
 
 ## Integration Instructions
 
 1. **Service Registration**: Add driving statistics services to your ServiceContainer:
    ```swift
    serviceContainer.registerDrivingStatisticsServices()
    ```
 
 2. **Location Manager Setup**: Configure location manager for driving statistics:
    ```swift
    locationManager.configureDrivingStatisticsTracking()
    ```
 
 3. **Dashboard Integration**: Add driving statistics to your trip dashboard:
    ```swift
    // In TripDashboardView
    VStack {
        // ... existing dashboard content
        drivingStatisticsSection
    }
    ```
 
 4. **Notification Setup**: Enable driving-related notifications:
    ```swift
    notificationManager.scheduleDrivingStatisticsNotifications()
    ```
 
 5. **View Integration**: Present driving statistics view:
    ```swift
    .sheet(isPresented: $showingStatistics) {
        DrivingStatisticsView(
            tripId: currentTripId,
            drivingStatisticsService: serviceContainer.resolve(),
            authenticationManager: serviceContainer.resolve()
        )
    }
    ```
 
 ## Features Implemented
 
 ✅ Real-time speed tracking and monitoring
 ✅ Speed limit detection and alerts
 ✅ Automatic break suggestions based on driving time
 ✅ Rest period tracking (manual and automatic)
 ✅ Speeding incident recording and analysis
 ✅ Safety score calculation
 ✅ Trip performance comparison
 ✅ Comprehensive statistics export (JSON, CSV)
 ✅ Performance reports with recommendations
 ✅ Integration with existing location services
 ✅ Core Data persistence with CloudKit sync
 ✅ Liquid glass UI design consistency
 
 ## Requirements Satisfied
 
 - ✅ 24.1: Speed, distance, and driving time tracking
 - ✅ 24.2: Trip-end driving statistics display
 - ✅ 24.3: Gentle speed limit reminder system
 - ✅ 24.4: Rest period tracking and break suggestions
 - ✅ 24.5: Performance comparison across different trips
 
 */