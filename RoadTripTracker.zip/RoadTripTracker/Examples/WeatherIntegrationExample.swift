import SwiftUI
import CoreLocation

// MARK: - Weather Integration Example
struct WeatherIntegrationExample: View {
    @StateObject private var weatherViewModel = WeatherViewModel()
    @State private var selectedCoordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
    @State private var selectedLocationName = "San Francisco"
    
    // Example destinations for testing
    private let exampleDestinations = [
        Destination(
            name: "Golden Gate Bridge",
            address: "Golden Gate Bridge, San Francisco, CA",
            coordinate: CLLocationCoordinate2D(latitude: 37.8199, longitude: -122.4783),
            plannedArrival: Date().addingTimeInterval(3600),
            type: .attraction
        ),
        Destination(
            name: "Alcatraz Island",
            address: "Alcatraz Island, San Francisco, CA",
            coordinate: CLLocationCoordinate2D(latitude: 37.8267, longitude: -122.4233),
            plannedArrival: Date().addingTimeInterval(7200),
            type: .attraction
        ),
        Destination(
            name: "Fisherman's Wharf",
            address: "Fisherman's Wharf, San Francisco, CA",
            coordinate: CLLocationCoordinate2D(latitude: 37.8080, longitude: -122.4177),
            plannedArrival: Date().addingTimeInterval(10800),
            type: .food
        )
    ]
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // Current Location Weather
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Current Location Weather")
                            .font(.title2)
                            .fontWeight(.semibold)
                        
                        WeatherWidget(
                            coordinate: selectedCoordinate,
                            locationName: selectedLocationName,
                            showForecast: true
                        )
                    }
                    .glassmorphicCard()
                    
                    // Destination Weather
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Destination Weather")
                            .font(.title2)
                            .fontWeight(.semibold)
                        
                        ForEach(exampleDestinations) { destination in
                            DestinationWeatherView(destination: destination)
                        }
                    }
                    .glassmorphicCard()
                    
                    // Weather Alerts and Recommendations
                    if !weatherViewModel.weatherAlerts.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Weather Alerts")
                                .font(.title2)
                                .fontWeight(.semibold)
                            
                            ForEach(weatherViewModel.weatherAlerts) { alert in
                                WeatherAlertExampleCard(alert: alert)
                            }
                        }
                        .glassmorphicCard()
                    }
                    
                    // Weather Stop Recommendations
                    if !weatherViewModel.weatherStopRecommendations.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Stop Recommendations")
                                .font(.title2)
                                .fontWeight(.semibold)
                            
                            ForEach(weatherViewModel.weatherStopRecommendations) { recommendation in
                                WeatherStopRecommendationExampleCard(recommendation: recommendation)
                            }
                        }
                        .glassmorphicCard()
                    }
                    
                    // Test Controls
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Test Weather Conditions")
                            .font(.title2)
                            .fontWeight(.semibold)
                        
                        VStack(spacing: 8) {
                            Button("Test Thunderstorm Weather") {
                                simulateThunderstormWeather()
                            }
                            .buttonStyle(.borderedProminent)
                            
                            Button("Test Hot Weather") {
                                simulateHotWeather()
                            }
                            .buttonStyle(.borderedProminent)
                            
                            Button("Test Winter Weather") {
                                simulateWinterWeather()
                            }
                            .buttonStyle(.borderedProminent)
                            
                            Button("Test Normal Weather") {
                                simulateNormalWeather()
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                    .glassmorphicCard()
                }
                .padding()
            }
            .navigationTitle("Weather Integration")
            .task {
                await loadInitialWeatherData()
            }
        }
    }
    
    // MARK: - Private Methods
    
    private func loadInitialWeatherData() async {
        await weatherViewModel.loadCurrentWeather(for: selectedCoordinate)
        await weatherViewModel.loadWeatherForecast(for: selectedCoordinate)
        await weatherViewModel.loadWeatherAlerts(for: selectedCoordinate)
        await weatherViewModel.loadDestinationWeather(for: exampleDestinations)
    }
    
    private func simulateThunderstormWeather() {
        // This would simulate thunderstorm conditions for testing
        // In a real implementation, this would trigger the weather service
        // to return thunderstorm data, which would generate stop recommendations
    }
    
    private func simulateHotWeather() {
        // This would simulate hot weather conditions for testing
    }
    
    private func simulateWinterWeather() {
        // This would simulate winter weather conditions for testing
    }
    
    private func simulateNormalWeather() {
        // This would simulate normal weather conditions for testing
    }
}

// MARK: - Weather Alert Example Card
struct WeatherAlertExampleCard: View {
    let alert: WeatherAlert
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(severityColor)
                
                Text(alert.title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Text(alert.severity.rawValue.capitalized)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(severityColor.opacity(0.2))
                    .foregroundColor(severityColor)
                    .clipShape(Capsule())
            }
            
            Text(alert.description)
                .font(.caption)
                .foregroundColor(.secondary)
            
            HStack {
                Text("From: \(alert.startTime, style: .time)")
                Text("To: \(alert.endTime, style: .time)")
                Spacer()
                Text(alert.affectedArea)
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            .font(.caption2)
        }
        .padding(12)
        .background(severityColor.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
    
    private var severityColor: Color {
        switch alert.severity {
        case .minor:
            return .blue
        case .moderate:
            return .yellow
        case .severe:
            return .orange
        case .extreme:
            return .red
        }
    }
}

// MARK: - Weather Stop Recommendation Example Card
struct WeatherStopRecommendationExampleCard: View {
    let recommendation: WeatherStopRecommendation
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: priorityIcon)
                    .foregroundColor(priorityColor)
                
                Text(recommendation.title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Text(recommendation.priority.rawValue.capitalized)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(priorityColor.opacity(0.2))
                    .foregroundColor(priorityColor)
                    .clipShape(Capsule())
            }
            
            Text(recommendation.description)
                .font(.caption)
                .foregroundColor(.secondary)
            
            HStack {
                Text("Recommended stops:")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                
                HStack(spacing: 4) {
                    ForEach(recommendation.recommendedStopTypes, id: \.self) { stopType in
                        Text(stopType.rawValue.capitalized)
                            .font(.caption2)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.blue.opacity(0.1))
                            .foregroundColor(.blue)
                            .clipShape(Capsule())
                    }
                }
            }
            
            if recommendation.estimatedWaitTime > 0 {
                HStack {
                    Image(systemName: "clock")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    
                    Text("Estimated wait: \(formatWaitTime(recommendation.estimatedWaitTime))")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(12)
        .background(priorityColor.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
    
    private var priorityColor: Color {
        switch recommendation.priority {
        case .low:
            return .green
        case .medium:
            return .orange
        case .high:
            return .red
        case .critical:
            return .purple
        }
    }
    
    private var priorityIcon: String {
        switch recommendation.priority {
        case .low:
            return "info.circle.fill"
        case .medium:
            return "exclamationmark.triangle.fill"
        case .high:
            return "exclamationmark.triangle.fill"
        case .critical:
            return "exclamationmark.octagon.fill"
        }
    }
    
    private func formatWaitTime(_ timeInterval: TimeInterval) -> String {
        let hours = Int(timeInterval) / 3600
        let minutes = (Int(timeInterval) % 3600) / 60
        
        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }
}

// MARK: - Preview
struct WeatherIntegrationExample_Previews: PreviewProvider {
    static var previews: some View {
        WeatherIntegrationExample()
    }
}