import SwiftUI
import CoreLocation

// MARK: - POI Integration Example
// This example shows how to integrate the POI discovery system into the main app

struct POIIntegrationExample: View {
    @StateObject private var poiViewModel: POIViewModel
    @StateObject private var locationManager = LocationManager()
    
    init() {
        let placesService = PlacesService()
        let notificationService = NotificationService()
        let tripService = TripService()
        let poiService = POIService(
            placesService: placesService,
            notificationService: notificationService,
            tripService: tripService
        )
        
        self._poiViewModel = StateObject(wrappedValue: POIViewModel(
            poiService: poiService,
            locationManager: LocationManager()
        ))
    }
    
    var body: some View {
        TabView {
            // Main POI Discovery View
            POIDiscoveryView(
                poiService: POIService(
                    placesService: PlacesService(),
                    notificationService: NotificationService(),
                    tripService: TripService()
                ),
                locationManager: LocationManager()
            )
            .tabItem {
                Image(systemName: "mappin.and.ellipse")
                Text("Discover")
            }
            
            // Trip Integration Example
            TripPOIIntegrationView(poiViewModel: poiViewModel)
                .tabItem {
                    Image(systemName: "map")
                    Text("Trip POIs")
                }
        }
        .onAppear {
            setupPOIIntegration()
        }
    }
    
    private func setupPOIIntegration() {
        // Example of setting up POI discovery for a trip
        let sampleTrip = Trip(
            name: "California Road Trip",
            code: "CA2024",
            createdBy: UUID(),
            participants: [
                Participant(
                    userId: UUID(),
                    user: User(
                        id: UUID(),
                        username: "traveler1",
                        email: "traveler1@example.com",
                        city: "San Francisco",
                        dateOfBirth: Calendar.current.date(byAdding: .year, value: -25, to: Date()) ?? Date()
                    )
                )
            ],
            destinations: [
                Destination(
                    name: "San Francisco",
                    address: "San Francisco, CA",
                    coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
                    type: .start
                ),
                Destination(
                    name: "Los Angeles",
                    address: "Los Angeles, CA",
                    coordinate: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437),
                    type: .end
                )
            ]
        )
        
        poiViewModel.setCurrentTrip(sampleTrip)
        
        // Set current location for POI discovery
        let currentLocation = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        poiViewModel.setCurrentLocation(currentLocation)
    }
}

// MARK: - Trip POI Integration View
struct TripPOIIntegrationView: View {
    @ObservedObject var poiViewModel: POIViewModel
    
    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                // Current Trip Info
                if let trip = poiViewModel.currentTrip {
                    tripInfoCard(trip)
                }
                
                // POI Discovery Actions
                poiActionsSection
                
                // Nearby POIs
                nearbyPOIsSection
                
                // Active Proposals
                activeProposalsSection
                
                Spacer()
            }
            .padding()
            .navigationTitle("Trip POIs")
        }
    }
    
    private func tripInfoCard(_ trip: Trip) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(trip.name)
                .font(.headline)
            
            Text("\(trip.destinations.count) destinations")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Text("\(trip.participants.count) participants")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
    
    private var poiActionsSection: some View {
        VStack(spacing: 12) {
            Text("POI Discovery")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            HStack(spacing: 12) {
                Button("Discover Nearby") {
                    Task {
                        await poiViewModel.discoverNearbyPOIs()
                    }
                }
                .buttonStyle(.bordered)
                
                Button("Along Route") {
                    Task {
                        await poiViewModel.discoverPOIsAlongRoute()
                    }
                }
                .buttonStyle(.bordered)
                
                Button("Filter") {
                    poiViewModel.showFilterSheet()
                }
                .buttonStyle(.bordered)
            }
        }
    }
    
    private var nearbyPOIsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Nearby Attractions")
                    .font(.headline)
                
                Spacer()
                
                if poiViewModel.isLoading {
                    ProgressView()
                        .scaleEffect(0.8)
                }
            }
            
            if poiViewModel.nearbyPOIs.isEmpty {
                Text("No POIs found nearby")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                LazyVStack(spacing: 8) {
                    ForEach(poiViewModel.nearbyPOIs.prefix(3)) { poi in
                        POIQuickCard(poi: poi, viewModel: poiViewModel)
                    }
                }
            }
        }
    }
    
    private var activeProposalsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Active Proposals")
                .font(.headline)
            
            if poiViewModel.proposals.isEmpty {
                Text("No active proposals")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                LazyVStack(spacing: 8) {
                    ForEach(poiViewModel.proposals.filter { $0.status == .pending }) { proposal in
                        ProposalQuickCard(proposal: proposal, viewModel: poiViewModel)
                    }
                }
            }
        }
    }
}

// MARK: - POI Quick Card
struct POIQuickCard: View {
    let poi: PointOfInterest
    let viewModel: POIViewModel
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: poi.category.iconName)
                .font(.title2)
                .foregroundColor(.accentColor)
                .frame(width: 30)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(poi.name)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .lineLimit(1)
                
                Text(poi.category.displayName)
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                if let rating = poi.rating {
                    Text(String(format: "%.1f ⭐", rating))
                        .font(.caption)
                        .foregroundColor(.orange)
                }
            }
            
            Spacer()
            
            if viewModel.canProposePOI(poi) {
                Button("Propose") {
                    viewModel.showProposalSheet(for: poi)
                }
                .font(.caption)
                .buttonStyle(.borderedProminent)
                .controlSize(.small)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemBackground))
        .cornerRadius(8)
        .shadow(color: .black.opacity(0.1), radius: 1, x: 0, y: 1)
    }
}

// MARK: - Proposal Quick Card
struct ProposalQuickCard: View {
    let proposal: POIProposal
    let viewModel: POIViewModel
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: proposal.poi.category.iconName)
                .font(.title2)
                .foregroundColor(.orange)
                .frame(width: 30)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(proposal.poi.name)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .lineLimit(1)
                
                Text("Pending approval")
                    .font(.caption)
                    .foregroundColor(.orange)
                
                Text("\(proposal.votes.count) votes")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            if !viewModel.hasUserVoted(for: proposal) {
                Button("Vote") {
                    // Show voting sheet
                }
                .font(.caption)
                .buttonStyle(.borderedProminent)
                .controlSize(.small)
            } else {
                Text("Voted")
                    .font(.caption)
                    .foregroundColor(.green)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemBackground))
        .cornerRadius(8)
        .shadow(color: .black.opacity(0.1), radius: 1, x: 0, y: 1)
    }
}

#Preview {
    POIIntegrationExample()
}