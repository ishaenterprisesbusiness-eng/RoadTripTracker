import Foundation
import CoreLocation
import SwiftUI

// MARK: - Emergency Integration Example
/**
 * This example demonstrates how to integrate the Emergency Response System
 * into the Road Trip Tracker app. The emergency system provides:
 *
 * 1. Panic button with emergency service alerts
 * 2. Exact location sharing to emergency contacts
 * 3. Check-in notifications for inactive participants
 * 4. Breakdown assistance finder (mechanics, towing)
 * 5. Offline emergency information caching
 *
 * Requirements covered: 23.1, 23.2, 23.3, 23.4, 23.5
 */

// MARK: - Emergency Integration in Main App
struct EmergencyIntegrationExample: View {
    @StateObject private var serviceContainer = ServiceContainer.shared
    
    var body: some View {
        TabView {
            // Main trip dashboard with emergency access
            TripDashboardWithEmergency()
                .tabItem {
                    Image(systemName: "map")
                    Text("Trip")
                }
            
            // Dedicated emergency tab
            EmergencyView(
                emergencyService: serviceContainer.emergencyService,
                locationManager: serviceContainer.locationService as! LocationManager
            )
            .tabItem {
                Image(systemName: "exclamationmark.triangle")
                Text("Emergency")
            }
            
            // Profile with emergency contacts
            ProfileWithEmergencyContacts()
                .tabItem {
                    Image(systemName: "person")
                    Text("Profile")
                }
        }
    }
}

// MARK: - Trip Dashboard with Emergency Integration
struct TripDashboardWithEmergency: View {
    @StateObject private var emergencyViewModel = EmergencyViewModel(
        emergencyService: ServiceContainer.shared.emergencyService,
        locationManager: ServiceContainer.shared.locationService as! LocationManager
    )
    
    var body: some View {
        VStack {
            // Regular trip dashboard content
            Text("Trip Dashboard")
                .font(.largeTitle)
            
            // Emergency status indicator
            if emergencyViewModel.isEmergencyActive {
                EmergencyStatusBanner(viewModel: emergencyViewModel)
            }
            
            // Quick emergency access
            HStack {
                Spacer()
                
                Button(action: {
                    emergencyViewModel.showingEmergencyAlert = true
                }) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.title2)
                        .foregroundColor(.white)
                        .frame(width: 44, height: 44)
                        .background(Color.red)
                        .clipShape(Circle())
                        .shadow(radius: 4)
                }
                .disabled(emergencyViewModel.isEmergencyActive)
            }
            .padding()
        }
        .sheet(isPresented: $emergencyViewModel.showingEmergencyAlert) {
            EmergencyAlertSheet(viewModel: emergencyViewModel)
        }
    }
}

// MARK: - Emergency Status Banner
struct EmergencyStatusBanner: View {
    @ObservedObject var viewModel: EmergencyViewModel
    
    var body: some View {
        HStack {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundColor(.red)
                .scaleEffect(1.2)
                .animation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true), value: viewModel.isEmergencyActive)
            
            VStack(alignment: .leading) {
                Text("Emergency Alert Active")
                    .font(.headline)
                    .foregroundColor(.red)
                
                Text("Help is on the way")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button("Cancel") {
                viewModel.cancelEmergencyAlert()
            }
            .font(.caption)
            .foregroundColor(.red)
        }
        .padding()
        .background(Color.red.opacity(0.1))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.red.opacity(0.3), lineWidth: 1)
        )
        .padding(.horizontal)
    }
}

// MARK: - Profile with Emergency Contacts
struct ProfileWithEmergencyContacts: View {
    var body: some View {
        NavigationView {
            List {
                Section("Profile") {
                    Text("User Profile Content")
                }
                
                Section("Emergency") {
                    NavigationLink("Emergency Contacts") {
                        EmergencyContactsView()
                    }
                    
                    NavigationLink("Emergency Settings") {
                        EmergencySettingsView()
                    }
                }
            }
            .navigationTitle("Profile")
        }
    }
}

// MARK: - Emergency Settings View
struct EmergencySettingsView: View {
    @State private var enableCheckInNotifications = true
    @State private var checkInInterval: Double = 30
    @State private var enableLocationSharing = true
    @State private var enableEmergencyContacts = true
    
    var body: some View {
        Form {
            Section("Check-in Monitoring") {
                Toggle("Enable Check-in Notifications", isOn: $enableCheckInNotifications)
                
                if enableCheckInNotifications {
                    VStack(alignment: .leading) {
                        Text("Check-in Interval: \(Int(checkInInterval)) minutes")
                            .font(.caption)
                        
                        Slider(value: $checkInInterval, in: 15...60, step: 15) {
                            Text("Interval")
                        }
                    }
                }
            } footer: {
                Text("Participants will be prompted to check in if they haven't been active for the specified interval.")
            }
            
            Section("Emergency Contacts") {
                Toggle("Enable Emergency Contact Notifications", isOn: $enableEmergencyContacts)
                
                if enableEmergencyContacts {
                    NavigationLink("Manage Emergency Contacts") {
                        EmergencyContactsView()
                    }
                }
            } footer: {
                Text("Emergency contacts will be notified when you trigger an emergency alert.")
            }
            
            Section("Location Sharing") {
                Toggle("Share Location in Emergencies", isOn: $enableLocationSharing)
            } footer: {
                Text("Your exact location will be shared with emergency contacts and services when needed.")
            }
            
            Section("Offline Emergency Data") {
                HStack {
                    Text("Cache Emergency Services")
                    Spacer()
                    Button("Update Now") {
                        // Update cached emergency services
                    }
                    .font(.caption)
                }
                
                HStack {
                    Text("Cache Emergency Contacts")
                    Spacer()
                    Button("Sync") {
                        // Sync emergency contacts for offline access
                    }
                    .font(.caption)
                }
            } footer: {
                Text("Emergency information is cached for offline access when cellular coverage is poor.")
            }
        }
        .navigationTitle("Emergency Settings")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Emergency Service Usage Examples
class EmergencyServiceUsageExamples {
    
    private let emergencyService: EmergencyServiceProtocol
    private let locationManager: LocationManager
    
    init(emergencyService: EmergencyServiceProtocol, locationManager: LocationManager) {
        self.emergencyService = emergencyService
        self.locationManager = locationManager
    }
    
    // MARK: - Example 1: Trigger Panic Alert
    func exampleTriggerPanicAlert() async {
        do {
            // Get current location
            let location = try await locationManager.getCurrentLocation()
            
            // Trigger emergency alert with optional message
            try await emergencyService.triggerEmergencyAlert(
                location: location.coordinate,
                message: "Car accident on Highway 1, need immediate assistance"
            )
            
            print("Emergency alert sent successfully")
            
        } catch {
            print("Failed to send emergency alert: \(error)")
        }
    }
    
    // MARK: - Example 2: Request Breakdown Assistance
    func exampleRequestBreakdownAssistance() async {
        do {
            // Get current location
            let location = try await locationManager.getCurrentLocation()
            
            // Get vehicle information (this would come from user profile)
            let vehicle = Vehicle(
                make: "Toyota",
                model: "Camry",
                vehicleNumber: "ABC123",
                odometerReading: 50000,
                type: .sedan
            )
            
            // Request breakdown assistance
            try await emergencyService.sendBreakdownAssistance(
                location: location.coordinate,
                vehicleInfo: vehicle
            )
            
            print("Breakdown assistance requested")
            
        } catch {
            print("Failed to request breakdown assistance: \(error)")
        }
    }
    
    // MARK: - Example 3: Find Nearby Emergency Services
    func exampleFindEmergencyServices() async {
        do {
            // Get current location
            let location = try await locationManager.getCurrentLocation()
            
            // Find nearby emergency services
            let services = try await emergencyService.findNearbyEmergencyServices(
                location: location.coordinate
            )
            
            // Filter by type if needed
            let hospitals = services.filter { $0.type == .hospital }
            let towingServices = services.filter { $0.type == .towingService }
            
            print("Found \(hospitals.count) hospitals and \(towingServices.count) towing services")
            
            // Use the services (call, get directions, etc.)
            if let nearestHospital = hospitals.first {
                print("Nearest hospital: \(nearestHospital.name) - \(nearestHospital.phoneNumber)")
            }
            
        } catch {
            print("Failed to find emergency services: \(error)")
        }
    }
    
    // MARK: - Example 4: Listen for Emergency Alerts
    func exampleListenForEmergencyAlerts() {
        emergencyService.emergencyAlerts
            .sink { alert in
                switch alert.alertType {
                case .panic:
                    self.handlePanicAlert(alert)
                case .breakdown:
                    self.handleBreakdownAlert(alert)
                case .accident:
                    self.handleAccidentAlert(alert)
                case .medical:
                    self.handleMedicalAlert(alert)
                case .other:
                    self.handleOtherAlert(alert)
                }
            }
    }
    
    // MARK: - Alert Handlers
    private func handlePanicAlert(_ alert: EmergencyAlert) {
        print("🚨 PANIC ALERT from participant")
        print("Location: \(alert.location)")
        print("Message: \(alert.message ?? "No message")")
        
        // Show urgent notification to user
        // Navigate to emergency response screen
        // Offer to call emergency services
    }
    
    private func handleBreakdownAlert(_ alert: EmergencyAlert) {
        print("🔧 BREAKDOWN ALERT from participant")
        print("Location: \(alert.location)")
        
        // Show breakdown assistance options
        // Offer to help find nearby services
    }
    
    private func handleAccidentAlert(_ alert: EmergencyAlert) {
        print("🚗 ACCIDENT ALERT from participant")
        print("Location: \(alert.location)")
        
        // Show emergency response options
        // Offer to call emergency services
        // Navigate to participant location
    }
    
    private func handleMedicalAlert(_ alert: EmergencyAlert) {
        print("🏥 MEDICAL ALERT from participant")
        print("Location: \(alert.location)")
        
        // Show medical emergency response
        // Offer to call ambulance
        // Find nearest hospital
    }
    
    private func handleOtherAlert(_ alert: EmergencyAlert) {
        print("ℹ️ OTHER ALERT from participant")
        print("Message: \(alert.message ?? "No details")")
        
        // Show general assistance options
    }
}

// MARK: - Emergency Contact Management Examples
class EmergencyContactManagementExamples {
    
    // MARK: - Example Emergency Contacts Setup
    func exampleSetupEmergencyContacts() -> [EmergencyContact] {
        return [
            // Primary contact - spouse
            EmergencyContact(
                name: "Sarah Johnson",
                relationship: "Spouse",
                phoneNumber: "+61 400 123 456",
                email: "sarah@example.com",
                contactMethod: .sms,
                isPrimary: true
            ),
            
            // Secondary contact - parent
            EmergencyContact(
                name: "Robert Johnson",
                relationship: "Father",
                phoneNumber: "+61 400 789 012",
                contactMethod: .call,
                isPrimary: false
            ),
            
            // Work contact
            EmergencyContact(
                name: "Emergency Services Coordinator",
                relationship: "Work",
                phoneNumber: "+61 400 555 000",
                email: "emergency@company.com",
                contactMethod: .email,
                isPrimary: false
            )
        ]
    }
    
    // MARK: - Example Contact Validation
    func validateEmergencyContact(_ contact: EmergencyContact) -> Bool {
        // Validate required fields
        guard !contact.name.isEmpty,
              !contact.relationship.isEmpty,
              !contact.phoneNumber.isEmpty else {
            return false
        }
        
        // Validate phone number format
        let phoneRegex = "^\\+?[1-9]\\d{1,14}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        guard phoneTest.evaluate(with: contact.phoneNumber) else {
            return false
        }
        
        // Validate email if provided
        if let email = contact.email, !email.isEmpty {
            let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegex)
            guard emailTest.evaluate(with: email) else {
                return false
            }
        }
        
        return true
    }
}

// MARK: - Offline Emergency Data Examples
class OfflineEmergencyDataExamples {
    
    // MARK: - Example Offline Emergency Services Cache
    func exampleCacheEmergencyServices() {
        let emergencyServices = [
            EmergencyService(
                name: "Melbourne Hospital",
                type: .hospital,
                phoneNumber: "000",
                address: "300 Grattan Street, Parkville VIC 3050",
                coordinate: CLLocationCoordinate2D(latitude: -37.7986, longitude: 144.9631),
                distance: 0,
                isOpen24Hours: true
            ),
            EmergencyService(
                name: "Victoria Police",
                type: .police,
                phoneNumber: "000",
                address: "637 Flinders Street, Melbourne VIC 3000",
                coordinate: CLLocationCoordinate2D(latitude: -37.8183, longitude: 144.9671),
                distance: 0,
                isOpen24Hours: true
            ),
            EmergencyService(
                name: "24/7 Towing Melbourne",
                type: .towingService,
                phoneNumber: "1800 869 464",
                address: "Various locations",
                coordinate: CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631),
                distance: 0,
                isOpen24Hours: true
            )
        ]
        
        // Cache these services for offline access
        // This would be stored in Core Data
        print("Cached \(emergencyServices.count) emergency services for offline access")
    }
    
    // MARK: - Example Emergency Information Cache
    func exampleCacheEmergencyInformation() {
        let emergencyInfo = [
            "Australia Emergency Number": "000",
            "Police Non-Emergency": "131 444",
            "Roadside Assistance": "13 11 11",
            "Poison Information": "13 11 26",
            "Mental Health Crisis": "1300 659 467"
        ]
        
        // Cache emergency numbers for offline access
        print("Cached emergency information: \(emergencyInfo)")
    }
}