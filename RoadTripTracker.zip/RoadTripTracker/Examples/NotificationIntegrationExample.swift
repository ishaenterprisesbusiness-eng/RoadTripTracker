import Foundation
import CoreLocation
import Combine

// MARK: - Notification Integration Example
// This file demonstrates how to integrate the notification system with other services

class NotificationIntegrationExample {
    
    private let notificationManager: NotificationManager
    private let tripService: TripServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    
    init(notificationManager: NotificationManager, tripService: TripServiceProtocol) {
        self.notificationManager = notificationManager
        self.tripService = tripService
        
        setupNotificationIntegration()
    }
    
    // MARK: - Setup Integration
    
    private func setupNotificationIntegration() {
        // Listen for trip updates and send notifications
        tripService.tripUpdates
            .sink { [weak self] trip in
                Task {
                    await self?.handleTripUpdate(trip)
                }
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Trip Event Handling
    
    private func handleTripUpdate(_ trip: Trip) async {
        switch trip.status {
        case .active:
            await notificationManager.notifyTripStarted(trip)
            await notificationManager.setupDestinationAlerts(for: trip)
            
        case .completed:
            await notificationManager.notifyTripCompleted(trip)
            
        default:
            break
        }
    }
    
    // MARK: - Participant Management Integration
    
    func handleParticipantJoined(_ participant: Participant, in trip: Trip) async {
        // Update trip with new participant
        var updatedTrip = trip
        updatedTrip.participants.append(participant)
        
        // Send notification to all participants
        await notificationManager.notifyParticipantJoined(participant, in: updatedTrip)
        
        // Setup check-in reminders for the new participant
        await notificationManager.scheduleCheckInReminder(
            for: participant,
            trip: updatedTrip,
            after: 3600 // 1 hour
        )
    }
    
    func handleParticipantLeft(_ participant: Participant, from trip: Trip) async {
        // Remove participant from trip
        var updatedTrip = trip
        updatedTrip.participants.removeAll { $0.id == participant.id }
        
        // Send notification to remaining participants
        await notificationManager.notifyParticipantLeft(participant, from: updatedTrip)
        
        // Cancel check-in reminders for the participant who left
        await notificationManager.cancelCheckInReminder(for: participant)
    }
    
    // MARK: - Location-Based Notifications
    
    func handleLocationUpdate(_ location: CLLocation, for participant: Participant, in trip: Trip) async {
        // Check if participant is approaching any destinations
        for destination in trip.destinations {
            let distance = location.distance(from: CLLocation(
                latitude: destination.coordinate.latitude,
                longitude: destination.coordinate.longitude
            ))
            
            // Send notification if within 5km of destination
            if distance <= 5000 && distance > 1000 {
                await notificationManager.notifyApproachingDestination(
                    destination,
                    participant: participant,
                    trip: trip,
                    distance: distance
                )
            }
        }
    }
    
    // MARK: - Emergency Handling
    
    func handleEmergencyAlert(
        type: EmergencyType,
        message: String,
        location: CLLocationCoordinate2D,
        participant: Participant,
        trip: Trip
    ) async {
        let emergency = EmergencyNotification(
            tripId: trip.id,
            participantId: participant.id,
            type: type,
            message: message,
            location: location
        )
        
        await notificationManager.notifyEmergency(emergency, participant: participant, trip: trip)
    }
    
    // MARK: - Budget Integration
    
    func handleBudgetUpdate(_ budget: Budget, for trip: Trip) async {
        let totalSpent = budget.expenses.reduce(0) { $0 + $1.amount }
        let percentageUsed = (totalSpent / budget.totalBudget) * 100
        
        // Send alert if budget is 80% used
        if percentageUsed >= 80 {
            let budgetAlert = BudgetAlert(
                type: .approaching,
                message: "Budget limit approaching",
                threshold: budget.totalBudget,
                currentAmount: totalSpent
            )
            
            await notificationManager.notifyBudgetAlert(budgetAlert, trip: trip)
        }
    }
    
    // MARK: - Weather Integration
    
    func handleWeatherAlert(_ weatherAlert: WeatherAlert, for location: String) async {
        await notificationManager.notifyWeatherAlert(weatherAlert, location: location)
    }
    
    // MARK: - Notification Preferences Management
    
    func updateUserNotificationPreferences(_ preferences: NotificationPreferences) async {
        await notificationManager.updateNotificationPreferences(preferences)
    }
    
    func requestNotificationPermissions() async -> Bool {
        return await notificationManager.requestNotificationPermission()
    }
}

// MARK: - Usage Example

class ExampleUsage {
    
    func demonstrateNotificationSystem() async {
        // Initialize services
        let serviceContainer = ServiceContainer.shared
        let notificationService = serviceContainer.notificationService
        let locationManager = serviceContainer.locationService as! LocationManager
        
        // Create notification manager
        let notificationManager = NotificationManager(
            notificationService: notificationService,
            locationManager: locationManager
        )
        
        // Create integration example
        let integration = NotificationIntegrationExample(
            notificationManager: notificationManager,
            tripService: serviceContainer.tripService
        )
        
        // Request notification permissions
        let permissionGranted = await integration.requestNotificationPermissions()
        guard permissionGranted else {
            print("Notification permissions not granted")
            return
        }
        
        // Create example trip and participants
        let user1 = User(
            username: "alice",
            email: "alice@example.com",
            city: "San Francisco",
            dateOfBirth: Calendar.current.date(byAdding: .year, value: -25, to: Date()) ?? Date()
        )
        
        let user2 = User(
            username: "bob",
            email: "bob@example.com",
            city: "San Francisco",
            dateOfBirth: Calendar.current.date(byAdding: .year, value: -30, to: Date()) ?? Date()
        )
        
        let participant1 = Participant(userId: user1.id, user: user1)
        let participant2 = Participant(userId: user2.id, user: user2)
        
        let destination = Destination(
            name: "Yosemite National Park",
            address: "Yosemite National Park, CA",
            coordinate: CLLocationCoordinate2D(latitude: 37.8651, longitude: -119.5383)
        )
        
        let trip = Trip(
            name: "Yosemite Adventure",
            code: "YOSE123",
            createdBy: user1.id,
            participants: [participant1],
            destinations: [destination],
            status: .planning
        )
        
        // Demonstrate participant joining
        await integration.handleParticipantJoined(participant2, in: trip)
        
        // Demonstrate trip starting
        var activeTrip = trip
        activeTrip.status = .active
        // This would trigger notifications through the trip service integration
        
        // Demonstrate location-based notification
        let currentLocation = CLLocation(latitude: 37.8000, longitude: -119.5000) // Near Yosemite
        await integration.handleLocationUpdate(currentLocation, for: participant1, in: activeTrip)
        
        // Demonstrate emergency alert
        await integration.handleEmergencyAlert(
            type: .breakdown,
            message: "Car broke down, need assistance",
            location: currentLocation.coordinate,
            participant: participant1,
            trip: activeTrip
        )
        
        // Demonstrate budget alert
        let budget = Budget(totalBudget: 1000.0)
        var budgetWithExpenses = budget
        budgetWithExpenses.expenses = [
            Expense(amount: 200.0, category: .fuel, description: "Gas", participantId: participant1.id),
            Expense(amount: 150.0, category: .food, description: "Lunch", participantId: participant1.id),
            Expense(amount: 500.0, category: .accommodation, description: "Hotel", participantId: participant2.id)
        ]
        
        await integration.handleBudgetUpdate(budgetWithExpenses, for: activeTrip)
        
        // Demonstrate weather alert
        let weatherAlert = WeatherAlert(
            title: "Severe Weather Warning",
            description: "Heavy snow expected in mountain areas",
            severity: .severe,
            startTime: Date(),
            endTime: Date().addingTimeInterval(3600 * 6), // 6 hours
            affectedAreas: ["Yosemite National Park"]
        )
        
        await integration.handleWeatherAlert(weatherAlert, for: "Yosemite National Park")
        
        print("Notification system demonstration completed")
    }
}