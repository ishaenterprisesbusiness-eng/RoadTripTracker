import SwiftUI

struct POIVoteSheet: View {
    let proposal: POIProposal
    let viewModel: POIViewModel
    
    @Environment(\.dismiss) private var dismiss
    @State private var selectedVote: VoteType = .approve
    @State private var comment = ""
    @State private var isSubmitting = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // POI Summary
                poiSummaryView
                
                // Vote Options
                voteOptionsSection
                
                // Comment Section
                commentSection
                
                Spacer()
                
                // Submit Button
                submitButton
            }
            .padding()
            .navigationTitle("Vote on Proposal")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    // MARK: - POI Summary View
    
    private var poiSummaryView: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                Image(systemName: proposal.poi.category.iconName)
                    .font(.title)
                    .foregroundColor(.accentColor)
                    .frame(width: 40, height: 40)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(proposal.poi.name)
                        .font(.headline)
                        .lineLimit(2)
                    
                    Text(proposal.poi.category.displayName)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.accentColor.opacity(0.1))
                        .cornerRadius(4)
                    
                    if let rating = proposal.poi.rating {
                        HStack {
                            Text(String(format: "%.1f", rating))
                                .font(.caption)
                                .fontWeight(.medium)
                            
                            HStack(spacing: 1) {
                                ForEach(0..<5) { index in
                                    Image(systemName: index < Int(rating) ? "star.fill" : "star")
                                        .font(.caption2)
                                        .foregroundColor(.orange)
                                }
                            }
                        }
                    }
                }
                
                Spacer()
            }
            
            if let message = proposal.proposalMessage {
                Text("Proposal Message:")
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Text(message)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
    
    // MARK: - Vote Options Section
    
    private var voteOptionsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Your Vote")
                .font(.headline)
            
            VStack(spacing: 8) {
                VoteOptionView(
                    vote: .approve,
                    title: "Approve",
                    description: "I want to visit this place",
                    icon: "hand.thumbsup.fill",
                    color: .green,
                    isSelected: selectedVote == .approve
                ) {
                    selectedVote = .approve
                }
                
                VoteOptionView(
                    vote: .reject,
                    title: "Reject",
                    description: "I don't want to visit this place",
                    icon: "hand.thumbsdown.fill",
                    color: .red,
                    isSelected: selectedVote == .reject
                ) {
                    selectedVote = .reject
                }
                
                VoteOptionView(
                    vote: .abstain,
                    title: "Abstain",
                    description: "I'm neutral about this place",
                    icon: "minus.circle.fill",
                    color: .gray,
                    isSelected: selectedVote == .abstain
                ) {
                    selectedVote = .abstain
                }
            }
        }
    }
    
    // MARK: - Comment Section
    
    private var commentSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Comment (Optional)")
                .font(.headline)
            
            TextField("Share your thoughts...", text: $comment, axis: .vertical)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .lineLimit(2...4)
        }
    }
    
    // MARK: - Submit Button
    
    private var submitButton: some View {
        Button(action: submitVote) {
            HStack {
                if isSubmitting {
                    ProgressView()
                        .scaleEffect(0.8)
                        .tint(.white)
                } else {
                    Image(systemName: "checkmark.circle.fill")
                }
                
                Text(isSubmitting ? "Submitting..." : "Submit Vote")
            }
            .font(.headline)
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.accentColor)
            .cornerRadius(12)
        }
        .disabled(isSubmitting)
    }
    
    // MARK: - Actions
    
    private func submitVote() {
        isSubmitting = true
        
        Task {
            await viewModel.votePOIProposal(
                proposal,
                vote: selectedVote,
                comment: comment.isEmpty ? nil : comment
            )
            
            await MainActor.run {
                isSubmitting = false
                dismiss()
            }
        }
    }
}

// MARK: - Vote Option View

struct VoteOptionView: View {
    let vote: VoteType
    let title: String
    let description: String
    let icon: String
    let color: Color
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                    .font(.title2)
                    .foregroundColor(isSelected ? .accentColor : .secondary)
                
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(color)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                    
                    Text(description)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(isSelected ? color.opacity(0.1) : Color(.systemGray6))
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(isSelected ? color : Color.clear, lineWidth: 2)
                    )
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}