import SwiftUI
import CoreLocation

// MARK: - Weather Widget
struct WeatherWidget: View {
    let coordinate: CLLocationCoordinate2D
    let locationName: String
    let showForecast: Bool
    
    @StateObject private var weatherViewModel = WeatherViewModel()
    @State private var showingFullWeather = false
    
    init(coordinate: CLLocationCoordinate2D, locationName: String, showForecast: Bool = false) {
        self.coordinate = coordinate
        self.locationName = locationName
        self.showForecast = showForecast
    }
    
    var body: some View {
        VStack(spacing: 12) {
            // Current Weather
            if let currentWeather = weatherViewModel.currentWeather {
                CompactWeatherCard(weather: currentWeather, locationName: locationName)
                    .onTapGesture {
                        showingFullWeather = true
                    }
            } else if weatherViewModel.isLoading {
                WeatherLoadingCard(locationName: locationName)
            } else {
                WeatherErrorCard(locationName: locationName) {
                    await loadWeatherData()
                }
            }
            
            // Weather Alerts
            if !weatherViewModel.severeWeatherWarnings.isEmpty {
                WeatherAlertsWidget(alerts: weatherViewModel.severeWeatherWarnings)
            }
            
            // Weather Stop Recommendations
            if !weatherViewModel.weatherStopRecommendations.isEmpty {
                WeatherStopRecommendationsWidget(recommendations: weatherViewModel.weatherStopRecommendations)
            }
            
            // Forecast (if requested)
            if showForecast && !weatherViewModel.weatherForecast.isEmpty {
                CompactForecastWidget(forecast: Array(weatherViewModel.weatherForecast.prefix(3)))
            }
        }
        .task {
            await loadWeatherData()
        }
        .sheet(isPresented: $showingFullWeather) {
            NavigationView {
                WeatherView(coordinate: coordinate, locationName: locationName)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button("Done") {
                                showingFullWeather = false
                            }
                        }
                    }
            }
        }
    }
    
    private func loadWeatherData() async {
        await weatherViewModel.loadCurrentWeather(for: coordinate)
        if showForecast {
            await weatherViewModel.loadWeatherForecast(for: coordinate, days: 3)
        }
        await weatherViewModel.loadWeatherAlerts(for: coordinate)
    }
}

// MARK: - Compact Weather Card
struct CompactWeatherCard: View {
    let weather: WeatherData
    let locationName: String
    
    var body: some View {
        HStack(spacing: 12) {
            // Weather Icon
            Image(systemName: WeatherViewModel().getWeatherIcon(for: weather.condition))
                .font(.title2)
                .foregroundColor(.primary)
                .frame(width: 32)
            
            // Weather Info
            VStack(alignment: .leading, spacing: 2) {
                Text(locationName)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .lineLimit(1)
                
                Text(weather.description.capitalized)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }
            
            Spacer()
            
            // Temperature
            VStack(alignment: .trailing, spacing: 2) {
                Text("\(Int(weather.temperature))°C")
                    .font(.title3)
                    .fontWeight(.semibold)
                
                Text("Feels \(Int(weather.feelsLike))°")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .padding(12)
        .background(Color.secondary.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - Weather Loading Card
struct WeatherLoadingCard: View {
    let locationName: String
    
    var body: some View {
        HStack(spacing: 12) {
            ProgressView()
                .frame(width: 32)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(locationName)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Text("Loading weather...")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
        .padding(12)
        .background(Color.secondary.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - Weather Error Card
struct WeatherErrorCard: View {
    let locationName: String
    let onRetry: () async -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "exclamationmark.triangle")
                .font(.title3)
                .foregroundColor(.orange)
                .frame(width: 32)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(locationName)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Text("Weather unavailable")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button("Retry") {
                Task {
                    await onRetry()
                }
            }
            .font(.caption)
            .foregroundColor(.blue)
        }
        .padding(12)
        .background(Color.secondary.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - Weather Alerts Widget
struct WeatherAlertsWidget: View {
    let alerts: [WeatherAlert]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(alerts.prefix(2)) { alert in
                HStack(spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.caption)
                        .foregroundColor(alertColor(for: alert.severity))
                    
                    Text(alert.title)
                        .font(.caption)
                        .fontWeight(.medium)
                        .lineLimit(1)
                    
                    Spacer()
                    
                    Text(alert.severity.rawValue.capitalized)
                        .font(.caption2)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(alertColor(for: alert.severity).opacity(0.2))
                        .foregroundColor(alertColor(for: alert.severity))
                        .clipShape(Capsule())
                }
            }
            
            if alerts.count > 2 {
                Text("+ \(alerts.count - 2) more alerts")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .padding(8)
        .background(Color.orange.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
    
    private func alertColor(for severity: WeatherAlertSeverity) -> Color {
        switch severity {
        case .minor:
            return .blue
        case .moderate:
            return .yellow
        case .severe:
            return .orange
        case .extreme:
            return .red
        }
    }
}

// MARK: - Compact Forecast Widget
struct CompactForecastWidget: View {
    let forecast: [WeatherData]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("3-Day Forecast")
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.secondary)
            
            HStack(spacing: 16) {
                ForEach(Array(forecast.enumerated()), id: \.offset) { index, weather in
                    CompactForecastItem(weather: weather, isToday: index == 0)
                }
            }
        }
        .padding(8)
        .background(Color.secondary.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
}

// MARK: - Compact Forecast Item
struct CompactForecastItem: View {
    let weather: WeatherData
    let isToday: Bool
    
    var body: some View {
        VStack(spacing: 4) {
            Text(isToday ? "Today" : dayOfWeek)
                .font(.caption2)
                .foregroundColor(.secondary)
            
            Image(systemName: WeatherViewModel().getWeatherIcon(for: weather.condition))
                .font(.caption)
                .foregroundColor(.primary)
            
            Text("\(Int(weather.temperature))°")
                .font(.caption)
                .fontWeight(.medium)
        }
        .frame(maxWidth: .infinity)
    }
    
    private var dayOfWeek: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE"
        return formatter.string(from: weather.timestamp)
    }
}

// MARK: - Weather Stop Recommendations Widget
struct WeatherStopRecommendationsWidget: View {
    let recommendations: [WeatherStopRecommendation]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(recommendations.prefix(2)) { recommendation in
                HStack(spacing: 8) {
                    Image(systemName: priorityIcon(for: recommendation.priority))
                        .font(.caption)
                        .foregroundColor(priorityColor(for: recommendation.priority))
                    
                    VStack(alignment: .leading, spacing: 2) {
                        Text(recommendation.title)
                            .font(.caption)
                            .fontWeight(.medium)
                            .lineLimit(1)
                        
                        Text(recommendation.description)
                            .font(.caption2)
                            .foregroundColor(.secondary)
                            .lineLimit(2)
                    }
                    
                    Spacer()
                    
                    Text(recommendation.priority.rawValue.capitalized)
                        .font(.caption2)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(priorityColor(for: recommendation.priority).opacity(0.2))
                        .foregroundColor(priorityColor(for: recommendation.priority))
                        .clipShape(Capsule())
                }
            }
            
            if recommendations.count > 2 {
                Text("+ \(recommendations.count - 2) more recommendations")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .padding(8)
        .background(Color.orange.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
    
    private func priorityColor(for priority: WeatherStopPriority) -> Color {
        switch priority {
        case .low:
            return .green
        case .medium:
            return .orange
        case .high:
            return .red
        case .critical:
            return .purple
        }
    }
    
    private func priorityIcon(for priority: WeatherStopPriority) -> String {
        switch priority {
        case .low:
            return "info.circle.fill"
        case .medium:
            return "exclamationmark.triangle.fill"
        case .high:
            return "exclamationmark.triangle.fill"
        case .critical:
            return "exclamationmark.octagon.fill"
        }
    }
}

// MARK: - Destination Weather Integration
struct DestinationWeatherView: View {
    let destination: Destination
    @StateObject private var weatherViewModel = WeatherViewModel()
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "cloud.sun")
                    .foregroundColor(.blue)
                
                Text("Weather at \(destination.name)")
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            
            WeatherWidget(
                coordinate: destination.coordinate,
                locationName: destination.name,
                showForecast: true
            )
        }
        .glassmorphicCard()
    }
}

// MARK: - Preview
struct WeatherWidget_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 20) {
            WeatherWidget(
                coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
                locationName: "San Francisco",
                showForecast: true
            )
            
            DestinationWeatherView(
                destination: Destination(
                    name: "Golden Gate Bridge",
                    address: "Golden Gate Bridge, San Francisco, CA",
                    coordinate: CLLocationCoordinate2D(latitude: 37.8199, longitude: -122.4783),
                    type: .attraction
                )
            )
        }
        .padding()
    }
}