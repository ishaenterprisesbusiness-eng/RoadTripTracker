import SwiftUI
import CoreLocation

struct TripHistoryCard: View {
    let trip: Trip
    
    var body: some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: 12) {
                // Trip Header
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(trip.name)
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundColor(.primary)
                        
                        Text(trip.code)
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(.secondary)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 2)
                            .background(
                                Capsule()
                                    .fill(.ultraThinMaterial)
                            )
                    }
                    
                    Spacer()
                    
                    TripStatusBadge(status: trip.status)
                }
                
                // Trip Details
                VStack(alignment: .leading, spacing: 8) {
                    // Destinations
                    if !trip.destinations.isEmpty {
                        HStack(spacing: 6) {
                            Image(systemName: "location")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text("\(trip.destinations.count) destinations")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            if trip.destinations.count > 0 {
                                Text("•")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                
                                Text(trip.destinations.first?.name ?? "Unknown")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                    .lineLimit(1)
                                
                                if trip.destinations.count > 1 {
                                    Text("→ \(trip.destinations.last?.name ?? "Unknown")")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                        .lineLimit(1)
                                }
                            }
                        }
                    }
                    
                    // Participants and Date
                    HStack(spacing: 12) {
                        HStack(spacing: 4) {
                            Image(systemName: "person.2")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text("\(trip.participants.count) participants")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        HStack(spacing: 4) {
                            Image(systemName: "calendar")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text(trip.createdAt.formatted(date: .abbreviated, time: .omitted))
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                    }
                }
                
                // Trip Progress (for active trips)
                if trip.status == .active {
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text("Progress")
                                .font(.caption)
                                .fontWeight(.medium)
                                .foregroundColor(.secondary)
                            
                            Spacer()
                            
                            Text("\(trip.currentDestinationIndex + 1) of \(trip.destinations.count)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        ProgressView(value: Double(trip.currentDestinationIndex + 1), total: Double(trip.destinations.count))
                            .progressViewStyle(LinearProgressViewStyle(tint: .blue))
                            .scaleEffect(y: 0.5)
                    }
                }
                
                // Distance and Duration (for completed trips)
                if trip.status == .completed {
                    HStack(spacing: 16) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Distance")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text("\(Int(calculateTripDistance())) km")
                                .font(.subheadline)
                                .fontWeight(.semibold)
                                .foregroundColor(.primary)
                        }
                        
                        if let startedAt = trip.startedAt {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Duration")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                
                                Text(formatDuration(from: startedAt, to: trip.createdAt))
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.primary)
                            }
                        }
                        
                        Spacer()
                    }
                }
            }
        }
    }
    
    // MARK: - Helper Methods
    
    private func calculateTripDistance() -> Double {
        guard trip.destinations.count > 1 else { return 0.0 }
        
        var totalDistance: Double = 0.0
        
        for i in 0..<(trip.destinations.count - 1) {
            let from = trip.destinations[i].coordinate
            let to = trip.destinations[i + 1].coordinate
            
            let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
            let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
            
            totalDistance += fromLocation.distance(from: toLocation) / 1000.0 // Convert to kilometers
        }
        
        return totalDistance
    }
    
    private func formatDuration(from startDate: Date, to endDate: Date) -> String {
        let duration = endDate.timeIntervalSince(startDate)
        let days = Int(duration) / (24 * 3600)
        let hours = Int(duration) % (24 * 3600) / 3600
        
        if days > 0 {
            return "\(days)d \(hours)h"
        } else {
            return "\(hours)h"
        }
    }
}

// MARK: - Trip Status Badge

struct TripStatusBadge: View {
    let status: TripStatus
    
    var body: some View {
        Text(status.displayName)
            .font(.caption)
            .fontWeight(.semibold)
            .foregroundColor(status.textColor)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                Capsule()
                    .fill(status.backgroundColor)
            )
    }
}

// MARK: - Trip Status Extensions

extension TripStatus {
    var displayName: String {
        switch self {
        case .planning: return "Planning"
        case .active: return "Active"
        case .paused: return "Paused"
        case .completed: return "Completed"
        case .cancelled: return "Cancelled"
        }
    }
    
    var backgroundColor: Color {
        switch self {
        case .planning: return .orange.opacity(0.2)
        case .active: return .green.opacity(0.2)
        case .paused: return .yellow.opacity(0.2)
        case .completed: return .blue.opacity(0.2)
        case .cancelled: return .red.opacity(0.2)
        }
    }
    
    var textColor: Color {
        switch self {
        case .planning: return .orange
        case .active: return .green
        case .paused: return .yellow
        case .completed: return .blue
        case .cancelled: return .red
        }
    }
}

#Preview {
    let sampleTrip = Trip(
        name: "Weekend Getaway",
        code: "ABC123",
        createdBy: UUID(),
        participants: [
            Participant(userId: UUID(), user: User(username: "John", email: "john@example.com", city: "Sydney", dateOfBirth: Date())),
            Participant(userId: UUID(), user: User(username: "Jane", email: "jane@example.com", city: "Melbourne", dateOfBirth: Date()))
        ],
        destinations: [
            Destination(name: "Sydney", address: "Sydney, NSW", coordinate: CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)),
            Destination(name: "Blue Mountains", address: "Blue Mountains, NSW", coordinate: CLLocationCoordinate2D(latitude: -33.7, longitude: 150.3)),
            Destination(name: "Newcastle", address: "Newcastle, NSW", coordinate: CLLocationCoordinate2D(latitude: -32.9283, longitude: 151.7817))
        ],
        status: .completed
    )
    
    return TripHistoryCard(trip: sampleTrip)
        .padding()
        .background(LiquidGlassBackground())
}