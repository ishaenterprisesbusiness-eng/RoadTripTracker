import SwiftUI
import UIKit
import CoreHaptics
import Combine

// MARK: - Glassmorphic Design System
// Advanced liquid glass design system with dynamic blur, fluid animations, and adaptive interfaces

// MARK: - Design System Configuration
struct GlasmorphicConfig {
    static let cornerRadius: CGFloat = 20
    static let borderWidth: CGFloat = 1
    static let shadowRadius: CGFloat = 20
    static let animationDuration: Double = 0.3
    static let springResponse: Double = 0.4
    static let springDamping: Double = 0.8
}

// MARK: - Advanced Material System
struct AdvancedMaterialSystem {
    enum MaterialType {
        case ultraThin, thin, regular, thick, ultraThick
        
        var blurRadius: CGFloat {
            switch self {
            case .ultraThin: return 10
            case .thin: return 15
            case .regular: return 20
            case .thick: return 25
            case .ultraThick: return 30
            }
        }
        
        var opacity: Double {
            switch self {
            case .ultraThin: return 0.6
            case .thin: return 0.7
            case .regular: return 0.8
            case .thick: return 0.85
            case .ultraThick: return 0.9
            }
        }
    }
    
    enum LightingCondition {
        case bright, normal, dark, veryDark
        
        var adaptiveOpacity: Double {
            switch self {
            case .bright: return 0.6
            case .normal: return 0.8
            case .dark: return 0.9
            case .veryDark: return 0.95
            }
        }
        
        var borderOpacity: Double {
            switch self {
            case .bright: return 0.4
            case .normal: return 0.3
            case .dark: return 0.2
            case .veryDark: return 0.1
            }
        }
    }
}

// MARK: - Fluid Animation System
struct FluidAnimationSystem {
    static let glassSpring = Animation.spring(
        response: GlasmorphicConfig.springResponse,
        dampingFraction: GlasmorphicConfig.springDamping
    )
    
    static let quickSpring = Animation.spring(
        response: 0.3,
        dampingFraction: 0.6
    )
    
    static let smoothSpring = Animation.spring(
        response: 0.6,
        dampingFraction: 0.8
    )
    
    static let elasticSpring = Animation.spring(
        response: 0.5,
        dampingFraction: 0.7
    )
    
    // Custom timing curves
    static let glassEaseIn = Animation.timingCurve(0.25, 0.1, 0.25, 1.0, duration: 0.4)
    static let glassEaseOut = Animation.timingCurve(0.0, 0.0, 0.58, 1.0, duration: 0.4)
    static let glassEaseInOut = Animation.timingCurve(0.42, 0.0, 0.58, 1.0, duration: 0.4)
}

// MARK: - Advanced Haptic System
class AdvancedHapticSystem: ObservableObject {
    private var hapticEngine: CHHapticEngine?
    private var cancellables = Set<AnyCancellable>()
    
    enum HapticType {
        case glassTouch, glassPress, glassSlide, glassShatter, glassChime
    }
    
    init() {
        setupHapticEngine()
    }
    
    private func setupHapticEngine() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        
        do {
            hapticEngine = try CHHapticEngine()
            try hapticEngine?.start()
            
            // Handle engine reset
            hapticEngine?.resetHandler = { [weak self] in
                try? self?.hapticEngine?.start()
            }
        } catch {
            print("Haptic engine setup failed: \(error)")
        }
    }
    
    func playHaptic(_ type: HapticType) {
        guard let hapticEngine = hapticEngine else { return }
        
        let events = createHapticEvents(for: type)
        
        do {
            let pattern = try CHHapticPattern(events: events, parameters: [])
            let player = try hapticEngine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic playback failed: \(error)")
        }
    }
    
    private func createHapticEvents(for type: HapticType) -> [CHHapticEvent] {
        switch type {
        case .glassTouch:
            return [
                CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.3),
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.4)
                    ],
                    relativeTime: 0
                )
            ]
            
        case .glassPress:
            return [
                CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.8),
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.9)
                    ],
                    relativeTime: 0
                ),
                CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.3),
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.5)
                    ],
                    relativeTime: 0.05
                )
            ]
            
        case .glassSlide:
            return [
                CHHapticEvent(
                    eventType: .hapticContinuous,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.1),
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.3)
                    ],
                    relativeTime: 0,
                    duration: 0.3
                )
            ]
            
        case .glassShatter:
            return [
                CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0),
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 1.0)
                    ],
                    relativeTime: 0
                ),
                CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.8),
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.7)
                    ],
                    relativeTime: 0.1
                ),
                CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.5),
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.4)
                    ],
                    relativeTime: 0.2
                )
            ]
            
        case .glassChime:
            return [
                CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.2),
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.6)
                    ],
                    relativeTime: 0
                ),
                CHHapticEvent(
                    eventType: .hapticContinuous,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.1),
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.3)
                    ],
                    relativeTime: 0.1,
                    duration: 0.5
                )
            ]
        }
    }
}

// MARK: - Adaptive Lighting System
class AdaptiveLightingSystem: ObservableObject {
    @Published var currentCondition: AdvancedMaterialSystem.LightingCondition = .normal
    @Published var adaptiveOpacity: Double = 0.8
    @Published var adaptiveBlur: CGFloat = 20
    @Published var adaptiveBorder: Double = 0.3
    
    private var timer: Timer?
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        updateLightingCondition()
        startLightingMonitoring()
    }
    
    deinit {
        timer?.invalidate()
    }
    
    private func updateLightingCondition() {
        let hour = Calendar.current.component(.hour, from: Date())
        let newCondition: AdvancedMaterialSystem.LightingCondition
        
        switch hour {
        case 6...8, 18...20:
            newCondition = .normal
        case 9...17:
            newCondition = .bright
        case 21...23, 0...5:
            newCondition = .dark
        default:
            newCondition = .veryDark
        }
        
        if newCondition != currentCondition {
            withAnimation(.easeInOut(duration: 2.0)) {
                currentCondition = newCondition
                adaptiveOpacity = newCondition.adaptiveOpacity
                adaptiveBorder = newCondition.borderOpacity
                adaptiveBlur = CGFloat(15 + (newCondition.adaptiveOpacity * 15))
            }
        }
    }
    
    private func startLightingMonitoring() {
        timer = Timer.scheduledTimer(withTimeInterval: 300, repeats: true) { [weak self] _ in
            self?.updateLightingCondition()
        }
    }
    
    func forceUpdate(to condition: AdvancedMaterialSystem.LightingCondition) {
        withAnimation(.easeInOut(duration: 1.0)) {
            currentCondition = condition
            adaptiveOpacity = condition.adaptiveOpacity
            adaptiveBorder = condition.borderOpacity
            adaptiveBlur = CGFloat(15 + (condition.adaptiveOpacity * 15))
        }
    }
}

// MARK: - Ultra-Advanced Glass Material
struct UltraGlassMaterial: View {
    let cornerRadius: CGFloat
    let materialType: AdvancedMaterialSystem.MaterialType
    let borderWidth: CGFloat
    let shadowRadius: CGFloat
    
    @StateObject private var lightingSystem = AdaptiveLightingSystem()
    @State private var shimmerPhase: Double = 0
    @State private var pulsePhase: Double = 0
    @State private var refractionOffset: CGSize = .zero
    
    init(
        cornerRadius: CGFloat = GlasmorphicConfig.cornerRadius,
        materialType: AdvancedMaterialSystem.MaterialType = .regular,
        borderWidth: CGFloat = GlasmorphicConfig.borderWidth,
        shadowRadius: CGFloat = GlasmorphicConfig.shadowRadius
    ) {
        self.cornerRadius = cornerRadius
        self.materialType = materialType
        self.borderWidth = borderWidth
        self.shadowRadius = shadowRadius
    }
    
    var body: some View {
        RoundedRectangle(cornerRadius: cornerRadius)
            .fill(.ultraThinMaterial)
            .overlay(
                ZStack {
                    // Base glass layer
                    RoundedRectangle(cornerRadius: cornerRadius)
                        .fill(
                            .regularMaterial.opacity(
                                materialType.opacity * lightingSystem.adaptiveOpacity
                            )
                        )
                    
                    // Multi-layer depth effect
                    ForEach(0..<3, id: \.self) { layer in
                        RoundedRectangle(cornerRadius: cornerRadius)
                            .fill(
                                RadialGradient(
                                    colors: [
                                        .white.opacity(0.1 / Double(layer + 1)),
                                        .clear
                                    ],
                                    center: .topLeading,
                                    startRadius: 0,
                                    endRadius: 100 + CGFloat(layer * 50)
                                )
                            )
                            .offset(refractionOffset)
                            .opacity(0.8 - Double(layer) * 0.2)
                    }
                    
                    // Animated shimmer effect
                    RoundedRectangle(cornerRadius: cornerRadius)
                        .fill(
                            LinearGradient(
                                colors: [
                                    .clear,
                                    .white.opacity(0.15),
                                    .clear,
                                    .white.opacity(0.1),
                                    .clear
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .rotationEffect(.degrees(shimmerPhase * 360))
                        .opacity(0.6)
                    
                    // Pulse glow
                    RoundedRectangle(cornerRadius: cornerRadius)
                        .fill(
                            RadialGradient(
                                colors: [
                                    .blue.opacity(0.1),
                                    .purple.opacity(0.05),
                                    .clear
                                ],
                                center: .center,
                                startRadius: 0,
                                endRadius: 200
                            )
                        )
                        .scaleEffect(1.0 + pulsePhase * 0.1)
                        .opacity(0.5 + pulsePhase * 0.3)
                    
                    // Adaptive border
                    RoundedRectangle(cornerRadius: cornerRadius)
                        .stroke(
                            LinearGradient(
                                colors: [
                                    .white.opacity(lightingSystem.adaptiveBorder),
                                    .white.opacity(lightingSystem.adaptiveBorder * 0.7),
                                    .blue.opacity(lightingSystem.adaptiveBorder * 0.3),
                                    .clear
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: borderWidth
                        )
                }
            )
            .shadow(
                color: .black.opacity(0.1),
                radius: shadowRadius,
                x: 0,
                y: shadowRadius * 0.5
            )
            .onAppear {
                startAnimations()
            }
    }
    
    private func startAnimations() {
        // Shimmer animation
        withAnimation(.linear(duration: 8).repeatForever(autoreverses: false)) {
            shimmerPhase = 1
        }
        
        // Pulse animation
        withAnimation(.easeInOut(duration: 3).repeatForever(autoreverses: true)) {
            pulsePhase = 1
        }
        
        // Refraction animation
        withAnimation(.easeInOut(duration: 4).repeatForever(autoreverses: true)) {
            refractionOffset = CGSize(width: 2, height: 1)
        }
    }
}

// MARK: - Fluid Glass Button
struct FluidGlassButton: View {
    let title: String
    let icon: String?
    let action: () -> Void
    let style: ButtonStyle
    
    @StateObject private var hapticSystem = AdvancedHapticSystem()
    @State private var isPressed = false
    @State private var pressScale: CGFloat = 1.0
    @State private var glowIntensity: Double = 0
    @State private var ripplePhase: Double = 0
    
    enum ButtonStyle {
        case primary, secondary, destructive, ghost, success
        
        var colors: [Color] {
            switch self {
            case .primary:
                return [.blue.opacity(0.8), .purple.opacity(0.6)]
            case .secondary:
                return [.gray.opacity(0.4), .gray.opacity(0.2)]
            case .destructive:
                return [.red.opacity(0.8), .orange.opacity(0.6)]
            case .ghost:
                return [.clear, .clear]
            case .success:
                return [.green.opacity(0.8), .mint.opacity(0.6)]
            }
        }
        
        var textColor: Color {
            switch self {
            case .primary, .destructive, .success:
                return .white
            case .secondary, .ghost:
                return .primary
            }
        }
        
        var glowColor: Color {
            switch self {
            case .primary:
                return .blue
            case .secondary:
                return .gray
            case .destructive:
                return .red
            case .ghost:
                return .blue
            case .success:
                return .green
            }
        }
    }
    
    init(
        title: String,
        icon: String? = nil,
        style: ButtonStyle = .primary,
        action: @escaping () -> Void
    ) {
        self.title = title
        self.icon = icon
        self.style = style
        self.action = action
    }
    
    var body: some View {
        Button(action: {
            hapticSystem.playHaptic(.glassPress)
            triggerRipple()
            action()
        }) {
            HStack(spacing: 12) {
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.system(size: 18, weight: .semibold))
                        .scaleEffect(isPressed ? 0.9 : 1.0)
                }
                
                Text(title)
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .foregroundColor(style.textColor)
            .background(
                ZStack {
                    // Base glass material
                    UltraGlassMaterial(
                        cornerRadius: 16,
                        materialType: .regular,
                        borderWidth: 1.5,
                        shadowRadius: 25
                    )
                    
                    // Color overlay
                    if style != .ghost {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(
                                LinearGradient(
                                    colors: style.colors,
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    }
                    
                    // Glow effect
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(
                            style.glowColor.opacity(glowIntensity),
                            lineWidth: 3
                        )
                        .blur(radius: 5)
                    
                    // Ripple effect
                    if ripplePhase > 0 {
                        Circle()
                            .stroke(
                                style.glowColor.opacity(1 - ripplePhase),
                                lineWidth: 2
                            )
                            .scaleEffect(ripplePhase * 2)
                            .opacity(1 - ripplePhase)
                    }
                }
            )
            .scaleEffect(pressScale)
            .animation(FluidAnimationSystem.elasticSpring, value: pressScale)
            .animation(FluidAnimationSystem.glassEaseOut, value: glowIntensity)
        }
        .pressEvents {
            withAnimation(FluidAnimationSystem.quickSpring) {
                isPressed = true
                pressScale = 0.95
                glowIntensity = 0.8
            }
            hapticSystem.playHaptic(.glassTouch)
        } onRelease: {
            withAnimation(FluidAnimationSystem.elasticSpring) {
                isPressed = false
                pressScale = 1.0
                glowIntensity = 0
            }
        }
    }
    
    private func triggerRipple() {
        ripplePhase = 0
        withAnimation(.easeOut(duration: 0.6)) {
            ripplePhase = 1
        }
    }
}

// MARK: - Advanced Glass Modal
struct AdvancedGlassModal<Content: View>: View {
    @Binding var isPresented: Bool
    let content: Content
    let dismissOnTapOutside: Bool
    
    @StateObject private var hapticSystem = AdvancedHapticSystem()
    @State private var backgroundOpacity: Double = 0
    @State private var contentScale: CGFloat = 0.8
    @State private var contentOpacity: Double = 0
    @State private var blurRadius: CGFloat = 20
    @State private var particleOpacity: Double = 0
    
    init(
        isPresented: Binding<Bool>,
        dismissOnTapOutside: Bool = true,
        @ViewBuilder content: () -> Content
    ) {
        self._isPresented = isPresented
        self.dismissOnTapOutside = dismissOnTapOutside
        self.content = content()
    }
    
    var body: some View {
        ZStack {
            if isPresented {
                // Multi-layer background
                ZStack {
                    // Base blur
                    Color.black
                        .opacity(backgroundOpacity * 0.4)
                        .ignoresSafeArea()
                    
                    // Frosted glass layer
                    Rectangle()
                        .fill(.ultraThinMaterial)
                        .ignoresSafeArea()
                        .opacity(backgroundOpacity * 0.9)
                    
                    // Animated particles
                    ForEach(0..<30, id: \.self) { index in
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [
                                        .white.opacity(0.2),
                                        .blue.opacity(0.1),
                                        .clear
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: CGFloat.random(in: 2...12))
                            .position(
                                x: CGFloat.random(in: 0...UIScreen.main.bounds.width),
                                y: CGFloat.random(in: 0...UIScreen.main.bounds.height)
                            )
                            .opacity(particleOpacity)
                            .animation(
                                .easeInOut(duration: Double.random(in: 3...8))
                                .repeatForever(autoreverses: true)
                                .delay(Double(index) * 0.1),
                                value: particleOpacity
                            )
                    }
                }
                .onTapGesture {
                    if dismissOnTapOutside {
                        dismissModal()
                    }
                }
                
                // Modal content
                VStack {
                    Spacer()
                    
                    content
                        .padding(28)
                        .background(
                            ZStack {
                                // Ultra glass material
                                UltraGlassMaterial(
                                    cornerRadius: 32,
                                    materialType: .thick,
                                    borderWidth: 2,
                                    shadowRadius: 50
                                )
                                
                                // Inner highlight
                                RoundedRectangle(cornerRadius: 32)
                                    .fill(
                                        RadialGradient(
                                            colors: [
                                                .white.opacity(0.2),
                                                .blue.opacity(0.1),
                                                .clear
                                            ],
                                            center: .topLeading,
                                            startRadius: 0,
                                            endRadius: 250
                                        )
                                    )
                                
                                // Animated border glow
                                RoundedRectangle(cornerRadius: 32)
                                    .stroke(
                                        LinearGradient(
                                            colors: [
                                                .blue.opacity(0.4),
                                                .purple.opacity(0.3),
                                                .pink.opacity(0.2),
                                                .clear
                                            ],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        ),
                                        lineWidth: 3
                                    )
                                    .opacity(contentOpacity)
                            }
                        )
                        .scaleEffect(contentScale)
                        .opacity(contentOpacity)
                        .blur(radius: blurRadius)
                        .padding(.horizontal, 24)
                    
                    Spacer()
                }
            }
        }
        .onChange(of: isPresented) { newValue in
            if newValue {
                presentModal()
            }
        }
    }
    
    private func presentModal() {
        hapticSystem.playHaptic(.glassChime)
        
        withAnimation(FluidAnimationSystem.smoothSpring) {
            backgroundOpacity = 1
            particleOpacity = 1
        }
        
        withAnimation(FluidAnimationSystem.elasticSpring.delay(0.1)) {
            contentScale = 1
            contentOpacity = 1
            blurRadius = 0
        }
    }
    
    private func dismissModal() {
        hapticSystem.playHaptic(.glassSlide)
        
        withAnimation(FluidAnimationSystem.quickSpring) {
            contentScale = 0.9
            contentOpacity = 0
            blurRadius = 15
        }
        
        withAnimation(FluidAnimationSystem.glassEaseIn.delay(0.1)) {
            backgroundOpacity = 0
            particleOpacity = 0
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            isPresented = false
        }
    }
}

// MARK: - Dynamic Glass TextField
struct DynamicGlassTextField: View {
    let title: String
    @Binding var text: String
    let icon: String
    let isSecure: Bool
    
    @StateObject private var hapticSystem = AdvancedHapticSystem()
    @FocusState private var isFocused: Bool
    @State private var animationPhase: Double = 0
    @State private var borderGlow: Double = 0
    @State private var iconRotation: Double = 0
    @State private var showSecureText = false
    
    init(
        title: String,
        text: Binding<String>,
        icon: String,
        isSecure: Bool = false
    ) {
        self.title = title
        self._text = text
        self.icon = icon
        self.isSecure = isSecure
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Floating label with animation
            Text(title)
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(isFocused ? .blue : .secondary)
                .opacity(isFocused || !text.isEmpty ? 1 : 0.7)
                .scaleEffect(isFocused ? 1.05 : 1.0)
                .animation(FluidAnimationSystem.glassSpring, value: isFocused)
            
            HStack(spacing: 16) {
                // Animated icon
                Image(systemName: icon)
                    .foregroundColor(isFocused ? .blue : .secondary)
                    .font(.system(size: 18, weight: .medium))
                    .frame(width: 24)
                    .scaleEffect(isFocused ? 1.1 : 1.0)
                    .rotationEffect(.degrees(iconRotation))
                    .animation(FluidAnimationSystem.elasticSpring, value: isFocused)
                
                // Text field
                Group {
                    if isSecure && !showSecureText {
                        SecureField("", text: $text)
                            .focused($isFocused)
                    } else {
                        TextField("", text: $text)
                            .focused($isFocused)
                    }
                }
                .textFieldStyle(.plain)
                .font(.body)
                
                // Secure field toggle
                if isSecure {
                    Button(action: {
                        showSecureText.toggle()
                        hapticSystem.playHaptic(.glassTouch)
                    }) {
                        Image(systemName: showSecureText ? "eye.slash" : "eye")
                            .foregroundColor(.secondary)
                            .font(.system(size: 16))
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)
            .background(
                ZStack {
                    // Base glass material
                    UltraGlassMaterial(
                        cornerRadius: 16,
                        materialType: isFocused ? .thick : .regular,
                        borderWidth: isFocused ? 2 : 1,
                        shadowRadius: isFocused ? 30 : 20
                    )
                    
                    // Focus glow effect
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(
                            LinearGradient(
                                colors: [
                                    .blue.opacity(borderGlow),
                                    .purple.opacity(borderGlow * 0.8),
                                    .pink.opacity(borderGlow * 0.6),
                                    .clear
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 3
                        )
                        .blur(radius: 2)
                        .opacity(isFocused ? 1 : 0)
                    
                    // Animated highlight
                    if isFocused {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(
                                LinearGradient(
                                    colors: [
                                        .blue.opacity(0.1),
                                        .clear,
                                        .purple.opacity(0.1)
                                    ],
                                    startPoint: UnitPoint(x: animationPhase, y: 0),
                                    endPoint: UnitPoint(x: animationPhase + 0.3, y: 1)
                                )
                            )
                            .opacity(0.6)
                    }
                }
            )
        }
        .onAppear {
            startAnimations()
        }
        .onChange(of: isFocused) { focused in
            if focused {
                hapticSystem.playHaptic(.glassTouch)
            }
            
            withAnimation(FluidAnimationSystem.glassEaseOut) {
                borderGlow = focused ? 0.8 : 0
                iconRotation = focused ? 5 : 0
            }
        }
    }
    
    private func startAnimations() {
        withAnimation(.linear(duration: 3).repeatForever(autoreverses: false)) {
            animationPhase = 1
        }
    }
}

// MARK: - Adaptive Glass Card
struct AdaptiveGlassCard<Content: View>: View {
    let content: Content
    let cornerRadius: CGFloat
    let padding: CGFloat
    let interactive: Bool
    
    @StateObject private var lightingSystem = AdaptiveLightingSystem()
    @StateObject private var hapticSystem = AdvancedHapticSystem()
    @State private var hoverScale: CGFloat = 1.0
    @State private var shadowIntensity: Double = 0.1
    @State private var glowIntensity: Double = 0
    @State private var isPressed = false
    
    init(
        cornerRadius: CGFloat = 24,
        padding: CGFloat = 24,
        interactive: Bool = false,
        @ViewBuilder content: () -> Content
    ) {
        self.cornerRadius = cornerRadius
        self.padding = padding
        self.interactive = interactive
        self.content = content()
    }
    
    var body: some View {
        content
            .padding(padding)
            .background(
                ZStack {
                    // Ultra glass material
                    UltraGlassMaterial(
                        cornerRadius: cornerRadius,
                        materialType: .regular,
                        borderWidth: 1.5,
                        shadowRadius: 30
                    )
                    
                    // Adaptive inner glow
                    RoundedRectangle(cornerRadius: cornerRadius)
                        .fill(
                            RadialGradient(
                                colors: [
                                    .white.opacity(lightingSystem.adaptiveOpacity * 0.15),
                                    .blue.opacity(lightingSystem.adaptiveOpacity * 0.05),
                                    .clear
                                ],
                                center: .center,
                                startRadius: 0,
                                endRadius: 200
                            )
                        )
                    
                    // Interactive glow
                    if interactive {
                        RoundedRectangle(cornerRadius: cornerRadius)
                            .stroke(
                                LinearGradient(
                                    colors: [
                                        .blue.opacity(glowIntensity),
                                        .purple.opacity(glowIntensity * 0.8),
                                        .clear
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ),
                                lineWidth: 2
                            )
                            .blur(radius: 3)
                    }
                }
            )
            .scaleEffect(hoverScale)
            .shadow(
                color: .black.opacity(shadowIntensity),
                radius: 25,
                x: 0,
                y: 12
            )
            .animation(FluidAnimationSystem.elasticSpring, value: hoverScale)
            .animation(FluidAnimationSystem.glassEaseOut, value: shadowIntensity)
            .animation(FluidAnimationSystem.glassEaseOut, value: glowIntensity)
            .onTapGesture {
                if interactive {
                    hapticSystem.playHaptic(.glassPress)
                    triggerInteraction()
                }
            }
            .pressEvents {
                if interactive {
                    withAnimation(FluidAnimationSystem.quickSpring) {
                        isPressed = true
                        hoverScale = 0.98
                        shadowIntensity = 0.05
                        glowIntensity = 0.6
                    }
                    hapticSystem.playHaptic(.glassTouch)
                }
            } onRelease: {
                if interactive {
                    withAnimation(FluidAnimationSystem.elasticSpring) {
                        isPressed = false
                        hoverScale = 1.0
                        shadowIntensity = 0.1
                        glowIntensity = 0
                    }
                }
            }
    }
    
    private func triggerInteraction() {
        withAnimation(FluidAnimationSystem.quickSpring) {
            hoverScale = 1.02
            shadowIntensity = 0.2
            glowIntensity = 0.8
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            withAnimation(FluidAnimationSystem.elasticSpring) {
                hoverScale = 1.0
                shadowIntensity = 0.1
                glowIntensity = 0
            }
        }
    }
}

// MARK: - Press Events Modifier
extension View {
    func pressEvents(onPress: @escaping () -> Void, onRelease: @escaping () -> Void) -> some View {
        self.simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    onPress()
                }
                .onEnded { _ in
                    onRelease()
                }
        )
    }
}