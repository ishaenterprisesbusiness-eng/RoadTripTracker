import SwiftUI
import UIKit
import CoreHaptics

// MARK: - Liquid Glass Background
struct LiquidGlassBackground: View {
    @State private var animateGradient = false
    
    var body: some View {
        ZStack {
            // Base gradient background
            LinearGradient(
                colors: [
                    Color.blue.opacity(0.1),
                    Color.purple.opacity(0.1),
                    Color.pink.opacity(0.05)
                ],
                startPoint: animateGradient ? .topLeading : .bottomTrailing,
                endPoint: animateGradient ? .bottomTrailing : .topLeading
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 8).repeatForever(autoreverses: true), value: animateGradient)
            
            // Floating glass orbs
            ForEach(0..<3, id: \.self) { index in
                Circle()
                    .fill(
                        RadialGradient(
                            colors: [
                                Color.white.opacity(0.1),
                                Color.clear
                            ],
                            center: .center,
                            startRadius: 0,
                            endRadius: 100
                        )
                    )
                    .frame(width: 200, height: 200)
                    .blur(radius: 1)
                    .offset(
                        x: CGFloat.random(in: -100...100),
                        y: CGFloat.random(in: -200...200)
                    )
                    .animation(
                        .easeInOut(duration: Double.random(in: 6...10))
                        .repeatForever(autoreverses: true)
                        .delay(Double(index) * 2),
                        value: animateGradient
                    )
            }
        }
        .onAppear {
            animateGradient = true
        }
    }
}

// MARK: - Liquid Glass Card
struct LiquidGlassCard<Content: View>: View {
    let content: Content
    
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        content
            .padding(24)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(
                                LinearGradient(
                                    colors: [
                                        .white.opacity(0.3),
                                        .white.opacity(0.1),
                                        .clear
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ),
                                lineWidth: 1
                            )
                    )
                    .shadow(color: .black.opacity(0.1), radius: 20, x: 0, y: 10)
            )
    }
}

// MARK: - Liquid Glass Text Field
struct LiquidGlassTextField: View {
    let title: String
    @Binding var text: String
    let icon: String
    
    @FocusState private var isFocused: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .opacity(isFocused || !text.isEmpty ? 1 : 0.7)
                .animation(.easeInOut(duration: 0.2), value: isFocused)
            
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .foregroundColor(isFocused ? .blue : .secondary)
                    .frame(width: 20)
                    .animation(.easeInOut(duration: 0.2), value: isFocused)
                
                TextField("", text: $text)
                    .focused($isFocused)
                    .textFieldStyle(.plain)
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(
                                isFocused ? .blue.opacity(0.5) : .white.opacity(0.2),
                                lineWidth: isFocused ? 2 : 1
                            )
                            .animation(.easeInOut(duration: 0.2), value: isFocused)
                    )
            )
        }
    }
}

// MARK: - Liquid Glass Secure Field
struct LiquidGlassSecureField: View {
    let title: String
    @Binding var text: String
    let icon: String
    
    @State private var isSecure = true
    @FocusState private var isFocused: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .opacity(isFocused || !text.isEmpty ? 1 : 0.7)
                .animation(.easeInOut(duration: 0.2), value: isFocused)
            
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .foregroundColor(isFocused ? .blue : .secondary)
                    .frame(width: 20)
                    .animation(.easeInOut(duration: 0.2), value: isFocused)
                
                Group {
                    if isSecure {
                        SecureField("", text: $text)
                            .focused($isFocused)
                    } else {
                        TextField("", text: $text)
                            .focused($isFocused)
                    }
                }
                .textFieldStyle(.plain)
                
                Button(action: { isSecure.toggle() }) {
                    Image(systemName: isSecure ? "eye.slash" : "eye")
                        .foregroundColor(.secondary)
                        .font(.system(size: 16))
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(
                                isFocused ? .blue.opacity(0.5) : .white.opacity(0.2),
                                lineWidth: isFocused ? 2 : 1
                            )
                            .animation(.easeInOut(duration: 0.2), value: isFocused)
                    )
            )
        }
    }
}

// MARK: - Liquid Glass Button
struct LiquidGlassButton: View {
    let title: String
    let icon: String?
    let action: () -> Void
    let style: ButtonStyle
    
    enum ButtonStyle {
        case primary
        case secondary
        case destructive
        
        var colors: [Color] {
            switch self {
            case .primary:
                return [.blue, .purple]
            case .secondary:
                return [.gray.opacity(0.3), .gray.opacity(0.1)]
            case .destructive:
                return [.red, .orange]
            }
        }
        
        var textColor: Color {
            switch self {
            case .primary, .destructive:
                return .white
            case .secondary:
                return .primary
            }
        }
    }
    
    init(title: String, icon: String? = nil, style: ButtonStyle = .primary, action: @escaping () -> Void) {
        self.title = title
        self.icon = icon
        self.style = style
        self.action = action
    }
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .semibold))
                }
                
                Text(title)
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .foregroundColor(style.textColor)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(
                        LinearGradient(
                            colors: style.colors,
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(.white.opacity(0.2), lineWidth: 1)
                    )
                    .shadow(
                        color: style.colors.first?.opacity(0.3) ?? .clear,
                        radius: 10,
                        x: 0,
                        y: 5
                    )
            )
        }
        .scaleEffect(1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.6), value: false)
    }
}

// MARK: - Liquid Glass Modal
struct LiquidGlassModal<Content: View>: View {
    @Binding var isPresented: Bool
    let content: Content
    
    init(isPresented: Binding<Bool>, @ViewBuilder content: () -> Content) {
        self._isPresented = isPresented
        self.content = content()
    }
    
    var body: some View {
        ZStack {
            if isPresented {
                // Background overlay
                Color.black.opacity(0.3)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                            isPresented = false
                        }
                    }
                
                // Modal content
                VStack {
                    Spacer()
                    
                    content
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 24)
                                .fill(.regularMaterial)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 24)
                                        .stroke(.white.opacity(0.2), lineWidth: 1)
                                )
                                .shadow(color: .black.opacity(0.2), radius: 30, x: 0, y: 15)
                        )
                        .padding(.horizontal, 20)
                    
                    Spacer()
                }
                .transition(.asymmetric(
                    insertion: .scale.combined(with: .opacity),
                    removal: .scale.combined(with: .opacity)
                ))
            }
        }
        .animation(.spring(response: 0.6, dampingFraction: 0.8), value: isPresented)
    }
}

// MARK: - Liquid Glass Navigation Bar
struct LiquidGlassNavigationBar: View {
    let title: String
    let leadingAction: (() -> Void)?
    let trailingAction: (() -> Void)?
    let leadingIcon: String?
    let trailingIcon: String?
    
    init(
        title: String,
        leadingAction: (() -> Void)? = nil,
        trailingAction: (() -> Void)? = nil,
        leadingIcon: String? = nil,
        trailingIcon: String? = nil
    ) {
        self.title = title
        self.leadingAction = leadingAction
        self.trailingAction = trailingAction
        self.leadingIcon = leadingIcon
        self.trailingIcon = trailingIcon
    }
    
    var body: some View {
        HStack {
            // Leading button
            if let leadingAction = leadingAction, let leadingIcon = leadingIcon {
                Button(action: leadingAction) {
                    Image(systemName: leadingIcon)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.primary)
                        .frame(width: 44, height: 44)
                        .background(
                            Circle()
                                .fill(.ultraThinMaterial)
                                .overlay(
                                    Circle()
                                        .stroke(.white.opacity(0.2), lineWidth: 1)
                                )
                        )
                }
            } else {
                Spacer()
                    .frame(width: 44)
            }
            
            Spacer()
            
            // Title
            Text(title)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Spacer()
            
            // Trailing button
            if let trailingAction = trailingAction, let trailingIcon = trailingIcon {
                Button(action: trailingAction) {
                    Image(systemName: trailingIcon)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.primary)
                        .frame(width: 44, height: 44)
                        .background(
                            Circle()
                                .fill(.ultraThinMaterial)
                                .overlay(
                                    Circle()
                                        .stroke(.white.opacity(0.2), lineWidth: 1)
                                )
                        )
                }
            } else {
                Spacer()
                    .frame(width: 44)
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(
            Rectangle()
                .fill(.regularMaterial)
                .overlay(
                    Rectangle()
                        .fill(
                            LinearGradient(
                                colors: [.white.opacity(0.1), .clear],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                )
        )
    }
}
// M
ARK: - Advanced Glassmorphic Design System

// MARK: - Haptic Feedback Manager
class HapticFeedbackManager: ObservableObject {
    private var hapticEngine: CHHapticEngine?
    
    init() {
        setupHapticEngine()
    }
    
    private func setupHapticEngine() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        
        do {
            hapticEngine = try CHHapticEngine()
            try hapticEngine?.start()
        } catch {
            print("Haptic engine failed to start: \(error)")
        }
    }
    
    func playGlassInteraction() {
        guard let hapticEngine = hapticEngine else { return }
        
        let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.3)
        let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.6)
        
        let event = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [sharpness, intensity],
            relativeTime: 0
        )
        
        do {
            let pattern = try CHHapticPattern(events: [event], parameters: [])
            let player = try hapticEngine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic feedback failed: \(error)")
        }
    }
    
    func playGlassPress() {
        guard let hapticEngine = hapticEngine else { return }
        
        let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.8)
        let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.9)
        
        let event = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [sharpness, intensity],
            relativeTime: 0
        )
        
        do {
            let pattern = try CHHapticPattern(events: [event], parameters: [])
            let player = try hapticEngine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic feedback failed: \(error)")
        }
    }
    
    func playGlassSlide() {
        guard let hapticEngine = hapticEngine else { return }
        
        let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.1)
        let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.4)
        
        let event = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [sharpness, intensity],
            relativeTime: 0,
            duration: 0.2
        )
        
        do {
            let pattern = try CHHapticPattern(events: [event], parameters: [])
            let player = try hapticEngine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Haptic feedback failed: \(error)")
        }
    }
}

// MARK: - Adaptive Lighting Manager
class AdaptiveLightingManager: ObservableObject {
    @Published var currentLightingCondition: LightingCondition = .normal
    @Published var adaptiveOpacity: Double = 0.8
    @Published var adaptiveBlurRadius: Double = 20
    
    enum LightingCondition {
        case bright, normal, dark, veryDark
        
        var glassOpacity: Double {
            switch self {
            case .bright: return 0.6
            case .normal: return 0.8
            case .dark: return 0.9
            case .veryDark: return 0.95
            }
        }
        
        var blurIntensity: Double {
            switch self {
            case .bright: return 15
            case .normal: return 20
            case .dark: return 25
            case .veryDark: return 30
            }
        }
        
        var borderOpacity: Double {
            switch self {
            case .bright: return 0.4
            case .normal: return 0.3
            case .dark: return 0.2
            case .veryDark: return 0.1
            }
        }
    }
    
    init() {
        updateLightingCondition()
        startLightingMonitoring()
    }
    
    private func updateLightingCondition() {
        // Simulate lighting detection based on time of day
        let hour = Calendar.current.component(.hour, from: Date())
        
        switch hour {
        case 6...8, 18...20:
            currentLightingCondition = .normal
        case 9...17:
            currentLightingCondition = .bright
        case 21...23, 0...5:
            currentLightingCondition = .dark
        default:
            currentLightingCondition = .veryDark
        }
        
        adaptiveOpacity = currentLightingCondition.glassOpacity
        adaptiveBlurRadius = currentLightingCondition.blurIntensity
    }
    
    private func startLightingMonitoring() {
        Timer.scheduledTimer(withTimeInterval: 300, repeats: true) { _ in
            self.updateLightingCondition()
        }
    }
}

// MARK: - Advanced Glass Material
struct AdvancedGlassMaterial: View {
    @StateObject private var lightingManager = AdaptiveLightingManager()
    @State private var animationPhase: Double = 0
    
    let cornerRadius: CGFloat
    let borderWidth: CGFloat
    let shadowRadius: CGFloat
    
    init(
        cornerRadius: CGFloat = 20,
        borderWidth: CGFloat = 1,
        shadowRadius: CGFloat = 20
    ) {
        self.cornerRadius = cornerRadius
        self.borderWidth = borderWidth
        self.shadowRadius = shadowRadius
    }
    
    var body: some View {
        RoundedRectangle(cornerRadius: cornerRadius)
            .fill(.ultraThinMaterial)
            .overlay(
                // Multi-layer glass effect
                ZStack {
                    // Inner glow
                    RoundedRectangle(cornerRadius: cornerRadius)
                        .fill(
                            RadialGradient(
                                colors: [
                                    .white.opacity(0.1),
                                    .clear
                                ],
                                center: .topLeading,
                                startRadius: 0,
                                endRadius: 100
                            )
                        )
                        .opacity(lightingManager.adaptiveOpacity * 0.5)
                    
                    // Animated shimmer
                    RoundedRectangle(cornerRadius: cornerRadius)
                        .fill(
                            LinearGradient(
                                colors: [
                                    .clear,
                                    .white.opacity(0.1),
                                    .clear
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .rotationEffect(.degrees(animationPhase * 360))
                        .opacity(0.3)
                    
                    // Border gradient
                    RoundedRectangle(cornerRadius: cornerRadius)
                        .stroke(
                            LinearGradient(
                                colors: [
                                    .white.opacity(lightingManager.currentLightingCondition.borderOpacity),
                                    .white.opacity(lightingManager.currentLightingCondition.borderOpacity * 0.5),
                                    .clear
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: borderWidth
                        )
                }
            )
            .shadow(
                color: .black.opacity(0.1),
                radius: shadowRadius,
                x: 0,
                y: shadowRadius * 0.5
            )
            .onAppear {
                withAnimation(.linear(duration: 8).repeatForever(autoreverses: false)) {
                    animationPhase = 1
                }
            }
    }
}

// MARK: - Fluid Animation Button
struct FluidGlassButton: View {
    let title: String
    let icon: String?
    let action: () -> Void
    let style: ButtonStyle
    
    @StateObject private var hapticManager = HapticFeedbackManager()
    @State private var isPressed = false
    @State private var animationOffset: CGFloat = 0
    @State private var pulseScale: CGFloat = 1.0
    
    enum ButtonStyle {
        case primary, secondary, destructive, ghost
        
        var colors: [Color] {
            switch self {
            case .primary:
                return [.blue.opacity(0.8), .purple.opacity(0.6)]
            case .secondary:
                return [.gray.opacity(0.3), .gray.opacity(0.1)]
            case .destructive:
                return [.red.opacity(0.8), .orange.opacity(0.6)]
            case .ghost:
                return [.clear, .clear]
            }
        }
        
        var textColor: Color {
            switch self {
            case .primary, .destructive:
                return .white
            case .secondary, .ghost:
                return .primary
            }
        }
    }
    
    init(title: String, icon: String? = nil, style: ButtonStyle = .primary, action: @escaping () -> Void) {
        self.title = title
        self.icon = icon
        self.style = style
        self.action = action
    }
    
    var body: some View {
        Button(action: {
            hapticManager.playGlassPress()
            action()
        }) {
            HStack(spacing: 12) {
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.system(size: 18, weight: .semibold))
                        .scaleEffect(isPressed ? 0.9 : 1.0)
                }
                
                Text(title)
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .foregroundColor(style.textColor)
            .background(
                ZStack {
                    // Base glass material
                    AdvancedGlassMaterial(cornerRadius: 16)
                    
                    // Gradient overlay for colored buttons
                    if style != .ghost {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(
                                LinearGradient(
                                    colors: style.colors,
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                    }
                    
                    // Animated highlight
                    RoundedRectangle(cornerRadius: 16)
                        .fill(
                            LinearGradient(
                                colors: [
                                    .white.opacity(0.2),
                                    .clear,
                                    .white.opacity(0.1)
                                ],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .offset(x: animationOffset)
                        .opacity(isPressed ? 0.8 : 0.3)
                }
            )
            .scaleEffect(pulseScale)
            .scaleEffect(isPressed ? 0.95 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: isPressed)
            .animation(.spring(response: 0.4, dampingFraction: 0.7), value: pulseScale)
        }
        .pressEvents {
            withAnimation(.easeInOut(duration: 0.1)) {
                isPressed = true
            }
            hapticManager.playGlassInteraction()
        } onRelease: {
            withAnimation(.easeInOut(duration: 0.1)) {
                isPressed = false
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 2).repeatForever(autoreverses: true)) {
                animationOffset = 200
            }
            
            withAnimation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true)) {
                pulseScale = 1.02
            }
        }
    }
}

// MARK: - Frosted Glass Modal
struct FrostedGlassModal<Content: View>: View {
    @Binding var isPresented: Bool
    let content: Content
    
    @StateObject private var hapticManager = HapticFeedbackManager()
    @State private var backgroundOpacity: Double = 0
    @State private var contentScale: CGFloat = 0.8
    @State private var contentOpacity: Double = 0
    @State private var blurRadius: CGFloat = 0
    
    init(isPresented: Binding<Bool>, @ViewBuilder content: () -> Content) {
        self._isPresented = isPresented
        self.content = content()
    }
    
    var body: some View {
        ZStack {
            if isPresented {
                // Multi-layer background
                ZStack {
                    // Base blur
                    Color.black
                        .opacity(backgroundOpacity * 0.3)
                        .ignoresSafeArea()
                    
                    // Frosted effect
                    Rectangle()
                        .fill(.ultraThinMaterial)
                        .ignoresSafeArea()
                        .opacity(backgroundOpacity * 0.8)
                    
                    // Animated particles
                    ForEach(0..<20, id: \.self) { index in
                        Circle()
                            .fill(.white.opacity(0.1))
                            .frame(width: CGFloat.random(in: 2...8))
                            .position(
                                x: CGFloat.random(in: 0...UIScreen.main.bounds.width),
                                y: CGFloat.random(in: 0...UIScreen.main.bounds.height)
                            )
                            .opacity(backgroundOpacity)
                            .animation(
                                .easeInOut(duration: Double.random(in: 3...6))
                                .repeatForever(autoreverses: true)
                                .delay(Double(index) * 0.1),
                                value: backgroundOpacity
                            )
                    }
                }
                .onTapGesture {
                    dismissModal()
                }
                
                // Modal content with advanced glass effect
                VStack {
                    Spacer()
                    
                    content
                        .padding(24)
                        .background(
                            ZStack {
                                // Multi-layer glass
                                AdvancedGlassMaterial(
                                    cornerRadius: 28,
                                    borderWidth: 1.5,
                                    shadowRadius: 40
                                )
                                
                                // Inner highlight
                                RoundedRectangle(cornerRadius: 28)
                                    .fill(
                                        RadialGradient(
                                            colors: [
                                                .white.opacity(0.15),
                                                .clear
                                            ],
                                            center: .topLeading,
                                            startRadius: 0,
                                            endRadius: 200
                                        )
                                    )
                                
                                // Animated border glow
                                RoundedRectangle(cornerRadius: 28)
                                    .stroke(
                                        LinearGradient(
                                            colors: [
                                                .blue.opacity(0.3),
                                                .purple.opacity(0.2),
                                                .clear
                                            ],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        ),
                                        lineWidth: 2
                                    )
                                    .opacity(contentOpacity)
                            }
                        )
                        .scaleEffect(contentScale)
                        .opacity(contentOpacity)
                        .blur(radius: blurRadius)
                        .padding(.horizontal, 20)
                    
                    Spacer()
                }
            }
        }
        .onChange(of: isPresented) { newValue in
            if newValue {
                presentModal()
            } else {
                dismissModal()
            }
        }
    }
    
    private func presentModal() {
        hapticManager.playGlassInteraction()
        
        withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
            backgroundOpacity = 1
        }
        
        withAnimation(.spring(response: 0.7, dampingFraction: 0.8).delay(0.1)) {
            contentScale = 1
            contentOpacity = 1
            blurRadius = 0
        }
    }
    
    private func dismissModal() {
        hapticManager.playGlassSlide()
        
        withAnimation(.spring(response: 0.5, dampingFraction: 0.9)) {
            contentScale = 0.9
            contentOpacity = 0
            blurRadius = 10
        }
        
        withAnimation(.spring(response: 0.4, dampingFraction: 0.8).delay(0.1)) {
            backgroundOpacity = 0
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            isPresented = false
        }
    }
}

// MARK: - Dynamic Glass TextField
struct DynamicGlassTextField: View {
    let title: String
    @Binding var text: String
    let icon: String
    
    @StateObject private var hapticManager = HapticFeedbackManager()
    @StateObject private var lightingManager = AdaptiveLightingManager()
    @FocusState private var isFocused: Bool
    @State private var animationPhase: Double = 0
    @State private var borderGlow: Double = 0
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Floating label
            Text(title)
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(isFocused ? .blue : .secondary)
                .opacity(isFocused || !text.isEmpty ? 1 : 0.7)
                .scaleEffect(isFocused ? 1.05 : 1.0)
                .animation(.spring(response: 0.4, dampingFraction: 0.8), value: isFocused)
            
            HStack(spacing: 16) {
                // Animated icon
                Image(systemName: icon)
                    .foregroundColor(isFocused ? .blue : .secondary)
                    .font(.system(size: 18, weight: .medium))
                    .frame(width: 24)
                    .scaleEffect(isFocused ? 1.1 : 1.0)
                    .rotationEffect(.degrees(isFocused ? animationPhase * 5 : 0))
                    .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isFocused)
                
                TextField("", text: $text)
                    .focused($isFocused)
                    .textFieldStyle(.plain)
                    .font(.body)
                    .onChange(of: isFocused) { focused in
                        if focused {
                            hapticManager.playGlassInteraction()
                        }
                    }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)
            .background(
                ZStack {
                    // Base glass material
                    AdvancedGlassMaterial(
                        cornerRadius: 16,
                        borderWidth: isFocused ? 2 : 1,
                        shadowRadius: isFocused ? 25 : 15
                    )
                    
                    // Focus glow effect
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(
                            LinearGradient(
                                colors: [
                                    .blue.opacity(borderGlow),
                                    .purple.opacity(borderGlow * 0.7),
                                    .clear
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 3
                        )
                        .opacity(isFocused ? 1 : 0)
                    
                    // Animated highlight
                    if isFocused {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(
                                LinearGradient(
                                    colors: [
                                        .blue.opacity(0.1),
                                        .clear,
                                        .purple.opacity(0.1)
                                    ],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .opacity(0.5)
                    }
                }
            )
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 2).repeatForever(autoreverses: true)) {
                animationPhase = 1
            }
        }
        .onChange(of: isFocused) { focused in
            withAnimation(.easeInOut(duration: 0.3)) {
                borderGlow = focused ? 0.8 : 0
            }
        }
    }
}

// MARK: - Adaptive Glass Card
struct AdaptiveGlassCard<Content: View>: View {
    let content: Content
    let cornerRadius: CGFloat
    let padding: CGFloat
    
    @StateObject private var lightingManager = AdaptiveLightingManager()
    @State private var hoverScale: CGFloat = 1.0
    @State private var shadowIntensity: Double = 0.1
    
    init(
        cornerRadius: CGFloat = 20,
        padding: CGFloat = 24,
        @ViewBuilder content: () -> Content
    ) {
        self.cornerRadius = cornerRadius
        self.padding = padding
        self.content = content()
    }
    
    var body: some View {
        content
            .padding(padding)
            .background(
                ZStack {
                    // Multi-layer glass effect
                    AdvancedGlassMaterial(
                        cornerRadius: cornerRadius,
                        borderWidth: 1.5,
                        shadowRadius: 25
                    )
                    
                    // Adaptive inner glow
                    RoundedRectangle(cornerRadius: cornerRadius)
                        .fill(
                            RadialGradient(
                                colors: [
                                    .white.opacity(lightingManager.adaptiveOpacity * 0.1),
                                    .clear
                                ],
                                center: .center,
                                startRadius: 0,
                                endRadius: 150
                            )
                        )
                    
                    // Hover effect
                    RoundedRectangle(cornerRadius: cornerRadius)
                        .fill(.white.opacity(0.05))
                        .opacity(hoverScale > 1.0 ? 1 : 0)
                }
            )
            .scaleEffect(hoverScale)
            .shadow(
                color: .black.opacity(shadowIntensity),
                radius: 20,
                x: 0,
                y: 10
            )
            .animation(.spring(response: 0.4, dampingFraction: 0.8), value: hoverScale)
            .animation(.easeInOut(duration: 0.3), value: shadowIntensity)
            .onTapGesture {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                    hoverScale = 1.05
                    shadowIntensity = 0.2
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                        hoverScale = 1.0
                        shadowIntensity = 0.1
                    }
                }
            }
    }
}

// MARK: - Press Event Modifier
extension View {
    func pressEvents(onPress: @escaping () -> Void, onRelease: @escaping () -> Void) -> some View {
        self.simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    onPress()
                }
                .onEnded { _ in
                    onRelease()
                }
        )
    }
}