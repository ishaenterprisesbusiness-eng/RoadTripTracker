import SwiftUI

// MARK: - Vehicle Info Card
struct VehicleInfoCard: View {
    let vehicle: Vehicle
    let showDetailedInfo: Bool
    
    init(vehicle: Vehicle, showDetailedInfo: Bool = true) {
        self.vehicle = vehicle
        self.showDetailedInfo = showDetailedInfo
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // Vehicle Icon
            vehicleIcon
            
            // Vehicle Information
            VStack(alignment: .leading, spacing: 4) {
                vehicleTitle
                
                if showDetailedInfo {
                    vehicleDetails
                }
            }
            
            Spacer()
            
            // Vehicle Type Badge
            if showDetailedInfo {
                vehicleTypeBadge
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(.white.opacity(0.2), lineWidth: 1)
                )
        )
    }
    
    // MARK: - Vehicle Icon
    private var vehicleIcon: some View {
        ZStack {
            Circle()
                .fill(
                    LinearGradient(
                        colors: [.blue.opacity(0.2), .purple.opacity(0.1)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 48, height: 48)
            
            Image(systemName: vehicleTypeIcon(for: vehicle.type))
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        }
    }
    
    // MARK: - Vehicle Title
    private var vehicleTitle: some View {
        HStack(spacing: 8) {
            Text("\(vehicle.make) \(vehicle.model)")
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            if let color = vehicle.color, !color.isEmpty {
                Text("(\(color))")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
    }
    
    // MARK: - Vehicle Details
    private var vehicleDetails: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(spacing: 16) {
                // License Plate
                HStack(spacing: 4) {
                    Image(systemName: "rectangle.and.text.magnifyingglass")
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                    
                    Text(vehicle.vehicleNumber)
                        .font(.caption)
                        .fontWeight(.medium)
                        .foregroundColor(.secondary)
                }
                
                // Odometer Reading
                HStack(spacing: 4) {
                    Image(systemName: "speedometer")
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                    
                    Text("\(formatOdometerReading(vehicle.odometerReading)) km")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
    }
    
    // MARK: - Vehicle Type Badge
    private var vehicleTypeBadge: some View {
        Text(vehicle.type.displayName)
            .font(.caption)
            .fontWeight(.medium)
            .foregroundColor(.blue)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: 6)
                    .fill(.blue.opacity(0.1))
                    .overlay(
                        RoundedRectangle(cornerRadius: 6)
                            .stroke(.blue.opacity(0.3), lineWidth: 1)
                    )
            )
    }
    
    // MARK: - Helper Methods
    private func vehicleTypeIcon(for type: VehicleType) -> String {
        switch type {
        case .caravan:
            return "truck.box"
        case .fourWDUte:
            return "truck.pickup"
        case .camperVan:
            return "bus"
        case .suv:
            return "car.side.fill"
        case .sedan:
            return "car.fill"
        case .hatchback:
            return "car.rear.fill"
        case .other:
            return "car.circle"
        }
    }
    
    private func formatOdometerReading(_ reading: Int) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.groupingSeparator = ","
        return formatter.string(from: NSNumber(value: reading)) ?? "\(reading)"
    }
}

// MARK: - Compact Vehicle Info Card
struct CompactVehicleInfoCard: View {
    let vehicle: Vehicle
    
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: vehicleTypeIcon(for: vehicle.type))
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.blue)
                .frame(width: 20)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("\(vehicle.make) \(vehicle.model)")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                Text(vehicle.vehicleNumber)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Text(vehicle.type.displayName)
                .font(.caption2)
                .fontWeight(.medium)
                .foregroundColor(.blue)
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(
                    RoundedRectangle(cornerRadius: 4)
                        .fill(.blue.opacity(0.1))
                )
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(.white.opacity(0.2), lineWidth: 1)
                )
        )
    }
    
    private func vehicleTypeIcon(for type: VehicleType) -> String {
        switch type {
        case .caravan:
            return "truck.box"
        case .fourWDUte:
            return "truck.pickup"
        case .camperVan:
            return "bus"
        case .suv:
            return "car.side.fill"
        case .sedan:
            return "car.fill"
        case .hatchback:
            return "car.rear.fill"
        case .other:
            return "car.circle"
        }
    }
}

// MARK: - Vehicle Info Row (for lists)
struct VehicleInfoRow: View {
    let vehicle: Vehicle
    let showOwnerName: String?
    
    init(vehicle: Vehicle, showOwnerName: String? = nil) {
        self.vehicle = vehicle
        self.showOwnerName = showOwnerName
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // Vehicle Icon
            Image(systemName: vehicleTypeIcon(for: vehicle.type))
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(.blue)
                .frame(width: 24, height: 24)
                .background(
                    Circle()
                        .fill(.blue.opacity(0.1))
                )
            
            // Vehicle Info
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 8) {
                    Text("\(vehicle.make) \(vehicle.model)")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                    
                    if let color = vehicle.color, !color.isEmpty {
                        Text("(\(color))")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                HStack(spacing: 12) {
                    Text(vehicle.vehicleNumber)
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Text(vehicle.type.displayName)
                        .font(.caption)
                        .foregroundColor(.blue)
                }
                
                if let ownerName = showOwnerName {
                    Text("Driven by \(ownerName)")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .italic()
                }
            }
            
            Spacer()
        }
        .padding(.vertical, 4)
    }
    
    private func vehicleTypeIcon(for type: VehicleType) -> String {
        switch type {
        case .caravan:
            return "truck.box"
        case .fourWDUte:
            return "truck.pickup"
        case .camperVan:
            return "bus"
        case .suv:
            return "car.side.fill"
        case .sedan:
            return "car.fill"
        case .hatchback:
            return "car.rear.fill"
        case .other:
            return "car.circle"
        }
    }
}

// MARK: - Preview
#Preview {
    VStack(spacing: 20) {
        VehicleInfoCard(
            vehicle: Vehicle(
                make: "Toyota",
                model: "Camry",
                vehicleNumber: "ABC123",
                odometerReading: 45000,
                type: .sedan,
                color: "Silver"
            )
        )
        
        CompactVehicleInfoCard(
            vehicle: Vehicle(
                make: "Ford",
                model: "F-150",
                vehicleNumber: "XYZ789",
                odometerReading: 75000,
                type: .fourWDUte,
                color: "Blue"
            )
        )
        
        VehicleInfoRow(
            vehicle: Vehicle(
                make: "Honda",
                model: "CR-V",
                vehicleNumber: "DEF456",
                odometerReading: 32000,
                type: .suv,
                color: "Red"
            ),
            showOwnerName: "John Doe"
        )
    }
    .padding()
    .background(LiquidGlassBackground())
}