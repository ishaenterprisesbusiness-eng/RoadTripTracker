import SwiftUI
import CoreHaptics

// MARK: - Glassmorphic Design System Validation
struct GlasmorphicValidation {
    
    // MARK: - Validation Functions
    static func validateHapticSystem() -> Bool {
        let hapticSystem = AdvancedHapticSystem()
        
        // Test all haptic types
        let hapticTypes: [AdvancedHapticSystem.HapticType] = [
            .glassTouch, .glassPress, .glassSlide, .glassShatter, .glassChime
        ]
        
        for hapticType in hapticTypes {
            hapticSystem.playHaptic(hapticType)
        }
        
        return true
    }
    
    static func validateLightingSystem() -> Bool {
        let lightingSystem = AdaptiveLightingSystem()
        
        // Test all lighting conditions
        let conditions: [AdvancedMaterialSystem.LightingCondition] = [
            .bright, .normal, .dark, .veryDark
        ]
        
        for condition in conditions {
            lightingSystem.forceUpdate(to: condition)
            
            // Validate opacity ranges
            guard condition.adaptiveOpacity >= 0.0 && condition.adaptiveOpacity <= 1.0 else {
                return false
            }
            
            // Validate border opacity ranges
            guard condition.borderOpacity >= 0.0 && condition.borderOpacity <= 1.0 else {
                return false
            }
        }
        
        return true
    }
    
    static func validateMaterialSystem() -> Bool {
        let materialTypes: [AdvancedMaterialSystem.MaterialType] = [
            .ultraThin, .thin, .regular, .thick, .ultraThick
        ]
        
        for materialType in materialTypes {
            // Validate blur radius
            guard materialType.blurRadius > 0 && materialType.blurRadius < 100 else {
                return false
            }
            
            // Validate opacity
            guard materialType.opacity > 0 && materialType.opacity <= 1.0 else {
                return false
            }
        }
        
        return true
    }
    
    static func validateButtonStyles() -> Bool {
        let buttonStyles: [FluidGlassButton.ButtonStyle] = [
            .primary, .secondary, .destructive, .ghost, .success
        ]
        
        for style in buttonStyles {
            // Validate colors array is not empty
            guard !style.colors.isEmpty else {
                return false
            }
            
            // Validate text color is defined
            let _ = style.textColor
            
            // Validate glow color is defined
            let _ = style.glowColor
        }
        
        return true
    }
    
    static func validateAnimationSystem() -> Bool {
        // Test that all animations are properly configured
        let _ = FluidAnimationSystem.glassSpring
        let _ = FluidAnimationSystem.quickSpring
        let _ = FluidAnimationSystem.smoothSpring
        let _ = FluidAnimationSystem.elasticSpring
        let _ = FluidAnimationSystem.glassEaseIn
        let _ = FluidAnimationSystem.glassEaseOut
        let _ = FluidAnimationSystem.glassEaseInOut
        
        return true
    }
    
    static func validateConfiguration() -> Bool {
        // Validate GlasmorphicConfig values
        guard GlasmorphicConfig.cornerRadius > 0 else { return false }
        guard GlasmorphicConfig.borderWidth > 0 else { return false }
        guard GlasmorphicConfig.shadowRadius > 0 else { return false }
        guard GlasmorphicConfig.animationDuration > 0 else { return false }
        guard GlasmorphicConfig.springResponse > 0 else { return false }
        guard GlasmorphicConfig.springDamping > 0 && GlasmorphicConfig.springDamping <= 1 else { return false }
        
        return true
    }
    
    // MARK: - Complete Validation
    static func validateCompleteSystem() -> ValidationResult {
        var results: [String: Bool] = [:]
        
        results["Haptic System"] = validateHapticSystem()
        results["Lighting System"] = validateLightingSystem()
        results["Material System"] = validateMaterialSystem()
        results["Button Styles"] = validateButtonStyles()
        results["Animation System"] = validateAnimationSystem()
        results["Configuration"] = validateConfiguration()
        
        let allPassed = results.values.allSatisfy { $0 }
        
        return ValidationResult(
            overallSuccess: allPassed,
            individualResults: results,
            summary: generateSummary(results: results)
        )
    }
    
    private static func generateSummary(results: [String: Bool]) -> String {
        let passedCount = results.values.filter { $0 }.count
        let totalCount = results.count
        
        var summary = "Glassmorphic Design System Validation\n"
        summary += "=====================================\n"
        summary += "Overall: \(passedCount)/\(totalCount) tests passed\n\n"
        
        for (test, passed) in results.sorted(by: { $0.key < $1.key }) {
            let status = passed ? "✅ PASS" : "❌ FAIL"
            summary += "\(status) - \(test)\n"
        }
        
        if passedCount == totalCount {
            summary += "\n🎉 All glassmorphic design system components are working correctly!"
        } else {
            summary += "\n⚠️ Some components need attention. Check the failed tests above."
        }
        
        return summary
    }
}

// MARK: - Validation Result
struct ValidationResult {
    let overallSuccess: Bool
    let individualResults: [String: Bool]
    let summary: String
    
    func printResults() {
        print(summary)
    }
}

// MARK: - Validation View for Testing
struct GlasmorphicValidationView: View {
    @State private var validationResult: ValidationResult?
    @State private var isValidating = false
    
    var body: some View {
        AdaptiveGlassCard {
            VStack(alignment: .leading, spacing: 20) {
                Text("Design System Validation")
                    .font(.title2)
                    .fontWeight(.bold)
                
                if let result = validationResult {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: result.overallSuccess ? "checkmark.circle.fill" : "xmark.circle.fill")
                                .foregroundColor(result.overallSuccess ? .green : .red)
                                .font(.title2)
                            
                            Text(result.overallSuccess ? "All Tests Passed" : "Some Tests Failed")
                                .font(.headline)
                                .fontWeight(.semibold)
                        }
                        
                        ForEach(result.individualResults.sorted(by: { $0.key < $1.key }), id: \.key) { test, passed in
                            HStack {
                                Image(systemName: passed ? "checkmark.circle" : "xmark.circle")
                                    .foregroundColor(passed ? .green : .red)
                                
                                Text(test)
                                    .font(.subheadline)
                                
                                Spacer()
                            }
                        }
                    }
                } else if isValidating {
                    HStack {
                        ProgressView()
                            .scaleEffect(0.8)
                        
                        Text("Validating design system...")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                } else {
                    Text("Run validation to check all glassmorphic design system components.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                FluidGlassButton(
                    title: isValidating ? "Validating..." : "Run Validation",
                    icon: "checkmark.shield",
                    style: .primary
                ) {
                    runValidation()
                }
                .disabled(isValidating)
            }
        }
    }
    
    private func runValidation() {
        isValidating = true
        validationResult = nil
        
        DispatchQueue.global(qos: .userInitiated).async {
            let result = GlasmorphicValidation.validateCompleteSystem()
            
            DispatchQueue.main.async {
                validationResult = result
                isValidating = false
                result.printResults()
            }
        }
    }
}

#Preview {
    GlasmorphicValidationView()
        .padding()
}