import SwiftUI

// MARK: - Glassmorphic Design System Test View
struct GlasmorphicTestView: View {
    @State private var showModal = false
    @State private var textFieldText = ""
    @State private var secureFieldText = ""
    @State private var selectedLighting: AdvancedMaterialSystem.LightingCondition = .normal
    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                // Header
                Text("Glassmorphic Design System")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                    .padding(.top)
                
                // Lighting Control
                AdaptiveGlassCard(interactive: true) {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Adaptive Lighting")
                            .font(.headline)
                            .fontWeight(.semibold)
                        
                        Picker("Lighting Condition", selection: $selectedLighting) {
                            Text("Bright").tag(AdvancedMaterialSystem.LightingCondition.bright)
                            Text("Normal").tag(AdvancedMaterialSystem.LightingCondition.normal)
                            Text("Dark").tag(AdvancedMaterialSystem.LightingCondition.dark)
                            Text("Very Dark").tag(AdvancedMaterialSystem.LightingCondition.veryDark)
                        }
                        .pickerStyle(.segmented)
                    }
                }
                
                // Button Styles
                AdaptiveGlassCard {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Fluid Glass Buttons")
                            .font(.headline)
                            .fontWeight(.semibold)
                        
                        VStack(spacing: 12) {
                            FluidGlassButton(
                                title: "Primary Button",
                                icon: "star.fill",
                                style: .primary
                            ) {
                                print("Primary button tapped")
                            }
                            
                            FluidGlassButton(
                                title: "Secondary Button",
                                icon: "gear",
                                style: .secondary
                            ) {
                                print("Secondary button tapped")
                            }
                            
                            FluidGlassButton(
                                title: "Success Button",
                                icon: "checkmark.circle.fill",
                                style: .success
                            ) {
                                print("Success button tapped")
                            }
                            
                            FluidGlassButton(
                                title: "Destructive Button",
                                icon: "trash.fill",
                                style: .destructive
                            ) {
                                print("Destructive button tapped")
                            }
                            
                            FluidGlassButton(
                                title: "Ghost Button",
                                icon: "eye",
                                style: .ghost
                            ) {
                                print("Ghost button tapped")
                            }
                        }
                    }
                }
                
                // Text Fields
                AdaptiveGlassCard {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Dynamic Glass Text Fields")
                            .font(.headline)
                            .fontWeight(.semibold)
                        
                        DynamicGlassTextField(
                            title: "Email Address",
                            text: $textFieldText,
                            icon: "envelope.fill"
                        )
                        
                        DynamicGlassTextField(
                            title: "Password",
                            text: $secureFieldText,
                            icon: "lock.fill",
                            isSecure: true
                        )
                    }
                }
                
                // Modal Test
                AdaptiveGlassCard(interactive: true) {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Advanced Glass Modal")
                            .font(.headline)
                            .fontWeight(.semibold)
                        
                        FluidGlassButton(
                            title: "Show Modal",
                            icon: "rectangle.stack.badge.plus",
                            style: .primary
                        ) {
                            showModal = true
                        }
                    }
                }
                
                // Material Types
                AdaptiveGlassCard {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Material Types")
                            .font(.headline)
                            .fontWeight(.semibold)
                        
                        VStack(spacing: 12) {
                            ForEach([
                                ("Ultra Thin", AdvancedMaterialSystem.MaterialType.ultraThin),
                                ("Thin", AdvancedMaterialSystem.MaterialType.thin),
                                ("Regular", AdvancedMaterialSystem.MaterialType.regular),
                                ("Thick", AdvancedMaterialSystem.MaterialType.thick),
                                ("Ultra Thick", AdvancedMaterialSystem.MaterialType.ultraThick)
                            ], id: \.0) { name, type in
                                HStack {
                                    Text(name)
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                    
                                    Spacer()
                                    
                                    Rectangle()
                                        .frame(width: 60, height: 30)
                                        .background(
                                            UltraGlassMaterial(
                                                cornerRadius: 8,
                                                materialType: type,
                                                borderWidth: 1,
                                                shadowRadius: 10
                                            )
                                        )
                                }
                            }
                        }
                    }
                }
                
                // Validation Section
                GlasmorphicValidationView()
                
                Spacer(minLength: 100)
            }
            .padding(.horizontal, 20)
        }
        .background(
            // Animated background
            ZStack {
                LinearGradient(
                    colors: [
                        .blue.opacity(0.1),
                        .purple.opacity(0.1),
                        .pink.opacity(0.05)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                // Floating orbs
                ForEach(0..<5, id: \.self) { index in
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [
                                    .white.opacity(0.1),
                                    .clear
                                ],
                                center: .center,
                                startRadius: 0,
                                endRadius: 100
                            )
                        )
                        .frame(width: 150, height: 150)
                        .blur(radius: 2)
                        .offset(
                            x: CGFloat.random(in: -100...100),
                            y: CGFloat.random(in: -200...200)
                        )
                        .animation(
                            .easeInOut(duration: Double.random(in: 8...12))
                            .repeatForever(autoreverses: true)
                            .delay(Double(index) * 2),
                            value: UUID()
                        )
                }
            }
        )
        .sheet(isPresented: $showModal) {
            AdvancedGlassModal(isPresented: $showModal) {
                VStack(spacing: 20) {
                    Text("Advanced Glass Modal")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("This modal demonstrates the advanced glassmorphic design with multi-layer effects, animated particles, and fluid animations.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                    
                    HStack(spacing: 16) {
                        FluidGlassButton(
                            title: "Cancel",
                            style: .secondary
                        ) {
                            showModal = false
                        }
                        
                        FluidGlassButton(
                            title: "Confirm",
                            icon: "checkmark",
                            style: .primary
                        ) {
                            showModal = false
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Preview
#Preview {
    GlasmorphicTestView()
}