import SwiftUI
import MapKit
import CoreLocation

struct AccommodationFinderView: View {
    @StateObject private var viewModel = AccommodationViewModel()
    @State private var showingFilters = false
    @State private var showingAccommodationDetail = false
    @State private var searchLocation: CLLocationCoordinate2D?
    @State private var searchRadius: Double = 25.0 // km
    
    let trip: Trip?
    let onAccommodationSelected: ((Accommodation) -> Void)?
    
    init(trip: Trip? = nil, onAccommodationSelected: ((Accommodation) -> Void)? = nil) {
        self.trip = trip
        self.onAccommodationSelected = onAccommodationSelected
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Search Controls
                searchControlsSection
                
                // Results
                if viewModel.isLoading {
                    loadingView
                } else if viewModel.accommodations.isEmpty && viewModel.errorMessage == nil {
                    emptyStateView
                } else if let errorMessage = viewModel.errorMessage {
                    errorView(errorMessage)
                } else {
                    accommodationsList
                }
            }
            .navigationTitle("Find Accommodation")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Filters") {
                        showingFilters = true
                    }
                }
            }
            .sheet(isPresented: $showingFilters) {
                AccommodationFiltersView(filters: $viewModel.searchFilters) {
                    performSearch()
                }
            }
            .sheet(isPresented: $showingAccommodationDetail) {
                if let accommodation = viewModel.selectedAccommodation {
                    AccommodationDetailView(
                        accommodation: accommodation,
                        trip: trip,
                        onAddToTrip: { accommodation in
                            if let trip = trip {
                                viewModel.addAccommodationToTrip(accommodation, trip: trip)
                            }
                            onAccommodationSelected?(accommodation)
                        }
                    )
                }
            }
        }
        .onAppear {
            setupInitialSearch()
        }
    }
    
    // MARK: - View Components
    
    private var searchControlsSection: some View {
        VStack(spacing: 16) {
            // Location Search
            HStack {
                Image(systemName: "location")
                    .foregroundColor(.secondary)
                
                Text(searchLocationText)
                    .foregroundColor(searchLocation == nil ? .secondary : .primary)
                
                Spacer()
                
                Button("Change") {
                    // TODO: Implement location picker
                }
                .font(.caption)
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(12)
            
            // Search Radius
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Search Radius")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    
                    Spacer()
                    
                    Text("\(Int(searchRadius)) km")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                Slider(value: $searchRadius, in: 5...100, step: 5)
                    .onChange(of: searchRadius) { _ in
                        performSearch()
                    }
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(12)
        }
        .padding(.horizontal)
        .padding(.top)
    }
    
    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.2)
            
            Text("Searching for accommodations...")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 16) {
            Image(systemName: "bed.double")
                .font(.system(size: 48))
                .foregroundColor(.secondary)
            
            Text("Find Your Perfect Stay")
                .font(.title2)
                .fontWeight(.semibold)
            
            Text("Search for hotels, motels, campgrounds, and more along your route")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            Button("Start Search") {
                performSearch()
            }
            .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    private func errorView(_ message: String) -> some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle")
                .font(.system(size: 48))
                .foregroundColor(.orange)
            
            Text("Search Error")
                .font(.title2)
                .fontWeight(.semibold)
            
            Text(message)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            Button("Try Again") {
                performSearch()
            }
            .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    private var accommodationsList: some View {
        List(viewModel.getFilteredAccommodations()) { accommodation in
            AccommodationRowView(accommodation: accommodation) {
                viewModel.selectAccommodation(accommodation)
                showingAccommodationDetail = true
            }
        }
        .listStyle(PlainListStyle())
    }
    
    // MARK: - Computed Properties
    
    private var searchLocationText: String {
        if let location = searchLocation {
            return "Near \(String(format: "%.4f", location.latitude)), \(String(format: "%.4f", location.longitude))"
        } else if let trip = trip, !trip.destinations.isEmpty {
            return "Along trip route"
        } else {
            return "Select search location"
        }
    }
    
    // MARK: - Methods
    
    private func setupInitialSearch() {
        if let trip = trip, !trip.destinations.isEmpty {
            // Search along the trip route
            let coordinates = trip.destinations.map { $0.coordinate }
            viewModel.searchAccommodationsAlongRoute(coordinates)
        } else {
            // Use current location or a default location
            // For now, use a default location (San Francisco)
            searchLocation = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
            performSearch()
        }
    }
    
    private func performSearch() {
        guard let location = searchLocation else { return }
        
        viewModel.searchAccommodations(
            near: location,
            radius: searchRadius * 1000 // Convert km to meters
        )
    }
}

// MARK: - Accommodation Row View
struct AccommodationRowView: View {
    let accommodation: Accommodation
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                // Accommodation Type Icon
                Image(systemName: accommodation.type.icon)
                    .font(.title2)
                    .foregroundColor(.blue)
                    .frame(width: 32, height: 32)
                
                VStack(alignment: .leading, spacing: 4) {
                    // Name and Type
                    HStack {
                        Text(accommodation.name)
                            .font(.headline)
                            .foregroundColor(.primary)
                            .lineLimit(1)
                        
                        Spacer()
                        
                        Text(accommodation.type.displayName)
                            .font(.caption)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 2)
                            .background(Color.blue.opacity(0.1))
                            .foregroundColor(.blue)
                            .cornerRadius(4)
                    }
                    
                    // Address
                    Text(accommodation.address)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                    
                    // Rating, Price, and Distance
                    HStack(spacing: 12) {
                        if let rating = accommodation.rating {
                            HStack(spacing: 2) {
                                Image(systemName: "star.fill")
                                    .font(.caption)
                                    .foregroundColor(.yellow)
                                Text(String(format: "%.1f", rating))
                                    .font(.caption)
                                    .fontWeight(.medium)
                            }
                        }
                        
                        if let priceRange = accommodation.priceRange {
                            Text(priceRange.displayName)
                                .font(.caption)
                                .fontWeight(.medium)
                                .foregroundColor(.green)
                        }
                        
                        if let distance = accommodation.distance {
                            Text(String(format: "%.1f km", distance))
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                    }
                    
                    // Amenities
                    if !accommodation.amenities.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(accommodation.amenities.prefix(4), id: \.self) { amenity in
                                    HStack(spacing: 2) {
                                        Image(systemName: amenity.icon)
                                            .font(.caption2)
                                        Text(amenity.displayName)
                                            .font(.caption2)
                                    }
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color(.systemGray5))
                                    .cornerRadius(4)
                                }
                                
                                if accommodation.amenities.count > 4 {
                                    Text("+\(accommodation.amenities.count - 4)")
                                        .font(.caption2)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                }
                
                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding(.vertical, 4)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Preview
struct AccommodationFinderView_Previews: PreviewProvider {
    static var previews: some View {
        AccommodationFinderView()
    }
}