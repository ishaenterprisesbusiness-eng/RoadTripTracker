import SwiftUI
import MapKit
import CoreLocation

struct VehicleMapView: UIViewRepresentable {
    @StateObject private var serviceContainer = ServiceContainer.shared
    @Binding var participants: [Participant]
    @Binding var route: Route?
    @Binding var selectedParticipant: Participant?
    
    let showUserLocation: Bool
    let autoZoom: Bool
    
    init(participants: Binding<[Participant]>, route: Binding<Route?> = .constant(nil), selectedParticipant: Binding<Participant?> = .constant(nil), showUserLocation: Bool = true, autoZoom: Bool = true) {
        self._participants = participants
        self._route = route
        self._selectedParticipant = selectedParticipant
        self.showUserLocation = showUserLocation
        self.autoZoom = autoZoom
    }
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = showUserLocation
        mapView.userTrackingMode = .none
        mapView.mapType = .standard
        mapView.showsCompass = true
        mapView.showsScale = true
        
        // Configure map appearance
        mapView.preferredConfiguration = MKStandardMapConfiguration()
        
        return mapView
    }
    
    func updateUIView(_ mapView: MKMapView, context: Context) {
        context.coordinator.updateParticipants(participants, on: mapView)
        context.coordinator.updateRoute(route, on: mapView)
        
        if autoZoom {
            context.coordinator.autoZoomToShowAllParticipants(on: mapView)
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: VehicleMapView
        private var participantAnnotations: [UUID: VehicleAnnotation] = [:]
        private var clusterAnnotations: [VehicleClusterAnnotation] = []
        private var routeOverlay: MKPolyline?
        private let clusteringManager = VehicleClusteringManager(clusterRadius: 100)
        
        init(_ parent: VehicleMapView) {
            self.parent = parent
        }
        
        // MARK: - Participant Management
        
        func updateParticipants(_ participants: [Participant], on mapView: MKMapView) {
            // Remove all existing annotations
            let allAnnotations = Array(participantAnnotations.values) + clusterAnnotations
            mapView.removeAnnotations(allAnnotations)
            
            // Clear tracking
            participantAnnotations.removeAll()
            clusterAnnotations.removeAll()
            
            // Apply clustering
            let (individualAnnotations, clusters) = clusteringManager.clusterParticipants(participants)
            
            // Add individual annotations
            for annotation in individualAnnotations {
                participantAnnotations[annotation.participant.id] = annotation
                mapView.addAnnotation(annotation)
            }
            
            // Add cluster annotations
            for cluster in clusters {
                clusterAnnotations.append(cluster)
                mapView.addAnnotation(cluster)
            }
        }
        
        private func updateVehicleAnnotation(_ annotation: VehicleAnnotation, with participant: Participant, on mapView: MKMapView) {
            guard let newLocation = participant.currentLocation else { return }
            
            let newCoordinate = newLocation
            let oldCoordinate = annotation.coordinate
            
            // Animate position change if significant
            if CLLocation(latitude: oldCoordinate.latitude, longitude: oldCoordinate.longitude)
                .distance(from: CLLocation(latitude: newLocation.latitude, longitude: newLocation.longitude)) > 10 {
                
                UIView.animate(withDuration: 1.0, delay: 0, options: [.curveEaseInOut]) {
                    annotation.coordinate = newCoordinate
                }
            } else {
                annotation.coordinate = newCoordinate
            }
            
            // Update annotation data
            annotation.participant = participant
        }
        
        // MARK: - Route Management
        
        func updateRoute(_ route: Route?, on mapView: MKMapView) {
            // Remove existing route overlay
            if let existingOverlay = routeOverlay {
                mapView.removeOverlay(existingOverlay)
                routeOverlay = nil
            }
            
            // Add new route overlay if available
            guard let route = route, !route.waypoints.isEmpty else { return }
            
            let coordinates = route.waypoints
            let polyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
            mapView.addOverlay(polyline)
            routeOverlay = polyline
        }
        
        // MARK: - Auto Zoom
        
        func autoZoomToShowAllParticipants(on mapView: MKMapView) {
            let individualAnnotations = Array(participantAnnotations.values)
            let allAnnotations = individualAnnotations + clusterAnnotations
            
            guard !allAnnotations.isEmpty else { return }
            
            if allAnnotations.count == 1 {
                // Single annotation - center on it with reasonable zoom
                let annotation = allAnnotations[0]
                let region = MKCoordinateRegion(
                    center: annotation.coordinate,
                    latitudinalMeters: 5000,
                    longitudinalMeters: 5000
                )
                mapView.setRegion(region, animated: true)
            } else {
                // Multiple annotations - show all with padding
                let coordinates = allAnnotations.map { $0.coordinate }
                let region = regionThatFits(coordinates: coordinates)
                mapView.setRegion(region, animated: true)
            }
        }
        
        private func regionThatFits(coordinates: [CLLocationCoordinate2D]) -> MKCoordinateRegion {
            guard !coordinates.isEmpty else {
                return MKCoordinateRegion()
            }
            
            var minLat = coordinates[0].latitude
            var maxLat = coordinates[0].latitude
            var minLon = coordinates[0].longitude
            var maxLon = coordinates[0].longitude
            
            for coordinate in coordinates {
                minLat = min(minLat, coordinate.latitude)
                maxLat = max(maxLat, coordinate.latitude)
                minLon = min(minLon, coordinate.longitude)
                maxLon = max(maxLon, coordinate.longitude)
            }
            
            let center = CLLocationCoordinate2D(
                latitude: (minLat + maxLat) / 2,
                longitude: (minLon + maxLon) / 2
            )
            
            let span = MKCoordinateSpan(
                latitudeDelta: (maxLat - minLat) * 1.3, // Add 30% padding
                longitudeDelta: (maxLon - minLon) * 1.3
            )
            
            return MKCoordinateRegion(center: center, span: span)
        }
        
        // MARK: - MKMapViewDelegate
        
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            if let vehicleAnnotation = annotation as? VehicleAnnotation {
                let identifier = "VehicleAnnotation"
                let annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? VehicleAnnotationView
                    ?? VehicleAnnotationView(annotation: vehicleAnnotation, reuseIdentifier: identifier)
                
                annotationView.annotation = vehicleAnnotation
                annotationView.configure(with: vehicleAnnotation.participant)
                
                return annotationView
            } else if let clusterAnnotation = annotation as? VehicleClusterAnnotation {
                let identifier = "VehicleClusterAnnotation"
                let annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? VehicleClusterAnnotationView
                    ?? VehicleClusterAnnotationView(annotation: clusterAnnotation, reuseIdentifier: identifier)
                
                annotationView.annotation = clusterAnnotation
                annotationView.configure(with: clusterAnnotation)
                
                return annotationView
            }
            
            return nil
        }
        
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let polyline = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: polyline)
                renderer.strokeColor = .systemBlue
                renderer.lineWidth = 4.0
                renderer.lineCap = .round
                renderer.lineJoin = .round
                return renderer
            }
            
            return MKOverlayRenderer(overlay: overlay)
        }
        
        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
            if let vehicleAnnotation = view.annotation as? VehicleAnnotation {
                parent.selectedParticipant = vehicleAnnotation.participant
                showParticipantDetails(for: vehicleAnnotation.participant, on: mapView)
            } else if let clusterAnnotation = view.annotation as? VehicleClusterAnnotation {
                showClusterDetails(for: clusterAnnotation, on: mapView)
            }
        }
        
        private func showParticipantDetails(for participant: Participant, on mapView: MKMapView) {
            // This could show a callout or trigger a sheet presentation
            // For now, we'll just ensure the annotation is selected
        }
        
        private func showClusterDetails(for cluster: VehicleClusterAnnotation, on mapView: MKMapView) {
            // This could show a sheet with all participants in the cluster
            // For now, we'll zoom in to show individual vehicles
            let region = MKCoordinateRegion(
                center: cluster.coordinate,
                latitudinalMeters: 200,
                longitudinalMeters: 200
            )
            mapView.setRegion(region, animated: true)
        }
    }
}

// MARK: - Vehicle Annotation
class VehicleAnnotation: NSObject, MKAnnotation {
    @objc dynamic var coordinate: CLLocationCoordinate2D
    var participant: Participant
    
    var title: String? {
        return participant.user.username
    }
    
    var subtitle: String? {
        if let vehicle = participant.user.vehicle {
            return "\(vehicle.make) \(vehicle.model)"
        }
        return nil
    }
    
    init(participant: Participant) {
        self.participant = participant
        self.coordinate = participant.currentLocation ?? CLLocationCoordinate2D(latitude: 0, longitude: 0)
        super.init()
    }
}

// MARK: - Vehicle Annotation View
class VehicleAnnotationView: MKAnnotationView {
    private let vehicleImageView = UIImageView()
    private let statusIndicator = UIView()
    private let containerView = UIView()
    
    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    private func setupView() {
        frame = CGRect(x: 0, y: 0, width: 44, height: 44)
        centerOffset = CGPoint(x: 0, y: -frame.height / 2)
        canShowCallout = true
        
        // Container view with liquid glass effect
        containerView.frame = bounds
        containerView.layer.cornerRadius = 22
        containerView.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.9)
        containerView.layer.shadowColor = UIColor.black.cgColor
        containerView.layer.shadowOffset = CGSize(width: 0, height: 2)
        containerView.layer.shadowRadius = 4
        containerView.layer.shadowOpacity = 0.3
        addSubview(containerView)
        
        // Vehicle image
        vehicleImageView.frame = CGRect(x: 8, y: 8, width: 28, height: 28)
        vehicleImageView.contentMode = .scaleAspectFit
        vehicleImageView.tintColor = .systemBlue
        containerView.addSubview(vehicleImageView)
        
        // Status indicator
        statusIndicator.frame = CGRect(x: 32, y: 4, width: 12, height: 12)
        statusIndicator.layer.cornerRadius = 6
        statusIndicator.backgroundColor = UIColor.systemGreen
        statusIndicator.layer.borderWidth = 2
        statusIndicator.layer.borderColor = UIColor.white.cgColor
        containerView.addSubview(statusIndicator)
    }
    
    func configure(with participant: Participant) {
        // Set vehicle icon based on vehicle type
        let vehicleIcon = vehicleIcon(for: participant.user.vehicle?.type ?? .other)
        vehicleImageView.image = UIImage(systemName: vehicleIcon)
        
        // Set status indicator color
        statusIndicator.backgroundColor = statusColor(for: participant)
        
        // Update accessibility
        accessibilityLabel = "\(participant.user.username)'s vehicle"
        if let vehicle = participant.user.vehicle {
            accessibilityHint = "\(vehicle.make) \(vehicle.model)"
        }
    }
    
    private func vehicleIcon(for vehicleType: VehicleType) -> String {
        switch vehicleType {
        case .caravan:
            return "car.side.fill"
        case .fourWDUte:
            return "car.side.fill"
        case .camperVan:
            return "car.side.fill"
        case .suv:
            return "car.side.fill"
        case .sedan:
            return "car.side.fill"
        case .hatchback:
            return "car.side.fill"
        case .other:
            return "car.side.fill"
        }
    }
    
    private func statusColor(for participant: Participant) -> UIColor {
        switch participant.status {
        case .active:
            return .systemGreen
        case .inactive:
            return .systemOrange
        case .joined:
            return .systemBlue
        case .invited:
            return .systemGray
        case .left:
            return .systemRed
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        vehicleImageView.image = nil
        statusIndicator.backgroundColor = .systemGray
    }
}

#Preview {
    VehicleMapView(
        participants: .constant([
            Participant(
                userId: UUID(),
                user: User(
                    username: "John Doe",
                    email: "john@example.com",
                    city: "San Francisco",
                    dateOfBirth: Date(),
                    vehicle: Vehicle(
                        make: "Toyota",
                        model: "Camry",
                        vehicleNumber: "ABC123",
                        odometerReading: 50000,
                        type: .sedan
                    )
                ),
                currentLocation: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
                isLocationSharingEnabled: true,
                status: .active
            )
        ])
    )
    .frame(height: 400)
}