import SwiftUI
import CoreLocation

struct LocationSharingToggleView: View {
    @StateObject private var serviceContainer = ServiceContainer.shared
    @State private var isLocationSharingEnabled = false
    @State private var authorizationStatus: CLAuthorizationStatus = .notDetermined
    @State private var showPermissionAlert = false
    @State private var isToggling = false
    
    let tripId: UUID?
    let participantId: UUID?
    
    var body: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Location Sharing")
                        .font(.headline)
                        .fontWeight(.medium)
                    
                    Text(statusDescription)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Toggle("", isOn: $isLocationSharingEnabled)
                    .toggleStyle(LiquidGlassToggleStyle())
                    .disabled(isToggling || !canToggleLocationSharing)
                    .onChange(of: isLocationSharingEnabled) { _, newValue in
                        handleLocationSharingToggle(newValue)
                    }
            }
            
            if authorizationStatus == .denied || authorizationStatus == .restricted {
                LocationPermissionBanner()
            }
        }
        .padding()
        .background(
            LiquidGlassCard()
        )
        .onAppear {
            setupInitialState()
        }
        .onReceive(serviceContainer.locationService.authorizationUpdates) { status in
            authorizationStatus = status
        }
        .alert("Location Permission Required", isPresented: $showPermissionAlert) {
            Button("Settings") {
                openSettings()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Please enable location access in Settings to share your location with the group.")
        }
    }
    
    private var statusDescription: String {
        switch authorizationStatus {
        case .notDetermined:
            return "Location permission not requested"
        case .denied, .restricted:
            return "Location permission denied"
        case .authorizedWhenInUse, .authorizedAlways:
            return isLocationSharingEnabled ? "Sharing location with group" : "Location sharing disabled"
        @unknown default:
            return "Unknown location status"
        }
    }
    
    private var canToggleLocationSharing: Bool {
        return authorizationStatus == .authorizedWhenInUse || authorizationStatus == .authorizedAlways
    }
    
    private func setupInitialState() {
        authorizationStatus = serviceContainer.locationService.authorizationStatus
        isLocationSharingEnabled = serviceContainer.locationService.isLocationSharingEnabled
        
        // Set trip context if provided
        if let tripId = tripId, let participantId = participantId {
            if let locationManager = serviceContainer.locationService as? LocationManager {
                locationManager.setTripContext(tripId: tripId, participantId: participantId)
            }
        }
    }
    
    private func handleLocationSharingToggle(_ enabled: Bool) {
        guard !isToggling else { return }
        
        // Check permission first
        guard canToggleLocationSharing else {
            isLocationSharingEnabled = false
            showPermissionAlert = true
            return
        }
        
        isToggling = true
        
        Task {
            do {
                if enabled {
                    try await serviceContainer.locationService.startLocationSharing()
                } else {
                    serviceContainer.locationService.stopLocationSharing()
                }
                
                await MainActor.run {
                    isToggling = false
                }
            } catch {
                await MainActor.run {
                    isLocationSharingEnabled = false
                    isToggling = false
                    
                    if error is LocationServiceError {
                        showPermissionAlert = true
                    }
                }
            }
        }
    }
    
    private func openSettings() {
        if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(settingsURL)
        }
    }
}

// MARK: - Location Permission Banner
struct LocationPermissionBanner: View {
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundColor(.orange)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("Location Access Disabled")
                    .font(.caption)
                    .fontWeight(.medium)
                
                Text("Enable in Settings to share location")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button("Settings") {
                if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(settingsURL)
                }
            }
            .font(.caption)
            .buttonStyle(.bordered)
            .controlSize(.mini)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(.orange.opacity(0.1))
                .stroke(.orange.opacity(0.3), lineWidth: 1)
        )
    }
}

// MARK: - Liquid Glass Toggle Style
struct LiquidGlassToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack {
            configuration.label
            
            Spacer()
            
            RoundedRectangle(cornerRadius: 16)
                .fill(
                    configuration.isOn ? 
                    .blue.gradient : 
                    Color(.systemGray4)
                )
                .frame(width: 50, height: 30)
                .overlay(
                    Circle()
                        .fill(.white)
                        .shadow(color: .black.opacity(0.2), radius: 2, x: 0, y: 1)
                        .padding(2)
                        .offset(x: configuration.isOn ? 10 : -10)
                        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: configuration.isOn)
                )
                .onTapGesture {
                    configuration.isOn.toggle()
                }
        }
    }
}

#Preview {
    VStack(spacing: 20) {
        LocationSharingToggleView(tripId: UUID(), participantId: UUID())
        
        LocationSharingToggleView(tripId: nil, participantId: nil)
    }
    .padding()
    .background(Color(.systemGroupedBackground))
}