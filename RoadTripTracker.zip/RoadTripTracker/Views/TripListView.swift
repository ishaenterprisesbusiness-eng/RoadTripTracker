import SwiftUI
import CoreLocation
import MapKit

struct TripListView: View {
    @ObservedObject var viewModel: TripViewModel
    
    var body: some View {
        ScrollView {
            LazyVStack(spacing: 16) {
                if let trip = viewModel.trip {
                    tripHeaderSection(trip: trip)
                    destinationsSection(trip: trip)
                    tripStatsSection
                } else {
                    noTripView
                }
            }
            .padding()
        }
        .refreshable {
            await viewModel.calculateEstimatedArrivalTimes()
        }
    }
    
    // MARK: - Trip Header Section
    
    private func tripHeaderSection(trip: Trip) -> some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(trip.name)
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        
                        Text("Trip Code: \(trip.code)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    TripStatusBadge(status: trip.status)
                }
                
                if let currentDestination = viewModel.currentDestination {
                    HStack {
                        Image(systemName: "location.fill")
                            .foregroundColor(.accentColor)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Current Destination")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text(currentDestination.name)
                                .font(.subheadline)
                                .fontWeight(.medium)
                                .foregroundColor(.primary)
                        }
                        
                        Spacer()
                    }
                }
                
                if let nextDestination = viewModel.nextDestination {
                    HStack {
                        Image(systemName: "arrow.right.circle.fill")
                            .foregroundColor(.blue)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Next Destination")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text(nextDestination.name)
                                .font(.subheadline)
                                .fontWeight(.medium)
                                .foregroundColor(.primary)
                        }
                        
                        Spacer()
                        
                        if let arrivalTime = viewModel.estimatedArrivalTimes[nextDestination.id] {
                            VStack(alignment: .trailing, spacing: 2) {
                                Text("ETA")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                
                                Text(arrivalTime, style: .time)
                                    .font(.subheadline)
                                    .fontWeight(.medium)
                                    .foregroundColor(.primary)
                            }
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - Destinations Section
    
    private func destinationsSection(trip: Trip) -> some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text("Destinations")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Text("\(trip.destinations.count) stops")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                LazyVStack(spacing: 12) {
                    ForEach(Array(trip.destinations.enumerated()), id: \.element.id) { index, destination in
                        DestinationListRow(
                            destination: destination,
                            index: index,
                            isCurrentDestination: index == trip.currentDestinationIndex,
                            estimatedArrival: viewModel.estimatedArrivalTimes[destination.id],
                            onTap: {
                                viewModel.selectDestination(destination)
                            }
                        )
                        
                        if index < trip.destinations.count - 1 {
                            RouteConnectionView()
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - Trip Stats Section
    
    private var tripStatsSection: some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("Trip Statistics")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                HStack(spacing: 20) {
                    StatItem(
                        title: "Total Distance",
                        value: formatDistance(viewModel.totalDistance),
                        icon: "road.lanes"
                    )
                    
                    StatItem(
                        title: "Estimated Duration",
                        value: formatDuration(viewModel.totalEstimatedDuration),
                        icon: "clock"
                    )
                }
            }
        }
    }
    
    // MARK: - No Trip View
    
    private var noTripView: some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                Image(systemName: "map")
                    .font(.system(size: 48))
                    .foregroundColor(.secondary)
                
                Text("No Active Trip")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                Text("Create a new trip or join an existing one to get started")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding(.vertical, 20)
        }
    }
    
    // MARK: - Helper Methods
    
    private func formatDistance(_ distance: CLLocationDistance) -> String {
        let formatter = MKDistanceFormatter()
        formatter.unitStyle = .abbreviated
        return formatter.string(fromDistance: distance)
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        
        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }
}

// MARK: - Destination List Row

struct DestinationListRow: View {
    let destination: Destination
    let index: Int
    let isCurrentDestination: Bool
    let estimatedArrival: Date?
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                // Destination number indicator
                ZStack {
                    Circle()
                        .fill(isCurrentDestination ? Color.accentColor : Color.gray.opacity(0.3))
                        .frame(width: 32, height: 32)
                    
                    Text("\(index + 1)")
                        .font(.subheadline)
                        .fontWeight(.bold)
                        .foregroundColor(isCurrentDestination ? .white : .primary)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(destination.name)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.leading)
                    
                    Text(destination.address)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.leading)
                    
                    HStack(spacing: 8) {
                        DestinationTypeBadge(type: destination.type)
                        
                        if let duration = destination.plannedDuration, duration > 0 {
                            Text("Stay: \(formatDuration(duration))")
                                .font(.caption2)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(
                                    RoundedRectangle(cornerRadius: 4)
                                        .fill(Color.blue.opacity(0.2))
                                )
                                .foregroundColor(.blue)
                        }
                    }
                    
                    // Weather information
                    WeatherWidget(
                        coordinate: destination.coordinate,
                        locationName: destination.name,
                        showForecast: false
                    )
                    .padding(.top, 4)
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 4) {
                    if let arrivalTime = estimatedArrival {
                        Text("ETA")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        
                        Text(arrivalTime, style: .time)
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(.primary)
                    }
                    
                    if isCurrentDestination {
                        Text("Current")
                            .font(.caption2)
                            .fontWeight(.medium)
                            .foregroundColor(.accentColor)
                    }
                }
            }
            .padding(.vertical, 8)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        
        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }
}

// MARK: - Route Connection View

struct RouteConnectionView: View {
    var body: some View {
        HStack {
            Spacer()
                .frame(width: 16) // Align with destination number
            
            VStack(spacing: 2) {
                ForEach(0..<3, id: \.self) { _ in
                    Circle()
                        .fill(Color.gray.opacity(0.4))
                        .frame(width: 3, height: 3)
                }
            }
            
            Spacer()
        }
        .frame(height: 16)
    }
}

// MARK: - Trip Status Badge

struct TripStatusBadge: View {
    let status: TripStatus
    
    var body: some View {
        Text(status.rawValue.capitalized)
            .font(.caption)
            .fontWeight(.medium)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(backgroundColor)
            )
            .foregroundColor(foregroundColor)
    }
    
    private var backgroundColor: Color {
        switch status {
        case .planning: return .orange.opacity(0.2)
        case .active: return .green.opacity(0.2)
        case .paused: return .yellow.opacity(0.2)
        case .completed: return .blue.opacity(0.2)
        case .cancelled: return .red.opacity(0.2)
        }
    }
    
    private var foregroundColor: Color {
        switch status {
        case .planning: return .orange
        case .active: return .green
        case .paused: return .yellow
        case .completed: return .blue
        case .cancelled: return .red
        }
    }
}

// MARK: - Destination Type Badge

struct DestinationTypeBadge: View {
    let type: DestinationType
    
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: iconName)
                .font(.caption2)
            
            Text(type.rawValue.capitalized)
                .font(.caption2)
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 2)
        .background(
            RoundedRectangle(cornerRadius: 4)
                .fill(backgroundColor)
        )
        .foregroundColor(foregroundColor)
    }
    
    private var iconName: String {
        switch type {
        case .start: return "play.circle"
        case .waypoint: return "location"
        case .fuel: return "fuelpump"
        case .food: return "fork.knife"
        case .accommodation: return "bed.double"
        case .attraction: return "star"
        case .end: return "flag.checkered"
        }
    }
    
    private var backgroundColor: Color {
        switch type {
        case .start: return .green.opacity(0.2)
        case .waypoint: return .gray.opacity(0.2)
        case .fuel: return .orange.opacity(0.2)
        case .food: return .red.opacity(0.2)
        case .accommodation: return .purple.opacity(0.2)
        case .attraction: return .yellow.opacity(0.2)
        case .end: return .blue.opacity(0.2)
        }
    }
    
    private var foregroundColor: Color {
        switch type {
        case .start: return .green
        case .waypoint: return .gray
        case .fuel: return .orange
        case .food: return .red
        case .accommodation: return .purple
        case .attraction: return .yellow
        case .end: return .blue
        }
    }
}

// MARK: - Stat Item

struct StatItem: View {
    let title: String
    let value: String
    let icon: String
    
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(.accentColor)
            
            Text(value)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
    }
}

#Preview {
    let mockTrip = Trip(
        name: "California Road Trip",
        code: "ABC123",
        createdBy: UUID(),
        destinations: [
            Destination(name: "San Francisco", address: "San Francisco, CA", coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194), type: .start),
            Destination(name: "Monterey Bay", address: "Monterey, CA", coordinate: CLLocationCoordinate2D(latitude: 36.6002, longitude: -121.8947), type: .attraction),
            Destination(name: "Los Angeles", address: "Los Angeles, CA", coordinate: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437), type: .end)
        ],
        status: .active
    )
    
    let mockViewModel = TripViewModel(tripService: MockTripService(), mapService: MockMapService())
    mockViewModel.trip = mockTrip
    
    return TripListView(viewModel: mockViewModel)
}

// MARK: - Mock Services for Preview

class MockMapService: MapServiceProtocol {
    func displayRoute(_ route: Route) async throws { }
    func showParticipants(_ participants: [Participant]) async throws { }
    func findNearbyPOIs(category: POICategory, near location: CLLocationCoordinate2D, radius: CLLocationDistance) async throws -> [PointOfInterest] { return [] }
    func calculateRoute(from origin: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D, waypoints: [CLLocationCoordinate2D]) async throws -> Route {
        return Route(name: "Mock Route", destinations: [])
    }
    func calculateMultiDestinationRoute(destinations: [Destination]) async throws -> Route {
        return Route(name: "Mock Route", destinations: destinations)
    }
    func getDirections(for route: Route) async throws -> [RouteStep] { return [] }
    func searchPlaces(query: String, near location: CLLocationCoordinate2D) async throws -> [Place] { return [] }
}