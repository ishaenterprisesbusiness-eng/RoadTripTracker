import SwiftUI

// MARK: - Participant List View
struct ParticipantListView: View {
    let participants: [Participant]
    
    var body: some View {
        ZStack {
            LiquidGlassBackground()
            
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(participants) { participant in
                        ParticipantCard(participant: participant)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
            }
        }
        .navigationTitle("Trip Participants")
        .navigationBarTitleDisplayMode(.large)
    }
}

// MARK: - Participant Card
struct ParticipantCard: View {
    let participant: Participant
    
    var body: some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                // Participant Header
                participantHeader
                
                // Vehicle Information
                if let vehicle = participant.user.vehicle {
                    VehicleInfoCard(vehicle: vehicle, showDetailedInfo: true)
                } else {
                    noVehicleInfo
                }
                
                // Location Status
                locationStatus
            }
        }
    }
    
    // MARK: - Participant Header
    private var participantHeader: some View {
        HStack(spacing: 12) {
            // Profile Avatar
            Circle()
                .fill(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 48, height: 48)
                .overlay(
                    Text(String(participant.user.username.prefix(1)).uppercased())
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                )
            
            // User Info
            VStack(alignment: .leading, spacing: 2) {
                Text(participant.user.username)
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                Text(participant.user.city)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            // Status Badge
            statusBadge
        }
    }
    
    // MARK: - Status Badge
    private var statusBadge: some View {
        Text(participant.status.displayName)
            .font(.caption)
            .fontWeight(.medium)
            .foregroundColor(participant.status.color)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: 6)
                    .fill(participant.status.color.opacity(0.1))
                    .overlay(
                        RoundedRectangle(cornerRadius: 6)
                            .stroke(participant.status.color.opacity(0.3), lineWidth: 1)
                    )
            )
    }
    
    // MARK: - No Vehicle Info
    private var noVehicleInfo: some View {
        HStack(spacing: 12) {
            Image(systemName: "car.circle")
                .font(.system(size: 24))
                .foregroundColor(.secondary)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("No Vehicle Information")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                Text("Participant hasn't added vehicle details yet")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(.secondary.opacity(0.1))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(.secondary.opacity(0.2), lineWidth: 1)
                )
        )
    }
    
    // MARK: - Location Status
    private var locationStatus: some View {
        HStack(spacing: 12) {
            Image(systemName: participant.isLocationSharingEnabled ? "location.fill" : "location.slash")
                .font(.system(size: 16))
                .foregroundColor(participant.isLocationSharingEnabled ? .green : .orange)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(participant.isLocationSharingEnabled ? "Location Sharing On" : "Location Sharing Off")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                if let lastUpdate = participant.lastLocationUpdate {
                    Text("Last updated: \(formatLastUpdate(lastUpdate))")
                        .font(.caption)
                        .foregroundColor(.secondary)
                } else {
                    Text("No location data available")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            if participant.isLocationSharingEnabled {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 16))
                    .foregroundColor(.green)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(.white.opacity(0.2), lineWidth: 1)
                )
        )
    }
    
    // MARK: - Helper Methods
    private func formatLastUpdate(_ date: Date) -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}

// MARK: - Participant Status Extension
extension ParticipantStatus {
    var displayName: String {
        switch self {
        case .invited:
            return "Invited"
        case .joined:
            return "Joined"
        case .active:
            return "Active"
        case .inactive:
            return "Inactive"
        case .left:
            return "Left"
        }
    }
    
    var color: Color {
        switch self {
        case .invited:
            return .orange
        case .joined:
            return .blue
        case .active:
            return .green
        case .inactive:
            return .yellow
        case .left:
            return .red
        }
    }
}

// MARK: - Sample Data for Preview
extension Participant {
    static let sampleData: [Participant] = [
        Participant(
            id: UUID(),
            userId: UUID(),
            user: User(
                id: UUID(),
                username: "John Doe",
                email: "john@example.com",
                city: "Sydney",
                dateOfBirth: Date(),
                vehicle: Vehicle(
                    make: "Toyota",
                    model: "Camry",
                    vehicleNumber: "ABC123",
                    odometerReading: 45000,
                    type: .sedan,
                    color: "Silver"
                )
            ),
            currentLocation: nil,
            lastLocationUpdate: Date().addingTimeInterval(-300), // 5 minutes ago
            isLocationSharingEnabled: true,
            status: .active
        ),
        Participant(
            id: UUID(),
            userId: UUID(),
            user: User(
                id: UUID(),
                username: "Jane Smith",
                email: "jane@example.com",
                city: "Melbourne",
                dateOfBirth: Date(),
                vehicle: Vehicle(
                    make: "Ford",
                    model: "F-150",
                    vehicleNumber: "XYZ789",
                    odometerReading: 75000,
                    type: .fourWDUte,
                    color: "Blue"
                )
            ),
            currentLocation: nil,
            lastLocationUpdate: Date().addingTimeInterval(-120), // 2 minutes ago
            isLocationSharingEnabled: true,
            status: .active
        ),
        Participant(
            id: UUID(),
            userId: UUID(),
            user: User(
                id: UUID(),
                username: "Mike Johnson",
                email: "mike@example.com",
                city: "Brisbane",
                dateOfBirth: Date(),
                vehicle: nil // No vehicle information
            ),
            currentLocation: nil,
            lastLocationUpdate: nil,
            isLocationSharingEnabled: false,
            status: .inactive
        )
    ]
}

// MARK: - Preview
#Preview {
    NavigationView {
        ParticipantListView(participants: Participant.sampleData)
    }
}