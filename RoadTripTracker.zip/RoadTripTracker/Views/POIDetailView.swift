import SwiftUI
import MapKit
import CoreLocation

struct POIDetailView: View {
    let poi: PointOfInterest
    let viewModel: POIViewModel
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // Header Image
                    headerImageView
                    
                    // Basic Info
                    basicInfoSection
                    
                    // Details Section
                    detailsSection
                    
                    // Reviews Section
                    reviewsSection
                    
                    // Action Buttons
                    actionButtonsSection
                }
                .padding()
            }
            .navigationTitle(poi.name)
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}    // MARK
: - Header Image
    
    private var headerImageView: some View {
        Group {
            if let photos = poi.photos, let firstPhoto = photos.first {
                AsyncImage(url: firstPhoto) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                } placeholder: {
                    Rectangle()
                        .fill(Color(.systemGray5))
                        .overlay(
                            Image(systemName: poi.category.iconName)
                                .font(.largeTitle)
                                .foregroundColor(.secondary)
                        )
                }
                .frame(height: 200)
                .clipped()
                .cornerRadius(12)
            } else {
                Rectangle()
                    .fill(Color(.systemGray5))
                    .frame(height: 200)
                    .overlay(
                        VStack {
                            Image(systemName: poi.category.iconName)
                                .font(.largeTitle)
                                .foregroundColor(.secondary)
                            Text(poi.category.displayName)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    )
                    .cornerRadius(12)
            }
        }
    }
    
    // MARK: - Basic Info Section
    
    private var basicInfoSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(poi.name)
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text(poi.category.displayName)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.accentColor.opacity(0.1))
                        .cornerRadius(8)
                }
                
                Spacer()
                
                if let rating = poi.rating {
                    VStack {
                        Text(String(format: "%.1f", rating))
                            .font(.title2)
                            .fontWeight(.bold)
                        HStack(spacing: 2) {
                            ForEach(0..<5) { index in
                                Image(systemName: index < Int(rating) ? "star.fill" : "star")
                                    .font(.caption)
                                    .foregroundColor(.orange)
                            }
                        }
                    }
                }
            }
            
            // Address
            HStack {
                Image(systemName: "location")
                    .foregroundColor(.secondary)
                Text(poi.address)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            // Status and Price
            HStack {
                if let isOpen = poi.isOpen {
                    HStack {
                        Circle()
                            .fill(isOpen ? Color.green : Color.red)
                            .frame(width: 8, height: 8)
                        Text(isOpen ? "Open now" : "Closed")
                            .font(.subheadline)
                            .foregroundColor(isOpen ? .green : .red)
                    }
                }
                
                if let priceLevel = poi.priceLevel {
                    Text(String(repeating: "$", count: min(priceLevel, 4)))
                        .font(.subheadline)
                        .foregroundColor(.green)
                        .fontWeight(.medium)
                }
                
                Spacer()
            }
        }
    }    // MA
RK: - Details Section
    
    private var detailsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let description = poi.description {
                Text("About")
                    .font(.headline)
                
                Text(description)
                    .font(.body)
                    .foregroundColor(.secondary)
            }
            
            if let openingHours = poi.openingHours, !openingHours.isEmpty {
                Text("Opening Hours")
                    .font(.headline)
                
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(openingHours, id: \.self) { hours in
                        Text(hours)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            if let phoneNumber = poi.phoneNumber {
                HStack {
                    Image(systemName: "phone")
                        .foregroundColor(.accentColor)
                    Text(phoneNumber)
                        .font(.subheadline)
                    Spacer()
                    Button("Call") {
                        if let url = URL(string: "tel:\(phoneNumber)") {
                            UIApplication.shared.open(url)
                        }
                    }
                    .font(.subheadline)
                    .foregroundColor(.accentColor)
                }
            }
            
            if let website = poi.website {
                HStack {
                    Image(systemName: "globe")
                        .foregroundColor(.accentColor)
                    Text("Website")
                        .font(.subheadline)
                    Spacer()
                    Button("Visit") {
                        UIApplication.shared.open(website)
                    }
                    .font(.subheadline)
                    .foregroundColor(.accentColor)
                }
            }
        }
    }
    
    // MARK: - Reviews Section
    
    private var reviewsSection: some View {
        Group {
            if let reviews = poi.reviews, !reviews.isEmpty {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Reviews")
                        .font(.headline)
                    
                    ForEach(reviews.prefix(3)) { review in
                        ReviewRowView(review: review)
                    }
                    
                    if reviews.count > 3 {
                        Button("View all \(reviews.count) reviews") {
                            // Handle view all reviews
                        }
                        .font(.subheadline)
                        .foregroundColor(.accentColor)
                    }
                }
            }
        }
    }
    
    // MARK: - Action Buttons Section
    
    private var actionButtonsSection: some View {
        VStack(spacing: 12) {
            if viewModel.canProposePOI(poi) {
                Button(action: { viewModel.showProposalSheet(for: poi) }) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("Propose as Stop")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.accentColor)
                    .cornerRadius(12)
                }
            } else if let status = viewModel.getProposalStatus(for: poi) {
                HStack {
                    Image(systemName: statusIcon(for: status))
                        .foregroundColor(statusColor(for: status))
                    Text("Status: \(status.displayName)")
                        .font(.headline)
                        .foregroundColor(statusColor(for: status))
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(statusColor(for: status).opacity(0.1))
                .cornerRadius(12)
            }
            
            Button(action: openInMaps) {
                HStack {
                    Image(systemName: "map")
                    Text("Open in Maps")
                }
                .font(.subheadline)
                .foregroundColor(.accentColor)
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
            }
        }
    }
    
    // MARK: - Helper Methods
    
    private func statusIcon(for status: POIProposalStatus) -> String {
        switch status {
        case .pending: return "clock"
        case .approved: return "checkmark.circle.fill"
        case .rejected: return "xmark.circle.fill"
        case .expired: return "exclamationmark.triangle.fill"
        }
    }
    
    private func statusColor(for status: POIProposalStatus) -> Color {
        switch status {
        case .pending: return .orange
        case .approved: return .green
        case .rejected: return .red
        case .expired: return .gray
        }
    }
    
    private func openInMaps() {
        let placemark = MKPlacemark(coordinate: poi.coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = poi.name
        mapItem.openInMaps()
    }
}

// MARK: - Review Row View

struct ReviewRowView: View {
    let review: POIReview
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(review.author)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Spacer()
                
                HStack(spacing: 2) {
                    ForEach(0..<5) { index in
                        Image(systemName: index < Int(review.rating) ? "star.fill" : "star")
                            .font(.caption)
                            .foregroundColor(.orange)
                    }
                }
            }
            
            Text(review.text)
                .font(.caption)
                .foregroundColor(.secondary)
                .lineLimit(3)
            
            Text(review.timestamp, style: .date)
                .font(.caption2)
                .foregroundColor(.tertiary)
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(8)
    }
}