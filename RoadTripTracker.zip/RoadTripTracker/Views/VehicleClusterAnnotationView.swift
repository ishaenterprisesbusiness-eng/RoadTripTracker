import SwiftUI
import MapKit
import CoreLocation

// MARK: - Vehicle Cluster Annotation
class VehicleClusterAnnotation: NSObject, MKAnnotation {
    @objc dynamic var coordinate: CLLocationCoordinate2D
    var participants: [Participant]
    var clusterRadius: CLLocationDistance
    
    var title: String? {
        return "\(participants.count) vehicles"
    }
    
    var subtitle: String? {
        return "Tap to see details"
    }
    
    init(participants: [Participant], coordinate: CLLocationCoordinate2D, radius: CLLocationDistance = 100) {
        self.participants = participants
        self.coordinate = coordinate
        self.clusterRadius = radius
        super.init()
    }
    
    func addParticipant(_ participant: Participant) {
        participants.append(participant)
    }
    
    func removeParticipant(_ participant: Participant) {
        participants.removeAll { $0.id == participant.id }
    }
    
    func updateCenterCoordinate() {
        guard !participants.isEmpty else { return }
        
        let validLocations = participants.compactMap { $0.currentLocation }
        guard !validLocations.isEmpty else { return }
        
        let avgLat = validLocations.map { $0.latitude }.reduce(0, +) / Double(validLocations.count)
        let avgLon = validLocations.map { $0.longitude }.reduce(0, +) / Double(validLocations.count)
        
        coordinate = CLLocationCoordinate2D(latitude: avgLat, longitude: avgLon)
    }
}

// MARK: - Vehicle Cluster Annotation View
class VehicleClusterAnnotationView: MKAnnotationView {
    private let containerView = UIView()
    private let countLabel = UILabel()
    private let backgroundCircle = UIView()
    
    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    private func setupView() {
        frame = CGRect(x: 0, y: 0, width: 60, height: 60)
        centerOffset = CGPoint(x: 0, y: -frame.height / 2)
        canShowCallout = true
        
        // Container view
        containerView.frame = bounds
        addSubview(containerView)
        
        // Background circle with liquid glass effect
        backgroundCircle.frame = bounds
        backgroundCircle.layer.cornerRadius = 30
        backgroundCircle.backgroundColor = UIColor.systemBlue.withAlphaComponent(0.9)
        backgroundCircle.layer.shadowColor = UIColor.black.cgColor
        backgroundCircle.layer.shadowOffset = CGSize(width: 0, height: 4)
        backgroundCircle.layer.shadowRadius = 8
        backgroundCircle.layer.shadowOpacity = 0.3
        
        // Add subtle border
        backgroundCircle.layer.borderWidth = 2
        backgroundCircle.layer.borderColor = UIColor.white.withAlphaComponent(0.3).cgColor
        
        containerView.addSubview(backgroundCircle)
        
        // Count label
        countLabel.frame = bounds
        countLabel.textAlignment = .center
        countLabel.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        countLabel.textColor = .white
        containerView.addSubview(countLabel)
        
        // Add pulsing animation
        addPulsingAnimation()
    }
    
    func configure(with clusterAnnotation: VehicleClusterAnnotation) {
        let count = clusterAnnotation.participants.count
        countLabel.text = "\(count)"
        
        // Adjust size based on count
        let size = sizeForCount(count)
        frame = CGRect(x: frame.origin.x, y: frame.origin.y, width: size, height: size)
        containerView.frame = bounds
        backgroundCircle.frame = bounds
        backgroundCircle.layer.cornerRadius = size / 2
        countLabel.frame = bounds
        
        // Adjust font size
        countLabel.font = UIFont.systemFont(ofSize: fontSizeForCount(count), weight: .bold)
        
        // Update accessibility
        accessibilityLabel = "\(count) vehicles clustered together"
        accessibilityHint = "Tap to see individual vehicles"
    }
    
    private func sizeForCount(_ count: Int) -> CGFloat {
        switch count {
        case 2...3:
            return 50
        case 4...6:
            return 60
        case 7...10:
            return 70
        default:
            return 80
        }
    }
    
    private func fontSizeForCount(_ count: Int) -> CGFloat {
        switch count {
        case 2...3:
            return 16
        case 4...6:
            return 18
        case 7...10:
            return 20
        default:
            return 22
        }
    }
    
    private func addPulsingAnimation() {
        let pulseAnimation = CABasicAnimation(keyPath: "transform.scale")
        pulseAnimation.duration = 2.0
        pulseAnimation.fromValue = 1.0
        pulseAnimation.toValue = 1.1
        pulseAnimation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        pulseAnimation.autoreverses = true
        pulseAnimation.repeatCount = .infinity
        
        backgroundCircle.layer.add(pulseAnimation, forKey: "pulse")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        countLabel.text = nil
        backgroundCircle.layer.removeAllAnimations()
        addPulsingAnimation()
    }
}

// MARK: - Vehicle Clustering Manager
class VehicleClusteringManager {
    private let clusterRadius: CLLocationDistance
    
    init(clusterRadius: CLLocationDistance = 100) {
        self.clusterRadius = clusterRadius
    }
    
    func clusterParticipants(_ participants: [Participant]) -> ([VehicleAnnotation], [VehicleClusterAnnotation]) {
        var individualAnnotations: [VehicleAnnotation] = []
        var clusterAnnotations: [VehicleClusterAnnotation] = []
        var processedParticipants: Set<UUID> = []
        
        for participant in participants {
            guard !processedParticipants.contains(participant.id),
                  let location = participant.currentLocation else {
                continue
            }
            
            // Find nearby participants
            let nearbyParticipants = findNearbyParticipants(
                to: participant,
                in: participants,
                excluding: processedParticipants
            )
            
            if nearbyParticipants.count > 1 {
                // Create cluster
                let clusterCoordinate = calculateCenterCoordinate(for: nearbyParticipants)
                let cluster = VehicleClusterAnnotation(
                    participants: nearbyParticipants,
                    coordinate: clusterCoordinate,
                    radius: clusterRadius
                )
                clusterAnnotations.append(cluster)
                
                // Mark participants as processed
                for p in nearbyParticipants {
                    processedParticipants.insert(p.id)
                }
            } else {
                // Create individual annotation
                let annotation = VehicleAnnotation(participant: participant)
                individualAnnotations.append(annotation)
                processedParticipants.insert(participant.id)
            }
        }
        
        return (individualAnnotations, clusterAnnotations)
    }
    
    private func findNearbyParticipants(
        to targetParticipant: Participant,
        in allParticipants: [Participant],
        excluding processedIds: Set<UUID>
    ) -> [Participant] {
        guard let targetLocation = targetParticipant.currentLocation else {
            return [targetParticipant]
        }
        
        let targetCLLocation = CLLocation(
            latitude: targetLocation.latitude,
            longitude: targetLocation.longitude
        )
        
        var nearbyParticipants = [targetParticipant]
        
        for participant in allParticipants {
            guard !processedIds.contains(participant.id),
                  participant.id != targetParticipant.id,
                  let participantLocation = participant.currentLocation else {
                continue
            }
            
            let participantCLLocation = CLLocation(
                latitude: participantLocation.latitude,
                longitude: participantLocation.longitude
            )
            
            let distance = targetCLLocation.distance(from: participantCLLocation)
            
            if distance <= clusterRadius {
                nearbyParticipants.append(participant)
            }
        }
        
        return nearbyParticipants
    }
    
    private func calculateCenterCoordinate(for participants: [Participant]) -> CLLocationCoordinate2D {
        let validLocations = participants.compactMap { $0.currentLocation }
        guard !validLocations.isEmpty else {
            return CLLocationCoordinate2D(latitude: 0, longitude: 0)
        }
        
        let avgLat = validLocations.map { $0.latitude }.reduce(0, +) / Double(validLocations.count)
        let avgLon = validLocations.map { $0.longitude }.reduce(0, +) / Double(validLocations.count)
        
        return CLLocationCoordinate2D(latitude: avgLat, longitude: avgLon)
    }
}

// MARK: - Cluster Detail View
struct ClusterDetailView: View {
    let participants: [Participant]
    let onParticipantSelected: (Participant) -> Void
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            List(participants, id: \.id) { participant in
                Button(action: {
                    onParticipantSelected(participant)
                    dismiss()
                }) {
                    HStack {
                        // Vehicle icon
                        Image(systemName: vehicleIcon(for: participant.user.vehicle?.type ?? .other))
                            .font(.title2)
                            .foregroundColor(.blue)
                            .frame(width: 30)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text(participant.user.username)
                                .font(.headline)
                                .foregroundColor(.primary)
                            
                            if let vehicle = participant.user.vehicle {
                                Text("\(vehicle.make) \(vehicle.model)")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                        }
                        
                        Spacer()
                        
                        // Status indicator
                        Circle()
                            .fill(statusColor(for: participant.status))
                            .frame(width: 12, height: 12)
                    }
                    .padding(.vertical, 4)
                }
                .buttonStyle(.plain)
            }
            .navigationTitle("Nearby Vehicles")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func vehicleIcon(for vehicleType: VehicleType) -> String {
        switch vehicleType {
        case .caravan:
            return "car.side.fill"
        case .fourWDUte:
            return "car.side.fill"
        case .camperVan:
            return "car.side.fill"
        case .suv:
            return "car.side.fill"
        case .sedan:
            return "car.side.fill"
        case .hatchback:
            return "car.side.fill"
        case .other:
            return "car.side.fill"
        }
    }
    
    private func statusColor(for status: ParticipantStatus) -> Color {
        switch status {
        case .active:
            return .green
        case .inactive:
            return .orange
        case .joined:
            return .blue
        case .invited:
            return .gray
        case .left:
            return .red
        }
    }
}

#Preview {
    ClusterDetailView(
        participants: [
            Participant(
                userId: UUID(),
                user: User(
                    username: "John Doe",
                    email: "john@example.com",
                    city: "San Francisco",
                    dateOfBirth: Date(),
                    vehicle: Vehicle(
                        make: "Toyota",
                        model: "Camry",
                        vehicleNumber: "ABC123",
                        odometerReading: 50000,
                        type: .sedan
                    )
                ),
                currentLocation: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
                isLocationSharingEnabled: true,
                status: .active
            ),
            Participant(
                userId: UUID(),
                user: User(
                    username: "Jane Smith",
                    email: "jane@example.com",
                    city: "San Francisco",
                    dateOfBirth: Date(),
                    vehicle: Vehicle(
                        make: "Honda",
                        model: "CR-V",
                        vehicleNumber: "XYZ789",
                        odometerReading: 30000,
                        type: .suv
                    )
                ),
                currentLocation: CLLocationCoordinate2D(latitude: 37.7750, longitude: -122.4195),
                isLocationSharingEnabled: true,
                status: .active
            )
        ],
        onParticipantSelected: { _ in }
    )
}