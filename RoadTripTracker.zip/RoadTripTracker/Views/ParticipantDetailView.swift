import SwiftUI
import CoreLocation

struct ParticipantDetailView: View {
    let participant: Participant
    let currentUserLocation: CLLocation?
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Header with participant info
                    ParticipantHeaderView(participant: participant)
                    
                    // Vehicle information
                    if let vehicle = participant.user.vehicle {
                        VehicleDetailCard(vehicle: vehicle)
                    }
                    
                    // Location and status information
                    LocationStatusCard(participant: participant, currentUserLocation: currentUserLocation)
                    
                    // Action buttons
                    ActionButtonsView(participant: participant)
                    
                    Spacer()
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Participant Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Participant Header View
struct ParticipantHeaderView: View {
    let participant: Participant
    
    var body: some View {
        VStack(spacing: 16) {
            // Profile image placeholder
            Circle()
                .fill(LinearGradient(
                    colors: [.blue.opacity(0.6), .purple.opacity(0.6)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ))
                .frame(width: 80, height: 80)
                .overlay(
                    Text(participant.user.username.prefix(2).uppercased())
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                )
                .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
            
            VStack(spacing: 4) {
                Text(participant.user.username)
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text(participant.user.city)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                // Status badge
                StatusBadge(status: participant.status)
            }
        }
        .padding()
        .background(
            LiquidGlassCard()
        )
    }
}

// MARK: - Vehicle Detail Card
struct VehicleDetailCard: View {
    let vehicle: Vehicle
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Image(systemName: vehicleIcon(for: vehicle.type))
                    .font(.title2)
                    .foregroundColor(.blue)
                
                Text("Vehicle Information")
                    .font(.headline)
                    .fontWeight(.semibold)
                
                Spacer()
            }
            
            VStack(spacing: 12) {
                VehicleInfoRow(label: "Make & Model", value: "\(vehicle.make) \(vehicle.model)")
                VehicleInfoRow(label: "License Plate", value: vehicle.vehicleNumber)
                VehicleInfoRow(label: "Type", value: vehicle.type.displayName)
                VehicleInfoRow(label: "Odometer", value: "\(vehicle.odometerReading.formatted()) km")
                
                if let color = vehicle.color {
                    VehicleInfoRow(label: "Color", value: color)
                }
            }
        }
        .padding()
        .background(
            LiquidGlassCard()
        )
    }
    
    private func vehicleIcon(for vehicleType: VehicleType) -> String {
        switch vehicleType {
        case .caravan:
            return "car.side.fill"
        case .fourWDUte:
            return "car.side.fill"
        case .camperVan:
            return "car.side.fill"
        case .suv:
            return "car.side.fill"
        case .sedan:
            return "car.side.fill"
        case .hatchback:
            return "car.side.fill"
        case .other:
            return "car.side.fill"
        }
    }
}

// MARK: - Vehicle Info Row
struct VehicleInfoRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
            
            Text(value)
                .font(.subheadline)
                .fontWeight(.medium)
        }
    }
}

// MARK: - Location Status Card
struct LocationStatusCard: View {
    let participant: Participant
    let currentUserLocation: CLLocation?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Image(systemName: "location.fill")
                    .font(.title2)
                    .foregroundColor(.green)
                
                Text("Location & Status")
                    .font(.headline)
                    .fontWeight(.semibold)
                
                Spacer()
            }
            
            VStack(spacing: 12) {
                // Location sharing status
                HStack {
                    Text("Location Sharing")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    HStack(spacing: 4) {
                        Circle()
                            .fill(participant.isLocationSharingEnabled ? .green : .red)
                            .frame(width: 8, height: 8)
                        
                        Text(participant.isLocationSharingEnabled ? "Enabled" : "Disabled")
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                }
                
                // Last location update
                if let lastUpdate = participant.lastLocationUpdate {
                    HStack {
                        Text("Last Update")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text(lastUpdate, style: .relative)
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                }
                
                // Distance from current user
                if let userLocation = currentUserLocation,
                   let participantLocation = participant.currentLocation {
                    let distance = userLocation.distance(from: CLLocation(
                        latitude: participantLocation.latitude,
                        longitude: participantLocation.longitude
                    ))
                    
                    HStack {
                        Text("Distance from You")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text(formatDistance(distance))
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                }
                
                // Coordinates (for debugging/technical users)
                if let location = participant.currentLocation {
                    HStack {
                        Text("Coordinates")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text("\(location.latitude, specifier: "%.4f"), \(location.longitude, specifier: "%.4f")")
                            .font(.caption)
                            .fontFamily(.monospaced)
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
        .padding()
        .background(
            LiquidGlassCard()
        )
    }
    
    private func formatDistance(_ distance: CLLocationDistance) -> String {
        if distance < 1000 {
            return "\(Int(distance)) m"
        } else {
            return "\(distance / 1000, specifier: "%.1f") km"
        }
    }
}

// MARK: - Status Badge
struct StatusBadge: View {
    let status: ParticipantStatus
    
    var body: some View {
        Text(status.rawValue.capitalized)
            .font(.caption)
            .fontWeight(.semibold)
            .padding(.horizontal, 12)
            .padding(.vertical, 4)
            .background(
                Capsule()
                    .fill(statusColor.opacity(0.2))
            )
            .foregroundColor(statusColor)
            .overlay(
                Capsule()
                    .stroke(statusColor.opacity(0.5), lineWidth: 1)
            )
    }
    
    private var statusColor: Color {
        switch status {
        case .active:
            return .green
        case .inactive:
            return .orange
        case .joined:
            return .blue
        case .invited:
            return .gray
        case .left:
            return .red
        }
    }
}

// MARK: - Action Buttons View
struct ActionButtonsView: View {
    let participant: Participant
    
    var body: some View {
        VStack(spacing: 12) {
            // Message button
            Button(action: {
                // TODO: Open chat with participant
            }) {
                HStack {
                    Image(systemName: "message.fill")
                    Text("Send Message")
                }
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(
                    LiquidGlassButton(isPressed: false)
                )
                .foregroundColor(.white)
            }
            
            // Call button (if phone number available)
            Button(action: {
                // TODO: Initiate call
            }) {
                HStack {
                    Image(systemName: "phone.fill")
                    Text("Call")
                }
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(
                    LiquidGlassButton(isPressed: false, color: .green)
                )
                .foregroundColor(.white)
            }
            
            // Navigate to participant
            if participant.currentLocation != nil {
                Button(action: {
                    // TODO: Open navigation to participant
                }) {
                    HStack {
                        Image(systemName: "location.north.fill")
                        Text("Navigate to Location")
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 44)
                    .background(
                        LiquidGlassButton(isPressed: false, color: .orange)
                    )
                    .foregroundColor(.white)
                }
            }
        }
        .padding()
        .background(
            LiquidGlassCard()
        )
    }
}

#Preview {
    ParticipantDetailView(
        participant: Participant(
            userId: UUID(),
            user: User(
                username: "John Doe",
                email: "john@example.com",
                city: "San Francisco",
                dateOfBirth: Date(),
                vehicle: Vehicle(
                    make: "Toyota",
                    model: "Camry",
                    vehicleNumber: "ABC123",
                    odometerReading: 50000,
                    type: .sedan,
                    color: "Blue"
                )
            ),
            currentLocation: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            lastLocationUpdate: Date(),
            isLocationSharingEnabled: true,
            status: .active
        ),
        currentUserLocation: CLLocation(latitude: 37.7849, longitude: -122.4094)
    )
}