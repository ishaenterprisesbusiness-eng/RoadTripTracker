import SwiftUI
import CoreLocation

// MARK: - Driving Statistics View
struct DrivingStatisticsView: View {
    @StateObject private var viewModel: DrivingStatisticsViewModel
    @State private var selectedTab: StatisticsTab = .current
    @State private var showingSpeedLimitSheet = false
    @State private var showingBreakSheet = false
    @State private var showingExportSheet = false
    
    private let tripId: UUID
    
    init(tripId: UUID, drivingStatisticsService: DrivingStatisticsServiceProtocol, authenticationManager: AuthenticationManagerProtocol) {
        self.tripId = tripId
        self._viewModel = StateObject(wrappedValue: DrivingStatisticsViewModel(
            drivingStatisticsService: drivingStatisticsService,
            authenticationManager: authenticationManager
        ))
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Tab Picker
                Picker("Statistics Tab", selection: $selectedTab) {
                    ForEach(StatisticsTab.allCases, id: \.self) { tab in
                        Text(tab.displayName).tag(tab)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()
                
                // Content
                TabView(selection: $selectedTab) {
                    CurrentTripView(viewModel: viewModel, tripId: tripId)
                        .tag(StatisticsTab.current)
                    
                    PerformanceView(viewModel: viewModel)
                        .tag(StatisticsTab.performance)
                    
                    ComparisonView(viewModel: viewModel)
                        .tag(StatisticsTab.comparison)
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            }
            .navigationTitle("Driving Statistics")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button("Set Speed Limit") {
                            showingSpeedLimitSheet = true
                        }
                        
                        Button("Take Break") {
                            showingBreakSheet = true
                        }
                        
                        Button("Export Data") {
                            showingExportSheet = true
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
            .sheet(isPresented: $showingSpeedLimitSheet) {
                SpeedLimitSheet(viewModel: viewModel)
            }
            .sheet(isPresented: $showingBreakSheet) {
                BreakSheet(viewModel: viewModel)
            }
            .sheet(isPresented: $showingExportSheet) {
                ExportSheet(viewModel: viewModel)
            }
            .alert("Break Suggestion", isPresented: $viewModel.showingBreakSuggestion) {
                Button("Take Break") {
                    Task {
                        await viewModel.acceptBreakSuggestion()
                    }
                }
                Button("Dismiss") {
                    Task {
                        await viewModel.dismissBreakSuggestion()
                    }
                }
            } message: {
                if let suggestion = viewModel.breakSuggestion {
                    Text(suggestion.message)
                }
            }
            .alert("Speeding Alert", isPresented: $viewModel.showingSpeedingAlert) {
                Button("OK") {
                    viewModel.dismissSpeedingAlert()
                }
            } message: {
                Text(viewModel.getSpeedWarningMessage())
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.clearError()
                }
            } message: {
                if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                }
            }
        }
        .task {
            if !viewModel.isTracking {
                await viewModel.startTracking(for: tripId)
            }
            await viewModel.loadPerformanceSummary()
            await viewModel.loadTripComparisons()
        }
    }
}

// MARK: - Statistics Tab Enum
enum StatisticsTab: String, CaseIterable {
    case current = "current"
    case performance = "performance"
    case comparison = "comparison"
    
    var displayName: String {
        switch self {
        case .current: return "Current"
        case .performance: return "Performance"
        case .comparison: return "History"
        }
    }
}

// MARK: - Current Trip View
struct CurrentTripView: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    let tripId: UUID
    
    var body: some View {
        ScrollView {
            LazyVStack(spacing: 16) {
                // Speed Card
                SpeedCard(viewModel: viewModel)
                
                // Trip Progress Card
                TripProgressCard(viewModel: viewModel)
                
                // Safety Score Card
                SafetyScoreCard(viewModel: viewModel)
                
                // Rest Period Card
                if viewModel.currentRestPeriod != nil {
                    RestPeriodCard(viewModel: viewModel)
                }
                
                // Recent Incidents Card
                if !viewModel.getRecentSpeedingIncidents().isEmpty {
                    RecentIncidentsCard(viewModel: viewModel)
                }
                
                // Controls
                ControlsCard(viewModel: viewModel)
            }
            .padding()
        }
    }
}

// MARK: - Speed Card
struct SpeedCard: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    
    var body: some View {
        GlasmorphicCard {
            VStack(spacing: 12) {
                HStack {
                    Text("Current Speed")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Circle()
                        .fill(viewModel.getSpeedColor())
                        .frame(width: 12, height: 12)
                }
                
                HStack(alignment: .bottom, spacing: 8) {
                    Text(String(format: "%.0f", viewModel.currentSpeedKmh))
                        .font(.system(size: 48, weight: .bold, design: .rounded))
                        .foregroundColor(viewModel.getSpeedColor())
                    
                    Text("km/h")
                        .font(.title2)
                        .foregroundColor(.secondary)
                        .padding(.bottom, 8)
                }
                
                HStack {
                    Text("Speed Limit: \(String(format: "%.0f", viewModel.speedLimitKmh)) km/h")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    if viewModel.speedExcessKmh > 0 {
                        Text("+\(String(format: "%.0f", viewModel.speedExcessKmh)) km/h")
                            .font(.caption)
                            .foregroundColor(viewModel.getSpeedColor())
                    }
                }
            }
        }
    }
}

// MARK: - Trip Progress Card
struct TripProgressCard: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    
    var body: some View {
        GlasmorphicCard {
            VStack(spacing: 16) {
                HStack {
                    Text("Trip Progress")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Text(viewModel.currentTripDurationFormatted)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                HStack(spacing: 24) {
                    StatisticItem(
                        title: "Distance",
                        value: viewModel.totalDistanceFormatted,
                        icon: "road.lanes"
                    )
                    
                    StatisticItem(
                        title: "Avg Speed",
                        value: viewModel.averageSpeedFormatted,
                        icon: "speedometer"
                    )
                    
                    StatisticItem(
                        title: "Rest Time",
                        value: viewModel.totalRestTimeFormatted,
                        icon: "pause.circle"
                    )
                }
            }
        }
    }
}

// MARK: - Safety Score Card
struct SafetyScoreCard: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    
    var body: some View {
        GlasmorphicCard {
            VStack(spacing: 16) {
                HStack {
                    Text("Safety Score")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Image(systemName: viewModel.safetyRating.icon)
                        .foregroundColor(viewModel.getSafetyColor())
                }
                
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(viewModel.safetyScoreFormatted)
                            .font(.system(size: 36, weight: .bold, design: .rounded))
                            .foregroundColor(viewModel.getSafetyColor())
                        
                        Text(viewModel.safetyRating.displayName)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing, spacing: 8) {
                        if let statistics = viewModel.currentStatistics {
                            Text("Incidents: \(statistics.speedingIncidents.count)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text("Breaks: \(statistics.restPeriods.count)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Rest Period Card
struct RestPeriodCard: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    
    var body: some View {
        GlasmorphicCard {
            VStack(spacing: 12) {
                HStack {
                    Text("Current Break")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    if let restPeriod = viewModel.currentRestPeriod {
                        Image(systemName: restPeriod.type.icon)
                            .foregroundColor(.blue)
                    }
                }
                
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(viewModel.getActiveRestDurationFormatted())
                            .font(.title2)
                            .fontWeight(.semibold)
                            .foregroundColor(.blue)
                        
                        if let restPeriod = viewModel.currentRestPeriod {
                            Text(restPeriod.type.displayName)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    Spacer()
                    
                    Button("End Break") {
                        Task {
                            await viewModel.endCurrentBreak()
                        }
                    }
                    .buttonStyle(GlasmorphicButtonStyle())
                }
            }
        }
    }
}

// MARK: - Recent Incidents Card
struct RecentIncidentsCard: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    
    var body: some View {
        GlasmorphicCard {
            VStack(alignment: .leading, spacing: 12) {
                Text("Recent Speeding Incidents")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                ForEach(viewModel.getRecentSpeedingIncidents()) { incident in
                    HStack {
                        Circle()
                            .fill(viewModel.getSpeedingSeverityColor(incident.severity))
                            .frame(width: 8, height: 8)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(String(format: "%.0f", incident.actualSpeedKmh)) km/h in \(String(format: "%.0f", incident.speedLimitKmh)) km/h zone")
                                .font(.caption)
                                .foregroundColor(.primary)
                            
                            Text(incident.timestamp.formatted(date: .omitted, time: .shortened))
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                        
                        Text(incident.severity.displayName)
                            .font(.caption2)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 2)
                            .background(viewModel.getSpeedingSeverityColor(incident.severity).opacity(0.2))
                            .foregroundColor(viewModel.getSpeedingSeverityColor(incident.severity))
                            .cornerRadius(8)
                    }
                }
            }
        }
    }
}

// MARK: - Controls Card
struct ControlsCard: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    
    var body: some View {
        GlasmorphicCard {
            VStack(spacing: 16) {
                Text("Controls")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                HStack(spacing: 16) {
                    if viewModel.isTracking {
                        Button("Pause Tracking") {
                            Task {
                                await viewModel.pauseTracking()
                            }
                        }
                        .buttonStyle(GlasmorphicButtonStyle())
                        
                        Button("Stop Tracking") {
                            Task {
                                await viewModel.stopTracking()
                            }
                        }
                        .buttonStyle(GlasmorphicButtonStyle(color: .red))
                    } else {
                        Button("Resume Tracking") {
                            Task {
                                await viewModel.resumeTracking()
                            }
                        }
                        .buttonStyle(GlasmorphicButtonStyle(color: .green))
                    }
                }
            }
        }
    }
}

// MARK: - Performance View
struct PerformanceView: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    
    var body: some View {
        ScrollView {
            LazyVStack(spacing: 16) {
                if let summary = viewModel.performanceSummary {
                    PerformanceSummaryCard(summary: summary)
                    
                    if let report = viewModel.performanceReport {
                        PerformanceReportCard(report: report)
                    }
                } else {
                    Text("No performance data available")
                        .foregroundColor(.secondary)
                        .padding()
                }
            }
            .padding()
        }
        .task {
            await viewModel.loadPerformanceSummary()
        }
    }
}

// MARK: - Performance Summary Card
struct PerformanceSummaryCard: View {
    let summary: DrivingPerformanceSummary
    
    var body: some View {
        GlasmorphicCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("Overall Performance")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                HStack(spacing: 24) {
                    StatisticItem(
                        title: "Total Trips",
                        value: "\(summary.totalTrips)",
                        icon: "car"
                    )
                    
                    StatisticItem(
                        title: "Total Distance",
                        value: String(format: "%.0f km", summary.totalDistanceKm),
                        icon: "road.lanes"
                    )
                    
                    StatisticItem(
                        title: "Safety Score",
                        value: String(format: "%.0f", summary.safetyScore),
                        icon: "shield"
                    )
                }
                
                HStack(spacing: 24) {
                    StatisticItem(
                        title: "Avg Speed",
                        value: String(format: "%.0f km/h", summary.averageSpeedKmh),
                        icon: "speedometer"
                    )
                    
                    StatisticItem(
                        title: "Best Speed",
                        value: String(format: "%.0f km/h", summary.bestAverageSpeedKmh),
                        icon: "star"
                    )
                    
                    StatisticItem(
                        title: "Incidents",
                        value: "\(summary.totalSpeedingIncidents)",
                        icon: "exclamationmark.triangle"
                    )
                }
            }
        }
    }
}

// MARK: - Performance Report Card
struct PerformanceReportCard: View {
    let report: PerformanceReport
    
    var body: some View {
        GlasmorphicCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("Performance Report")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Rating: \(report.summary.overallRating.displayName)")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                    
                    if !report.summary.strengths.isEmpty {
                        Text("Strengths:")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.green)
                        
                        ForEach(report.summary.strengths, id: \.self) { strength in
                            Text("• \(strength)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    if !report.summary.areasForImprovement.isEmpty {
                        Text("Areas for Improvement:")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.orange)
                        
                        ForEach(report.summary.areasForImprovement, id: \.self) { area in
                            Text("• \(area)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Comparison View
struct ComparisonView: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    
    var body: some View {
        ScrollView {
            LazyVStack(spacing: 16) {
                if !viewModel.tripComparisons.isEmpty {
                    ForEach(viewModel.tripComparisons, id: \.tripId) { trip in
                        TripComparisonCard(trip: trip, isSelected: viewModel.selectedTripForComparison == trip.tripId) {
                            viewModel.selectTripForComparison(trip.tripId)
                        }
                    }
                } else {
                    Text("No trip history available")
                        .foregroundColor(.secondary)
                        .padding()
                }
            }
            .padding()
        }
        .task {
            await viewModel.loadTripComparisons()
        }
    }
}

// MARK: - Trip Comparison Card
struct TripComparisonCard: View {
    let trip: TripComparisonData
    let isSelected: Bool
    let onTap: () -> Void
    
    var body: some View {
        GlasmorphicCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text(trip.tripName)
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Text(trip.date.formatted(date: .abbreviated, time: .omitted))
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                HStack(spacing: 16) {
                    StatisticItem(
                        title: "Distance",
                        value: String(format: "%.0f km", trip.totalDistanceKm),
                        icon: "road.lanes"
                    )
                    
                    StatisticItem(
                        title: "Time",
                        value: String(format: "%.1fh", trip.totalTimeHours),
                        icon: "clock"
                    )
                    
                    StatisticItem(
                        title: "Safety",
                        value: String(format: "%.0f", trip.safetyScore),
                        icon: "shield"
                    )
                }
            }
        }
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(isSelected ? Color.blue : Color.clear, lineWidth: 2)
        )
        .onTapGesture {
            onTap()
        }
    }
}

// MARK: - Statistic Item
struct StatisticItem: View {
    let title: String
    let value: String
    let icon: String
    
    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(.blue)
            
            Text(value)
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Text(title)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Speed Limit Sheet
struct SpeedLimitSheet: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var speedLimit: Double = 50
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                Text("Set Speed Limit")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                VStack(spacing: 16) {
                    Text("\(Int(speedLimit)) km/h")
                        .font(.system(size: 48, weight: .bold, design: .rounded))
                        .foregroundColor(.blue)
                    
                    Slider(value: $speedLimit, in: 20...130, step: 5)
                        .accentColor(.blue)
                }
                
                Spacer()
            }
            .padding()
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Set") {
                        Task {
                            await viewModel.updateSpeedLimit(speedLimit)
                            dismiss()
                        }
                    }
                }
            }
        }
        .onAppear {
            speedLimit = viewModel.speedLimitKmh
        }
    }
}

// MARK: - Break Sheet
struct BreakSheet: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var selectedBreakType: RestType = .manual
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                Text("Take a Break")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                VStack(spacing: 16) {
                    ForEach(RestType.allCases, id: \.self) { type in
                        Button {
                            selectedBreakType = type
                        } label: {
                            HStack {
                                Image(systemName: type.icon)
                                    .frame(width: 24)
                                
                                Text(type.displayName)
                                    .fontWeight(.medium)
                                
                                Spacer()
                                
                                if selectedBreakType == type {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.blue)
                                }
                            }
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(selectedBreakType == type ? Color.blue.opacity(0.1) : Color.clear)
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                
                Spacer()
            }
            .padding()
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Start Break") {
                        Task {
                            // Use a default location for now
                            let location = CLLocationCoordinate2D(latitude: 0, longitude: 0)
                            await viewModel.startManualBreak(type: selectedBreakType, location: location)
                            dismiss()
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Export Sheet
struct ExportSheet: View {
    @ObservedObject var viewModel: DrivingStatisticsViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var selectedFormat: ExportFormat = .json
    @State private var isExporting = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                Text("Export Statistics")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                VStack(spacing: 16) {
                    ForEach(ExportFormat.allCases, id: \.self) { format in
                        Button {
                            selectedFormat = format
                        } label: {
                            HStack {
                                Text(format.displayName)
                                    .fontWeight(.medium)
                                
                                Spacer()
                                
                                if selectedFormat == format {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.blue)
                                }
                            }
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(selectedFormat == format ? Color.blue.opacity(0.1) : Color.clear)
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                
                Spacer()
            }
            .padding()
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Export") {
                        Task {
                            isExporting = true
                            if let data = await viewModel.exportStatistics(format: selectedFormat) {
                                // Handle export data (save to files, share, etc.)
                            }
                            isExporting = false
                            dismiss()
                        }
                    }
                    .disabled(isExporting)
                }
            }
        }
    }
}