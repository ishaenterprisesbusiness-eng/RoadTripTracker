import SwiftUI
import MapKit

struct TripCreationView: View {
    @StateObject private var viewModel: TripCreationViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var showingDestinationDetails = false
    @State private var selectedDestinationIndex: Int?
    
    init(tripService: TripServiceProtocol, placesService: PlacesServiceProtocol) {
        self._viewModel = StateObject(wrappedValue: TripCreationViewModel(tripService: tripService, placesService: placesService))
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    tripBasicInfoSection
                    destinationSearchSection
                    destinationsListSection
                    tripSettingsSection
                    tripSummarySection
                    createTripButton
                }
                .padding()
            }
            .navigationTitle("Create Trip")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
        .alert("Error", isPresented: $viewModel.showingError) {
            Button("OK") { }
        } message: {
            Text(viewModel.errorMessage ?? "An unknown error occurred")
        }
        .onChange(of: viewModel.createdTrip) { trip in
            if trip != nil {
                dismiss()
            }
        }
    }
    
    // MARK: - Trip Basic Info Section
    
    private var tripBasicInfoSection: some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("Trip Details")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Trip Name")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    TextField("Enter trip name", text: $viewModel.tripName)
                        .textFieldStyle(LiquidGlassTextFieldStyle())
                }
            }
        }
    }
    
    // MARK: - Destination Search Section
    
    private var destinationSearchSection: some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("Add Destinations")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                HStack {
                    TextField("Search for places...", text: $viewModel.searchText)
                        .textFieldStyle(LiquidGlassTextFieldStyle())
                    
                    if viewModel.isSearching {
                        ProgressView()
                            .scaleEffect(0.8)
                    }
                }
                
                if !viewModel.searchResults.isEmpty {
                    LazyVStack(spacing: 8) {
                        ForEach(viewModel.searchResults) { result in
                            SearchResultRow(result: result) {
                                viewModel.addDestination(from: result)
                            }
                        }
                    }
                    .frame(maxHeight: 200)
                }
            }
        }
    }
    
    // MARK: - Destinations List Section
    
    private var destinationsListSection: some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text("Destinations (\(viewModel.destinations.count))")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    if viewModel.destinations.count > 2 {
                        Button("Optimize Route") {
                            Task {
                                await viewModel.optimizeRoute()
                            }
                        }
                        .font(.caption)
                        .foregroundColor(.accentColor)
                    }
                }
                
                if viewModel.destinations.isEmpty {
                    Text("No destinations added yet")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.vertical, 20)
                } else {
                    LazyVStack(spacing: 8) {
                        ForEach(Array(viewModel.destinations.enumerated()), id: \.element.id) { index, destination in
                            DestinationRow(
                                destination: destination,
                                index: index,
                                onEdit: {
                                    selectedDestinationIndex = index
                                    showingDestinationDetails = true
                                },
                                onDelete: {
                                    viewModel.removeDestination(at: index)
                                }
                            )
                        }
                        .onMove(perform: viewModel.moveDestination)
                    }
                }
            }
        }
    }
    
    // MARK: - Trip Settings Section
    
    private var tripSettingsSection: some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("Trip Settings")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                VStack(spacing: 12) {
                    Toggle("Public Trip", isOn: $viewModel.isPublic)
                    Toggle("Allow Participant Invites", isOn: $viewModel.allowParticipantInvites)
                    Toggle("Enable Budget Tracking", isOn: $viewModel.enableBudgetTracking)
                    
                    if viewModel.enableBudgetTracking {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Total Budget")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            
                            TextField("0.00", value: $viewModel.totalBudget, format: .currency(code: "USD"))
                                .textFieldStyle(LiquidGlassTextFieldStyle())
                                .keyboardType(.decimalPad)
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - Trip Summary Section
    
    private var tripSummarySection: some View {
        LiquidGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("Trip Summary")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                if !viewModel.destinations.isEmpty {
                    VStack(spacing: 8) {
                        HStack {
                            Text("Estimated Distance:")
                                .foregroundColor(.secondary)
                            Spacer()
                            Text(formatDistance(viewModel.estimatedTripDistance))
                                .fontWeight(.medium)
                        }
                        
                        HStack {
                            Text("Estimated Duration:")
                                .foregroundColor(.secondary)
                            Spacer()
                            Text(formatDuration(viewModel.estimatedTripDuration))
                                .fontWeight(.medium)
                        }
                        
                        if viewModel.enableBudgetTracking && viewModel.totalBudget > 0 {
                            HStack {
                                Text("Budget:")
                                    .foregroundColor(.secondary)
                                Spacer()
                                Text(viewModel.totalBudget, format: .currency(code: "USD"))
                                    .fontWeight(.medium)
                            }
                        }
                    }
                } else {
                    Text("Add destinations to see trip summary")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .center)
                }
            }
        }
    }
    
    // MARK: - Create Trip Button
    
    private var createTripButton: some View {
        Button(action: {
            Task {
                await viewModel.createTrip()
            }
        }) {
            HStack {
                if viewModel.isCreatingTrip {
                    ProgressView()
                        .scaleEffect(0.8)
                        .foregroundColor(.white)
                }
                
                Text(viewModel.isCreatingTrip ? "Creating Trip..." : "Create Trip")
                    .fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(viewModel.canCreateTrip ? Color.accentColor : Color.gray)
            )
            .foregroundColor(.white)
        }
        .disabled(!viewModel.canCreateTrip)
    }
    
    // MARK: - Helper Methods
    
    private func formatDistance(_ distance: CLLocationDistance) -> String {
        let formatter = MKDistanceFormatter()
        formatter.unitStyle = .abbreviated
        return formatter.string(fromDistance: distance)
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        
        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }
}

// MARK: - Search Result Row

struct SearchResultRow: View {
    let result: PlaceSearchResult
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(result.name)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.leading)
                    
                    Text(result.address)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.leading)
                }
                
                Spacer()
                
                Image(systemName: "plus.circle.fill")
                    .foregroundColor(.accentColor)
            }
            .padding(.vertical, 8)
            .padding(.horizontal, 12)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.gray.opacity(0.1))
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Destination Row

struct DestinationRow: View {
    let destination: Destination
    let index: Int
    let onEdit: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("\(index + 1)")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(width: 20, height: 20)
                        .background(Circle().fill(Color.accentColor))
                    
                    Text(destination.name)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                }
                
                Text(destination.address)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.leading)
                
                if let type = destination.type, type != .waypoint {
                    Text(type.rawValue.capitalized)
                        .font(.caption2)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(
                            RoundedRectangle(cornerRadius: 4)
                                .fill(Color.accentColor.opacity(0.2))
                        )
                        .foregroundColor(.accentColor)
                }
            }
            
            Spacer()
            
            HStack(spacing: 8) {
                Button(action: onEdit) {
                    Image(systemName: "pencil")
                        .foregroundColor(.blue)
                }
                
                Button(action: onDelete) {
                    Image(systemName: "trash")
                        .foregroundColor(.red)
                }
            }
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 12)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.gray.opacity(0.05))
        )
    }
}

#Preview {
    TripCreationView(
        tripService: MockTripService(),
        placesService: MockPlacesService()
    )
}

// MARK: - Mock Services for Preview

class MockTripService: TripServiceProtocol {
    var activeTrip: Trip? = nil
    var tripUpdates: AnyPublisher<Trip?, Never> = Just(nil).eraseToAnyPublisher()
    
    func createTrip(name: String, destinations: [Destination], settings: TripSettings) async throws -> Trip {
        return Trip(name: name, code: "ABC123", createdBy: UUID(), destinations: destinations)
    }
    
    func joinTrip(code: String) async throws -> Trip {
        return Trip(name: "Test Trip", code: code, createdBy: UUID())
    }
    
    func leaveTrip(_ tripId: UUID) async throws { }
    func updateTrip(_ trip: Trip) async throws { }
    func deleteTrip(_ tripId: UUID) async throws { }
    func generateTripCode() -> String { return "ABC123" }
    func validateTripCode(_ code: String) async throws -> Bool { return true }
    func getTripHistory(for userId: UUID) async throws -> [Trip] { return [] }
    func optimizeRoute(destinations: [Destination]) async throws -> [Destination] { return destinations }
    func addDestination(_ destination: Destination, to tripId: UUID) async throws { }
    func removeDestination(_ destinationId: UUID, from tripId: UUID) async throws { }
    func reorderDestinations(_ destinations: [Destination], in tripId: UUID) async throws { }
}

class MockPlacesService: PlacesServiceProtocol {
    func searchPlaces(query: String, region: MKCoordinateRegion?) async throws -> [PlaceSearchResult] {
        return [
            PlaceSearchResult(id: "1", name: "Test Restaurant", address: "123 Main St", coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194), category: .restaurant),
            PlaceSearchResult(id: "2", name: "Test Gas Station", address: "456 Oak Ave", coordinate: CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094), category: .gasStation)
        ]
    }
    
    func getPlaceDetails(for placeId: String) async throws -> PlaceDetails {
        throw PlacesServiceError.notImplemented
    }
    
    func getNearbyPlaces(coordinate: CLLocationCoordinate2D, radius: Double, category: PlaceCategory) async throws -> [PlaceSearchResult] {
        return []
    }
}