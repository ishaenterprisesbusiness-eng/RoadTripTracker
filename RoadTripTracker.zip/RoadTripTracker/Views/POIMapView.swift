import SwiftUI
import MapKit

struct POIMapView: View {
    let pois: [PointOfInterest]
    let viewModel: POIViewModel
    
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    )
    @State private var selectedPOI: PointOfInterest?
    
    var body: some View {
        ZStack {
            Map(coordinateRegion: $region, annotationItems: pois) { poi in
                MapAnnotation(coordinate: poi.coordinate) {
                    POIMapAnnotation(poi: poi, isSelected: selectedPOI?.id == poi.id) {
                        selectedPOI = poi
                        viewModel.selectPOI(poi)
                    }
                }
            }
            .onAppear {
                updateRegionForPOIs()
            }
            .onChange(of: pois) { _ in
                updateRegionForPOIs()
            }
            
            // Selected POI Card
            if let selectedPOI = selectedPOI {
                VStack {
                    Spacer()
                    
                    POIMapCard(poi: selectedPOI, viewModel: viewModel) {
                        self.selectedPOI = nil
                    }
                    .padding()
                }
            }
        }
    }
    
    private func updateRegionForPOIs() {
        guard !pois.isEmpty else { return }
        
        if pois.count == 1 {
            region = MKCoordinateRegion(
                center: pois[0].coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
            )
        } else {
            let coordinates = pois.map { $0.coordinate }
            let minLat = coordinates.map { $0.latitude }.min() ?? 0
            let maxLat = coordinates.map { $0.latitude }.max() ?? 0
            let minLon = coordinates.map { $0.longitude }.min() ?? 0
            let maxLon = coordinates.map { $0.longitude }.max() ?? 0
            
            let center = CLLocationCoordinate2D(
                latitude: (minLat + maxLat) / 2,
                longitude: (minLon + maxLon) / 2
            )
            
            let span = MKCoordinateSpan(
                latitudeDelta: (maxLat - minLat) * 1.2,
                longitudinalDelta: (maxLon - minLon) * 1.2
            )
            
            region = MKCoordinateRegion(center: center, span: span)
        }
    }
}

// MARK: - POI Map Annotation

struct POIMapAnnotation: View {
    let poi: PointOfInterest
    let isSelected: Bool
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 0) {
                Image(systemName: poi.category.iconName)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.white)
                    .frame(width: 32, height: 32)
                    .background(
                        Circle()
                            .fill(categoryColor)
                            .shadow(color: .black.opacity(0.3), radius: 2, x: 0, y: 1)
                    )
                    .scaleEffect(isSelected ? 1.2 : 1.0)
                
                // Pointer
                Triangle()
                    .fill(categoryColor)
                    .frame(width: 8, height: 6)
                    .offset(y: -1)
                    .scaleEffect(isSelected ? 1.2 : 1.0)
            }
        }
        .buttonStyle(PlainButtonStyle())
        .animation(.easeInOut(duration: 0.2), value: isSelected)
    }
    
    private var categoryColor: Color {
        switch poi.category {
        case .nature: return .green
        case .history: return .brown
        case .entertainment: return .purple
        case .shopping: return .blue
        case .culture: return .orange
        case .sports: return .red
        case .food: return .yellow
        case .accommodation: return .indigo
        case .services: return .gray
        case .other: return .accentColor
        }
    }
}

// MARK: - Triangle Shape

struct Triangle: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.midX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.closeSubpath()
        return path
    }
}

// MARK: - POI Map Card

struct POIMapCard: View {
    let poi: PointOfInterest
    let viewModel: POIViewModel
    let onDismiss: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            // POI Icon
            Image(systemName: poi.category.iconName)
                .font(.title2)
                .foregroundColor(.accentColor)
                .frame(width: 40, height: 40)
            
            // POI Info
            VStack(alignment: .leading, spacing: 4) {
                Text(poi.name)
                    .font(.headline)
                    .lineLimit(1)
                
                Text(poi.category.displayName)
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                if let rating = poi.rating {
                    HStack {
                        Text(String(format: "%.1f", rating))
                            .font(.caption)
                            .fontWeight(.medium)
                        
                        HStack(spacing: 1) {
                            ForEach(0..<5) { index in
                                Image(systemName: index < Int(rating) ? "star.fill" : "star")
                                    .font(.caption2)
                                    .foregroundColor(.orange)
                            }
                        }
                    }
                }
            }
            
            Spacer()
            
            // Action Buttons
            VStack(spacing: 8) {
                Button(action: { viewModel.selectPOI(poi) }) {
                    Image(systemName: "info.circle")
                        .font(.title3)
                        .foregroundColor(.accentColor)
                }
                
                if viewModel.canProposePOI(poi) {
                    Button(action: { viewModel.showProposalSheet(for: poi) }) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title3)
                            .foregroundColor(.accentColor)
                    }
                }
            }
            
            // Dismiss Button
            Button(action: onDismiss) {
                Image(systemName: "xmark.circle.fill")
                    .font(.title3)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(.ultraThinMaterial)
                .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
        )
    }
}