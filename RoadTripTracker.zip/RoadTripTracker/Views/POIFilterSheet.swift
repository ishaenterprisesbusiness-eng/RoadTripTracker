import SwiftUI
import CoreLocation

struct POIFilterSheet: View {
    let viewModel: POIViewModel
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedCategories: Set<POICategory>
    @State private var minRating: Double
    @State private var maxDistance: Double
    @State private var sortBy: POISortOption
    @State private var isOpenNow: Bool
    @State private var hasPhotos: Bool
    
    init(viewModel: POIViewModel) {
        self.viewModel = viewModel
        self._selectedCategories = State(initialValue: viewModel.searchFilter.categories)
        self._minRating = State(initialValue: viewModel.searchFilter.minRating ?? 0.0)
        self._maxDistance = State(initialValue: Double(viewModel.searchFilter.maxDistance ?? 10000) / 1000) // Convert to km
        self._sortBy = State(initialValue: viewModel.searchFilter.sortBy)
        self._isOpenNow = State(initialValue: viewModel.searchFilter.isOpenNow ?? false)
        self._hasPhotos = State(initialValue: viewModel.searchFilter.hasPhotos ?? false)
    }
    
    var body: some View {
        NavigationView {
            Form {
                // Categories Section
                categoriesSection
                
                // Rating Section
                ratingSection
                
                // Distance Section
                distanceSection
                
                // Sort Section
                sortSection
                
                // Additional Filters
                additionalFiltersSection
            }
            .navigationTitle("Filter Places")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Reset") {
                        resetFilters()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Apply") {
                        applyFilters()
                        dismiss()
                    }
                    .fontWeight(.semibold)
                }
            }
        }
    }
}    //
 MARK: - Categories Section
    
    private var categoriesSection: some View {
        Section("Categories") {
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 2), spacing: 12) {
                ForEach(POICategory.allCases, id: \.self) { category in
                    CategoryToggleView(
                        category: category,
                        isSelected: selectedCategories.contains(category)
                    ) {
                        if selectedCategories.contains(category) {
                            selectedCategories.remove(category)
                        } else {
                            selectedCategories.insert(category)
                        }
                    }
                }
            }
            .padding(.vertical, 8)
        }
    }
    
    // MARK: - Rating Section
    
    private var ratingSection: some View {
        Section("Minimum Rating") {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Any")
                    Spacer()
                    Text(String(format: "%.1f+ ⭐", minRating))
                        .fontWeight(.medium)
                }
                
                Slider(value: $minRating, in: 0...5, step: 0.5) {
                    Text("Rating")
                } minimumValueLabel: {
                    Text("0")
                        .font(.caption)
                } maximumValueLabel: {
                    Text("5")
                        .font(.caption)
                }
            }
            .padding(.vertical, 4)
        }
    }
    
    // MARK: - Distance Section
    
    private var distanceSection: some View {
        Section("Maximum Distance") {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Within")
                    Spacer()
                    Text("\(Int(maxDistance)) km")
                        .fontWeight(.medium)
                }
                
                Slider(value: $maxDistance, in: 1...50, step: 1) {
                    Text("Distance")
                } minimumValueLabel: {
                    Text("1km")
                        .font(.caption)
                } maximumValueLabel: {
                    Text("50km")
                        .font(.caption)
                }
            }
            .padding(.vertical, 4)
        }
    }
    
    // MARK: - Sort Section
    
    private var sortSection: some View {
        Section("Sort By") {
            ForEach(POISortOption.allCases, id: \.self) { option in
                HStack {
                    Text(option.displayName)
                    Spacer()
                    if sortBy == option {
                        Image(systemName: "checkmark")
                            .foregroundColor(.accentColor)
                    }
                }
                .contentShape(Rectangle())
                .onTapGesture {
                    sortBy = option
                }
            }
        }
    }
    
    // MARK: - Additional Filters Section
    
    private var additionalFiltersSection: some View {
        Section("Additional Filters") {
            Toggle("Open now", isOn: $isOpenNow)
            Toggle("Has photos", isOn: $hasPhotos)
        }
    }
    
    // MARK: - Actions
    
    private func resetFilters() {
        selectedCategories = Set(POICategory.allCases)
        minRating = 0.0
        maxDistance = 10.0
        sortBy = .distance
        isOpenNow = false
        hasPhotos = false
    }
    
    private func applyFilters() {
        viewModel.searchFilter = POISearchFilter(
            categories: selectedCategories,
            minRating: minRating > 0 ? minRating : nil,
            maxDistance: maxDistance * 1000, // Convert back to meters
            isOpenNow: isOpenNow ? true : nil,
            hasPhotos: hasPhotos ? true : nil,
            sortBy: sortBy
        )
    }
}

// MARK: - Category Toggle View

struct CategoryToggleView: View {
    let category: POICategory
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: category.iconName)
                    .font(.subheadline)
                    .foregroundColor(isSelected ? .white : .accentColor)
                
                Text(category.displayName)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(isSelected ? .white : .primary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(isSelected ? Color.accentColor : Color(.systemGray6))
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}