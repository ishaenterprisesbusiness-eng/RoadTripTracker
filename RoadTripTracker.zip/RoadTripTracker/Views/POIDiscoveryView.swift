import SwiftUI
import MapKit
import CoreLocation

struct POIDiscoveryView: View {
    @StateObject private var viewModel: POIViewModel
    @State private var selectedTab = 0
    @State private var showingMap = false
    
    init(poiService: POIServiceProtocol, locationManager: LocationManagerProtocol) {
        self._viewModel = StateObject(wrappedValue: POIViewModel(poiService: poiService, locationManager: locationManager))
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Search and Filter Bar
                searchAndFilterBar
                
                // Tab Selector
                tabSelector
                
                // Content
                TabView(selection: $selectedTab) {
                    // Nearby POIs
                    nearbyPOIsView
                        .tag(0)
                    
                    // Search Results
                    searchResultsView
                        .tag(1)
                    
                    // Proposals
                    proposalsView
                        .tag(2)
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            }
            .navigationTitle("Discover Places")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingMap.toggle() }) {
                        Image(systemName: showingMap ? "list.bullet" : "map")
                    }
                }
            }
            .sheet(isPresented: $viewModel.showingPOIDetails) {
                if let poi = viewModel.selectedPOI {
                    POIDetailView(poi: poi, viewModel: viewModel)
                }
            }
            .sheet(isPresented: $viewModel.showingProposalSheet) {
                if let poi = viewModel.selectedPOI {
                    POIProposalSheet(poi: poi, viewModel: viewModel)
                }
            }
            .sheet(isPresented: $viewModel.showingFilterSheet) {
                POIFilterSheet(viewModel: viewModel)
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                }
            }
        }
    }
    
    // MARK: - Search and Filter Bar
    
    private var searchAndFilterBar: some View {
        HStack {
            // Search Field
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)
                
                TextField("Search attractions, landmarks...", text: $viewModel.searchQuery)
                    .textFieldStyle(PlainTextFieldStyle())
                
                if !viewModel.searchQuery.isEmpty {
                    Button(action: viewModel.clearSearch) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color(.systemGray6))
            .cornerRadius(10)
            
            // Filter Button
            Button(action: viewModel.showFilterSheet) {
                Image(systemName: "slider.horizontal.3")
                    .foregroundColor(.primary)
                    .padding(8)
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
    }
    
    // MARK: - Tab Selector
    
    private var tabSelector: some View {
        HStack {
            TabButton(title: "Nearby", isSelected: selectedTab == 0) {
                selectedTab = 0
            }
            
            TabButton(title: "Search", isSelected: selectedTab == 1) {
                selectedTab = 1
            }
            
            TabButton(title: "Proposals", isSelected: selectedTab == 2) {
                selectedTab = 2
                Task {
                    await viewModel.loadPOIProposals()
                }
            }
        }
        .padding(.horizontal)
        .padding(.bottom, 8)
    }
    
    // MARK: - Nearby POIs View
    
    private var nearbyPOIsView: some View {
        Group {
            if showingMap {
                POIMapView(pois: viewModel.nearbyPOIs, viewModel: viewModel)
            } else {
                POIListView(pois: viewModel.nearbyPOIs, viewModel: viewModel, title: "Nearby Attractions")
            }
        }
        .onAppear {
            Task {
                await viewModel.discoverNearbyPOIs()
            }
        }
    }
    
    // MARK: - Search Results View
    
    private var searchResultsView: some View {
        Group {
            if showingMap {
                POIMapView(pois: viewModel.searchResults, viewModel: viewModel)
            } else {
                POIListView(pois: viewModel.searchResults, viewModel: viewModel, title: "Search Results")
            }
        }
    }
    
    // MARK: - Proposals View
    
    private var proposalsView: some View {
        POIProposalsView(viewModel: viewModel)
    }
}

// MARK: - Tab Button

struct TabButton: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.subheadline)
                .fontWeight(isSelected ? .semibold : .regular)
                .foregroundColor(isSelected ? .white : .primary)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(isSelected ? Color.accentColor : Color.clear)
                )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - POI List View

struct POIListView: View {
    let pois: [PointOfInterest]
    let viewModel: POIViewModel
    let title: String
    
    var body: some View {
        Group {
            if viewModel.isLoading {
                ProgressView("Discovering places...")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if pois.isEmpty {
                ContentUnavailableView(
                    "No Places Found",
                    systemImage: "mappin.slash",
                    description: Text("Try adjusting your search or filters")
                )
            } else {
                List(pois) { poi in
                    POIRowView(poi: poi, viewModel: viewModel)
                        .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                        .listRowSeparator(.hidden)
                }
                .listStyle(PlainListStyle())
            }
        }
    }
}

// MARK: - POI Row View

struct POIRowView: View {
    let poi: PointOfInterest
    let viewModel: POIViewModel
    
    var body: some View {
        Button(action: { viewModel.selectPOI(poi) }) {
            HStack(spacing: 12) {
                // Category Icon
                Image(systemName: poi.category.iconName)
                    .font(.title2)
                    .foregroundColor(.accentColor)
                    .frame(width: 30, height: 30)
                
                // POI Info
                VStack(alignment: .leading, spacing: 4) {
                    Text(poi.name)
                        .font(.headline)
                        .foregroundColor(.primary)
                        .lineLimit(1)
                    
                    Text(poi.address)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                    
                    HStack {
                        if let rating = poi.rating {
                            Text(viewModel.formatRating(rating))
                                .font(.caption)
                                .foregroundColor(.orange)
                        }
                        
                        if let priceLevel = poi.priceLevel {
                            Text(viewModel.formatPriceLevel(priceLevel))
                                .font(.caption)
                                .foregroundColor(.green)
                        }
                        
                        Text(viewModel.isOpenNow(poi))
                            .font(.caption)
                            .foregroundColor(poi.isOpen == true ? .green : .red)
                        
                        Spacer()
                        
                        // Proposal Status
                        if let status = viewModel.getProposalStatus(for: poi) {
                            ProposalStatusBadge(status: status)
                        }
                    }
                }
                
                Spacer()
                
                // Action Button
                if viewModel.canProposePOI(poi) {
                    Button(action: { viewModel.showProposalSheet(for: poi) }) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                            .foregroundColor(.accentColor)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .padding(.vertical, 4)
        }
        .buttonStyle(PlainButtonStyle())
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.systemBackground))
                .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
        )
    }
}

// MARK: - Proposal Status Badge

struct ProposalStatusBadge: View {
    let status: POIProposalStatus
    
    var body: some View {
        Text(status.displayName)
            .font(.caption2)
            .fontWeight(.medium)
            .padding(.horizontal, 6)
            .padding(.vertical, 2)
            .background(
                RoundedRectangle(cornerRadius: 4)
                    .fill(backgroundColor)
            )
            .foregroundColor(textColor)
    }
    
    private var backgroundColor: Color {
        switch status {
        case .pending: return .orange.opacity(0.2)
        case .approved: return .green.opacity(0.2)
        case .rejected: return .red.opacity(0.2)
        case .expired: return .gray.opacity(0.2)
        }
    }
    
    private var textColor: Color {
        switch status {
        case .pending: return .orange
        case .approved: return .green
        case .rejected: return .red
        case .expired: return .gray
        }
    }
}

#Preview {
    POIDiscoveryView(
        poiService: POIService(
            placesService: PlacesService(),
            notificationService: NotificationService(),
            tripService: TripService()
        ),
        locationManager: LocationManager()
    )
}