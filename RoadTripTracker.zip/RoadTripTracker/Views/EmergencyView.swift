import SwiftUI
import CoreLocation

// MARK: - Emergency View
struct EmergencyView: View {
    @StateObject private var viewModel: EmergencyViewModel
    @State private var showingConfirmation = false
    @State private var confirmationMessage = ""
    
    init(emergencyService: EmergencyServiceProtocol, locationManager: LocationManager) {
        self._viewModel = StateObject(wrappedValue: EmergencyViewModel(
            emergencyService: emergencyService,
            locationManager: locationManager
        ))
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Emergency Status Section
                    emergencyStatusSection
                    
                    // Quick Actions Section
                    quickActionsSection
                    
                    // Emergency Services Section
                    emergencyServicesSection
                    
                    // Recent Alerts Section
                    if !viewModel.emergencyAlerts.isEmpty {
                        recentAlertsSection
                    }
                }
                .padding()
            }
            .navigationTitle("Emergency")
            .navigationBarTitleDisplayMode(.large)
            .onAppear {
                viewModel.loadNearbyEmergencyServices()
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.dismissError()
                }
            } message: {
                if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                }
            }
            .sheet(isPresented: $viewModel.showingEmergencyAlert) {
                EmergencyAlertSheet(viewModel: viewModel)
            }
            .sheet(isPresented: $viewModel.showingBreakdownAssistance) {
                BreakdownAssistanceSheet(viewModel: viewModel)
            }
            .sheet(isPresented: $viewModel.showingEmergencyServices) {
                EmergencyServicesSheet(viewModel: viewModel)
            }
            .confirmationDialog("Confirm Action", isPresented: $showingConfirmation) {
                Button("Confirm", role: .destructive) {
                    handleConfirmation()
                }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text(confirmationMessage)
            }
        }
    }
    
    // MARK: - Emergency Status Section
    private var emergencyStatusSection: some View {
        VStack(spacing: 16) {
            if viewModel.isEmergencyActive {
                // Active Emergency Status
                VStack(spacing: 12) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 48))
                        .foregroundColor(.red)
                        .scaleEffect(viewModel.isEmergencyActive ? 1.1 : 1.0)
                        .animation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true), value: viewModel.isEmergencyActive)
                    
                    Text("Emergency Alert Active")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                    
                    Text("Your emergency alert has been sent to trip participants and emergency contacts.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                    
                    Button("Cancel Emergency Alert") {
                        confirmationMessage = "Are you sure you want to cancel the emergency alert?"
                        showingConfirmation = true
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .tint(.red)
                }
                .padding()
                .background(Color.red.opacity(0.1))
                .cornerRadius(16)
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(Color.red.opacity(0.3), lineWidth: 2)
                )
            } else {
                // Normal Status
                VStack(spacing: 12) {
                    Image(systemName: "shield.checkered")
                        .font(.system(size: 48))
                        .foregroundColor(.green)
                    
                    Text("Emergency Services Ready")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Text("Tap the panic button if you need immediate assistance.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                }
                .padding()
                .background(Color.green.opacity(0.1))
                .cornerRadius(16)
            }
        }
    }
    
    // MARK: - Quick Actions Section
    private var quickActionsSection: some View {
        VStack(spacing: 16) {
            Text("Quick Actions")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            LazyVGrid(columns: [
                GridItem(.flexible()),
                GridItem(.flexible())
            ], spacing: 16) {
                // Panic Button
                EmergencyActionCard(
                    title: "Panic Alert",
                    subtitle: "Send emergency alert",
                    icon: "exclamationmark.triangle.fill",
                    color: .red,
                    isDisabled: viewModel.isEmergencyActive
                ) {
                    viewModel.showingEmergencyAlert = true
                }
                
                // Breakdown Assistance
                EmergencyActionCard(
                    title: "Breakdown",
                    subtitle: "Request assistance",
                    icon: "car.fill",
                    color: .orange
                ) {
                    viewModel.showingBreakdownAssistance = true
                }
                
                // Emergency Services
                EmergencyActionCard(
                    title: "Services",
                    subtitle: "Find nearby help",
                    icon: "cross.circle.fill",
                    color: .blue
                ) {
                    viewModel.showingEmergencyServices = true
                }
                
                // Call 000
                EmergencyActionCard(
                    title: "Call 000",
                    subtitle: "Emergency services",
                    icon: "phone.fill",
                    color: .red
                ) {
                    if let phoneURL = URL(string: "tel://000") {
                        UIApplication.shared.open(phoneURL)
                    }
                }
            }
        }
    }
    
    // MARK: - Emergency Services Section
    private var emergencyServicesSection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Nearby Emergency Services")
                    .font(.headline)
                
                Spacer()
                
                Button("Refresh") {
                    viewModel.loadNearbyEmergencyServices()
                }
                .font(.caption)
                .foregroundColor(.blue)
            }
            
            if viewModel.isLoadingServices {
                ProgressView("Loading services...")
                    .frame(maxWidth: .infinity)
                    .padding()
            } else if viewModel.nearbyEmergencyServices.isEmpty {
                Text("No emergency services found nearby")
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding()
            } else {
                LazyVStack(spacing: 12) {
                    ForEach(viewModel.nearbyEmergencyServices.prefix(3)) { service in
                        EmergencyServiceRow(service: service) {
                            viewModel.callEmergencyService(service)
                        } onDirections: {
                            viewModel.getDirectionsToService(service)
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - Recent Alerts Section
    private var recentAlertsSection: some View {
        VStack(spacing: 16) {
            Text("Recent Alerts")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            LazyVStack(spacing: 12) {
                ForEach(viewModel.emergencyAlerts.prefix(5)) { alert in
                    EmergencyAlertRow(alert: EmergencyAlertDisplayModel(alert: alert, userName: "User"))
                }
            }
        }
    }
    
    // MARK: - Helper Methods
    private func handleConfirmation() {
        if viewModel.isEmergencyActive {
            viewModel.cancelEmergencyAlert()
        }
    }
}

// MARK: - Emergency Action Card
struct EmergencyActionCard: View {
    let title: String
    let subtitle: String
    let icon: String
    let color: Color
    var isDisabled: Bool = false
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 32))
                    .foregroundColor(isDisabled ? .gray : color)
                
                VStack(spacing: 4) {
                    Text(title)
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Text(subtitle)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color(UIColor.systemBackground))
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
        }
        .disabled(isDisabled)
        .opacity(isDisabled ? 0.6 : 1.0)
    }
}

// MARK: - Emergency Service Row
struct EmergencyServiceRow: View {
    let service: EmergencyService
    let onCall: () -> Void
    let onDirections: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            // Service Icon
            Image(systemName: serviceIcon)
                .font(.title2)
                .foregroundColor(serviceColor)
                .frame(width: 32, height: 32)
            
            // Service Info
            VStack(alignment: .leading, spacing: 4) {
                Text(service.name)
                    .font(.headline)
                    .lineLimit(1)
                
                Text(service.address)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                
                HStack {
                    Text("\(Int(service.distance))m away")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    
                    if service.isOpen24Hours {
                        Text("• 24/7")
                            .font(.caption2)
                            .foregroundColor(.green)
                    }
                }
            }
            
            Spacer()
            
            // Action Buttons
            HStack(spacing: 8) {
                Button(action: onCall) {
                    Image(systemName: "phone.fill")
                        .font(.caption)
                        .foregroundColor(.white)
                        .frame(width: 28, height: 28)
                        .background(Color.green)
                        .clipShape(Circle())
                }
                
                Button(action: onDirections) {
                    Image(systemName: "location.fill")
                        .font(.caption)
                        .foregroundColor(.white)
                        .frame(width: 28, height: 28)
                        .background(Color.blue)
                        .clipShape(Circle())
                }
            }
        }
        .padding()
        .background(Color(UIColor.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
    }
    
    private var serviceIcon: String {
        switch service.type {
        case .hospital: return "cross.circle.fill"
        case .police: return "shield.fill"
        case .fireStation: return "flame.fill"
        case .mechanic: return "wrench.fill"
        case .towingService: return "car.fill"
        }
    }
    
    private var serviceColor: Color {
        switch service.type {
        case .hospital: return .red
        case .police: return .blue
        case .fireStation: return .red
        case .mechanic: return .orange
        case .towingService: return .orange
        }
    }
}

// MARK: - Emergency Alert Row
struct EmergencyAlertRow: View {
    let alert: EmergencyAlertDisplayModel
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: alert.alertTypeIcon)
                .font(.title2)
                .foregroundColor(alert.alertTypeColor)
                .frame(width: 32, height: 32)
            
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(alert.alert.alertType.rawValue.capitalized)
                        .font(.headline)
                    
                    Spacer()
                    
                    Text(alert.timeAgo)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Text("From: \(alert.userName)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                if let message = alert.alert.message {
                    Text(message)
                        .font(.caption)
                        .foregroundColor(.primary)
                        .lineLimit(2)
                }
            }
            
            Spacer()
            
            Circle()
                .fill(alert.statusColor)
                .frame(width: 12, height: 12)
        }
        .padding()
        .background(Color(UIColor.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
    }
}

// MARK: - Preview
struct EmergencyView_Previews: PreviewProvider {
    static var previews: some View {
        EmergencyView(
            emergencyService: MockEmergencyService(),
            locationManager: LocationManager()
        )
    }
}

// MARK: - Mock Emergency Service
class MockEmergencyService: EmergencyServiceProtocol {
    var emergencyAlerts: AnyPublisher<EmergencyAlert, Never> {
        Just(EmergencyAlert(
            tripId: UUID(),
            userId: UUID(),
            alertType: .panic,
            location: CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631)
        )).eraseToAnyPublisher()
    }
    
    func triggerEmergencyAlert(location: CLLocationCoordinate2D, message: String?) async throws {
        // Mock implementation
    }
    
    func sendBreakdownAssistance(location: CLLocationCoordinate2D, vehicleInfo: Vehicle) async throws {
        // Mock implementation
    }
    
    func findNearbyEmergencyServices(location: CLLocationCoordinate2D) async throws -> [EmergencyService] {
        return []
    }
    
    func cancelEmergencyAlert() async throws {
        // Mock implementation
    }
}