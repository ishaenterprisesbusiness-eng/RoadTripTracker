import SwiftUI

struct POIProposalsView: View {
    let viewModel: POIViewModel
    @State private var selectedProposal: POIProposal?
    @State private var showingVoteSheet = false
    
    var body: some View {
        Group {
            if viewModel.proposals.isEmpty {
                ContentUnavailableView(
                    "No Proposals",
                    systemImage: "tray",
                    description: Text("No POI proposals have been made for this trip yet")
                )
            } else {
                List(viewModel.proposals) { proposal in
                    ProposalRowView(proposal: proposal, viewModel: viewModel) {
                        selectedProposal = proposal
                        showingVoteSheet = true
                    }
                    .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                    .listRowSeparator(.hidden)
                }
                .listStyle(PlainListStyle())
            }
        }
        .sheet(isPresented: $showingVoteSheet) {
            if let proposal = selectedProposal {
                POIVoteSheet(proposal: proposal, viewModel: viewModel)
            }
        }
    }
}

// MARK: - Proposal Row View

struct ProposalRowView: View {
    let proposal: POIProposal
    let viewModel: POIViewModel
    let onVote: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Header
            HStack {
                Image(systemName: proposal.poi.category.iconName)
                    .font(.title2)
                    .foregroundColor(.accentColor)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(proposal.poi.name)
                        .font(.headline)
                        .lineLimit(1)
                    
                    Text("Proposed by \(proposerName)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                ProposalStatusBadge(status: proposal.status)
            }
            
            // POI Details
            if let rating = proposal.poi.rating {
                HStack {
                    Text(String(format: "%.1f", rating))
                        .font(.caption)
                        .fontWeight(.medium)
                    
                    HStack(spacing: 1) {
                        ForEach(0..<5) { index in
                            Image(systemName: index < Int(rating) ? "star.fill" : "star")
                                .font(.caption2)
                                .foregroundColor(.orange)
                        }
                    }
                    
                    Spacer()
                    
                    Text(proposal.poi.category.displayName)
                        .font(.caption)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.accentColor.opacity(0.1))
                        .cornerRadius(4)
                }
            }
            
            // Proposal Message
            if let message = proposal.proposalMessage {
                Text(message)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
            }
            
            // Voting Section
            if proposal.status == .pending {
                votingSection
            } else {
                votingResultsSection
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.systemBackground))
                .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
        )
    }
} 
   // MARK: - Voting Section
    
    private var votingSection: some View {
        VStack(spacing: 8) {
            // Vote Progress
            HStack {
                Text("Votes: \(proposal.votes.count)/\(totalParticipants)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                Text(timeRemaining)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            // Vote Breakdown
            HStack(spacing: 16) {
                VoteCountView(
                    type: .approve,
                    count: approveVotes,
                    color: .green
                )
                
                VoteCountView(
                    type: .reject,
                    count: rejectVotes,
                    color: .red
                )
                
                VoteCountView(
                    type: .abstain,
                    count: abstainVotes,
                    color: .gray
                )
                
                Spacer()
            }
            
            // Vote Button
            if !viewModel.hasUserVoted(for: proposal) {
                Button(action: onVote) {
                    Text("Vote")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 6)
                        .background(Color.accentColor)
                        .cornerRadius(8)
                }
            } else if let userVote = viewModel.getUserVote(for: proposal) {
                HStack {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.green)
                    Text("You voted: \(userVote.displayName)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
    }
    
    // MARK: - Voting Results Section
    
    private var votingResultsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Final Result")
                .font(.caption)
                .foregroundColor(.secondary)
            
            HStack(spacing: 16) {
                VoteCountView(
                    type: .approve,
                    count: approveVotes,
                    color: .green
                )
                
                VoteCountView(
                    type: .reject,
                    count: rejectVotes,
                    color: .red
                )
                
                VoteCountView(
                    type: .abstain,
                    count: abstainVotes,
                    color: .gray
                )
                
                Spacer()
                
                if let decidedAt = proposal.decidedAt {
                    Text(decidedAt, style: .date)
                        .font(.caption2)
                        .foregroundColor(.tertiary)
                }
            }
        }
    }
    
    // MARK: - Computed Properties
    
    private var proposerName: String {
        // In a real app, you'd look up the user name by ID
        "User"
    }
    
    private var totalParticipants: Int {
        viewModel.currentTrip?.participants.count ?? 0
    }
    
    private var approveVotes: Int {
        proposal.votes.filter { $0.vote == .approve }.count
    }
    
    private var rejectVotes: Int {
        proposal.votes.filter { $0.vote == .reject }.count
    }
    
    private var abstainVotes: Int {
        proposal.votes.filter { $0.vote == .abstain }.count
    }
    
    private var timeRemaining: String {
        let elapsed = Date().timeIntervalSince(proposal.createdAt)
        let remaining = max(0, 24 * 3600 - elapsed) // 24 hour voting period
        
        if remaining > 3600 {
            return "\(Int(remaining / 3600))h remaining"
        } else if remaining > 60 {
            return "\(Int(remaining / 60))m remaining"
        } else {
            return "Voting ends soon"
        }
    }
}

// MARK: - Vote Count View

struct VoteCountView: View {
    let type: VoteType
    let count: Int
    let color: Color
    
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: iconName)
                .font(.caption)
                .foregroundColor(color)
            
            Text("\(count)")
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(color)
        }
    }
    
    private var iconName: String {
        switch type {
        case .approve: return "hand.thumbsup.fill"
        case .reject: return "hand.thumbsdown.fill"
        case .abstain: return "minus.circle.fill"
        }
    }
}