import SwiftUI
import CoreLocation

// MARK: - Expense List View
struct ExpenseListView: View {
    @ObservedObject var viewModel: BudgetViewModel
    let trip: Trip
    let expenses: [Expense]
    
    var body: some View {
        NavigationView {
            ZStack {
                // Glassmorphic background
                GlasmorphicDesignSystem.backgroundGradient
                    .ignoresSafeArea()
                
                if expenses.isEmpty {
                    emptyStateView
                } else {
                    expensesList
                }
            }
            .navigationTitle("Expenses")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Add", systemImage: "plus") {
                        viewModel.showingAddExpense = true
                    }
                }
            }
        }
    }
    
    // MARK: - Empty State View
    private var emptyStateView: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(spacing: 20) {
                Image(systemName: "receipt")
                    .font(.system(size: 60))
                    .foregroundColor(.gray)
                
                Text("No Expenses Yet")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Start tracking your trip expenses by adding your first expense.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                
                Button("Add First Expense") {
                    viewModel.showingAddExpense = true
                }
                .buttonStyle(GlasmorphicDesignSystem.GlassButtonStyle())
            }
            .padding(30)
        }
        .padding()
    }
    
    // MARK: - Expenses List
    private var expensesList: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(groupedExpenses, id: \.key) { dateGroup in
                    expenseDateSection(date: dateGroup.key, expenses: dateGroup.value)
                }
            }
            .padding()
        }
    }
    
    private func expenseDateSection(date: Date, expenses: [Expense]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            // Date header
            HStack {
                Text(formatDate(date))
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Spacer()
                
                Text("$\(viewModel.formattedAmount(expenses.reduce(0) { $0 + $1.amount }))")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
            }
            .padding(.horizontal)
            
            // Expenses for this date
            GlasmorphicDesignSystem.createGlassCard {
                VStack(spacing: 0) {
                    ForEach(Array(expenses.enumerated()), id: \.element.id) { index, expense in
                        expenseRow(expense)
                        
                        if index < expenses.count - 1 {
                            Divider()
                                .background(.white.opacity(0.2))
                        }
                    }
                }
                .padding(.vertical, 8)
            }
        }
    }
    
    private func expenseRow(_ expense: Expense) -> some View {
        HStack(spacing: 12) {
            // Category icon
            Image(systemName: viewModel.categoryIcon(for: expense.category))
                .foregroundColor(Color(viewModel.categoryColor(for: expense.category)))
                .frame(width: 24, height: 24)
            
            // Expense details
            VStack(alignment: .leading, spacing: 4) {
                Text(expense.description)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                HStack {
                    Text(expense.category.displayName)
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    if let participant = trip.participants.first(where: { $0.id == expense.participantId }) {
                        Text("• \(participant.user.username)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Text("• \(formatTime(expense.timestamp))")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            // Amount
            VStack(alignment: .trailing) {
                Text("$\(viewModel.formattedAmount(expense.amount))")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                if expense.location != nil {
                    Image(systemName: "location.fill")
                        .font(.caption2)
                        .foregroundColor(.blue)
                }
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .contentShape(Rectangle())
        .onTapGesture {
            // Could show expense details or edit
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button("Delete", systemImage: "trash") {
                viewModel.deleteExpense(expense.id, from: trip.id)
            }
            .tint(.red)
        }
    }
    
    // MARK: - Computed Properties
    private var groupedExpenses: [(key: Date, value: [Expense])] {
        let calendar = Calendar.current
        let grouped = Dictionary(grouping: expenses) { expense in
            calendar.startOfDay(for: expense.timestamp)
        }
        
        return grouped.sorted { $0.key > $1.key } // Most recent first
    }
    
    // MARK: - Helper Methods
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        
        if Calendar.current.isDateInToday(date) {
            return "Today"
        } else if Calendar.current.isDateInYesterday(date) {
            return "Yesterday"
        } else if Calendar.current.isDate(date, equalTo: Date(), toGranularity: .weekOfYear) {
            formatter.dateFormat = "EEEE" // Day of week
            return formatter.string(from: date)
        } else {
            formatter.dateStyle = .medium
            return formatter.string(from: date)
        }
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

// MARK: - Preview
struct ExpenseListView_Previews: PreviewProvider {
    static var previews: some View {
        let mockTrip = Trip(
            name: "Sample Trip",
            code: "ABC123",
            createdBy: UUID(),
            participants: [
                Participant(
                    userId: UUID(),
                    user: User(
                        id: UUID(),
                        username: "John Doe",
                        email: "john@example.com",
                        city: "Test City",
                        dateOfBirth: Date(),
                        age: 25
                    )
                )
            ],
            destinations: []
        )
        
        let mockExpenses = [
            Expense(
                amount: 45.50,
                category: .fuel,
                description: "Gas station fill-up",
                participantId: mockTrip.participants[0].id,
                timestamp: Date(),
                location: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
            ),
            Expense(
                amount: 28.75,
                category: .food,
                description: "Lunch at roadside diner",
                participantId: mockTrip.participants[0].id,
                timestamp: Calendar.current.date(byAdding: .hour, value: -2, to: Date()) ?? Date()
            ),
            Expense(
                amount: 120.00,
                category: .accommodation,
                description: "Hotel night stay",
                participantId: mockTrip.participants[0].id,
                timestamp: Calendar.current.date(byAdding: .day, value: -1, to: Date()) ?? Date()
            )
        ]
        
        ExpenseListView(
            viewModel: BudgetViewModel(
                budgetService: MockBudgetService(),
                locationService: MockLocationService()
            ),
            trip: mockTrip,
            expenses: mockExpenses
        )
    }
}

// MARK: - Mock Services for Preview
private class MockBudgetService: BudgetServiceProtocol {
    func createBudget(for tripId: UUID, totalBudget: Double, perPersonBudget: Double?) async throws -> Budget {
        return Budget(totalBudget: totalBudget, perPersonBudget: perPersonBudget)
    }
    
    func addExpense(_ expense: Expense, to tripId: UUID) async throws {}
    func updateExpense(_ expense: Expense) async throws {}
    func deleteExpense(_ expenseId: UUID, from tripId: UUID) async throws {}
    
    func getBudgetSummary(for tripId: UUID) async throws -> BudgetSummary {
        return BudgetSummary(
            tripId: tripId,
            totalBudget: 1000,
            totalSpent: 650,
            remainingBudget: 350
        )
    }
    
    var budgetUpdates: AnyPublisher<BudgetUpdate, Never> {
        Empty().eraseToAnyPublisher()
    }
}

private class MockLocationService: LocationServiceProtocol {
    var currentLocation: CLLocation? = CLLocation(latitude: 0, longitude: 0)
    var authorizationStatus: CLAuthorizationStatus = .authorizedWhenInUse
    var locationUpdates: AnyPublisher<CLLocation, Never> = Empty().eraseToAnyPublisher()
    var authorizationUpdates: AnyPublisher<CLAuthorizationStatus, Never> = Empty().eraseToAnyPublisher()
    var isLocationSharingEnabled: Bool = true
    
    func requestLocationPermission() async throws {}
    func startLocationSharing() async throws {}
    func stopLocationSharing() {}
    func getCurrentLocation() async throws -> CLLocation {
        return CLLocation(latitude: 0, longitude: 0)
    }
    func startMonitoringSignificantLocationChanges() {}
    func stopMonitoringSignificantLocationChanges() {}
    func calculateDistance(from: CLLocation, to: CLLocation) -> CLLocationDistance { return 0 }
    func calculateDrivingDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) async throws -> CLLocationDistance { return 0 }
    func isLocationStale(_ location: CLLocation, threshold: TimeInterval) -> Bool { return false }
}