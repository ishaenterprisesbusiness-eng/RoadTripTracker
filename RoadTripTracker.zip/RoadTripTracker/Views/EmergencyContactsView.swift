import SwiftUI

// MARK: - Emergency Contacts View
struct EmergencyContactsView: View {
    @StateObject private var viewModel = EmergencyContactsViewModel()
    @State private var showingAddContact = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                if viewModel.emergencyContacts.isEmpty {
                    emptyStateView
                } else {
                    contactsList
                }
            }
            .navigationTitle("Emergency Contacts")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Add") {
                        showingAddContact = true
                    }
                }
            }
            .sheet(isPresented: $showingAddContact) {
                AddEmergencyContactSheet(viewModel: viewModel)
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.dismissError()
                }
            } message: {
                if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                }
            }
        }
        .onAppear {
            viewModel.loadEmergencyContacts()
        }
    }
    
    // MARK: - Empty State View
    private var emptyStateView: some View {
        VStack(spacing: 24) {
            Spacer()
            
            Image(systemName: "person.2.circle")
                .font(.system(size: 64))
                .foregroundColor(.gray)
            
            VStack(spacing: 12) {
                Text("No Emergency Contacts")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text("Add emergency contacts who will be notified if you trigger an emergency alert during your trip.")
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 32)
            }
            
            Button("Add Emergency Contact") {
                showingAddContact = true
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            
            Spacer()
        }
        .padding()
    }
    
    // MARK: - Contacts List
    private var contactsList: some View {
        List {
            Section {
                ForEach(viewModel.emergencyContacts) { contact in
                    EmergencyContactRow(contact: contact) {
                        viewModel.deleteContact(contact)
                    } onEdit: {
                        viewModel.selectedContact = contact
                        showingAddContact = true
                    }
                }
                .onDelete(perform: deleteContacts)
            } header: {
                Text("Your emergency contacts will be notified via \(viewModel.emergencyContacts.first?.contactMethod.displayName ?? "SMS") when you trigger an emergency alert.")
                    .font(.caption)
                    .textCase(.none)
            }
            
            Section {
                Button("Add Emergency Contact") {
                    showingAddContact = true
                }
                .foregroundColor(.blue)
            }
        }
        .listStyle(.insetGrouped)
    }
    
    // MARK: - Helper Methods
    private func deleteContacts(offsets: IndexSet) {
        for index in offsets {
            let contact = viewModel.emergencyContacts[index]
            viewModel.deleteContact(contact)
        }
    }
}

// MARK: - Emergency Contact Row
struct EmergencyContactRow: View {
    let contact: EmergencyContact
    let onDelete: () -> Void
    let onEdit: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            // Contact Icon
            Image(systemName: contact.isPrimary ? "person.circle.fill" : "person.circle")
                .font(.title2)
                .foregroundColor(contact.isPrimary ? .blue : .gray)
            
            // Contact Info
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(contact.name)
                        .font(.headline)
                    
                    if contact.isPrimary {
                        Text("PRIMARY")
                            .font(.caption2)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.blue)
                            .cornerRadius(4)
                    }
                }
                
                Text(contact.relationship)
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                HStack {
                    Text(contact.phoneNumber)
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Text("•")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Text(contact.contactMethod.displayName)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            // Action Menu
            Menu {
                Button("Edit") {
                    onEdit()
                }
                
                Button("Call") {
                    if let phoneURL = URL(string: "tel://\(contact.phoneNumber)") {
                        UIApplication.shared.open(phoneURL)
                    }
                }
                
                if let email = contact.email {
                    Button("Email") {
                        if let emailURL = URL(string: "mailto:\(email)") {
                            UIApplication.shared.open(emailURL)
                        }
                    }
                }
                
                Divider()
                
                Button("Delete", role: .destructive) {
                    onDelete()
                }
            } label: {
                Image(systemName: "ellipsis.circle")
                    .font(.title3)
                    .foregroundColor(.gray)
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Add Emergency Contact Sheet
struct AddEmergencyContactSheet: View {
    @ObservedObject var viewModel: EmergencyContactsViewModel
    @Environment(\.dismiss) private var dismiss
    
    @State private var name = ""
    @State private var relationship = ""
    @State private var phoneNumber = ""
    @State private var email = ""
    @State private var contactMethod = EmergencyContactMethod.sms
    @State private var isPrimary = false
    
    private var isEditing: Bool {
        viewModel.selectedContact != nil
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section("Contact Information") {
                    TextField("Name", text: $name)
                    TextField("Relationship", text: $relationship)
                        .textInputAutocapitalization(.words)
                    TextField("Phone Number", text: $phoneNumber)
                        .keyboardType(.phonePad)
                }
                
                Section("Contact Method") {
                    Picker("Preferred Method", selection: $contactMethod) {
                        ForEach(EmergencyContactMethod.allCases, id: \.self) { method in
                            Text(method.displayName).tag(method)
                        }
                    }
                    .pickerStyle(.segmented)
                    
                    if contactMethod == .email {
                        TextField("Email Address", text: $email)
                            .keyboardType(.emailAddress)
                            .textInputAutocapitalization(.never)
                    }
                }
                
                Section {
                    Toggle("Primary Contact", isOn: $isPrimary)
                } footer: {
                    Text("Primary contacts are notified first in emergencies.")
                }
            }
            .navigationTitle(isEditing ? "Edit Contact" : "Add Contact")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveContact()
                    }
                    .disabled(!isFormValid)
                }
            }
        }
        .onAppear {
            loadContactData()
        }
        .onDisappear {
            viewModel.selectedContact = nil
        }
    }
    
    private var isFormValid: Bool {
        !name.isEmpty && 
        !relationship.isEmpty && 
        !phoneNumber.isEmpty &&
        (contactMethod != .email || !email.isEmpty)
    }
    
    private func loadContactData() {
        if let contact = viewModel.selectedContact {
            name = contact.name
            relationship = contact.relationship
            phoneNumber = contact.phoneNumber
            email = contact.email ?? ""
            contactMethod = contact.contactMethod
            isPrimary = contact.isPrimary
        }
    }
    
    private func saveContact() {
        let contact = EmergencyContact(
            id: viewModel.selectedContact?.id ?? UUID(),
            name: name,
            relationship: relationship,
            phoneNumber: phoneNumber,
            email: contactMethod == .email ? email : nil,
            contactMethod: contactMethod,
            isPrimary: isPrimary
        )
        
        if isEditing {
            viewModel.updateContact(contact)
        } else {
            viewModel.addContact(contact)
        }
        
        dismiss()
    }
}

// MARK: - Emergency Contacts View Model
@MainActor
class EmergencyContactsViewModel: ObservableObject {
    @Published var emergencyContacts: [EmergencyContact] = []
    @Published var errorMessage: String?
    @Published var selectedContact: EmergencyContact?
    
    func loadEmergencyContacts() {
        // This would load from Core Data or user service
        // For now, using mock data
        emergencyContacts = [
            EmergencyContact(
                name: "John Smith",
                relationship: "Spouse",
                phoneNumber: "+61 400 123 456",
                email: "john@example.com",
                contactMethod: .sms,
                isPrimary: true
            ),
            EmergencyContact(
                name: "Sarah Johnson",
                relationship: "Sister",
                phoneNumber: "+61 400 789 012",
                contactMethod: .call,
                isPrimary: false
            )
        ]
    }
    
    func addContact(_ contact: EmergencyContact) {
        // If this is set as primary, remove primary from others
        if contact.isPrimary {
            for index in emergencyContacts.indices {
                emergencyContacts[index].isPrimary = false
            }
        }
        
        emergencyContacts.append(contact)
        saveContacts()
    }
    
    func updateContact(_ contact: EmergencyContact) {
        guard let index = emergencyContacts.firstIndex(where: { $0.id == contact.id }) else {
            return
        }
        
        // If this is set as primary, remove primary from others
        if contact.isPrimary {
            for i in emergencyContacts.indices {
                if i != index {
                    emergencyContacts[i].isPrimary = false
                }
            }
        }
        
        emergencyContacts[index] = contact
        saveContacts()
    }
    
    func deleteContact(_ contact: EmergencyContact) {
        emergencyContacts.removeAll { $0.id == contact.id }
        saveContacts()
    }
    
    func dismissError() {
        errorMessage = nil
    }
    
    private func saveContacts() {
        // This would save to Core Data or user service
        print("Saving emergency contacts: \(emergencyContacts.count)")
    }
}

// MARK: - Preview
struct EmergencyContactsView_Previews: PreviewProvider {
    static var previews: some View {
        EmergencyContactsView()
    }
}