import SwiftUI
import MapKit

struct FoodStopListView: View {
    @StateObject private var viewModel: FoodStopViewModel
    @State private var showingCuisineFilter = false
    @State private var proposalNotes = ""
    
    init(foodStopService: FoodStopServiceProtocol, locationManager: LocationManager) {
        self._viewModel = StateObject(wrappedValue: FoodStopViewModel(foodStopService: foodStopService, locationManager: locationManager))
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Filter Section
                cuisineFilterSection
                
                // Active Food Stop Section
                if let activeFoodStop = viewModel.activeFoodStop {
                    activeFoodStopSection(activeFoodStop)
                }
                
                // Proposed Food Stops Section
                if !viewModel.proposedFoodStops.isEmpty {
                    proposedFoodStopsSection
                }
                
                // Nearby Restaurants Section
                nearbyRestaurantsSection
                
                Spacer()
            }
            .navigationTitle("Food Stops")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Find Restaurants") {
                        Task {
                            await viewModel.searchNearbyRestaurants()
                        }
                    }
                }
            }
            .sheet(isPresented: $viewModel.showingProposalSheet) {
                foodStopProposalSheet
            }
            .sheet(isPresented: $viewModel.showingOrderSheet) {
                orderSheet
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.errorMessage = nil
                }
            } message: {
                Text(viewModel.errorMessage ?? "")
            }
        }
    }
    
    // MARK: - Cuisine Filter Section
    
    @ViewBuilder
    private var cuisineFilterSection: some View {
        HStack {
            Text("Filter by cuisine:")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Button(action: {
                showingCuisineFilter = true
            }) {
                HStack {
                    Text(viewModel.selectedCuisineFilter?.displayName ?? "All Cuisines")
                        .font(.subheadline)
                    Image(systemName: "chevron.down")
                        .font(.caption)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Color(.systemGray5))
                .cornerRadius(8)
            }
            
            if viewModel.selectedCuisineFilter != nil {
                Button("Clear") {
                    viewModel.selectedCuisineFilter = nil
                    Task {
                        await viewModel.searchNearbyRestaurants()
                    }
                }
                .font(.caption)
                .foregroundColor(.blue)
            }
            
            Spacer()
        }
        .padding(.horizontal)
        .confirmationDialog("Select Cuisine", isPresented: $showingCuisineFilter) {
            ForEach(CuisineType.allCases, id: \.self) { cuisine in
                Button(cuisine.displayName) {
                    viewModel.selectedCuisineFilter = cuisine
                    Task {
                        await viewModel.searchNearbyRestaurants()
                    }
                }
            }
            
            Button("All Cuisines") {
                viewModel.selectedCuisineFilter = nil
                Task {
                    await viewModel.searchNearbyRestaurants()
                }
            }
            
            Button("Cancel", role: .cancel) {}
        }
    }
    
    // MARK: - Active Food Stop Section
    
    @ViewBuilder
    private func activeFoodStopSection(_ foodStop: FoodStop) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "fork.knife.circle.fill")
                    .foregroundColor(.blue)
                Text("Active Food Stop")
                    .font(.headline)
                Spacer()
                Text(foodStop.proposalStatus.displayName)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.blue.opacity(0.2))
                    .cornerRadius(8)
            }
            
            restaurantCard(foodStop.restaurant, showProposalButton: false)
            
            // Order Status
            orderStatusView(foodStop)
            
            // Action Buttons
            HStack(spacing: 12) {
                if !viewModel.isParticipantOrdered(UUID()) { // Replace with actual participant ID
                    Button("Place Order") {
                        viewModel.showOrderSheet()
                    }
                    .buttonStyle(.borderedProminent)
                } else if !viewModel.isParticipantReady(UUID()) { // Replace with actual participant ID
                    Button("Ready to Continue") {
                        Task {
                            await viewModel.markReadyToContinue()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                }
                
                Spacer()
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal)
    }
    
    // MARK: - Proposed Food Stops Section
    
    @ViewBuilder
    private var proposedFoodStopsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "clock.fill")
                    .foregroundColor(.orange)
                Text("Proposed Food Stops")
                    .font(.headline)
                Spacer()
            }
            .padding(.horizontal)
            
            ForEach(viewModel.proposedFoodStops) { foodStop in
                proposedFoodStopCard(foodStop)
            }
        }
    }
    
    @ViewBuilder
    private func proposedFoodStopCard(_ foodStop: FoodStop) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(foodStop.restaurant.name)
                    .font(.headline)
                Spacer()
                Text(foodStop.proposalStatus.displayName)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(statusColor(for: foodStop.proposalStatus).opacity(0.2))
                    .foregroundColor(statusColor(for: foodStop.proposalStatus))
                    .cornerRadius(8)
            }
            
            if let cuisine = foodStop.restaurant.cuisine {
                HStack {
                    Image(systemName: cuisine.icon)
                        .foregroundColor(.secondary)
                    Text(cuisine.displayName)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Text(foodStop.restaurant.address)
                .font(.caption)
                .foregroundColor(.secondary)
            
            if let notes = foodStop.notes {
                Text(notes)
                    .font(.caption)
                    .padding(8)
                    .background(Color(.systemGray5))
                    .cornerRadius(8)
            }
            
            // Approval Status
            HStack {
                Label("\(foodStop.approvals.count) approved", systemImage: "checkmark.circle.fill")
                    .foregroundColor(.green)
                    .font(.caption)
                
                Label("\(foodStop.rejections.count) rejected", systemImage: "xmark.circle.fill")
                    .foregroundColor(.red)
                    .font(.caption)
                
                Spacer()
            }
            
            // Action Buttons
            if foodStop.proposalStatus == .pending {
                HStack(spacing: 12) {
                    Button("Approve") {
                        Task {
                            await viewModel.approveFoodStop(foodStop)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    
                    Button("Reject") {
                        Task {
                            await viewModel.rejectFoodStop(foodStop)
                        }
                    }
                    .buttonStyle(.bordered)
                    
                    Spacer()
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
        .padding(.horizontal)
    }
    
    // MARK: - Nearby Restaurants Section
    
    @ViewBuilder
    private var nearbyRestaurantsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "location.fill")
                    .foregroundColor(.green)
                Text("Nearby Restaurants")
                    .font(.headline)
                Spacer()
                
                if viewModel.isLoading {
                    ProgressView()
                        .scaleEffect(0.8)
                }
            }
            .padding(.horizontal)
            
            if viewModel.nearbyRestaurants.isEmpty && !viewModel.isLoading {
                Text("No restaurants found. Tap 'Find Restaurants' to search.")
                    .foregroundColor(.secondary)
                    .padding()
            } else {
                ForEach(viewModel.nearbyRestaurants) { restaurant in
                    restaurantCard(restaurant, showProposalButton: true)
                }
            }
        }
    }
    
    @ViewBuilder
    private func restaurantCard(_ restaurant: Restaurant, showProposalButton: Bool) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(restaurant.name)
                        .font(.headline)
                    
                    if let cuisine = restaurant.cuisine {
                        HStack {
                            Image(systemName: cuisine.icon)
                                .foregroundColor(.secondary)
                            Text(cuisine.displayName)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 2) {
                    if let rating = restaurant.rating {
                        HStack(spacing: 2) {
                            Image(systemName: "star.fill")
                                .foregroundColor(.yellow)
                                .font(.caption)
                            Text(String(format: "%.1f", rating))
                                .font(.caption)
                        }
                    }
                    
                    if let priceLevel = restaurant.priceLevel {
                        Text(viewModel.formatPriceLevel(priceLevel))
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            Text(restaurant.address)
                .font(.caption)
                .foregroundColor(.secondary)
            
            // Restaurant Status
            HStack {
                if let isOpen = restaurant.isOpenNow {
                    Label(isOpen ? "Open" : "Closed", systemImage: isOpen ? "checkmark.circle.fill" : "xmark.circle.fill")
                        .foregroundColor(isOpen ? .green : .red)
                        .font(.caption)
                }
                
                if let waitTime = restaurant.estimatedWaitTime {
                    Label("Wait: \(viewModel.formatEstimatedWaitTime(waitTime))", systemImage: "clock")
                        .foregroundColor(.orange)
                        .font(.caption)
                }
                
                Spacer()
            }
            
            // Features
            if !restaurant.features.isEmpty {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 8) {
                    ForEach(restaurant.features.prefix(8), id: \.self) { feature in
                        HStack(spacing: 4) {
                            Image(systemName: feature.icon)
                                .font(.caption2)
                            Text(feature.displayName)
                                .font(.caption2)
                        }
                        .foregroundColor(.secondary)
                    }
                }
            }
            
            if showProposalButton {
                Button("Propose as Food Stop") {
                    viewModel.showProposalSheet(for: restaurant)
                }
                .buttonStyle(.bordered)
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
        .padding(.horizontal)
    }
    
    // MARK: - Order Status View
    
    @ViewBuilder
    private func orderStatusView(_ foodStop: FoodStop) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Order Status")
                .font(.subheadline)
                .fontWeight(.medium)
            
            if foodStop.orders.isEmpty {
                Text("No orders placed yet")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                ForEach(foodStop.orders) { order in
                    HStack {
                        Circle()
                            .fill(Color(viewModel.getOrderStatusColor(order.orderStatus)))
                            .frame(width: 8, height: 8)
                        
                        Text("Participant") // Replace with actual participant name
                            .font(.caption)
                        
                        Spacer()
                        
                        Text(order.orderStatus.displayName)
                            .font(.caption)
                            .foregroundColor(Color(order.orderStatus.color))
                        
                        if order.isReadyToContinue {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                                .font(.caption)
                        }
                    }
                }
            }
        }
        .padding(12)
        .background(Color(.systemGray5))
        .cornerRadius(8)
    }
    
    // MARK: - Sheets
    
    @ViewBuilder
    private var foodStopProposalSheet: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                if let restaurant = viewModel.selectedRestaurant {
                    restaurantCard(restaurant, showProposalButton: false)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Notes (Optional)")
                            .font(.headline)
                        
                        TextField("Add any notes about this food stop...", text: $proposalNotes, axis: .vertical)
                            .textFieldStyle(.roundedBorder)
                            .lineLimit(3...6)
                    }
                    
                    Spacer()
                }
            }
            .padding()
            .navigationTitle("Propose Food Stop")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        viewModel.showingProposalSheet = false
                        proposalNotes = ""
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Propose") {
                        if let restaurant = viewModel.selectedRestaurant {
                            Task {
                                await viewModel.proposeFoodStop(
                                    restaurant: restaurant,
                                    notes: proposalNotes.isEmpty ? nil : proposalNotes
                                )
                                proposalNotes = ""
                            }
                        }
                    }
                    .disabled(viewModel.isLoading)
                }
            }
        }
    }
    
    @ViewBuilder
    private var orderSheet: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                // Order Items Section
                VStack(alignment: .leading, spacing: 12) {
                    Text("Order Items")
                        .font(.headline)
                    
                    if viewModel.orderItems.isEmpty {
                        Text("No items added yet")
                            .foregroundColor(.secondary)
                            .font(.subheadline)
                    } else {
                        ForEach(Array(viewModel.orderItems.enumerated()), id: \.offset) { index, item in
                            orderItemRow(item: item, index: index)
                        }
                    }
                    
                    Button("Add Item") {
                        viewModel.addOrderItem(name: "New Item")
                    }
                    .buttonStyle(.bordered)
                }
                
                Divider()
                
                // Special Instructions
                VStack(alignment: .leading, spacing: 8) {
                    Text("Special Instructions (Optional)")
                        .font(.headline)
                    
                    TextField("Any special requests...", text: $viewModel.specialInstructions, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .lineLimit(2...4)
                }
                
                // Order Total
                if !viewModel.orderItems.isEmpty {
                    HStack {
                        Text("Total:")
                            .font(.headline)
                        Spacer()
                        Text("$\(String(format: "%.2f", viewModel.getTotalOrderCost()))")
                            .font(.headline)
                            .fontWeight(.bold)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                }
                
                Toggle("Ready to continue after eating", isOn: $viewModel.isReadyToContinue)
                    .font(.subheadline)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Place Order")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        viewModel.showingOrderSheet = false
                        viewModel.clearOrderForm()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Place Order") {
                        Task {
                            await viewModel.placeOrder()
                        }
                    }
                    .disabled(viewModel.isLoading || viewModel.orderItems.isEmpty)
                }
            }
        }
    }
    
    @ViewBuilder
    private func orderItemRow(item: OrderItem, index: Int) -> some View {
        HStack {
            TextField("Item name", text: .constant(item.name))
                .textFieldStyle(.roundedBorder)
            
            Stepper(value: .constant(item.quantity), in: 1...10) {
                Text("\(item.quantity)")
                    .frame(width: 30)
            }
            
            Button(action: {
                viewModel.removeOrderItem(at: index)
            }) {
                Image(systemName: "trash")
                    .foregroundColor(.red)
            }
        }
    }
    
    // MARK: - Helper Methods
    
    private func statusColor(for status: StopProposalStatus) -> Color {
        switch status {
        case .pending: return .orange
        case .approved: return .green
        case .rejected: return .red
        case .active: return .blue
        case .completed: return .gray
        case .cancelled: return .gray
        }
    }
}

#Preview {
    FoodStopListView(
        foodStopService: FoodStopService(
            placesService: PlacesService(),
            notificationService: MockNotificationService(),
            routeManager: RouteManager(
                navigationService: NavigationService(),
                mapService: MapService(),
                locationManager: LocationManager()
            )
        ),
        locationManager: LocationManager()
    )
}

// MARK: - Mock Notification Service for Preview
private class MockNotificationService: NotificationServiceProtocol {
    var notificationPermissionStatus: AnyPublisher<UNAuthorizationStatus, Never> {
        Just(.authorized).eraseToAnyPublisher()
    }
    
    func requestNotificationPermission() async throws -> Bool { true }
    func scheduleLocalNotification(_ notification: LocalNotification) async throws {}
    func cancelNotification(withIdentifier identifier: String) async throws {}
    func cancelAllNotifications() async throws {}
    func sendPushNotification(_ notification: PushNotification) async throws {}
    func registerForRemoteNotifications() async throws -> Data { Data() }
    func handleRemoteNotification(_ userInfo: [AnyHashable: Any]) async {}
}