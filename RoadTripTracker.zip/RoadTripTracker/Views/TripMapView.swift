import SwiftUI
import MapKit
import CoreLocation

struct TripMapView: View {
    @ObservedObject var viewModel: TripViewModel
    @State private var showingDestinationDetails = false
    @State private var showingParticipantDetails = false
    @State private var selectedParticipant: Participant?
    @State private var showVehicles = true
    
    var body: some View {
        ZStack {
            if showVehicles && !(viewModel.trip?.participants.isEmpty ?? true) {
                vehicleMapView
            } else {
                destinationMapView
            }
            
            VStack {
                Spacer()
                
                if let trip = viewModel.trip {
                    mapControlsOverlay(trip: trip)
                }
            }
        }
        .sheet(isPresented: $showingDestinationDetails) {
            if let selectedDestination = viewModel.selectedDestination {
                DestinationDetailsSheet(
                    destination: selectedDestination,
                    estimatedArrival: viewModel.estimatedArrivalTimes[selectedDestination.id]
                ) {
                    viewModel.deselectDestination()
                }
            }
        }
        .sheet(isPresented: $showingParticipantDetails) {
            if let participant = selectedParticipant {
                ParticipantDetailView(
                    participant: participant,
                    currentUserLocation: viewModel.currentUserLocation
                )
            }
        }
        .onChange(of: viewModel.selectedDestination) { destination in
            showingDestinationDetails = destination != nil
        }
        .onChange(of: selectedParticipant) { participant in
            showingParticipantDetails = participant != nil
        }
    }
    
    // MARK: - Map Views
    
    private var vehicleMapView: some View {
        VehicleMapView(
            participants: .constant(viewModel.trip?.participants ?? []),
            route: .constant(viewModel.currentRoute),
            selectedParticipant: $selectedParticipant,
            showUserLocation: true,
            autoZoom: true
        )
    }
    
    private var destinationMapView: some View {
        Map(coordinateRegion: $viewModel.mapRegion, annotationItems: viewModel.trip?.destinations ?? []) { destination in
            MapAnnotation(coordinate: destination.coordinate) {
                DestinationMapMarker(
                    destination: destination,
                    index: getDestinationIndex(destination),
                    isSelected: viewModel.selectedDestination?.id == destination.id,
                    isCurrent: isCurrentDestination(destination),
                    onTap: {
                        viewModel.selectDestination(destination)
                    }
                )
            }
        }
        .overlay(
            routeOverlay
        )
        .onTapGesture {
            viewModel.deselectDestination()
        }
    }
    
    // MARK: - Route Overlay
    
    private var routeOverlay: some View {
        Group {
            if let trip = viewModel.trip, trip.destinations.count > 1 {
                RoutePolylineView(destinations: trip.destinations)
            }
        }
    }
    
    // MARK: - Map Controls Overlay
    
    private func mapControlsOverlay(trip: Trip) -> some View {
        VStack(spacing: 12) {
            // Current destination info
            if let currentDestination = viewModel.currentDestination {
                CurrentDestinationCard(
                    destination: currentDestination,
                    estimatedArrival: viewModel.estimatedArrivalTimes[currentDestination.id]
                )
            }
            
            // Map controls
            HStack {
                // Toggle between vehicle and destination view
                MapControlButton(
                    icon: showVehicles ? "car.side.fill" : "mappin.and.ellipse",
                    action: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            showVehicles.toggle()
                        }
                    }
                )
                
                // Zoom to fit all destinations/vehicles
                MapControlButton(
                    icon: "arrow.up.left.and.arrow.down.right",
                    action: {
                        withAnimation(.easeInOut(duration: 0.5)) {
                            if showVehicles {
                                // Auto-zoom will be handled by VehicleMapView
                            } else {
                                viewModel.updateMapRegion(for: trip)
                            }
                        }
                    }
                )
                
                Spacer()
                
                // Toggle route visibility (only for destination view)
                if !showVehicles {
                    MapControlButton(
                        icon: viewModel.routePolyline != nil ? "eye.slash" : "eye",
                        action: {
                            Task {
                                if viewModel.routePolyline != nil {
                                    viewModel.routePolyline = nil
                                } else {
                                    await viewModel.loadRoute()
                                }
                            }
                        }
                    )
                }
                
                // Refresh route
                MapControlButton(
                    icon: "arrow.clockwise",
                    isLoading: viewModel.isLoadingRoute,
                    action: {
                        Task {
                            await viewModel.loadRoute()
                        }
                    }
                )
            }
        }
        .padding()
    }
    
    // MARK: - Helper Methods
    
    private func getDestinationIndex(_ destination: Destination) -> Int {
        return viewModel.trip?.destinations.firstIndex(where: { $0.id == destination.id }) ?? 0
    }
    
    private func isCurrentDestination(_ destination: Destination) -> Bool {
        guard let trip = viewModel.trip else { return false }
        return trip.currentDestinationIndex < trip.destinations.count &&
               trip.destinations[trip.currentDestinationIndex].id == destination.id
    }
}

// MARK: - Destination Map Marker

struct DestinationMapMarker: View {
    let destination: Destination
    let index: Int
    let isSelected: Bool
    let isCurrent: Bool
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            ZStack {
                // Outer ring for selection
                if isSelected {
                    Circle()
                        .stroke(Color.accentColor, lineWidth: 3)
                        .frame(width: 50, height: 50)
                        .scaleEffect(1.2)
                        .opacity(0.8)
                }
                
                // Main marker
                Circle()
                    .fill(markerColor)
                    .frame(width: 40, height: 40)
                    .shadow(color: .black.opacity(0.3), radius: 4, x: 0, y: 2)
                
                // Destination number or icon
                if isCurrent {
                    Image(systemName: "location.fill")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                } else {
                    Text("\(index + 1)")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                }
                
                // Type indicator
                VStack {
                    Spacer()
                    
                    Image(systemName: typeIcon)
                        .font(.system(size: 8))
                        .foregroundColor(.white)
                        .padding(2)
                        .background(
                            Circle()
                                .fill(typeColor)
                        )
                        .offset(x: 12, y: -12)
                }
                .frame(width: 40, height: 40)
            }
        }
        .buttonStyle(PlainButtonStyle())
        .scaleEffect(isSelected ? 1.1 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isSelected)
    }
    
    private var markerColor: Color {
        if isCurrent {
            return .accentColor
        } else {
            switch destination.type {
            case .start: return .green
            case .end: return .blue
            case .fuel: return .orange
            case .food: return .red
            case .accommodation: return .purple
            case .attraction: return .yellow
            default: return .gray
            }
        }
    }
    
    private var typeIcon: String {
        switch destination.type {
        case .start: return "play.fill"
        case .waypoint: return "circle.fill"
        case .fuel: return "fuelpump.fill"
        case .food: return "fork.knife"
        case .accommodation: return "bed.double.fill"
        case .attraction: return "star.fill"
        case .end: return "flag.checkered"
        }
    }
    
    private var typeColor: Color {
        markerColor.opacity(0.8)
    }
}

// MARK: - Route Polyline View

struct RoutePolylineView: View {
    let destinations: [Destination]
    
    var body: some View {
        // This is a simplified route visualization
        // In a real implementation, you would use MKPolyline with MapKit
        Path { path in
            guard destinations.count > 1 else { return }
            
            let coordinates = destinations.map { $0.coordinate }
            
            // Convert coordinates to screen points (simplified)
            // This would need proper coordinate-to-screen conversion
            for (index, coordinate) in coordinates.enumerated() {
                let point = CGPoint(x: coordinate.longitude * 100, y: coordinate.latitude * 100)
                
                if index == 0 {
                    path.move(to: point)
                } else {
                    path.addLine(to: point)
                }
            }
        }
        .stroke(Color.accentColor, style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
        .opacity(0.7)
    }
}

// MARK: - Current Destination Card

struct CurrentDestinationCard: View {
    let destination: Destination
    let estimatedArrival: Date?
    
    var body: some View {
        LiquidGlassCard {
            HStack(spacing: 12) {
                Image(systemName: "location.fill")
                    .font(.title2)
                    .foregroundColor(.accentColor)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Current Destination")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Text(destination.name)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Text(destination.address)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                
                Spacer()
                
                if let arrivalTime = estimatedArrival {
                    VStack(alignment: .trailing, spacing: 2) {
                        Text("ETA")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        
                        Text(arrivalTime, style: .time)
                            .font(.subheadline)
                            .fontWeight(.medium)
                            .foregroundColor(.primary)
                    }
                }
            }
        }
        .padding(.horizontal)
    }
}

// MARK: - Map Control Button

struct MapControlButton: View {
    let icon: String
    let isLoading: Bool
    let action: () -> Void
    
    init(icon: String, isLoading: Bool = false, action: @escaping () -> Void) {
        self.icon = icon
        self.isLoading = isLoading
        self.action = action
    }
    
    var body: some View {
        Button(action: action) {
            Group {
                if isLoading {
                    ProgressView()
                        .scaleEffect(0.8)
                } else {
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .medium))
                }
            }
            .foregroundColor(.primary)
            .frame(width: 44, height: 44)
            .background(
                Circle()
                    .fill(.ultraThinMaterial)
                    .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
            )
        }
        .disabled(isLoading)
    }
}

// MARK: - Destination Details Sheet

struct DestinationDetailsSheet: View {
    let destination: Destination
    let estimatedArrival: Date?
    let onDismiss: () -> Void
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // Header
                    VStack(alignment: .leading, spacing: 8) {
                        Text(destination.name)
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        
                        Text(destination.address)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        DestinationTypeBadge(type: destination.type)
                    }
                    
                    // Timing information
                    if let arrivalTime = estimatedArrival {
                        LiquidGlassCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Timing")
                                    .font(.headline)
                                    .foregroundColor(.primary)
                                
                                HStack {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text("Estimated Arrival")
                                            .font(.subheadline)
                                            .foregroundColor(.secondary)
                                        
                                        Text(arrivalTime, style: .time)
                                            .font(.title3)
                                            .fontWeight(.semibold)
                                            .foregroundColor(.primary)
                                    }
                                    
                                    Spacer()
                                    
                                    if let duration = destination.plannedDuration, duration > 0 {
                                        VStack(alignment: .trailing, spacing: 4) {
                                            Text("Planned Stay")
                                                .font(.subheadline)
                                                .foregroundColor(.secondary)
                                            
                                            Text(formatDuration(duration))
                                                .font(.title3)
                                                .fontWeight(.semibold)
                                                .foregroundColor(.primary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    // Notes
                    if let notes = destination.notes, !notes.isEmpty {
                        LiquidGlassCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Notes")
                                    .font(.headline)
                                    .foregroundColor(.primary)
                                
                                Text(notes)
                                    .font(.subheadline)
                                    .foregroundColor(.primary)
                            }
                        }
                    }
                    
                    Spacer()
                }
                .padding()
            }
            .navigationTitle("Destination Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        onDismiss()
                    }
                }
            }
        }
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        
        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }
}

#Preview {
    let mockTrip = Trip(
        name: "California Road Trip",
        code: "ABC123",
        createdBy: UUID(),
        destinations: [
            Destination(name: "San Francisco", address: "San Francisco, CA", coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194), type: .start),
            Destination(name: "Monterey Bay", address: "Monterey, CA", coordinate: CLLocationCoordinate2D(latitude: 36.6002, longitude: -121.8947), type: .attraction),
            Destination(name: "Los Angeles", address: "Los Angeles, CA", coordinate: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437), type: .end)
        ],
        status: .active
    )
    
    let mockViewModel = TripViewModel(tripService: MockTripService(), mapService: MockMapService())
    mockViewModel.trip = mockTrip
    
    return TripMapView(viewModel: mockViewModel)
}

// MARK: - Mock Services for Preview

class MockMapService: MapServiceProtocol {
    func displayRoute(_ route: Route) async throws { }
    func showParticipants(_ participants: [Participant]) async throws { }
    func findNearbyPOIs(category: POICategory, near location: CLLocationCoordinate2D, radius: CLLocationDistance) async throws -> [PointOfInterest] { return [] }
    func calculateRoute(from origin: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D, waypoints: [CLLocationCoordinate2D]) async throws -> Route {
        return Route(name: "Mock Route", destinations: [])
    }
    func calculateMultiDestinationRoute(destinations: [Destination]) async throws -> Route {
        return Route(name: "Mock Route", destinations: destinations)
    }
    func getDirections(for route: Route) async throws -> [RouteStep] { return [] }
    func searchPlaces(query: String, near location: CLLocationCoordinate2D) async throws -> [Place] { return [] }
}