import SwiftUI
import LocalAuthentication

struct LoginView: View {
    @StateObject private var viewModel = AuthenticationViewModel()
    
    // Form fields
    @State private var email = ""
    @State private var password = ""
    @State private var rememberMe = false
    
    // UI State
    @State private var showRegistration = false
    @State private var showForgotPassword = false
    @State private var showBiometricOption = false
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background with liquid glass effect
                LiquidGlassBackground()
                
                ScrollView {
                    VStack(spacing: 32) {
                        // Header
                        headerSection
                        
                        // Login Form
                        loginForm
                        
                        // Biometric Authentication
                        if showBiometricOption {
                            biometricSection
                        }
                        
                        // Sign In Button
                        signInButton
                        
                        // Forgot Password Link
                        forgotPasswordLink
                        
                        // Divider
                        dividerSection
                        
                        // Registration Link
                        registrationLink
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 32)
                }
            }
            .navigationBarHidden(true)
        }
        .sheet(isPresented: $showRegistration) {
            RegistrationView()
        }
        .sheet(isPresented: $showForgotPassword) {
            ForgotPasswordView()
        }
        .alert("Login Error", isPresented: .constant(viewModel.errorMessage != nil)) {
            Button("OK") {
                viewModel.clearError()
            }
        } message: {
            Text(viewModel.errorMessage ?? "")
        }
        .onAppear {
            checkBiometricAvailability()
        }
        .onChange(of: viewModel.authenticationState) { state in
            if case .authenticated = state {
                // Navigation will be handled by the parent view
            }
        }
    }
    
    // MARK: - Header Section
    private var headerSection: some View {
        VStack(spacing: 20) {
            // App Logo/Icon with animated glow
            ZStack {
                Circle()
                    .fill(
                        RadialGradient(
                            colors: [.blue.opacity(0.3), .clear],
                            center: .center,
                            startRadius: 0,
                            endRadius: 80
                        )
                    )
                    .frame(width: 120, height: 120)
                    .blur(radius: 10)
                
                Image(systemName: "car.2.fill")
                    .font(.system(size: 60))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .shadow(color: .blue.opacity(0.5), radius: 15, x: 0, y: 8)
            }
            
            VStack(spacing: 8) {
                Text("Welcome Back")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                Text("Sign in to continue your journey")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
    }
    
    // MARK: - Login Form
    private var loginForm: some View {
        LiquidGlassCard {
            VStack(spacing: 24) {
                // Email Field
                LiquidGlassTextField(
                    title: "Email",
                    text: $email,
                    icon: "envelope.fill"
                )
                .keyboardType(.emailAddress)
                .textInputAutocapitalization(.never)
                
                // Password Field
                LiquidGlassSecureField(
                    title: "Password",
                    text: $password,
                    icon: "lock.fill"
                )
                
                // Remember Me Toggle
                HStack {
                    Button(action: { rememberMe.toggle() }) {
                        HStack(spacing: 8) {
                            Image(systemName: rememberMe ? "checkmark.square.fill" : "square")
                                .foregroundColor(rememberMe ? .blue : .secondary)
                                .font(.system(size: 18))
                            
                            Text("Remember me")
                                .font(.subheadline)
                                .foregroundColor(.primary)
                        }
                    }
                    
                    Spacer()
                }
            }
        }
    }
    
    // MARK: - Biometric Section
    private var biometricSection: some View {
        VStack(spacing: 16) {
            Text("or")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Button(action: handleBiometricAuth) {
                HStack(spacing: 12) {
                    Image(systemName: biometricIcon)
                        .font(.system(size: 20))
                    
                    Text("Sign in with \(biometricType)")
                        .font(.headline)
                        .fontWeight(.medium)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 56)
                .foregroundColor(.primary)
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(.ultraThinMaterial)
                        .overlay(
                            RoundedRectangle(cornerRadius: 16)
                                .stroke(.white.opacity(0.2), lineWidth: 1)
                        )
                        .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
                )
            }
            .disabled(viewModel.isLoading)
        }
    }
    
    // MARK: - Sign In Button
    private var signInButton: some View {
        Button(action: handleSignIn) {
            HStack {
                if viewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .scaleEffect(0.8)
                } else {
                    Text("Sign In")
                        .font(.headline)
                        .fontWeight(.semibold)
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .foregroundColor(.white)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(
                        LinearGradient(
                            colors: isFormValid ? [.blue, .purple] : [.gray.opacity(0.5)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .shadow(
                        color: isFormValid ? .blue.opacity(0.3) : .clear,
                        radius: 10,
                        x: 0,
                        y: 5
                    )
            )
        }
        .disabled(!isFormValid || viewModel.isLoading)
        .scaleEffect(viewModel.isLoading ? 0.95 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.6), value: viewModel.isLoading)
    }
    
    // MARK: - Forgot Password Link
    private var forgotPasswordLink: some View {
        Button(action: { showForgotPassword = true }) {
            Text("Forgot Password?")
                .font(.subheadline)
                .foregroundColor(.blue)
                .fontWeight(.medium)
        }
    }
    
    // MARK: - Divider Section
    private var dividerSection: some View {
        HStack {
            Rectangle()
                .fill(.secondary.opacity(0.3))
                .frame(height: 1)
            
            Text("or")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .padding(.horizontal, 16)
            
            Rectangle()
                .fill(.secondary.opacity(0.3))
                .frame(height: 1)
        }
    }
    
    // MARK: - Registration Link
    private var registrationLink: some View {
        Button(action: { showRegistration = true }) {
            VStack(spacing: 12) {
                HStack(spacing: 4) {
                    Text("Don't have an account?")
                        .foregroundColor(.secondary)
                    
                    Text("Sign Up")
                        .foregroundColor(.blue)
                        .fontWeight(.semibold)
                }
                .font(.subheadline)
                
                Text("Join thousands of road trip enthusiasts")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
    }
    
    // MARK: - Computed Properties
    private var isFormValid: Bool {
        !email.isEmpty && !password.isEmpty && isEmailValid
    }
    
    private var isEmailValid: Bool {
        let emailRegex = #"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"#
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    @State private var biometricManager = BiometricAuthManager()
    
    private var biometricType: String {
        return biometricManager.biometricType.displayName
    }
    
    private var biometricIcon: String {
        return biometricManager.biometricType.iconName
    }
    
    // MARK: - Actions
    private func handleSignIn() {
        Task {
            await viewModel.signIn(email: email, password: password)
        }
    }
    
    private func handleBiometricAuth() {
        Task {
            await viewModel.authenticateWithBiometrics()
        }
    }
    
    private func checkBiometricAvailability() {
        showBiometricOption = biometricManager.isBiometricAvailable
    }
}

// MARK: - Forgot Password View
struct ForgotPasswordView: View {
    @StateObject private var viewModel = AuthenticationViewModel()
    @Environment(\.dismiss) private var dismiss
    
    @State private var email = ""
    @State private var showSuccess = false
    
    var body: some View {
        NavigationView {
            ZStack {
                LiquidGlassBackground()
                
                VStack(spacing: 32) {
                    // Header
                    VStack(spacing: 16) {
                        Image(systemName: "envelope.badge")
                            .font(.system(size: 60))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [.blue, .purple],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                        
                        VStack(spacing: 8) {
                            Text("Reset Password")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                                .foregroundColor(.primary)
                            
                            Text("Enter your email address and we'll send you a link to reset your password")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                        }
                    }
                    
                    // Email Form
                    LiquidGlassCard {
                        LiquidGlassTextField(
                            title: "Email",
                            text: $email,
                            icon: "envelope.fill"
                        )
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                    }
                    
                    // Reset Button
                    Button(action: handlePasswordReset) {
                        HStack {
                            if viewModel.isLoading {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    .scaleEffect(0.8)
                            } else {
                                Text("Send Reset Link")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .foregroundColor(.white)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(
                                    LinearGradient(
                                        colors: isEmailValid ? [.blue, .purple] : [.gray.opacity(0.5)],
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                        )
                    }
                    .disabled(!isEmailValid || viewModel.isLoading)
                    
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 32)
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
        .alert("Reset Link Sent", isPresented: $showSuccess) {
            Button("OK") {
                dismiss()
            }
        } message: {
            Text("If an account with this email exists, you'll receive a password reset link shortly.")
        }
        .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
            Button("OK") {
                viewModel.clearError()
            }
        } message: {
            Text(viewModel.errorMessage ?? "")
        }
    }
    
    private var isEmailValid: Bool {
        let emailRegex = #"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"#
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    private func handlePasswordReset() {
        Task {
            await viewModel.resetPassword(email: email)
            if viewModel.errorMessage == nil {
                showSuccess = true
            }
        }
    }
}

#Preview {
    LoginView()
}