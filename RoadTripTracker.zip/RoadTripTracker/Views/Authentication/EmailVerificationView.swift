import SwiftUI

struct EmailVerificationView: View {
    @StateObject private var viewModel = AuthenticationViewModel()
    @Environment(\.dismiss) private var dismiss
    
    let email: String
    
    @State private var verificationCode = ""
    @State private var showResendSuccess = false
    @State private var resendCooldown = 0
    @State private var timer: Timer?
    
    var body: some View {
        NavigationView {
            ZStack {
                LiquidGlassBackground()
                
                VStack(spacing: 32) {
                    // Header
                    headerSection
                    
                    // Verification Form
                    verificationForm
                    
                    // Verify Button
                    verifyButton
                    
                    // Resend Section
                    resendSection
                    
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 32)
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Back") {
                        dismiss()
                    }
                }
            }
        }
        .alert("Verification Error", isPresented: .constant(viewModel.errorMessage != nil)) {
            Button("OK") {
                viewModel.clearError()
            }
        } message: {
            Text(viewModel.errorMessage ?? "")
        }
        .alert("Email Resent", isPresented: $showResendSuccess) {
            Button("OK") { }
        } message: {
            Text("A new verification email has been sent to \(email)")
        }
        .onChange(of: viewModel.authenticationState) { state in
            if case .authenticated = state {
                dismiss()
            }
        }
        .onDisappear {
            timer?.invalidate()
        }
    }
    
    // MARK: - Header Section
    private var headerSection: some View {
        VStack(spacing: 20) {
            // Email verification icon with animation
            ZStack {
                Circle()
                    .fill(
                        RadialGradient(
                            colors: [.blue.opacity(0.3), .clear],
                            center: .center,
                            startRadius: 0,
                            endRadius: 80
                        )
                    )
                    .frame(width: 120, height: 120)
                    .blur(radius: 10)
                
                Image(systemName: "envelope.badge.shield.half.filled")
                    .font(.system(size: 60))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .shadow(color: .blue.opacity(0.5), radius: 15, x: 0, y: 8)
            }
            
            VStack(spacing: 12) {
                Text("Verify Your Email")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                VStack(spacing: 8) {
                    Text("We've sent a verification link to:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text(email)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(.blue.opacity(0.1))
                        )
                    
                    Text("Click the link in the email or enter the verification code below")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
            }
        }
    }
    
    // MARK: - Verification Form
    private var verificationForm: some View {
        LiquidGlassCard {
            VStack(spacing: 20) {
                Text("Verification Code")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                // Verification code input
                HStack(spacing: 8) {
                    ForEach(0..<6, id: \.self) { index in
                        VerificationDigitField(
                            text: $verificationCode,
                            index: index
                        )
                    }
                }
                
                Text("Enter the 6-digit code from your email")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
    }
    
    // MARK: - Verify Button
    private var verifyButton: some View {
        Button(action: handleVerification) {
            HStack {
                if viewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .scaleEffect(0.8)
                } else {
                    Text("Verify Email")
                        .font(.headline)
                        .fontWeight(.semibold)
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .foregroundColor(.white)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(
                        LinearGradient(
                            colors: isCodeValid ? [.blue, .purple] : [.gray.opacity(0.5)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .shadow(
                        color: isCodeValid ? .blue.opacity(0.3) : .clear,
                        radius: 10,
                        x: 0,
                        y: 5
                    )
            )
        }
        .disabled(!isCodeValid || viewModel.isLoading)
        .scaleEffect(viewModel.isLoading ? 0.95 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.6), value: viewModel.isLoading)
    }
    
    // MARK: - Resend Section
    private var resendSection: some View {
        VStack(spacing: 16) {
            Text("Didn't receive the email?")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            if resendCooldown > 0 {
                Text("Resend available in \(resendCooldown)s")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            } else {
                Button(action: handleResendEmail) {
                    HStack(spacing: 8) {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 16))
                        
                        Text("Resend Email")
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                    .foregroundColor(.blue)
                }
                .disabled(viewModel.isLoading)
            }
        }
    }
    
    // MARK: - Computed Properties
    private var isCodeValid: Bool {
        verificationCode.count == 6 && verificationCode.allSatisfy { $0.isNumber }
    }
    
    // MARK: - Actions
    private func handleVerification() {
        Task {
            await viewModel.verifyEmail(token: verificationCode)
        }
    }
    
    private func handleResendEmail() {
        Task {
            await viewModel.resetPassword(email: email) // This will trigger resend
            if viewModel.errorMessage == nil {
                showResendSuccess = true
                startResendCooldown()
            }
        }
    }
    
    private func startResendCooldown() {
        resendCooldown = 60
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if resendCooldown > 0 {
                resendCooldown -= 1
            } else {
                timer?.invalidate()
                timer = nil
            }
        }
    }
}

// MARK: - Verification Digit Field
struct VerificationDigitField: View {
    @Binding var text: String
    let index: Int
    
    @FocusState private var isFocused: Bool
    
    var body: some View {
        TextField("", text: .constant(digitText))
            .focused($isFocused)
            .keyboardType(.numberPad)
            .multilineTextAlignment(.center)
            .font(.title2)
            .fontWeight(.semibold)
            .frame(width: 45, height: 55)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(
                                isFocused ? .blue.opacity(0.5) : .white.opacity(0.2),
                                lineWidth: isFocused ? 2 : 1
                            )
                            .animation(.easeInOut(duration: 0.2), value: isFocused)
                    )
            )
            .onChange(of: text) { newValue in
                // Auto-focus next field when digit is entered
                if newValue.count > index && index < 5 {
                    // Move focus to next field (this would need proper focus management)
                }
            }
            .onTapGesture {
                isFocused = true
            }
    }
    
    private var digitText: String {
        guard text.count > index else { return "" }
        let digitIndex = text.index(text.startIndex, offsetBy: index)
        return String(text[digitIndex])
    }
}

#Preview {
    EmailVerificationView(email: "test@example.com")
}