import SwiftUI

struct RegistrationView: View {
    @StateObject private var viewModel = AuthenticationViewModel()
    @Environment(\.dismiss) private var dismiss
    
    // Form fields
    @State private var username = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var city = ""
    @State private var dateOfBirth = Date()
    
    // Vehicle details
    @State private var showVehicleDetails = false
    @State private var vehicleMake = ""
    @State private var vehicleModel = ""
    @State private var vehicleNumber = ""
    @State private var odometerReading = ""
    @State private var selectedVehicleType = VehicleType.sedan
    @State private var vehicleColor = ""
    
    // UI State
    @State private var showDatePicker = false
    @State private var agreedToTerms = false
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background with liquid glass effect
                LiquidGlassBackground()
                
                ScrollView {
                    VStack(spacing: 24) {
                        // Header
                        headerSection
                        
                        // Registration Form
                        registrationForm
                        
                        // Vehicle Details Section
                        vehicleDetailsSection
                        
                        // Terms and Conditions
                        termsSection
                        
                        // Register Button
                        registerButton
                        
                        // Sign In Link
                        signInLink
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 32)
                }
            }
            .navigationBarHidden(true)
        }
        .alert("Registration Error", isPresented: .constant(viewModel.errorMessage != nil)) {
            Button("OK") {
                viewModel.clearError()
            }
        } message: {
            Text(viewModel.errorMessage ?? "")
        }
        .onChange(of: viewModel.authenticationState) { state in
            if case .emailVerificationRequired = state {
                // Navigate to email verification view
                dismiss()
            }
        }
    }
    
    // MARK: - Header Section
    private var headerSection: some View {
        VStack(spacing: 16) {
            // App Logo/Icon
            Image(systemName: "car.2.fill")
                .font(.system(size: 60))
                .foregroundStyle(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .shadow(color: .blue.opacity(0.3), radius: 10, x: 0, y: 5)
            
            VStack(spacing: 8) {
                Text("Create Account")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                Text("Join the road trip adventure")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
    }
    
    // MARK: - Registration Form
    private var registrationForm: some View {
        LiquidGlassCard {
            VStack(spacing: 20) {
                // Username Field
                LiquidGlassTextField(
                    title: "Username",
                    text: $username,
                    icon: "person.fill"
                )
                
                // Email Field
                LiquidGlassTextField(
                    title: "Email",
                    text: $email,
                    icon: "envelope.fill"
                )
                .keyboardType(.emailAddress)
                .textInputAutocapitalization(.never)
                
                // Password Field
                LiquidGlassSecureField(
                    title: "Password",
                    text: $password,
                    icon: "lock.fill"
                )
                
                // Confirm Password Field
                LiquidGlassSecureField(
                    title: "Confirm Password",
                    text: $confirmPassword,
                    icon: "lock.fill"
                )
                
                // City Field
                LiquidGlassTextField(
                    title: "City",
                    text: $city,
                    icon: "location.fill"
                )
                
                // Date of Birth
                Button(action: { showDatePicker.toggle() }) {
                    HStack {
                        Image(systemName: "calendar")
                            .foregroundColor(.blue)
                            .frame(width: 20)
                        
                        Text("Date of Birth")
                            .foregroundColor(.primary)
                        
                        Spacer()
                        
                        Text(dateOfBirth, style: .date)
                            .foregroundColor(.secondary)
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(.ultraThinMaterial)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(.white.opacity(0.2), lineWidth: 1)
                            )
                    )
                }
                .sheet(isPresented: $showDatePicker) {
                    DatePickerSheet(selectedDate: $dateOfBirth)
                }
            }
        }
    }
    
    // MARK: - Vehicle Details Section
    private var vehicleDetailsSection: some View {
        VStack(spacing: 16) {
            // Toggle for vehicle details
            Button(action: { 
                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                    showVehicleDetails.toggle()
                }
            }) {
                HStack {
                    Image(systemName: "car.fill")
                        .foregroundColor(.blue)
                    
                    Text("Add Vehicle Details")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Image(systemName: showVehicleDetails ? "chevron.up" : "chevron.down")
                        .foregroundColor(.secondary)
                        .rotationEffect(.degrees(showVehicleDetails ? 180 : 0))
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(.ultraThinMaterial)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(.white.opacity(0.2), lineWidth: 1)
                        )
                )
            }
            
            if showVehicleDetails {
                LiquidGlassCard {
                    VStack(spacing: 20) {
                        // Vehicle Make
                        LiquidGlassTextField(
                            title: "Make",
                            text: $vehicleMake,
                            icon: "car.fill"
                        )
                        
                        // Vehicle Model
                        LiquidGlassTextField(
                            title: "Model",
                            text: $vehicleModel,
                            icon: "car.fill"
                        )
                        
                        // Vehicle Number
                        LiquidGlassTextField(
                            title: "License Plate",
                            text: $vehicleNumber,
                            icon: "number"
                        )
                        
                        // Odometer Reading
                        LiquidGlassTextField(
                            title: "Odometer (km)",
                            text: $odometerReading,
                            icon: "speedometer"
                        )
                        .keyboardType(.numberPad)
                        
                        // Vehicle Type Picker
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Vehicle Type")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            
                            Picker("Vehicle Type", selection: $selectedVehicleType) {
                                ForEach(VehicleType.allCases, id: \.self) { type in
                                    Text(type.displayName).tag(type)
                                }
                            }
                            .pickerStyle(.menu)
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(.ultraThinMaterial)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(.white.opacity(0.2), lineWidth: 1)
                                    )
                            )
                        }
                        
                        // Vehicle Color (Optional)
                        LiquidGlassTextField(
                            title: "Color (Optional)",
                            text: $vehicleColor,
                            icon: "paintpalette.fill"
                        )
                    }
                }
                .transition(.asymmetric(
                    insertion: .scale.combined(with: .opacity),
                    removal: .scale.combined(with: .opacity)
                ))
            }
        }
    }
    
    // MARK: - Terms Section
    private var termsSection: some View {
        Button(action: { agreedToTerms.toggle() }) {
            HStack(spacing: 12) {
                Image(systemName: agreedToTerms ? "checkmark.square.fill" : "square")
                    .foregroundColor(agreedToTerms ? .blue : .secondary)
                    .font(.title2)
                
                Text("I agree to the Terms of Service and Privacy Policy")
                    .font(.footnote)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.leading)
                
                Spacer()
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(.white.opacity(0.2), lineWidth: 1)
                )
        )
    }
    
    // MARK: - Register Button
    private var registerButton: some View {
        Button(action: handleRegistration) {
            HStack {
                if viewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .scaleEffect(0.8)
                } else {
                    Text("Create Account")
                        .font(.headline)
                        .fontWeight(.semibold)
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .foregroundColor(.white)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(
                        LinearGradient(
                            colors: isFormValid ? [.blue, .purple] : [.gray.opacity(0.5)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .shadow(
                        color: isFormValid ? .blue.opacity(0.3) : .clear,
                        radius: 10,
                        x: 0,
                        y: 5
                    )
            )
        }
        .disabled(!isFormValid || viewModel.isLoading)
        .scaleEffect(viewModel.isLoading ? 0.95 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.6), value: viewModel.isLoading)
    }
    
    // MARK: - Sign In Link
    private var signInLink: some View {
        Button(action: { dismiss() }) {
            HStack(spacing: 4) {
                Text("Already have an account?")
                    .foregroundColor(.secondary)
                
                Text("Sign In")
                    .foregroundColor(.blue)
                    .fontWeight(.semibold)
            }
            .font(.subheadline)
        }
    }
    
    // MARK: - Computed Properties
    private var isFormValid: Bool {
        !username.isEmpty &&
        !email.isEmpty &&
        !password.isEmpty &&
        password == confirmPassword &&
        !city.isEmpty &&
        agreedToTerms &&
        isPasswordValid
    }
    
    private var isPasswordValid: Bool {
        password.count >= 8 &&
        password.range(of: "[A-Z]", options: .regularExpression) != nil &&
        password.range(of: "[a-z]", options: .regularExpression) != nil &&
        password.range(of: "[0-9]", options: .regularExpression) != nil
    }
    
    private var vehicle: Vehicle? {
        guard showVehicleDetails,
              !vehicleMake.isEmpty,
              !vehicleModel.isEmpty,
              !vehicleNumber.isEmpty,
              let odometer = Int(odometerReading) else {
            return nil
        }
        
        return Vehicle(
            make: vehicleMake,
            model: vehicleModel,
            vehicleNumber: vehicleNumber,
            odometerReading: odometer,
            type: selectedVehicleType,
            color: vehicleColor.isEmpty ? nil : vehicleColor
        )
    }
    
    // MARK: - Actions
    private func handleRegistration() {
        Task {
            await viewModel.signUp(
                username: username,
                email: email,
                password: password,
                city: city,
                dateOfBirth: dateOfBirth,
                vehicle: vehicle
            )
        }
    }
}

// MARK: - Date Picker Sheet
struct DatePickerSheet: View {
    @Binding var selectedDate: Date
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            VStack {
                DatePicker(
                    "Date of Birth",
                    selection: $selectedDate,
                    in: ...Date(),
                    displayedComponents: .date
                )
                .datePickerStyle(.wheel)
                .padding()
                
                Spacer()
            }
            .navigationTitle("Date of Birth")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

#Preview {
    RegistrationView()
}