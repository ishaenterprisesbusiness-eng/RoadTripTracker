import SwiftUI
import PhotosUI

struct ProfileEditView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var authViewModel: AuthenticationViewModel
    
    let user: User
    
    @State private var username: String
    @State private var city: String
    @State private var dateOfBirth: Date
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var profileImage: UIImage?
    
    @State private var isLoading = false
    @State private var showingError = false
    @State private var errorMessage = ""
    
    init(user: User) {
        self.user = user
        self._username = State(initialValue: user.username)
        self._city = State(initialValue: user.city)
        self._dateOfBirth = State(initialValue: user.dateOfBirth)
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                LiquidGlassBackground()
                
                ScrollView {
                    VStack(spacing: 24) {
                        // Profile Image Section
                        profileImageSection
                        
                        // Personal Information
                        personalInformationSection
                        
                        // Save Button
                        LiquidGlassButton(
                            title: isLoading ? "Saving..." : "Save Changes",
                            icon: "checkmark.circle.fill",
                            style: .primary
                        ) {
                            Task {
                                await saveChanges()
                            }
                        }
                        .disabled(isLoading || !hasChanges)
                        .opacity(isLoading || !hasChanges ? 0.6 : 1.0)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .padding(.bottom, 100)
                }
            }
            .navigationTitle("Edit Profile")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .alert("Error", isPresented: $showingError) {
                Button("OK") { }
            } message: {
                Text(errorMessage)
            }
        }
        .onChange(of: selectedPhoto) { _, newPhoto in
            Task {
                if let newPhoto = newPhoto {
                    if let data = try? await newPhoto.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        profileImage = image
                    }
                }
            }
        }
    }
    
    // MARK: - Profile Image Section
    
    private var profileImageSection: some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                Text("Profile Photo")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                HStack {
                    // Current/New Profile Image
                    Group {
                        if let profileImage = profileImage {
                            Image(uiImage: profileImage)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                        } else if let profileImageURL = user.profileImageURL {
                            AsyncImage(url: profileImageURL) { image in
                                image
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                            } placeholder: {
                                Circle()
                                    .fill(LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .overlay(
                                        Text(String(username.prefix(1)).uppercased())
                                            .font(.title)
                                            .fontWeight(.bold)
                                            .foregroundColor(.white)
                                    )
                            }
                        } else {
                            Circle()
                                .fill(LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                                .overlay(
                                    Text(String(username.prefix(1)).uppercased())
                                        .font(.title)
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                )
                        }
                    }
                    .frame(width: 100, height: 100)
                    .clipShape(Circle())
                    .overlay(
                        Circle()
                            .stroke(.white.opacity(0.3), lineWidth: 2)
                    )
                    
                    Spacer()
                    
                    VStack(spacing: 12) {
                        PhotosPicker(selection: $selectedPhoto, matching: .images) {
                            LiquidGlassButton(
                                title: "Change Photo",
                                icon: "camera.fill",
                                style: .secondary
                            ) { }
                        }
                        
                        if profileImage != nil || user.profileImageURL != nil {
                            Button("Remove Photo") {
                                profileImage = nil
                                selectedPhoto = nil
                            }
                            .font(.subheadline)
                            .foregroundColor(.red)
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - Personal Information Section
    
    private var personalInformationSection: some View {
        LiquidGlassCard {
            VStack(spacing: 20) {
                Text("Personal Information")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                VStack(spacing: 16) {
                    // Username
                    LiquidGlassTextField(
                        title: "Username",
                        text: $username,
                        icon: "person"
                    )
                    
                    // Email (Read-only)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Email")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        HStack(spacing: 12) {
                            Image(systemName: "envelope")
                                .foregroundColor(.secondary)
                                .frame(width: 20)
                            
                            Text(user.email)
                                .foregroundColor(.secondary)
                            
                            Spacer()
                            
                            Text("Cannot be changed")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(.ultraThinMaterial)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(.white.opacity(0.1), lineWidth: 1)
                                )
                        )
                    }
                    
                    // City
                    LiquidGlassTextField(
                        title: "City",
                        text: $city,
                        icon: "location"
                    )
                    
                    // Date of Birth
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Date of Birth")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        HStack(spacing: 12) {
                            Image(systemName: "calendar")
                                .foregroundColor(.secondary)
                                .frame(width: 20)
                            
                            DatePicker(
                                "",
                                selection: $dateOfBirth,
                                in: ...Date(),
                                displayedComponents: .date
                            )
                            .datePickerStyle(.compact)
                            .labelsHidden()
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(.ultraThinMaterial)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(.white.opacity(0.2), lineWidth: 1)
                                )
                        )
                    }
                    
                    // Age Display
                    HStack {
                        Text("Age: \(calculatedAge)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Spacer()
                    }
                }
            }
        }
    }
    
    // MARK: - Computed Properties
    
    private var hasChanges: Bool {
        username != user.username ||
        city != user.city ||
        dateOfBirth != user.dateOfBirth ||
        profileImage != nil
    }
    
    private var calculatedAge: Int {
        Calendar.current.dateComponents([.year], from: dateOfBirth, to: Date()).year ?? 0
    }
    
    // MARK: - Methods
    
    private func saveChanges() async {
        isLoading = true
        errorMessage = ""
        
        do {
            // Create updated user object
            var updatedUser = user
            updatedUser.username = username
            updatedUser.city = city
            updatedUser.dateOfBirth = dateOfBirth
            updatedUser.age = calculatedAge
            
            // TODO: Upload profile image if changed
            if let profileImage = profileImage {
                // In a real app, you would upload the image to a server and get back a URL
                // For now, we'll just simulate this
                print("Would upload profile image: \(profileImage)")
            }
            
            // TODO: Update user profile via AuthenticationManager
            // await authViewModel.updateProfile(updatedUser)
            
            // Simulate API call
            try await Task.sleep(nanoseconds: 1_000_000_000) // 1 second delay
            
            dismiss()
            
        } catch {
            errorMessage = "Failed to save changes: \(error.localizedDescription)"
            showingError = true
        }
        
        isLoading = false
    }
}

#Preview {
    let sampleUser = User(
        username: "John Doe",
        email: "john.doe@example.com",
        city: "Sydney",
        dateOfBirth: Calendar.current.date(byAdding: .year, value: -30, to: Date()) ?? Date()
    )
    
    return ProfileEditView(user: sampleUser)
        .environmentObject(AuthenticationViewModel())
}