import SwiftUI
import CoreLocation
import Combine

// MARK: - Budget View
struct BudgetView: View {
    @StateObject private var viewModel: BudgetViewModel
    let trip: Trip
    let currentParticipant: Participant
    
    init(trip: Trip, currentParticipant: Participant, budgetService: BudgetServiceProtocol, locationService: LocationServiceProtocol) {
        self.trip = trip
        self.currentParticipant = currentParticipant
        self._viewModel = StateObject(wrappedValue: BudgetViewModel(budgetService: budgetService, locationService: locationService))
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                // Glassmorphic background
                GlasmorphicDesignSystem.backgroundGradient
                    .ignoresSafeArea()
                
                ScrollView {
                    LazyVStack(spacing: 20) {
                        if let summary = viewModel.budgetSummary {
                            budgetSummaryCard(summary)
                            categoryBreakdownCard(summary)
                            participantSpendingCard(summary)
                            recentExpensesCard(summary)
                        } else if viewModel.isLoading {
                            loadingView
                        } else {
                            noBudgetView
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Budget")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button("Add Expense", systemImage: "plus.circle") {
                            viewModel.showingAddExpense = true
                        }
                        
                        Button("Budget Settings", systemImage: "gearshape") {
                            viewModel.showingBudgetSettings = true
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                            .foregroundColor(.primary)
                    }
                }
            }
            .sheet(isPresented: $viewModel.showingAddExpense) {
                AddExpenseView(
                    viewModel: viewModel,
                    trip: trip,
                    currentParticipant: currentParticipant
                )
            }
            .sheet(isPresented: $viewModel.showingBudgetSettings) {
                BudgetSettingsView(
                    viewModel: viewModel,
                    trip: trip
                )
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.clearError()
                }
            } message: {
                Text(viewModel.errorMessage ?? "")
            }
            .onAppear {
                viewModel.loadBudgetSummary(for: trip.id)
            }
        }
    }
    
    // MARK: - Budget Summary Card
    private func budgetSummaryCard(_ summary: BudgetSummary) -> some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    VStack(alignment: .leading) {
                        Text("Trip Budget")
                            .font(.headline)
                            .foregroundColor(.primary)
                        
                        Text(summary.statusMessage)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing) {
                        Text("$\(viewModel.formattedAmount(summary.totalBudget))")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        
                        Text("Total Budget")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                // Budget progress bar
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Spent: $\(viewModel.formattedAmount(summary.totalSpent))")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                        
                        Spacer()
                        
                        Text("Remaining: $\(viewModel.formattedAmount(summary.remainingBudget))")
                            .font(.subheadline)
                            .foregroundColor(summary.remainingBudget >= 0 ? .green : .red)
                    }
                    
                    ProgressView(value: min(summary.spentPercentage, 1.0))
                        .progressViewStyle(LinearProgressViewStyle(tint: progressColor(for: summary.spentPercentage)))
                        .scaleEffect(x: 1, y: 2, anchor: .center)
                }
                
                // Quick stats
                HStack {
                    VStack {
                        Text("$\(viewModel.formattedAmount(summary.averageSpendingPerDay))")
                            .font(.title3)
                            .fontWeight(.semibold)
                        Text("Per Day")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    VStack {
                        Text("\(Int(summary.spentPercentage * 100))%")
                            .font(.title3)
                            .fontWeight(.semibold)
                        Text("Used")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    VStack {
                        Text("$\(viewModel.formattedAmount(summary.projectedTotalSpending))")
                            .font(.title3)
                            .fontWeight(.semibold)
                        Text("Projected")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            .padding()
        }
    }
    
    // MARK: - Category Breakdown Card
    private func categoryBreakdownCard(_ summary: BudgetSummary) -> some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("Spending by Category")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                ForEach(ExpenseCategory.allCases, id: \.self) { category in
                    let amount = summary.spendingByCategory[category] ?? 0
                    if amount > 0 {
                        categoryRow(category: category, amount: amount, total: summary.totalSpent)
                    }
                }
                
                if summary.spendingByCategory.isEmpty {
                    Text("No expenses recorded yet")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding()
                }
            }
            .padding()
        }
    }
    
    private func categoryRow(category: ExpenseCategory, amount: Double, total: Double) -> some View {
        HStack {
            Image(systemName: viewModel.categoryIcon(for: category))
                .foregroundColor(Color(viewModel.categoryColor(for: category)))
                .frame(width: 20)
            
            Text(category.displayName)
                .font(.subheadline)
            
            Spacer()
            
            VStack(alignment: .trailing) {
                Text("$\(viewModel.formattedAmount(amount))")
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                if total > 0 {
                    Text("\(Int((amount / total) * 100))%")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
    }
    
    // MARK: - Participant Spending Card
    private func participantSpendingCard(_ summary: BudgetSummary) -> some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("Spending by Participant")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                ForEach(trip.participants, id: \.id) { participant in
                    let amount = summary.spendingByParticipant[participant.id] ?? 0
                    participantRow(participant: participant, amount: amount)
                }
            }
            .padding()
        }
    }
    
    private func participantRow(participant: Participant, amount: Double) -> some View {
        HStack {
            Text(participant.user.username)
                .font(.subheadline)
            
            Spacer()
            
            Text("$\(viewModel.formattedAmount(amount))")
                .font(.subheadline)
                .fontWeight(.medium)
        }
    }
    
    // MARK: - Recent Expenses Card
    private func recentExpensesCard(_ summary: BudgetSummary) -> some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text("Recent Expenses")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Button("View All") {
                        // Navigate to full expense list
                    }
                    .font(.caption)
                    .foregroundColor(.blue)
                }
                
                // Show last 3 expenses (would need to be passed from summary)
                Text("Recent expenses would be shown here")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            }
            .padding()
        }
    }
    
    // MARK: - Loading View
    private var loadingView: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(spacing: 16) {
                ProgressView()
                    .scaleEffect(1.2)
                
                Text("Loading budget information...")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            .padding(40)
        }
    }
    
    // MARK: - No Budget View
    private var noBudgetView: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(spacing: 20) {
                Image(systemName: "dollarsign.circle")
                    .font(.system(size: 60))
                    .foregroundColor(.blue)
                
                Text("No Budget Set")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Set up a budget for this trip to track expenses and stay within your spending limits.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                
                Button("Set Up Budget") {
                    viewModel.showingBudgetSettings = true
                }
                .buttonStyle(GlasmorphicDesignSystem.GlassButtonStyle())
            }
            .padding(30)
        }
    }
    
    // MARK: - Helper Methods
    private func progressColor(for percentage: Double) -> Color {
        if percentage >= 0.9 { return .red }
        else if percentage >= 0.8 { return .orange }
        else if percentage >= 0.6 { return .yellow }
        else { return .green }
    }
}

// MARK: - Preview
struct BudgetView_Previews: PreviewProvider {
    static var previews: some View {
        let mockTrip = Trip(
            name: "Sample Trip",
            code: "ABC123",
            createdBy: UUID(),
            participants: [],
            destinations: []
        )
        
        let mockParticipant = Participant(
            userId: UUID(),
            user: User(
                id: UUID(),
                username: "Test User",
                email: "test@example.com",
                city: "Test City",
                dateOfBirth: Date(),
                age: 25
            )
        )
        
        // Would need to provide mock services
        BudgetView(
            trip: mockTrip,
            currentParticipant: mockParticipant,
            budgetService: MockBudgetService(),
            locationService: MockLocationService()
        )
    }
}

// MARK: - Mock Services for Preview
class MockBudgetService: BudgetServiceProtocol {
    func createBudget(for tripId: UUID, totalBudget: Double, perPersonBudget: Double?) async throws -> Budget {
        return Budget(totalBudget: totalBudget, perPersonBudget: perPersonBudget)
    }
    
    func addExpense(_ expense: Expense, to tripId: UUID) async throws {}
    func updateExpense(_ expense: Expense) async throws {}
    func deleteExpense(_ expenseId: UUID, from tripId: UUID) async throws {}
    
    func getBudgetSummary(for tripId: UUID) async throws -> BudgetSummary {
        return BudgetSummary(
            tripId: tripId,
            totalBudget: 1000,
            totalSpent: 650,
            remainingBudget: 350,
            spendingByCategory: [.fuel: 300, .food: 250, .activities: 100],
            spendingByParticipant: [UUID(): 650]
        )
    }
    
    var budgetUpdates: AnyPublisher<BudgetUpdate, Never> {
        Empty().eraseToAnyPublisher()
    }
}

class MockLocationService: LocationServiceProtocol {
    var currentLocation: CLLocation? = CLLocation(latitude: 0, longitude: 0)
    var authorizationStatus: CLAuthorizationStatus = .authorizedWhenInUse
    var locationUpdates: AnyPublisher<CLLocation, Never> = Empty().eraseToAnyPublisher()
    var authorizationUpdates: AnyPublisher<CLAuthorizationStatus, Never> = Empty().eraseToAnyPublisher()
    var isLocationSharingEnabled: Bool = true
    
    func requestLocationPermission() async throws {}
    func startLocationSharing() async throws {}
    func stopLocationSharing() {}
    func getCurrentLocation() async throws -> CLLocation {
        return CLLocation(latitude: 0, longitude: 0)
    }
    func startMonitoringSignificantLocationChanges() {}
    func stopMonitoringSignificantLocationChanges() {}
    func calculateDistance(from: CLLocation, to: CLLocation) -> CLLocationDistance { return 0 }
    func calculateDrivingDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) async throws -> CLLocationDistance { return 0 }
    func isLocationStale(_ location: CLLocation, threshold: TimeInterval) -> Bool { return false }
}