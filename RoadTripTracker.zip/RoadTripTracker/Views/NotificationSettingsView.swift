import SwiftUI
import UserNotifications

struct NotificationSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var notificationManager = NotificationManager(
        notificationService: ServiceContainer.shared.notificationService,
        locationManager: ServiceContainer.shared.locationService as! LocationManager
    )
    
    @State private var preferences = NotificationPreferences()
    @State private var permissionStatus: UNAuthorizationStatus = .notDetermined
    
    @State private var isLoading = false
    @State private var showingError = false
    @State private var showingSuccess = false
    @State private var showingPermissionAlert = false
    @State private var errorMessage = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                LiquidGlassBackground()
                
                ScrollView {
                    VStack(spacing: 24) {
                        // Header
                        LiquidGlassCard {
                            VStack(spacing: 16) {
                                HStack {
                                    Image(systemName: "bell.badge")
                                        .font(.system(size: 32))
                                        .foregroundColor(.blue)
                                    
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text("Notification Preferences")
                                            .font(.title2)
                                            .fontWeight(.bold)
                                            .foregroundColor(.primary)
                                        
                                        Text("Customize your notification settings")
                                            .font(.subheadline)
                                            .foregroundColor(.secondary)
                                    }
                                    
                                    Spacer()
                                }
                            }
                        }
                        
                        // Trip Notifications
                        tripNotificationsSection
                        
                        // Communication Notifications
                        communicationNotificationsSection
                        
                        // Quiet Hours
                        quietHoursSection
                        
                        // Save Button
                        LiquidGlassButton(
                            title: isLoading ? "Saving..." : "Save Preferences",
                            icon: "checkmark.circle.fill",
                            style: .primary
                        ) {
                            Task {
                                await savePreferences()
                            }
                        }
                        .disabled(isLoading)
                        .opacity(isLoading ? 0.6 : 1.0)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .padding(.bottom, 100)
                }
            }
            .navigationTitle("Notifications")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .alert("Error", isPresented: $showingError) {
                Button("OK") { }
            } message: {
                Text(errorMessage)
            }
            .alert("Success", isPresented: $showingSuccess) {
                Button("OK") {
                    dismiss()
                }
            } message: {
                Text("Your notification preferences have been saved.")
            }
        }
        .onAppear {
            loadPreferences()
            checkPermissionStatus()
        }
        .onReceive(notificationManager.notificationPermissionStatus) { status in
            permissionStatus = status
        }
        .alert("Notifications Disabled", isPresented: $showingPermissionAlert) {
            Button("Settings") {
                openNotificationSettings()
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("Please enable notifications in Settings to receive trip alerts and updates.")
        }
    }
    
    // MARK: - Trip Notifications Section
    
    private var tripNotificationsSection: some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                HStack {
                    Text("Trip Notifications")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Spacer()
                }
                
                VStack(spacing: 12) {
                    notificationToggle(
                        title: "Trip Updates",
                        description: "Route changes, destination updates",
                        isOn: $preferences.tripEvents,
                        icon: "map"
                    )
                    
                    Divider()
                    
                    notificationToggle(
                        title: "Participant Updates",
                        description: "When someone joins or leaves your trip",
                        isOn: $preferences.participantUpdates,
                        icon: "person.badge.plus"
                    )
                    
                    Divider()
                    
                    notificationToggle(
                        title: "Location Alerts",
                        description: "Approaching destinations and waypoints",
                        isOn: $preferences.locationAlerts,
                        icon: "location"
                    )
                    
                    Divider()
                    
                    notificationToggle(
                        title: "Emergency Alerts",
                        description: "Critical safety notifications",
                        isOn: $preferences.emergencyAlerts,
                        icon: "exclamationmark.triangle.fill",
                        isImportant: true
                    )
                }
            }
        }
    }
    
    // MARK: - Communication Notifications Section
    
    private var communicationNotificationsSection: some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                HStack {
                    Text("Communication & Features")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Spacer()
                }
                
                VStack(spacing: 12) {
                    notificationToggle(
                        title: "Weather Alerts",
                        description: "Severe weather warnings",
                        isOn: $preferences.weatherAlerts,
                        icon: "cloud.bolt"
                    )
                    
                    Divider()
                    
                    notificationToggle(
                        title: "Budget Alerts",
                        description: "Budget limit notifications",
                        isOn: $preferences.budgetAlerts,
                        icon: "dollarsign.circle"
                    )
                }
            }
        }
    }
    
    // MARK: - Quiet Hours Section
    
    private var quietHoursSection: some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                HStack {
                    Text("Quiet Hours")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Toggle("", isOn: $preferences.respectDoNotDisturb)
                        .labelsHidden()
                }
                
                if preferences.respectDoNotDisturb {
                    VStack(spacing: 16) {
                        Text("Reduce non-critical notifications during these hours")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        HStack(spacing: 20) {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Start Time")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                
                                Picker("Start Hour", selection: $preferences.quietHoursStart) {
                                    ForEach(0..<24, id: \.self) { hour in
                                        Text("\(hour):00").tag(hour)
                                    }
                                }
                                .pickerStyle(.menu)
                            }
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("End Time")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                
                                Picker("End Hour", selection: $preferences.quietHoursEnd) {
                                    ForEach(0..<24, id: \.self) { hour in
                                        Text("\(hour):00").tag(hour)
                                    }
                                }
                                .pickerStyle(.menu)
                            }
                        }
                        
                        Text("Emergency alerts will always be delivered regardless of quiet hours settings.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
        }
        .animation(.easeInOut(duration: 0.3), value: preferences.respectDoNotDisturb)
    }
    
    // MARK: - Helper Views
    
    private func notificationToggle(
        title: String,
        description: String,
        isOn: Binding<Bool>,
        icon: String,
        isImportant: Bool = false
    ) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 18))
                .foregroundColor(isImportant ? .red : .blue)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.body)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                Text(description)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Toggle("", isOn: isOn)
                .labelsHidden()
                .disabled(isImportant && isOn.wrappedValue) // Emergency alerts cannot be disabled
        }
        .padding(.vertical, 4)
    }
    
    // MARK: - Methods
    
    private func loadPreferences() {
        preferences = notificationManager.getNotificationPreferences()
    }
    
    private func checkPermissionStatus() {
        Task {
            let settings = await UNUserNotificationCenter.current().notificationSettings()
            await MainActor.run {
                permissionStatus = settings.authorizationStatus
            }
        }
    }
    
    private func savePreferences() async {
        isLoading = true
        errorMessage = ""
        
        // Check if notifications are enabled
        if permissionStatus == .denied {
            showingPermissionAlert = true
            isLoading = false
            return
        }
        
        // Request permission if not determined
        if permissionStatus == .notDetermined {
            let granted = await notificationManager.requestNotificationPermission()
            if !granted {
                showingPermissionAlert = true
                isLoading = false
                return
            }
        }
        
        do {
            await notificationManager.updateNotificationPreferences(preferences)
            showingSuccess = true
        } catch {
            errorMessage = "Failed to save preferences: \(error.localizedDescription)"
            showingError = true
        }
        
        isLoading = false
    }
    
    private func openNotificationSettings() {
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
            return
        }
        
        if UIApplication.shared.canOpenURL(settingsUrl) {
            UIApplication.shared.open(settingsUrl)
        }
    }
}

#Preview {
    NotificationSettingsView()
}