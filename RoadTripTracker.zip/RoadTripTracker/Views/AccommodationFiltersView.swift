import SwiftUI

struct AccommodationFiltersView: View {
    @Binding var filters: AccommodationSearchFilters
    @Environment(\.dismiss) private var dismiss
    
    let onApply: () -> Void
    
    @State private var selectedTypes: Set<AccommodationType>
    @State private var minRating: Double
    @State private var maxDistance: Double
    @State private var selectedAmenities: Set<Amenity>
    @State private var priceRangeEnabled = false
    @State private var minPriceRange: PriceRange = .budget
    @State private var maxPriceRange: PriceRange = .luxury
    
    init(filters: Binding<AccommodationSearchFilters>, onApply: @escaping () -> Void) {
        self._filters = filters
        self.onApply = onApply
        
        // Initialize state from current filters
        self._selectedTypes = State(initialValue: filters.wrappedValue.types)
        self._minRating = State(initialValue: filters.wrappedValue.minRating ?? 0.0)
        self._maxDistance = State(initialValue: filters.wrappedValue.maxDistance ?? 50.0)
        self._selectedAmenities = State(initialValue: filters.wrappedValue.requiredAmenities)
        
        if let priceRange = filters.wrappedValue.priceRange {
            self._priceRangeEnabled = State(initialValue: true)
            self._minPriceRange = State(initialValue: priceRange.lowerBound)
            self._maxPriceRange = State(initialValue: priceRange.upperBound)
        }
    }
    
    var body: some View {
        NavigationView {
            Form {
                accommodationTypesSection
                priceRangeSection
                ratingSection
                distanceSection
                amenitiesSection
            }
            .navigationTitle("Filters")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Reset") {
                        resetFilters()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Apply") {
                        applyFilters()
                        dismiss()
                    }
                    .fontWeight(.semibold)
                }
            }
        }
    }
    
    // MARK: - View Sections
    
    private var accommodationTypesSection: some View {
        Section("Accommodation Types") {
            ForEach(AccommodationType.allCases, id: \.self) { type in
                HStack {
                    Image(systemName: type.icon)
                        .foregroundColor(.blue)
                        .frame(width: 24)
                    
                    Text(type.displayName)
                    
                    Spacer()
                    
                    if selectedTypes.contains(type) {
                        Image(systemName: "checkmark")
                            .foregroundColor(.blue)
                    }
                }
                .contentShape(Rectangle())
                .onTapGesture {
                    toggleAccommodationType(type)
                }
            }
        }
    }
    
    private var priceRangeSection: some View {
        Section("Price Range") {
            Toggle("Filter by price", isOn: $priceRangeEnabled)
            
            if priceRangeEnabled {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("From")
                        Spacer()
                        Picker("Min Price", selection: $minPriceRange) {
                            ForEach(PriceRange.allCases, id: \.self) { range in
                                Text(range.displayName).tag(range)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                    }
                    
                    HStack {
                        Text("To")
                        Spacer()
                        Picker("Max Price", selection: $maxPriceRange) {
                            ForEach(PriceRange.allCases, id: \.self) { range in
                                Text(range.displayName).tag(range)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                    }
                }
            }
        }
    }
    
    private var ratingSection: some View {
        Section("Minimum Rating") {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Rating")
                    Spacer()
                    HStack(spacing: 2) {
                        ForEach(0..<Int(minRating), id: \.self) { _ in
                            Image(systemName: "star.fill")
                                .foregroundColor(.yellow)
                                .font(.caption)
                        }
                        if minRating > 0 {
                            Text(String(format: "%.1f+", minRating))
                                .font(.caption)
                                .foregroundColor(.secondary)
                        } else {
                            Text("Any")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                Slider(value: $minRating, in: 0...5, step: 0.5)
            }
        }
    }
    
    private var distanceSection: some View {
        Section("Maximum Distance") {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Distance")
                    Spacer()
                    Text("\(Int(maxDistance)) km")
                        .foregroundColor(.secondary)
                }
                
                Slider(value: $maxDistance, in: 5...100, step: 5)
            }
        }
    }
    
    private var amenitiesSection: some View {
        Section("Required Amenities") {
            LazyVGrid(columns: [
                GridItem(.flexible()),
                GridItem(.flexible())
            ], spacing: 12) {
                ForEach(Amenity.allCases, id: \.self) { amenity in
                    amenityToggle(amenity)
                }
            }
            .padding(.vertical, 8)
        }
    }
    
    private func amenityToggle(_ amenity: Amenity) -> some View {
        Button(action: {
            toggleAmenity(amenity)
        }) {
            HStack(spacing: 6) {
                Image(systemName: amenity.icon)
                    .font(.caption)
                    .frame(width: 16)
                
                Text(amenity.displayName)
                    .font(.caption)
                    .lineLimit(1)
                
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 6)
            .background(
                selectedAmenities.contains(amenity) ?
                Color.blue.opacity(0.1) : Color(.systemGray6)
            )
            .foregroundColor(
                selectedAmenities.contains(amenity) ? .blue : .primary
            )
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(
                        selectedAmenities.contains(amenity) ? Color.blue : Color.clear,
                        lineWidth: 1
                    )
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    // MARK: - Methods
    
    private func toggleAccommodationType(_ type: AccommodationType) {
        if selectedTypes.contains(type) {
            selectedTypes.remove(type)
        } else {
            selectedTypes.insert(type)
        }
    }
    
    private func toggleAmenity(_ amenity: Amenity) {
        if selectedAmenities.contains(amenity) {
            selectedAmenities.remove(amenity)
        } else {
            selectedAmenities.insert(amenity)
        }
    }
    
    private func resetFilters() {
        selectedTypes = Set(AccommodationType.allCases)
        minRating = 0.0
        maxDistance = 50.0
        selectedAmenities = []
        priceRangeEnabled = false
        minPriceRange = .budget
        maxPriceRange = .luxury
    }
    
    private func applyFilters() {
        var updatedFilters = AccommodationSearchFilters()
        
        updatedFilters.types = selectedTypes.isEmpty ? Set(AccommodationType.allCases) : selectedTypes
        updatedFilters.minRating = minRating > 0 ? minRating : nil
        updatedFilters.maxDistance = maxDistance
        updatedFilters.requiredAmenities = selectedAmenities
        
        if priceRangeEnabled {
            updatedFilters.priceRange = minPriceRange...maxPriceRange
        }
        
        filters = updatedFilters
        onApply()
    }
}

// MARK: - Preview
struct AccommodationFiltersView_Previews: PreviewProvider {
    @State static var sampleFilters = AccommodationSearchFilters()
    
    static var previews: some View {
        AccommodationFiltersView(filters: $sampleFilters) {
            print("Filters applied")
        }
    }
}