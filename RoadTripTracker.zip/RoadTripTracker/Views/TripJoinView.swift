import SwiftUI

struct TripJoinView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = TripJoinViewModel()
    @State private var tripCode = ""
    @State private var showingAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                LiquidGlassBackground()
                
                ScrollView {
                    VStack(spacing: 32) {
                        headerSection
                        tripCodeSection
                        joinButtonSection
                        
                        if viewModel.isLoading {
                            loadingSection
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 40)
                }
            }
            .navigationTitle("Join Trip")
            .navigationBarTitleDisplayMode(.large)
            .navigationBarBackButtonHidden()
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                    .foregroundColor(.blue)
                }
            }
        }
        .alert("Trip Join Status", isPresented: $showingAlert) {
            Button("OK") {
                if viewModel.joinedTrip != nil {
                    dismiss()
                }
            }
        } message: {
            Text(alertMessage)
        }
        .onChange(of: viewModel.errorMessage) { errorMessage in
            if let error = errorMessage {
                alertMessage = error
                showingAlert = true
            }
        }
        .onChange(of: viewModel.joinedTrip) { trip in
            if trip != nil {
                alertMessage = "Successfully joined the trip!"
                showingAlert = true
            }
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 16) {
            Image(systemName: "car.2.fill")
                .font(.system(size: 64))
                .foregroundStyle(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            
            VStack(spacing: 8) {
                Text("Join a Road Trip")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                Text("Enter the trip code shared by the trip organizer to join their road trip adventure")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
    }
    
    private var tripCodeSection: some View {
        LiquidGlassCard {
            VStack(spacing: 20) {
                HStack {
                    Image(systemName: "number.circle.fill")
                        .font(.title2)
                        .foregroundColor(.blue)
                    
                    Text("Trip Code")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Spacer()
                }
                
                VStack(spacing: 12) {
                    TextField("Enter 6-digit trip code", text: $tripCode)
                        .textFieldStyle(LiquidGlassTextFieldStyle())
                        .textCase(.uppercase)
                        .autocorrectionDisabled()
                        .keyboardType(.asciiCapable)
                        .onChange(of: tripCode) { newValue in
                            // Limit to 6 characters and uppercase
                            let filtered = String(newValue.prefix(6).uppercased())
                            if tripCode != filtered {
                                tripCode = filtered
                            }
                        }
                    
                    Text("Trip codes are 6 characters long (letters and numbers)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
    }
    
    private var joinButtonSection: some View {
        VStack(spacing: 16) {
            LiquidGlassButton(
                title: "Join Trip",
                icon: "arrow.right.circle.fill",
                style: .primary,
                isEnabled: tripCode.count == 6 && !viewModel.isLoading
            ) {
                Task {
                    await viewModel.joinTrip(code: tripCode)
                }
            }
            
            Text("Make sure you have your vehicle details added to your profile before joining a trip")
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
    }
    
    private var loadingSection: some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                ProgressView()
                    .scaleEffect(1.2)
                
                Text("Joining trip...")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            .padding(.vertical, 8)
        }
    }
}

// MARK: - Trip Join View Model
@MainActor
class TripJoinViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var joinedTrip: Trip?
    
    private let tripService: TripServiceProtocol
    
    init(tripService: TripServiceProtocol = ServiceContainer.shared.tripService) {
        self.tripService = tripService
    }
    
    func joinTrip(code: String) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let trip = try await tripService.joinTrip(code: code)
            joinedTrip = trip
        } catch {
            if let tripError = error as? TripServiceError {
                errorMessage = tripError.errorDescription
            } else {
                errorMessage = "Failed to join trip: \(error.localizedDescription)"
            }
        }
        
        isLoading = false
    }
}

#Preview {
    TripJoinView()
}