import SwiftUI
import Combine

struct ProfileView: View {
    @EnvironmentObject var authViewModel: AuthenticationViewModel
    @StateObject private var profileViewModel = ProfileViewModel()
    @State private var showingVehicleEntry = false
    @State private var showingProfileEdit = false
    @State private var showingPasswordChange = false
    @State private var showingNotificationSettings = false
    
    var body: some View {
        NavigationView {
            ZStack {
                LiquidGlassBackground()
                
                ScrollView {
                    VStack(spacing: 24) {
                        // User Profile Header
                        if let user = authViewModel.currentUser {
                            userProfileHeader(user)
                        }
                        
                        // Account Statistics
                        accountStatisticsSection
                        
                        // Trip History
                        tripHistorySection
                        
                        // Vehicle Section
                        vehicleSection
                        
                        // Settings Section
                        settingsSection
                        
                        // Account Actions
                        accountActionsSection
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .padding(.bottom, 100) // Extra padding for tab bar
                }
            }
            .navigationTitle("Profile")
            .navigationBarTitleDisplayMode(.large)
            .refreshable {
                await profileViewModel.refreshData()
            }
        }
        .sheet(isPresented: $showingVehicleEntry) {
            VehicleEntryView()
        }
        .sheet(isPresented: $showingProfileEdit) {
            if let user = authViewModel.currentUser {
                ProfileEditView(user: user)
            }
        }
        .sheet(isPresented: $showingPasswordChange) {
            PasswordChangeView()
        }
        .sheet(isPresented: $showingNotificationSettings) {
            NotificationSettingsView()
        }
        .onAppear {
            Task {
                await profileViewModel.loadTripHistory()
                await profileViewModel.loadAccountStatistics()
            }
        }
    }
    
    // MARK: - User Profile Header
    
    private func userProfileHeader(_ user: User) -> some View {
        LiquidGlassCard {
            VStack(spacing: 20) {
                // Profile Image and Basic Info
                HStack(spacing: 16) {
                    // Profile Image
                    AsyncImage(url: user.profileImageURL) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                    } placeholder: {
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [.blue, .purple],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .overlay(
                                Text(String(user.username.prefix(1)).uppercased())
                                    .font(.title)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                            )
                    }
                    .frame(width: 80, height: 80)
                    .clipShape(Circle())
                    .overlay(
                        Circle()
                            .stroke(.white.opacity(0.3), lineWidth: 2)
                    )
                    
                    // User Details
                    VStack(alignment: .leading, spacing: 4) {
                        Text(user.username)
                            .font(.title2)
                            .fontWeight(.semibold)
                            .foregroundColor(.primary)
                        
                        Text(user.email)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        HStack(spacing: 8) {
                            Image(systemName: "location")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text(user.city)
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text("•")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text("Age \(user.age)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    Spacer()
                }
                
                // Edit Profile Button
                LiquidGlassButton(
                    title: "Edit Profile",
                    icon: "pencil",
                    style: .secondary
                ) {
                    showingProfileEdit = true
                }
            }
        }
    }
    
    // MARK: - Account Statistics
    
    private var accountStatisticsSection: some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                HStack {
                    Text("Account Statistics")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Spacer()
                }
                
                HStack(spacing: 20) {
                    statisticItem(
                        title: "Trips Completed",
                        value: "\(profileViewModel.accountStats.tripsCompleted)",
                        icon: "checkmark.circle.fill",
                        color: .green
                    )
                    
                    Divider()
                        .frame(height: 40)
                    
                    statisticItem(
                        title: "Total Distance",
                        value: "\(Int(profileViewModel.accountStats.totalKilometers)) km",
                        icon: "road.lanes",
                        color: .blue
                    )
                    
                    Divider()
                        .frame(height: 40)
                    
                    statisticItem(
                        title: "Active Trips",
                        value: "\(profileViewModel.accountStats.activeTrips)",
                        icon: "location.fill",
                        color: .orange
                    )
                }
            }
        }
    }
    
    private func statisticItem(title: String, value: String, icon: String, color: Color) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 24))
                .foregroundColor(color)
            
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.primary)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
    }
    
    // MARK: - Trip History Section
    
    private var tripHistorySection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Trip History")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                Spacer()
                
                NavigationLink(destination: TripHistoryView()) {
                    Text("View All")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.blue)
                }
            }
            
            if profileViewModel.recentTrips.isEmpty {
                LiquidGlassCard {
                    VStack(spacing: 12) {
                        Image(systemName: "map.circle")
                            .font(.system(size: 48))
                            .foregroundColor(.secondary)
                        
                        Text("No Trips Yet")
                            .font(.headline)
                            .foregroundColor(.primary)
                        
                        Text("Start your first road trip adventure!")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.vertical, 8)
                }
            } else {
                LazyVStack(spacing: 12) {
                    ForEach(profileViewModel.recentTrips.prefix(3)) { trip in
                        TripHistoryCard(trip: trip)
                    }
                }
            }
        }
    }
    
    // MARK: - Vehicle Section
    
    private var vehicleSection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Vehicle Information")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                Spacer()
                
                Button(action: { showingVehicleEntry = true }) {
                    Text(authViewModel.currentUser?.vehicle == nil ? "Add Vehicle" : "Edit Vehicle")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.blue)
                }
            }
            
            if let vehicle = authViewModel.currentUser?.vehicle {
                VehicleInfoCard(vehicle: vehicle)
            } else {
                LiquidGlassCard {
                    VStack(spacing: 12) {
                        Image(systemName: "car.circle")
                            .font(.system(size: 48))
                            .foregroundColor(.secondary)
                        
                        Text("No Vehicle Added")
                            .font(.headline)
                            .foregroundColor(.primary)
                        
                        Text("Add your vehicle details to help other participants identify your car during trips")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                        
                        LiquidGlassButton(
                            title: "Add Vehicle Details",
                            icon: "plus.circle.fill",
                            style: .primary
                        ) {
                            showingVehicleEntry = true
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
        }
    }
    
    // MARK: - Settings Section
    
    private var settingsSection: some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                HStack {
                    Text("Settings")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Spacer()
                }
                
                VStack(spacing: 12) {
                    settingsRow(
                        title: "Change Password",
                        icon: "lock.shield",
                        action: { showingPasswordChange = true }
                    )
                    
                    Divider()
                    
                    settingsRow(
                        title: "Notification Preferences",
                        icon: "bell.badge",
                        action: { showingNotificationSettings = true }
                    )
                    
                    Divider()
                    
                    settingsRow(
                        title: "Privacy Settings",
                        icon: "hand.raised.shield",
                        action: { /* TODO: Implement privacy settings */ }
                    )
                }
            }
        }
    }
    
    private func settingsRow(title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 18))
                    .foregroundColor(.blue)
                    .frame(width: 24)
                
                Text(title)
                    .font(.body)
                    .foregroundColor(.primary)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.secondary)
            }
            .padding(.vertical, 4)
        }
    }
    
    // MARK: - Account Actions
    
    private var accountActionsSection: some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                Text("Account Actions")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                VStack(spacing: 12) {
                    LiquidGlassButton(
                        title: "Sign Out",
                        icon: "rectangle.portrait.and.arrow.right",
                        style: .destructive
                    ) {
                        Task {
                            try? await authViewModel.signOut()
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    ProfileView()
        .environmentObject(AuthenticationViewModel())
}