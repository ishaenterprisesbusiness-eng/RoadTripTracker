import SwiftUI
import MapKit

struct FuelStopMapView: View {
    @StateObject private var viewModel: FuelStopViewModel
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    )
    @State private var selectedGasStation: GasStation?
    @State private var showingStationDetails = false
    
    init(fuelStopService: FuelStopServiceProtocol, locationManager: LocationManager) {
        self._viewModel = StateObject(wrappedValue: FuelStopViewModel(fuelStopService: fuelStopService, locationManager: locationManager))
    }
    
    var body: some View {
        ZStack {
            Map(coordinateRegion: $region, annotationItems: mapAnnotations) { annotation in
                MapAnnotation(coordinate: annotation.coordinate) {
                    gasStationAnnotation(annotation)
                }
            }
            .ignoresSafeArea()
            
            // Floating controls
            VStack {
                HStack {
                    Spacer()
                    
                    VStack(spacing: 12) {
                        // Search button
                        Button(action: {
                            Task {
                                await viewModel.searchNearbyGasStations()
                            }
                        }) {
                            Image(systemName: "magnifyingglass")
                                .font(.title2)
                                .foregroundColor(.white)
                                .frame(width: 44, height: 44)
                                .background(Color.blue)
                                .clipShape(Circle())
                                .shadow(radius: 4)
                        }
                        
                        // Center on location button
                        Button(action: centerOnCurrentLocation) {
                            Image(systemName: "location.fill")
                                .font(.title2)
                                .foregroundColor(.white)
                                .frame(width: 44, height: 44)
                                .background(Color.green)
                                .clipShape(Circle())
                                .shadow(radius: 4)
                        }
                    }
                    .padding(.trailing)
                }
                
                Spacer()
                
                // Active fuel stop banner
                if let activeFuelStop = viewModel.activeFuelStop {
                    activeFuelStopBanner(activeFuelStop)
                        .padding(.horizontal)
                        .padding(.bottom, 20)
                }
            }
        }
        .sheet(isPresented: $showingStationDetails) {
            if let station = selectedGasStation {
                gasStationDetailSheet(station)
            }
        }
        .sheet(isPresented: $viewModel.showingCheckInSheet) {
            fuelStopCheckInSheet
        }
        .onAppear {
            centerOnCurrentLocation()
        }
    }
    
    // MARK: - Map Annotations
    
    private var mapAnnotations: [GasStationAnnotation] {
        var annotations: [GasStationAnnotation] = []
        
        // Add nearby gas stations
        annotations.append(contentsOf: viewModel.nearbyGasStations.map { station in
            GasStationAnnotation(
                gasStation: station,
                type: .nearby
            )
        })
        
        // Add proposed fuel stops
        annotations.append(contentsOf: viewModel.proposedFuelStops.map { fuelStop in
            GasStationAnnotation(
                gasStation: fuelStop.gasStation,
                type: .proposed(fuelStop.proposalStatus)
            )
        })
        
        // Add active fuel stop
        if let activeFuelStop = viewModel.activeFuelStop {
            annotations.append(GasStationAnnotation(
                gasStation: activeFuelStop.gasStation,
                type: .active
            ))
        }
        
        return annotations
    }
    
    @ViewBuilder
    private func gasStationAnnotation(_ annotation: GasStationAnnotation) -> some View {
        Button(action: {
            selectedGasStation = annotation.gasStation
            showingStationDetails = true
        }) {
            VStack(spacing: 2) {
                Image(systemName: annotation.type.iconName)
                    .font(.title2)
                    .foregroundColor(.white)
                    .frame(width: 32, height: 32)
                    .background(annotation.type.color)
                    .clipShape(Circle())
                    .overlay(
                        Circle()
                            .stroke(Color.white, lineWidth: 2)
                    )
                    .shadow(radius: 3)
                
                Text(annotation.gasStation.name)
                    .font(.caption2)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color.white.opacity(0.9))
                    .cornerRadius(4)
                    .shadow(radius: 1)
            }
        }
    }
    
    // MARK: - Active Fuel Stop Banner
    
    @ViewBuilder
    private func activeFuelStopBanner(_ fuelStop: FuelStop) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "fuelpump.fill")
                    .foregroundColor(.blue)
                
                Text("Active Fuel Stop")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Spacer()
                
                Button("Check In") {
                    viewModel.showCheckInSheet()
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.small)
            }
            
            Text(fuelStop.gasStation.name)
                .font(.subheadline)
                .fontWeight(.medium)
            
            Text(fuelStop.gasStation.address)
                .font(.caption)
                .foregroundColor(.secondary)
            
            // Quick status
            HStack {
                Label("\(fuelStop.checkIns.count) checked in", systemImage: "person.fill")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                let readyCount = fuelStop.checkIns.filter { $0.isReadyToContinue }.count
                Label("\(readyCount) ready", systemImage: "checkmark.circle.fill")
                    .font(.caption)
                    .foregroundColor(readyCount > 0 ? .green : .secondary)
            }
        }
        .padding()
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
        .shadow(radius: 4)
    }
    
    // MARK: - Gas Station Detail Sheet
    
    @ViewBuilder
    private func gasStationDetailSheet(_ gasStation: GasStation) -> some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // Header
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(gasStation.name)
                                .font(.title2)
                                .fontWeight(.bold)
                            
                            Spacer()
                            
                            if let rating = gasStation.rating {
                                HStack(spacing: 4) {
                                    Image(systemName: "star.fill")
                                        .foregroundColor(.yellow)
                                    Text(String(format: "%.1f", rating))
                                        .fontWeight(.medium)
                                }
                            }
                        }
                        
                        if let brand = gasStation.brand {
                            Text(brand)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        
                        Text(gasStation.address)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                    Divider()
                    
                    // Operating Hours
                    HStack {
                        Image(systemName: "clock")
                            .foregroundColor(.blue)
                        
                        Text(gasStation.isOpen24Hours ? "Open 24 Hours" : "Check hours")
                            .font(.subheadline)
                        
                        Spacer()
                    }
                    
                    // Phone Number
                    if let phoneNumber = gasStation.phoneNumber {
                        HStack {
                            Image(systemName: "phone")
                                .foregroundColor(.green)
                            
                            Button(phoneNumber) {
                                if let url = URL(string: "tel:\(phoneNumber)") {
                                    UIApplication.shared.open(url)
                                }
                            }
                            .font(.subheadline)
                            
                            Spacer()
                        }
                    }
                    
                    // Fuel Prices
                    if let prices = gasStation.currentFuelPrices, !prices.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Fuel Prices")
                                .font(.headline)
                            
                            ForEach(Array(prices.keys), id: \.self) { fuelType in
                                HStack {
                                    Text(fuelType.displayName)
                                        .font(.subheadline)
                                    
                                    Spacer()
                                    
                                    Text("$\(String(format: "%.2f", prices[fuelType] ?? 0.0))")
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                }
                            }
                        }
                        
                        Divider()
                    }
                    
                    // Amenities
                    if !gasStation.amenities.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Amenities")
                                .font(.headline)
                            
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 2), spacing: 12) {
                                ForEach(gasStation.amenities, id: \.self) { amenity in
                                    HStack {
                                        Image(systemName: amenity.icon)
                                            .foregroundColor(.blue)
                                            .frame(width: 20)
                                        
                                        Text(amenity.displayName)
                                            .font(.subheadline)
                                        
                                        Spacer()
                                    }
                                }
                            }
                        }
                        
                        Divider()
                    }
                    
                    // Distance from route
                    if let distance = gasStation.distanceFromRoute {
                        HStack {
                            Image(systemName: "location")
                                .foregroundColor(.orange)
                            
                            Text("Distance from route: \(String(format: "%.1f", distance / 1000)) km")
                                .font(.subheadline)
                            
                            Spacer()
                        }
                    }
                    
                    Spacer(minLength: 20)
                    
                    // Action Button
                    Button("Propose as Fuel Stop") {
                        viewModel.showProposalSheet(for: gasStation)
                        showingStationDetails = false
                    }
                    .buttonStyle(.borderedProminent)
                    .frame(maxWidth: .infinity)
                }
                .padding()
            }
            .navigationTitle("Gas Station")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        showingStationDetails = false
                    }
                }
            }
        }
        .sheet(isPresented: $viewModel.showingProposalSheet) {
            fuelStopProposalSheet
        }
    }
    
    // MARK: - Fuel Stop Check-in Sheet
    
    @ViewBuilder
    private var fuelStopCheckInSheet: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Fuel Amount (Liters)")
                        .font(.headline)
                    
                    TextField("Enter fuel amount", text: $viewModel.fuelAmount)
                        .textFieldStyle(.roundedBorder)
                        .keyboardType(.decimalPad)
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Fuel Cost")
                        .font(.headline)
                    
                    TextField("Enter total cost", text: $viewModel.fuelCost)
                        .textFieldStyle(.roundedBorder)
                        .keyboardType(.decimalPad)
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Notes (Optional)")
                        .font(.headline)
                    
                    TextField("Any additional notes...", text: $viewModel.checkInNotes, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .lineLimit(2...4)
                }
                
                Toggle("Ready to continue", isOn: $viewModel.isReadyToContinue)
                    .font(.headline)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Check In")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        viewModel.showingCheckInSheet = false
                        viewModel.clearCheckInForm()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Check In") {
                        Task {
                            await viewModel.checkInAtFuelStop()
                        }
                    }
                    .disabled(viewModel.isLoading)
                }
            }
        }
    }
    
    // MARK: - Fuel Stop Proposal Sheet
    
    @ViewBuilder
    private var fuelStopProposalSheet: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                if let gasStation = viewModel.selectedGasStation {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(gasStation.name)
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Text(gasStation.address)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Notes (Optional)")
                            .font(.headline)
                        
                        TextField("Add any notes about this fuel stop...", text: .constant(""), axis: .vertical)
                            .textFieldStyle(.roundedBorder)
                            .lineLimit(3...6)
                    }
                    
                    Spacer()
                }
            }
            .padding()
            .navigationTitle("Propose Fuel Stop")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        viewModel.showingProposalSheet = false
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Propose") {
                        if let gasStation = viewModel.selectedGasStation {
                            Task {
                                await viewModel.proposeFuelStop(gasStation: gasStation)
                            }
                        }
                    }
                    .disabled(viewModel.isLoading)
                }
            }
        }
    }
    
    // MARK: - Helper Methods
    
    private func centerOnCurrentLocation() {
        // This would typically use the location manager to get current location
        // For now, we'll use a default location
        region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        )
    }
}

// MARK: - Gas Station Annotation

private struct GasStationAnnotation: Identifiable {
    let id = UUID()
    let gasStation: GasStation
    let type: AnnotationType
    
    var coordinate: CLLocationCoordinate2D {
        gasStation.coordinate
    }
    
    enum AnnotationType {
        case nearby
        case proposed(StopProposalStatus)
        case active
        
        var iconName: String {
            switch self {
            case .nearby:
                return "fuelpump"
            case .proposed(let status):
                switch status {
                case .pending: return "clock"
                case .approved: return "checkmark.circle.fill"
                case .rejected: return "xmark.circle.fill"
                default: return "fuelpump"
                }
            case .active:
                return "fuelpump.fill"
            }
        }
        
        var color: Color {
            switch self {
            case .nearby:
                return .gray
            case .proposed(let status):
                switch status {
                case .pending: return .orange
                case .approved: return .green
                case .rejected: return .red
                default: return .gray
                }
            case .active:
                return .blue
            }
        }
    }
}

#Preview {
    FuelStopMapView(
        fuelStopService: FuelStopService(
            placesService: PlacesService(),
            notificationService: MockNotificationService(),
            routeManager: RouteManager()
        ),
        locationManager: LocationManager()
    )
}

// MARK: - Mock Notification Service for Preview
private class MockNotificationService: NotificationServiceProtocol {
    var notificationPermissionStatus: AnyPublisher<UNAuthorizationStatus, Never> {
        Just(.authorized).eraseToAnyPublisher()
    }
    
    func requestNotificationPermission() async throws -> Bool { true }
    func scheduleLocalNotification(_ notification: LocalNotification) async throws {}
    func cancelNotification(withIdentifier identifier: String) async throws {}
    func cancelAllNotifications() async throws {}
    func sendPushNotification(_ notification: PushNotification) async throws {}
    func registerForRemoteNotifications() async throws -> Data { Data() }
    func handleRemoteNotification(_ userInfo: [AnyHashable: Any]) async {}
}