import SwiftUI
import CoreLocation

struct TripDashboardView: View {
    @StateObject private var viewModel = TripDashboardViewModel()
    @State private var showingTripDetails = false
    @State private var showingParticipantList = false
    
    var body: some View {
        NavigationView {
            ZStack {
                LiquidGlassBackground()
                
                if viewModel.isLoading {
                    loadingView
                } else if let trip = viewModel.activeTrip {
                    activeTripDashboard(trip)
                } else {
                    noActiveTripView
                }
            }
            .navigationTitle("Trip Dashboard")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    if viewModel.activeTrip != nil {
                        Button("Refresh") {
                            Task {
                                await viewModel.refreshMetrics()
                            }
                        }
                    }
                }
            }
        }
        .onAppear {
            Task {
                await viewModel.loadDashboard()
            }
        }
        .alert("Error", isPresented: $viewModel.showingError) {
            Button("OK") { }
        } message: {
            Text(viewModel.errorMessage ?? "An unknown error occurred")
        }
    }
    
    // MARK: - Loading View
    
    private var loadingView: some View {
        VStack(spacing: 20) {
            ProgressView()
                .scaleEffect(1.5)
                .tint(.blue)
            
            Text("Loading Dashboard...")
                .font(.headline)
                .foregroundColor(.secondary)
        }
    }
    
    // MARK: - No Active Trip View
    
    private var noActiveTripView: some View {
        LiquidGlassCard {
            VStack(spacing: 24) {
                Image(systemName: "gauge.with.dots.needle.33percent")
                    .font(.system(size: 64))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                
                VStack(spacing: 8) {
                    Text("No Active Trip")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Text("Start or join a trip to see real-time metrics and dashboard")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
            }
            .padding(.vertical, 40)
        }
        .padding(.horizontal, 20)
    }
    
    // MARK: - Active Trip Dashboard
    
    private func activeTripDashboard(_ trip: Trip) -> some View {
        ScrollView {
            LazyVStack(spacing: 20) {
                // Trip Header
                tripHeaderSection(trip)
                
                // Key Metrics
                keyMetricsSection
                
                // Destination Information
                destinationInfoSection
                
                // Weather Information
                weatherInfoSection
                
                // Participant Status
                participantStatusSection(trip)
                
                // Quick Actions
                quickActionsSection
            }
            .padding(.horizontal, 20)
            .padding(.top, 10)
        }
        .refreshable {
            await viewModel.refreshMetrics()
        }
    }
    
    // MARK: - Trip Header Section
    
    private func tripHeaderSection(_ trip: Trip) -> some View {
        LiquidGlassCard {
            VStack(spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("ACTIVE TRIP")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.blue)
                        
                        Text(trip.name)
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing, spacing: 4) {
                        Text("STATUS")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        
                        HStack(spacing: 6) {
                            Circle()
                                .fill(trip.status == .active ? Color.green : Color.orange)
                                .frame(width: 8, height: 8)
                            
                            Text(trip.status.displayName)
                                .font(.subheadline)
                                .fontWeight(.medium)
                                .foregroundColor(.primary)
                        }
                    }
                }
                
                Divider()
                    .background(Color.white.opacity(0.2))
                
                HStack(spacing: 20) {
                    tripStatItem(
                        icon: "car.fill",
                        title: "Active Vehicles",
                        value: "\(viewModel.activeVehicleCount)",
                        color: .green
                    )
                    
                    Divider()
                        .frame(height: 40)
                        .background(Color.white.opacity(0.2))
                    
                    tripStatItem(
                        icon: "mappin.and.ellipse",
                        title: "Destinations",
                        value: "\(trip.destinations.count)",
                        color: .blue
                    )
                    
                    Divider()
                        .frame(height: 40)
                        .background(Color.white.opacity(0.2))
                    
                    tripStatItem(
                        icon: "road.lanes",
                        title: "Remaining",
                        value: viewModel.formattedTotalRemaining,
                        color: .purple
                    )
                }
            }
        }
    }
    
    // MARK: - Key Metrics Section
    
    private var keyMetricsSection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Real-Time Metrics")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                Spacer()
                
                Text("Updated \(formatLastUpdate())")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            LazyVGrid(columns: [
                GridItem(.flexible()),
                GridItem(.flexible())
            ], spacing: 16) {
                // Time to Next Destination
                metricCard(
                    title: "Time to Next",
                    value: viewModel.formattedTimeToNext,
                    subtitle: viewModel.nextDestination?.name ?? "No destination",
                    icon: "clock.fill",
                    color: .orange
                )
                
                // Time to Final Destination
                metricCard(
                    title: "Time to Final",
                    value: viewModel.formattedTimeToFinal,
                    subtitle: viewModel.finalDestination?.name ?? "No destination",
                    icon: "flag.fill",
                    color: .red
                )
                
                // Distance to Next
                metricCard(
                    title: "Distance to Next",
                    value: viewModel.formattedDistanceToNext,
                    subtitle: "Driving distance",
                    icon: "location.fill",
                    color: .blue
                )
                
                // Distance to Final
                metricCard(
                    title: "Distance to Final",
                    value: viewModel.formattedDistanceToFinal,
                    subtitle: "Total remaining",
                    icon: "target",
                    color: .purple
                )
            }
        }
    }
    
    // MARK: - Destination Info Section
    
    private var destinationInfoSection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Destination Information")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                Spacer()
            }
            
            VStack(spacing: 12) {
                if let nextDestination = viewModel.nextDestination {
                    destinationCard(
                        destination: nextDestination,
                        title: "Next Destination",
                        estimatedArrival: viewModel.estimatedArrivalNext,
                        distance: viewModel.formattedDistanceToNext,
                        isPrimary: true
                    )
                }
                
                if let finalDestination = viewModel.finalDestination,
                   finalDestination.id != viewModel.nextDestination?.id {
                    destinationCard(
                        destination: finalDestination,
                        title: "Final Destination",
                        estimatedArrival: viewModel.estimatedArrivalFinal,
                        distance: viewModel.formattedDistanceToFinal,
                        isPrimary: false
                    )
                }
            }
        }
    }
    
    // MARK: - Weather Info Section
    
    private var weatherInfoSection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Weather Information")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                Spacer()
            }
            
            if let nextDestination = viewModel.nextDestination {
                WeatherWidget(
                    coordinate: nextDestination.coordinate,
                    locationName: nextDestination.name,
                    showForecast: false
                )
            } else if let currentLocation = viewModel.currentUserLocation {
                WeatherWidget(
                    coordinate: currentLocation.coordinate,
                    locationName: "Current Location",
                    showForecast: false
                )
            }
        }
    }
    
    // MARK: - Participant Status Section
    
    private func participantStatusSection(_ trip: Trip) -> some View {
        VStack(spacing: 16) {
            HStack {
                Text("Participant Status")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                Spacer()
                
                Button("View All") {
                    showingParticipantList = true
                }
                .font(.subheadline)
                .foregroundColor(.blue)
            }
            
            LiquidGlassCard {
                VStack(spacing: 12) {
                    ForEach(Array(viewModel.participantStatuses.values.prefix(3)), id: \.participant.id) { status in
                        participantStatusRow(status)
                        
                        if status.participant.id != Array(viewModel.participantStatuses.values.prefix(3)).last?.participant.id {
                            Divider()
                                .background(Color.white.opacity(0.2))
                        }
                    }
                    
                    if viewModel.participantStatuses.count > 3 {
                        Button("View All \(viewModel.participantStatuses.count) Participants") {
                            showingParticipantList = true
                        }
                        .font(.subheadline)
                        .foregroundColor(.blue)
                        .padding(.top, 8)
                    }
                }
            }
        }
    }
    
    // MARK: - Quick Actions Section
    
    private var quickActionsSection: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Quick Actions")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                Spacer()
            }
            
            LazyVGrid(columns: [
                GridItem(.flexible()),
                GridItem(.flexible())
            ], spacing: 16) {
                actionCard(
                    title: "View Trip",
                    icon: "map.fill",
                    color: .blue
                ) {
                    showingTripDetails = true
                }
                
                actionCard(
                    title: "Participants",
                    icon: "person.3.fill",
                    color: .green
                ) {
                    showingParticipantList = true
                }
                
                actionCard(
                    title: "Navigation",
                    icon: "location.north.fill",
                    color: .orange
                ) {
                    // Open navigation to next destination
                    openNavigation()
                }
                
                actionCard(
                    title: "Emergency",
                    icon: "exclamationmark.triangle.fill",
                    color: .red
                ) {
                    // Handle emergency action
                    handleEmergency()
                }
            }
        }
    }
    
    // MARK: - Helper Views
    
    private func tripStatItem(icon: String, title: String, value: String, color: Color) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
            
            Text(value)
                .font(.headline)
                .fontWeight(.bold)
                .foregroundColor(.primary)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
    
    private func metricCard(title: String, value: String, subtitle: String, icon: String, color: Color) -> some View {
        LiquidGlassCard(style: .secondary) {
            VStack(spacing: 12) {
                HStack {
                    Image(systemName: icon)
                        .font(.title2)
                        .foregroundColor(color)
                    
                    Spacer()
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(value)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Text(title)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                    
                    Text(subtitle)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
    
    private func destinationCard(destination: Destination, title: String, estimatedArrival: Date?, distance: String, isPrimary: Bool) -> some View {
        LiquidGlassCard(style: isPrimary ? .primary : .secondary) {
            VStack(spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(title)
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(isPrimary ? .blue : .secondary)
                        
                        Text(destination.name)
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundColor(.primary)
                            .lineLimit(1)
                        
                        Text(destination.address)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .lineLimit(2)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing, spacing: 4) {
                        Text(distance)
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        
                        if let arrival = estimatedArrival {
                            Text("ETA: \(formatTime(arrival))")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
        }
    }
    
    private func participantStatusRow(_ status: ParticipantDashboardStatus) -> some View {
        HStack(spacing: 12) {
            // Status indicator
            Circle()
                .fill(Color(status.statusColor))
                .frame(width: 12, height: 12)
            
            // Participant info
            VStack(alignment: .leading, spacing: 2) {
                Text(status.participant.user.username)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                Text(status.statusText)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            // Distance info
            VStack(alignment: .trailing, spacing: 2) {
                Text("\(String(format: "%.1f", status.distanceToNext)) km")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                Text("to next")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }
    
    private func actionCard(title: String, icon: String, color: Color, action: @escaping () -> Void) -> some View {
        LiquidGlassCard(style: .secondary) {
            Button(action: action) {
                VStack(spacing: 12) {
                    Image(systemName: icon)
                        .font(.system(size: 28))
                        .foregroundColor(color)
                    
                    Text(title)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                }
                .padding(.vertical, 8)
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(PlainButtonStyle())
        }
    }
    
    // MARK: - Helper Methods
    
    private func formatLastUpdate() -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: Date())
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    private func openNavigation() {
        guard let nextDestination = viewModel.nextDestination else { return }
        
        let coordinate = nextDestination.coordinate
        let url = URL(string: "maps://?daddr=\(coordinate.latitude),\(coordinate.longitude)")!
        
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url)
        }
    }
    
    private func handleEmergency() {
        // This would trigger emergency protocols
        // For now, we'll just show an alert
        // In a real implementation, this would send emergency notifications
    }
}

#Preview {
    TripDashboardView()
        .preferredColorScheme(.dark)
}