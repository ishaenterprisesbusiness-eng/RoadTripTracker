import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @EnvironmentObject var integrationManager: AppIntegrationManager
    @EnvironmentObject var accessibilityManager: AccessibilityManager
    @StateObject private var authViewModel = AuthenticationViewModel()
    
    var body: some View {
        Group {
            if authViewModel.isAuthenticated {
                MainTabView()
                    .accessibilityAnnouncement("Welcome back to Road Trip Tracker")
            } else {
                AuthenticationView()
                    .accessibilityAnnouncement("Please sign in to continue")
            }
        }
        .environmentObject(authViewModel)
        .onAppear {
            setupAccessibilityNotifications()
        }
    }
    
    private func setupAccessibilityNotifications() {
        // Announce app state changes for accessibility
        if accessibilityManager.isVoiceOverEnabled {
            if integrationManager.isOfflineMode {
                accessibilityManager.announceForAccessibility(
                    "App is running in offline mode. Some features may be limited.",
                    priority: .announcement
                )
            }
        }
    }
}

// MARK: - Main Tab View
struct MainTabView: View {
    @StateObject private var lightingSystem = AdaptiveLightingSystem()
    @EnvironmentObject var accessibilityManager: AccessibilityManager
    @EnvironmentObject var integrationManager: AppIntegrationManager
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            TripDashboardView()
                .tabItem {
                    Image(systemName: "gauge")
                    Text("Dashboard")
                }
                .tag(0)
                .accessibilityElement(.tripDashboard)
            
            MapView()
                .tabItem {
                    Image(systemName: "map")
                    Text("Map")
                }
                .tag(1)
                .accessibilityElement(.mapView)
            
            ChatView()
                .tabItem {
                    Image(systemName: "message")
                    Text("Chat")
                }
                .tag(2)
                .accessibilityElement(.chatView)
            
            ProfileView()
                .tabItem {
                    Image(systemName: "person")
                    Text("Profile")
                }
                .tag(3)
                .accessibilityElement(.profileView)
            
            // Add glassmorphic test view for development
            #if DEBUG
            GlasmorphicTestView()
                .tabItem {
                    Image(systemName: "paintbrush")
                    Text("Design")
                }
                .tag(4)
            #endif
        }
        .background(
            // Adaptive glassmorphic background
            adaptiveBackground
                .ignoresSafeArea()
        )
        .preferredColorScheme(.dark)
        .onChange(of: selectedTab) { newTab in
            announceTabChange(newTab)
        }
        .overlay(
            // Offline mode indicator
            offlineModeIndicator,
            alignment: .top
        )
    }
    
    // MARK: - Adaptive Background
    private var adaptiveBackground: some View {
        ZStack {
            // Base gradient with accessibility considerations
            LinearGradient(
                colors: accessibilityManager.shouldReduceTransparency() ? [
                    .black,
                    .black
                ] : [
                    .blue.opacity(0.1),
                    .purple.opacity(0.1),
                    .pink.opacity(0.05)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            
            // Animated elements (only if motion is not reduced)
            if !accessibilityManager.shouldReduceAnimations() {
                ForEach(0..<3, id: \.self) { index in
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [
                                    .white.opacity(lightingSystem.adaptiveOpacity * 0.1),
                                    .clear
                                ],
                                center: .center,
                                startRadius: 0,
                                endRadius: 100
                            )
                        )
                        .frame(width: 200, height: 200)
                        .adaptiveBlur(radius: 2)
                        .offset(
                            x: CGFloat.random(in: -100...100),
                            y: CGFloat.random(in: -200...200)
                        )
                        .animation(
                            .easeInOut(duration: Double.random(in: 8...12))
                            .repeatForever(autoreverses: true)
                            .delay(Double(index) * 3),
                            value: lightingSystem.adaptiveOpacity
                        )
                }
            }
        }
    }
    
    // MARK: - Offline Mode Indicator
    private var offlineModeIndicator: some View {
        Group {
            if integrationManager.isOfflineMode {
                HStack(spacing: 8) {
                    Image(systemName: "wifi.slash")
                        .font(.caption)
                    
                    Text("Offline Mode")
                        .font(.caption)
                        .fontWeight(.medium)
                }
                .foregroundColor(.orange)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(
                    Capsule()
                        .fill(.ultraThinMaterial)
                        .overlay(
                            Capsule()
                                .stroke(.orange.opacity(0.5), lineWidth: 1)
                        )
                )
                .padding(.top, 8)
                .accessibilityLabel("App is running in offline mode")
                .accessibilityHint("Some features may be limited without internet connection")
            }
        }
    }
    
    // MARK: - Accessibility Helpers
    private func announceTabChange(_ tabIndex: Int) {
        guard accessibilityManager.isVoiceOverEnabled else { return }
        
        let tabNames = ["Dashboard", "Map", "Chat", "Profile", "Design"]
        if tabIndex < tabNames.count {
            accessibilityManager.announceForAccessibility(
                "\(tabNames[tabIndex]) tab selected",
                priority: .layoutChanged
            )
        }
    }
}

// MARK: - Authentication View
struct AuthenticationView: View {
    @EnvironmentObject var authViewModel: AuthenticationViewModel
    
    var body: some View {
        Group {
            switch authViewModel.authenticationState {
            case .emailVerificationRequired:
                if let email = authViewModel.currentUser?.email {
                    EmailVerificationView(email: email)
                } else {
                    LoginView()
                }
            default:
                LoginView()
            }
        }
    }
}



struct MapView: View {
    @State private var showLocationSettings = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Coming Soon Card
                    AdaptiveGlassCard {
                        VStack(alignment: .leading, spacing: 16) {
                            HStack {
                                Image(systemName: "map.fill")
                                    .font(.title2)
                                    .foregroundColor(.blue)
                                
                                Text("Interactive Map")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                
                                Spacer()
                            }
                            
                            Text("Real-time vehicle tracking, route visualization, and destination management coming soon.")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.leading)
                            
                            FluidGlassButton(
                                title: "Location Settings",
                                icon: "location.circle",
                                style: .secondary
                            ) {
                                showLocationSettings = true
                            }
                        }
                    }
                    
                    // Features Preview
                    AdaptiveGlassCard {
                        VStack(alignment: .leading, spacing: 16) {
                            Text("Upcoming Features")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            VStack(alignment: .leading, spacing: 12) {
                                FeatureRow(icon: "car.2.fill", title: "Vehicle Tracking", description: "See all convoy vehicles in real-time")
                                FeatureRow(icon: "route", title: "Smart Routing", description: "Optimized multi-destination routes")
                                FeatureRow(icon: "location.north.fill", title: "Navigation", description: "Turn-by-turn directions")
                                FeatureRow(icon: "fuelpump.fill", title: "Stop Planning", description: "Coordinate fuel and food stops")
                            }
                        }
                    }
                    
                    Spacer(minLength: 100)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
            }
            .navigationTitle("Map")
            .navigationBarTitleDisplayMode(.large)
        }
        .sheet(isPresented: $showLocationSettings) {
            AdvancedGlassModal(isPresented: $showLocationSettings) {
                VStack(spacing: 20) {
                    Text("Location Settings")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("Configure location sharing and privacy settings for your road trip.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                    
                    FluidGlassButton(
                        title: "Configure",
                        icon: "gear",
                        style: .primary
                    ) {
                        showLocationSettings = false
                    }
                }
            }
        }
    }
}

struct ChatView: View {
    @State private var showChatSettings = false
    @State private var messageText = ""
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Coming Soon Card
                    AdaptiveGlassCard {
                        VStack(alignment: .leading, spacing: 16) {
                            HStack {
                                Image(systemName: "message.fill")
                                    .font(.title2)
                                    .foregroundColor(.green)
                                
                                Text("Group Chat")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                
                                Spacer()
                            }
                            
                            Text("Real-time messaging, photo sharing, and location updates for your road trip group.")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.leading)
                            
                            FluidGlassButton(
                                title: "Chat Settings",
                                icon: "gear",
                                style: .secondary
                            ) {
                                showChatSettings = true
                            }
                        }
                    }
                    
                    // Message Preview
                    AdaptiveGlassCard {
                        VStack(alignment: .leading, spacing: 16) {
                            Text("Message Preview")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            DynamicGlassTextField(
                                title: "Type a message",
                                text: $messageText,
                                icon: "message"
                            )
                            
                            FluidGlassButton(
                                title: "Send Message",
                                icon: "paperplane.fill",
                                style: .primary
                            ) {
                                // Preview functionality
                                messageText = ""
                            }
                        }
                    }
                    
                    // Features Preview
                    AdaptiveGlassCard {
                        VStack(alignment: .leading, spacing: 16) {
                            Text("Chat Features")
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            VStack(alignment: .leading, spacing: 12) {
                                FeatureRow(icon: "message.badge.fill", title: "Real-time Messaging", description: "Instant group communication")
                                FeatureRow(icon: "photo.fill", title: "Photo Sharing", description: "Share trip memories instantly")
                                FeatureRow(icon: "location.fill", title: "Location Sharing", description: "Quick location updates")
                                FeatureRow(icon: "bell.fill", title: "Smart Notifications", description: "Important trip alerts")
                            }
                        }
                    }
                    
                    Spacer(minLength: 100)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
            }
            .navigationTitle("Chat")
            .navigationBarTitleDisplayMode(.large)
        }
        .sheet(isPresented: $showChatSettings) {
            AdvancedGlassModal(isPresented: $showChatSettings) {
                VStack(spacing: 20) {
                    Text("Chat Settings")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("Configure notification preferences and chat behavior for your road trip group.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                    
                    HStack(spacing: 16) {
                        FluidGlassButton(
                            title: "Cancel",
                            style: .secondary
                        ) {
                            showChatSettings = false
                        }
                        
                        FluidGlassButton(
                            title: "Save",
                            icon: "checkmark",
                            style: .primary
                        ) {
                            showChatSettings = false
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Feature Row Component
struct FeatureRow: View {
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.blue)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Text(description)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
    }
}

// ProfileView is now defined in its own file: RoadTripTracker/Views/ProfileView.swift

#Preview {
    ContentView()
        .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
}