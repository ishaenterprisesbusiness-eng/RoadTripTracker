import SwiftUI
import CoreLocation
import PhotosUI

// MARK: - Chat View
struct ChatView: View {
    @StateObject private var viewModel = ChatViewModel()
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var showingEmergencyAlert = false
    @State private var emergencyMessage = ""
    
    let tripId: UUID
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background gradient
                LinearGradient(
                    colors: [
                        Color.blue.opacity(0.1),
                        Color.purple.opacity(0.05)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Connection status bar
                    if viewModel.connectionStatus != .connected {
                        connectionStatusBar
                    }
                    
                    // Messages list
                    messagesScrollView
                    
                    // Message input area
                    messageInputArea
                }
            }
            .navigationTitle("Group Chat")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    emergencyButton
                }
            }
            .task {
                await viewModel.loadMessages(for: tripId)
            }
            .onDisappear {
                Task {
                    await viewModel.disconnect()
                }
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.clearError()
                }
            } message: {
                Text(viewModel.errorMessage ?? "")
            }
            .alert("Emergency Alert", isPresented: $showingEmergencyAlert) {
                TextField("Emergency message", text: $emergencyMessage)
                Button("Send") {
                    Task {
                        await viewModel.sendEmergencyMessage(emergencyMessage)
                        emergencyMessage = ""
                    }
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Send an emergency message to all trip participants")
            }
            .photosPicker(isPresented: $viewModel.showingPhotoPicker, selection: $selectedPhoto, matching: .images)
            .onChange(of: selectedPhoto) { _, newValue in
                Task {
                    if let newValue,
                       let data = try? await newValue.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        await viewModel.sendPhotoMessage(image)
                    }
                    selectedPhoto = nil
                }
            }
        }
    }
    
    // MARK: - Connection Status Bar
    private var connectionStatusBar: some View {
        HStack {
            Circle()
                .fill(statusColor)
                .frame(width: 8, height: 8)
            
            Text(statusText)
                .font(.caption)
                .foregroundColor(.secondary)
            
            Spacer()
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(
            Rectangle()
                .fill(.ultraThinMaterial)
                .overlay(
                    Rectangle()
                        .stroke(Color.white.opacity(0.2), lineWidth: 0.5)
                )
        )
    }
    
    private var statusColor: Color {
        switch viewModel.connectionStatus {
        case .connected:
            return .green
        case .connecting:
            return .orange
        case .disconnected:
            return .red
        case .error:
            return .red
        }
    }
    
    private var statusText: String {
        switch viewModel.connectionStatus {
        case .connected:
            return "Connected"
        case .connecting:
            return "Connecting..."
        case .disconnected:
            return "Disconnected"
        case .error(let message):
            return "Error: \(message)"
        }
    }
    
    // MARK: - Messages Scroll View
    private var messagesScrollView: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 12) {
                    ForEach(Array(viewModel.messages.enumerated()), id: \.element.id) { index, message in
                        let previousMessage = index > 0 ? viewModel.messages[index - 1] : nil
                        
                        VStack(spacing: 4) {
                            // Timestamp separator
                            if viewModel.shouldShowTimestamp(message, previousMessage: previousMessage) {
                                timestampView(message.timestamp)
                            }
                            
                            // Message bubble
                            MessageBubbleView(
                                message: message,
                                isFromCurrentUser: viewModel.isMessageFromCurrentUser(message),
                                onRetry: {
                                    Task {
                                        await viewModel.retryFailedMessage(message)
                                    }
                                },
                                onDelete: {
                                    Task {
                                        await viewModel.deleteMessage(message)
                                    }
                                }
                            )
                            .onAppear {
                                Task {
                                    await viewModel.markMessageAsRead(message)
                                }
                            }
                        }
                    }
                }
                .padding()
            }
            .onChange(of: viewModel.messages.count) { _, _ in
                // Auto-scroll to bottom when new messages arrive
                if let lastMessage = viewModel.messages.last {
                    withAnimation(.easeOut(duration: 0.3)) {
                        proxy.scrollTo(lastMessage.id, anchor: .bottom)
                    }
                }
            }
        }
    }
    
    private func timestampView(_ timestamp: Date) -> some View {
        Text(viewModel.formatMessageTime(timestamp))
            .font(.caption2)
            .foregroundColor(.secondary)
            .padding(.horizontal, 12)
            .padding(.vertical, 4)
            .background(
                Capsule()
                    .fill(.ultraThinMaterial)
                    .overlay(
                        Capsule()
                            .stroke(Color.white.opacity(0.2), lineWidth: 0.5)
                    )
            )
            .padding(.vertical, 8)
    }
    
    // MARK: - Message Input Area
    private var messageInputArea: some View {
        VStack(spacing: 0) {
            // Input controls
            HStack(spacing: 12) {
                // Photo button
                Button {
                    viewModel.showingPhotoPicker = true
                } label: {
                    Image(systemName: "photo")
                        .font(.title2)
                        .foregroundColor(.blue)
                }
                .buttonStyle(GlassButtonStyle())
                
                // Location button
                Button {
                    Task {
                        await viewModel.sendLocationMessage()
                    }
                } label: {
                    Image(systemName: "location")
                        .font(.title2)
                        .foregroundColor(.green)
                }
                .buttonStyle(GlassButtonStyle())
                
                // Text input
                HStack {
                    TextField("Type a message...", text: $viewModel.messageText, axis: .vertical)
                        .textFieldStyle(PlainTextFieldStyle())
                        .lineLimit(1...4)
                    
                    if !viewModel.messageText.isEmpty {
                        Button {
                            Task {
                                await viewModel.sendMessage()
                            }
                        } label: {
                            Image(systemName: "arrow.up.circle.fill")
                                .font(.title2)
                                .foregroundColor(.blue)
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(
                    RoundedRectangle(cornerRadius: 25)
                        .fill(.ultraThinMaterial)
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(Color.white.opacity(0.2), lineWidth: 0.5)
                        )
                )
            }
            .padding()
            .background(
                Rectangle()
                    .fill(.regularMaterial)
                    .overlay(
                        Rectangle()
                            .stroke(Color.white.opacity(0.1), lineWidth: 0.5)
                    )
            )
        }
    }
    
    // MARK: - Emergency Button
    private var emergencyButton: some View {
        Button {
            showingEmergencyAlert = true
        } label: {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundColor(.red)
        }
    }
}

// MARK: - Message Bubble View
struct MessageBubbleView: View {
    let message: Message
    let isFromCurrentUser: Bool
    let onRetry: () -> Void
    let onDelete: () -> Void
    
    @State private var showingDetails = false
    
    var body: some View {
        HStack {
            if isFromCurrentUser {
                Spacer(minLength: 50)
            }
            
            VStack(alignment: isFromCurrentUser ? .trailing : .leading, spacing: 4) {
                // Message content
                messageContent
                
                // Message status
                if isFromCurrentUser {
                    messageStatus
                }
            }
            
            if !isFromCurrentUser {
                Spacer(minLength: 50)
            }
        }
        .contextMenu {
            if message.deliveryStatus == .failed {
                Button("Retry", action: onRetry)
            }
            
            if isFromCurrentUser {
                Button("Delete", role: .destructive, action: onDelete)
            }
            
            Button("Details") {
                showingDetails = true
            }
        }
        .sheet(isPresented: $showingDetails) {
            MessageDetailsView(message: message)
        }
    }
    
    private var messageContent: some View {
        Group {
            switch message.type {
            case .text:
                textMessageContent
            case .location:
                locationMessageContent
            case .photo:
                photoMessageContent
            case .system:
                systemMessageContent
            case .emergency:
                emergencyMessageContent
            }
        }
    }
    
    private var textMessageContent: some View {
        Text(message.content)
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(isFromCurrentUser ? .blue.opacity(0.8) : .ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.white.opacity(0.2), lineWidth: 0.5)
                    )
            )
            .foregroundColor(isFromCurrentUser ? .white : .primary)
    }
    
    private var locationMessageContent: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "location.fill")
                    .foregroundColor(.green)
                Text("Shared Location")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            if let location = message.location {
                Text("Lat: \(location.latitude, specifier: "%.4f"), Lng: \(location.longitude, specifier: "%.4f")")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(isFromCurrentUser ? .green.opacity(0.8) : .ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.white.opacity(0.2), lineWidth: 0.5)
                )
        )
        .foregroundColor(isFromCurrentUser ? .white : .primary)
    }
    
    private var photoMessageContent: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Photo placeholder (would load actual image in production)
            RoundedRectangle(cornerRadius: 12)
                .fill(.gray.opacity(0.3))
                .frame(width: 200, height: 150)
                .overlay(
                    Image(systemName: "photo")
                        .font(.largeTitle)
                        .foregroundColor(.gray)
                )
            
            if !message.content.isEmpty && message.content != "Shared a photo" {
                Text(message.content)
                    .font(.caption)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(isFromCurrentUser ? .purple.opacity(0.8) : .ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.white.opacity(0.2), lineWidth: 0.5)
                )
        )
    }
    
    private var systemMessageContent: some View {
        Text(message.content)
            .font(.caption)
            .foregroundColor(.secondary)
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(
                Capsule()
                    .fill(.ultraThinMaterial)
                    .overlay(
                        Capsule()
                            .stroke(Color.white.opacity(0.2), lineWidth: 0.5)
                    )
            )
    }
    
    private var emergencyMessageContent: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.red)
                Text("EMERGENCY")
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundColor(.red)
            }
            
            Text(message.content)
                .fontWeight(.medium)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.red.opacity(0.1))
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.red.opacity(0.5), lineWidth: 1)
                )
        )
        .foregroundColor(.red)
    }
    
    private var messageStatus: some View {
        HStack(spacing: 4) {
            if message.deliveryStatus == .failed {
                Button(action: onRetry) {
                    Image(systemName: "exclamationmark.circle")
                        .foregroundColor(.red)
                        .font(.caption)
                }
            } else {
                statusIcon
            }
            
            Text(viewModel.formatMessageTime(message.timestamp))
                .font(.caption2)
                .foregroundColor(.secondary)
        }
    }
    
    private var statusIcon: some View {
        Group {
            switch message.deliveryStatus {
            case .sending:
                Image(systemName: "clock")
                    .foregroundColor(.orange)
            case .sent:
                Image(systemName: "checkmark")
                    .foregroundColor(.gray)
            case .delivered:
                Image(systemName: "checkmark.circle")
                    .foregroundColor(.blue)
            case .failed:
                Image(systemName: "exclamationmark.circle")
                    .foregroundColor(.red)
            }
        }
        .font(.caption2)
    }
}

// MARK: - Message Details View
struct MessageDetailsView: View {
    let message: Message
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            List {
                Section("Message Info") {
                    LabeledContent("Type", value: message.type.rawValue.capitalized)
                    LabeledContent("Status", value: message.deliveryStatus.rawValue.capitalized)
                    LabeledContent("Timestamp", value: message.timestamp.formatted())
                }
                
                if !message.readBy.isEmpty {
                    Section("Read By") {
                        Text("\(message.readBy.count) participants")
                    }
                }
                
                if let location = message.location {
                    Section("Location") {
                        LabeledContent("Latitude", value: String(format: "%.6f", location.latitude))
                        LabeledContent("Longitude", value: String(format: "%.6f", location.longitude))
                    }
                }
            }
            .navigationTitle("Message Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Glass Button Style
struct GlassButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(12)
            .background(
                Circle()
                    .fill(.ultraThinMaterial)
                    .overlay(
                        Circle()
                            .stroke(Color.white.opacity(0.2), lineWidth: 0.5)
                    )
            )
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .animation(.easeInOut(duration: 0.1), value: configuration.isPressed)
    }
}

// MARK: - Preview
#Preview {
    ChatView(tripId: UUID())
}