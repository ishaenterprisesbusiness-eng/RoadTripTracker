import SwiftUI
import PhotosUI
import CoreLocation

// MARK: - Photo Sharing View
struct PhotoSharingView: View {
    @StateObject private var viewModel = PhotoSharingViewModel()
    @State private var selectedPhotos: [PhotosPickerItem] = []
    @State private var showingPhotoDetail: PhotoShare?
    @State private var showingCaptionEditor: PhotoShare?
    @State private var captionText: String = ""
    @State private var showingDeleteConfirmation = false
    
    let tripId: UUID
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background gradient
                LinearGradient(
                    colors: [
                        Color.purple.opacity(0.1),
                        Color.pink.opacity(0.05)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Filter and sort controls
                    if !viewModel.tripPhotos.isEmpty {
                        controlsSection
                    }
                    
                    // Photos grid
                    photosGridView
                    
                    // Selection toolbar
                    if viewModel.isSelectionMode {
                        selectionToolbar
                    }
                }
            }
            .navigationTitle("Trip Photos")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    if viewModel.isSelectionMode {
                        selectionModeButtons
                    } else {
                        normalModeButtons
                    }
                }
            }
            .task {
                await viewModel.loadTripPhotos(for: tripId)
            }
            .photosPicker(
                isPresented: $viewModel.showingPhotoPicker,
                selection: $selectedPhotos,
                maxSelectionCount: 10,
                matching: .images
            )
            .onChange(of: selectedPhotos) { _, newPhotos in
                Task {
                    await handleSelectedPhotos(newPhotos)
                }
            }
            .sheet(item: $showingPhotoDetail) { photoShare in
                PhotoDetailView(photoShare: photoShare, viewModel: viewModel)
            }
            .sheet(item: $showingCaptionEditor) { photoShare in
                CaptionEditorView(
                    photoShare: photoShare,
                    captionText: $captionText,
                    onSave: { caption in
                        // Update caption logic would go here
                        showingCaptionEditor = nil
                    }
                )
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.clearError()
                }
            } message: {
                Text(viewModel.errorMessage ?? "")
            }
            .alert("Delete Photos", isPresented: $showingDeleteConfirmation) {
                Button("Delete", role: .destructive) {
                    Task {
                        await viewModel.deleteSelectedPhotos()
                    }
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Are you sure you want to delete \(viewModel.selectedPhotos.count) photo(s)?")
            }
        }
    }
    
    // MARK: - Controls Section
    private var controlsSection: some View {
        VStack(spacing: 12) {
            HStack {
                // Filter menu
                Menu {
                    ForEach(PhotoFilterOption.allCases, id: \.rawValue) { option in
                        Button {
                            viewModel.setFilterOption(option)
                        } label: {
                            HStack {
                                Text(option.displayName)
                                if viewModel.filterOption == option {
                                    Image(systemName: "checkmark")
                                }
                            }
                        }
                    }
                } label: {
                    HStack {
                        Image(systemName: "line.3.horizontal.decrease.circle")
                        Text(viewModel.filterOption.displayName)
                        Image(systemName: "chevron.down")
                    }
                    .font(.caption)
                    .foregroundColor(.primary)
                }
                .buttonStyle(GlassButtonStyle())
                
                Spacer()
                
                // Sort menu
                Menu {
                    ForEach(PhotoSortOption.allCases, id: \.rawValue) { option in
                        Button {
                            viewModel.setSortOption(option)
                        } label: {
                            HStack {
                                Text(option.displayName)
                                if viewModel.sortOption == option {
                                    Image(systemName: "checkmark")
                                }
                            }
                        }
                    }
                } label: {
                    HStack {
                        Image(systemName: "arrow.up.arrow.down.circle")
                        Text(viewModel.sortOption.displayName)
                        Image(systemName: "chevron.down")
                    }
                    .font(.caption)
                    .foregroundColor(.primary)
                }
                .buttonStyle(GlassButtonStyle())
            }
            
            // Photo count
            Text("\(viewModel.tripPhotos.count) photos")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(
            Rectangle()
                .fill(.ultraThinMaterial)
                .overlay(
                    Rectangle()
                        .stroke(Color.white.opacity(0.1), lineWidth: 0.5)
                )
        )
    }
    
    // MARK: - Photos Grid View
    private var photosGridView: some View {
        Group {
            if viewModel.isLoading && viewModel.tripPhotos.isEmpty {
                loadingView
            } else if viewModel.tripPhotos.isEmpty {
                emptyStateView
            } else {
                photosGrid
            }
        }
    }
    
    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.2)
            Text("Loading photos...")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 20) {
            Image(systemName: "photo.on.rectangle.angled")
                .font(.system(size: 60))
                .foregroundColor(.gray)
            
            VStack(spacing: 8) {
                Text("No Photos Yet")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Share your first photo to get started!")
                    .font(.body)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            
            Button {
                viewModel.showingPhotoPicker = true
            } label: {
                HStack {
                    Image(systemName: "plus")
                    Text("Add Photos")
                }
                .font(.headline)
                .foregroundColor(.white)
                .padding(.horizontal, 24)
                .padding(.vertical, 12)
                .background(
                    RoundedRectangle(cornerRadius: 25)
                        .fill(.blue)
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(Color.white.opacity(0.2), lineWidth: 0.5)
                        )
                )
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
    
    private var photosGrid: some View {
        ScrollView {
            LazyVStack(spacing: 20) {
                ForEach(viewModel.groupedPhotos) { group in
                    VStack(alignment: .leading, spacing: 12) {
                        // Date header
                        HStack {
                            Text(group.displayDate)
                                .font(.headline)
                                .fontWeight(.semibold)
                            
                            Spacer()
                            
                            Text("\(group.photos.count) photos")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .padding(.horizontal)
                        
                        // Photos grid
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 4), count: 3), spacing: 4) {
                            ForEach(group.photos) { photoShare in
                                PhotoThumbnailView(
                                    photoShare: photoShare,
                                    isSelected: viewModel.selectedPhotos.contains { $0.id == photoShare.id },
                                    isSelectionMode: viewModel.isSelectionMode,
                                    onTap: {
                                        if viewModel.isSelectionMode {
                                            viewModel.togglePhotoSelection(photoShare)
                                        } else {
                                            showingPhotoDetail = photoShare
                                        }
                                    },
                                    onLongPress: {
                                        if !viewModel.isSelectionMode {
                                            viewModel.isSelectionMode = true
                                            viewModel.togglePhotoSelection(photoShare)
                                        }
                                    }
                                )
                            }
                        }
                        .padding(.horizontal)
                    }
                }
            }
            .padding(.vertical)
        }
    }
    
    // MARK: - Selection Toolbar
    private var selectionToolbar: some View {
        HStack {
            Button("Select All") {
                viewModel.selectAllPhotos()
            }
            .disabled(viewModel.selectedPhotos.count == viewModel.tripPhotos.count)
            
            Spacer()
            
            Text("\(viewModel.selectedPhotos.count) selected")
                .font(.caption)
                .foregroundColor(.secondary)
            
            Spacer()
            
            Button("Delete") {
                showingDeleteConfirmation = true
            }
            .foregroundColor(.red)
            .disabled(viewModel.selectedPhotos.isEmpty)
        }
        .padding()
        .background(
            Rectangle()
                .fill(.regularMaterial)
                .overlay(
                    Rectangle()
                        .stroke(Color.white.opacity(0.1), lineWidth: 0.5)
                )
        )
    }
    
    // MARK: - Toolbar Buttons
    private var normalModeButtons: some View {
        Group {
            // Download all button
            Button {
                Task {
                    await viewModel.downloadAllPhotos()
                }
            } label: {
                Image(systemName: "square.and.arrow.down")
            }
            .disabled(viewModel.tripPhotos.isEmpty)
            
            // Create album button
            Button {
                Task {
                    await viewModel.createTripAlbum()
                }
            } label: {
                Image(systemName: "rectangle.stack")
            }
            .disabled(viewModel.tripPhotos.isEmpty)
            
            // Add photos button
            Button {
                viewModel.showingPhotoPicker = true
            } label: {
                Image(systemName: "plus")
            }
        }
    }
    
    private var selectionModeButtons: some View {
        Button("Cancel") {
            viewModel.deselectAllPhotos()
        }
    }
    
    // MARK: - Helper Methods
    
    private func handleSelectedPhotos(_ items: [PhotosPickerItem]) async {
        var images: [UIImage] = []
        
        for item in items {
            if let data = try? await item.loadTransferable(type: Data.self),
               let image = UIImage(data: data) {
                images.append(image)
            }
        }
        
        if !images.isEmpty {
            await viewModel.shareMultiplePhotos(images)
        }
        
        selectedPhotos.removeAll()
    }
}

// MARK: - Photo Thumbnail View
struct PhotoThumbnailView: View {
    let photoShare: PhotoShare
    let isSelected: Bool
    let isSelectionMode: Bool
    let onTap: () -> Void
    let onLongPress: () -> Void
    
    @State private var thumbnailImage: UIImage?
    @State private var isLoading = true
    
    var body: some View {
        ZStack {
            // Photo thumbnail
            Group {
                if let image = thumbnailImage {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                } else if isLoading {
                    Rectangle()
                        .fill(.gray.opacity(0.3))
                        .overlay(
                            ProgressView()
                                .scaleEffect(0.8)
                        )
                } else {
                    Rectangle()
                        .fill(.gray.opacity(0.3))
                        .overlay(
                            Image(systemName: "photo")
                                .font(.title2)
                                .foregroundColor(.gray)
                        )
                }
            }
            .frame(height: 120)
            .clipped()
            .cornerRadius(12)
            
            // Selection overlay
            if isSelectionMode {
                VStack {
                    HStack {
                        Spacer()
                        
                        ZStack {
                            Circle()
                                .fill(.ultraThinMaterial)
                                .frame(width: 24, height: 24)
                            
                            if isSelected {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.blue)
                                    .font(.title3)
                            } else {
                                Circle()
                                    .stroke(Color.white, lineWidth: 2)
                                    .frame(width: 20, height: 20)
                            }
                        }
                        .padding(8)
                    }
                    
                    Spacer()
                }
            }
            
            // Location indicator
            if photoShare.location != nil {
                VStack {
                    Spacer()
                    
                    HStack {
                        Image(systemName: "location.fill")
                            .font(.caption2)
                            .foregroundColor(.white)
                            .padding(4)
                            .background(
                                Circle()
                                    .fill(.black.opacity(0.6))
                            )
                        
                        Spacer()
                    }
                    .padding(8)
                }
            }
            
            // Caption indicator
            if photoShare.caption != nil && !photoShare.caption!.isEmpty {
                VStack {
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        Image(systemName: "text.bubble.fill")
                            .font(.caption2)
                            .foregroundColor(.white)
                            .padding(4)
                            .background(
                                Circle()
                                    .fill(.black.opacity(0.6))
                            )
                    }
                    .padding(8)
                }
            }
        }
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(isSelected ? Color.blue : Color.clear, lineWidth: 3)
        )
        .onTapGesture {
            onTap()
        }
        .onLongPressGesture {
            onLongPress()
        }
        .task {
            await loadThumbnail()
        }
    }
    
    private func loadThumbnail() async {
        isLoading = true
        
        // Try to load thumbnail first, fallback to main photo
        let urlToLoad = photoShare.thumbnailURL ?? photoShare.photoURL
        
        do {
            let (data, _) = try await URLSession.shared.data(from: urlToLoad)
            if let image = UIImage(data: data) {
                await MainActor.run {
                    thumbnailImage = image
                }
            }
        } catch {
            // Failed to load
        }
        
        await MainActor.run {
            isLoading = false
        }
    }
}

// MARK: - Photo Detail View
struct PhotoDetailView: View {
    let photoShare: PhotoShare
    let viewModel: PhotoSharingViewModel
    
    @Environment(\.dismiss) private var dismiss
    @State private var fullImage: UIImage?
    @State private var isLoading = true
    @State private var showingShareSheet = false
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.black.ignoresSafeArea()
                
                VStack {
                    // Photo
                    if let image = fullImage {
                        Image(uiImage: image)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .clipped()
                    } else if isLoading {
                        ProgressView()
                            .scaleEffect(1.5)
                            .tint(.white)
                    } else {
                        Image(systemName: "photo")
                            .font(.system(size: 60))
                            .foregroundColor(.gray)
                    }
                    
                    // Photo info
                    VStack(alignment: .leading, spacing: 8) {
                        if let caption = photoShare.caption, !caption.isEmpty {
                            Text(caption)
                                .font(.body)
                                .foregroundColor(.white)
                        }
                        
                        Text(photoShare.timestamp.formatted(date: .abbreviated, time: .shortened))
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        if let location = photoShare.location {
                            HStack {
                                Image(systemName: "location.fill")
                                    .foregroundColor(.blue)
                                Text("Lat: \(location.latitude, specifier: "%.4f"), Lng: \(location.longitude, specifier: "%.4f")")
                            }
                            .font(.caption)
                            .foregroundColor(.gray)
                        }
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(
                        Rectangle()
                            .fill(.ultraThinMaterial)
                    )
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Close") {
                        dismiss()
                    }
                    .foregroundColor(.white)
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingShareSheet = true
                    } label: {
                        Image(systemName: "square.and.arrow.up")
                            .foregroundColor(.white)
                    }
                    .disabled(fullImage == nil)
                }
            }
            .task {
                await loadFullImage()
            }
            .sheet(isPresented: $showingShareSheet) {
                if let image = fullImage {
                    ShareSheet(items: [image])
                }
            }
        }
    }
    
    private func loadFullImage() async {
        isLoading = true
        
        if let image = await viewModel.downloadPhoto(photoShare) {
            await MainActor.run {
                fullImage = image
            }
        }
        
        await MainActor.run {
            isLoading = false
        }
    }
}

// MARK: - Caption Editor View
struct CaptionEditorView: View {
    let photoShare: PhotoShare
    @Binding var captionText: String
    let onSave: (String) -> Void
    
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            VStack {
                TextField("Add a caption...", text: $captionText, axis: .vertical)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .lineLimit(3...6)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Edit Caption")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        onSave(captionText)
                    }
                }
            }
        }
        .onAppear {
            captionText = photoShare.caption ?? ""
        }
    }
}

// MARK: - Share Sheet
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// MARK: - Preview
#Preview {
    PhotoSharingView(tripId: UUID())
}