import SwiftUI
import MapKit

struct TripView: View {
    @StateObject private var viewModel: TripViewModel
    @State private var showingTripCreation = false
    @State private var showingJoinTrip = false
    
    init(tripService: TripServiceProtocol, mapService: MapServiceProtocol) {
        self._viewModel = StateObject(wrappedValue: TripViewModel(tripService: tripService, mapService: mapService))
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                if viewModel.trip != nil {
                    // View mode selector
                    viewModeSelector
                    
                    // Content based on selected view mode
                    contentView
                } else {
                    // No active trip state
                    noActiveTripView
                }
            }
            .navigationTitle("Trip")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    if viewModel.trip != nil {
                        tripActionsMenu
                    } else {
                        newTripButton
                    }
                }
            }
        }
        .sheet(isPresented: $showingTripCreation) {
            TripCreationView(
                tripService: ServiceContainer.shared.tripService,
                placesService: ServiceContainer.shared.placesService
            )
        }
        .sheet(isPresented: $showingJoinTrip) {
            JoinTripView(tripService: ServiceContainer.shared.tripService)
        }
        .alert("Error", isPresented: $viewModel.showingError) {
            Button("OK") { }
        } message: {
            Text(viewModel.errorMessage ?? "An unknown error occurred")
        }
    }
    
    // MARK: - View Mode Selector
    
    private var viewModeSelector: some View {
        HStack(spacing: 0) {
            ForEach(TripViewMode.allCases, id: \.self) { mode in
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        viewModel.setViewMode(mode)
                    }
                }) {
                    HStack(spacing: 8) {
                        Image(systemName: mode.systemImage)
                            .font(.system(size: 14, weight: .medium))
                        
                        Text(mode.displayName)
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                    .foregroundColor(viewModel.viewMode == mode ? .white : .primary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(
                        RoundedRectangle(cornerRadius: 8)
                            .fill(viewModel.viewMode == mode ? Color.accentColor : Color.clear)
                    )
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(.ultraThinMaterial)
    }
    
    // MARK: - Content View
    
    private var contentView: some View {
        Group {
            switch viewModel.viewMode {
            case .list:
                TripListView(viewModel: viewModel)
            case .map:
                TripMapView(viewModel: viewModel)
            }
        }
        .transition(.asymmetric(
            insertion: .move(edge: .trailing).combined(with: .opacity),
            removal: .move(edge: .leading).combined(with: .opacity)
        ))
    }
    
    // MARK: - No Active Trip View
    
    private var noActiveTripView: some View {
        VStack(spacing: 24) {
            Spacer()
            
            // Illustration
            VStack(spacing: 16) {
                Image(systemName: "map.circle")
                    .font(.system(size: 80))
                    .foregroundColor(.accentColor.opacity(0.6))
                
                VStack(spacing: 8) {
                    Text("No Active Trip")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Text("Create a new trip or join an existing one to start your road trip adventure")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                }
            }
            
            // Action buttons
            VStack(spacing: 12) {
                Button(action: {
                    showingTripCreation = true
                }) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                            .font(.title3)
                        
                        Text("Create New Trip")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color.accentColor)
                    )
                    .foregroundColor(.white)
                }
                
                Button(action: {
                    showingJoinTrip = true
                }) {
                    HStack {
                        Image(systemName: "person.2.circle")
                            .font(.title3)
                        
                        Text("Join Existing Trip")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.accentColor, lineWidth: 2)
                    )
                    .foregroundColor(.accentColor)
                }
            }
            .padding(.horizontal, 32)
            
            Spacer()
        }
        .background(Color(.systemGroupedBackground))
    }
    
    // MARK: - Trip Actions Menu
    
    private var tripActionsMenu: some View {
        Menu {
            Button(action: {
                // Share trip code
                shareTrip()
            }) {
                Label("Share Trip", systemImage: "square.and.arrow.up")
            }
            
            Button(action: {
                // Edit trip
                // This would open trip editing view
            }) {
                Label("Edit Trip", systemImage: "pencil")
            }
            
            Divider()
            
            Button(role: .destructive, action: {
                // Leave trip
                leaveTrip()
            }) {
                Label("Leave Trip", systemImage: "person.badge.minus")
            }
        } label: {
            Image(systemName: "ellipsis.circle")
                .font(.title3)
        }
    }
    
    // MARK: - New Trip Button
    
    private var newTripButton: some View {
        Button(action: {
            showingTripCreation = true
        }) {
            Image(systemName: "plus")
                .font(.title3)
                .fontWeight(.medium)
        }
    }
    
    // MARK: - Actions
    
    private func shareTrip() {
        guard let trip = viewModel.trip else { return }
        
        let shareText = "Join my road trip '\(trip.name)' using code: \(trip.code)"
        let activityViewController = UIActivityViewController(
            activityItems: [shareText],
            applicationActivities: nil
        )
        
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first {
            window.rootViewController?.present(activityViewController, animated: true)
        }
    }
    
    private func leaveTrip() {
        guard let trip = viewModel.trip else { return }
        
        Task {
            do {
                try await ServiceContainer.shared.tripService.leaveTrip(trip.id)
            } catch {
                viewModel.errorMessage = error.localizedDescription
                viewModel.showingError = true
            }
        }
    }
}

// MARK: - Join Trip View

struct JoinTripView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var tripCode: String = ""
    @State private var isJoining: Bool = false
    @State private var errorMessage: String?
    @State private var showingError: Bool = false
    
    let tripService: TripServiceProtocol
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                Spacer()
                
                VStack(spacing: 16) {
                    Image(systemName: "person.2.circle.fill")
                        .font(.system(size: 60))
                        .foregroundColor(.accentColor)
                    
                    VStack(spacing: 8) {
                        Text("Join Trip")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                        
                        Text("Enter the trip code shared by the trip organizer")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Trip Code")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                    
                    TextField("Enter 6-digit code", text: $tripCode)
                        .textFieldStyle(LiquidGlassTextFieldStyle())
                        .textCase(.uppercase)
                        .autocorrectionDisabled()
                        .onReceive(tripCode.publisher.collect()) { characters in
                            tripCode = String(characters.prefix(6))
                        }
                }
                
                Button(action: joinTrip) {
                    HStack {
                        if isJoining {
                            ProgressView()
                                .scaleEffect(0.8)
                                .foregroundColor(.white)
                        }
                        
                        Text(isJoining ? "Joining..." : "Join Trip")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(canJoinTrip ? Color.accentColor : Color.gray)
                    )
                    .foregroundColor(.white)
                }
                .disabled(!canJoinTrip)
                
                Spacer()
            }
            .padding(.horizontal, 32)
            .navigationTitle("Join Trip")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
        .alert("Error", isPresented: $showingError) {
            Button("OK") { }
        } message: {
            Text(errorMessage ?? "An unknown error occurred")
        }
    }
    
    private var canJoinTrip: Bool {
        tripCode.count == 6 && !isJoining
    }
    
    private func joinTrip() {
        guard canJoinTrip else { return }
        
        isJoining = true
        
        Task {
            do {
                _ = try await tripService.joinTrip(code: tripCode)
                await MainActor.run {
                    dismiss()
                }
            } catch {
                await MainActor.run {
                    errorMessage = error.localizedDescription
                    showingError = true
                    isJoining = false
                }
            }
        }
    }
}

#Preview {
    TripView(
        tripService: MockTripService(),
        mapService: MockMapService()
    )
}