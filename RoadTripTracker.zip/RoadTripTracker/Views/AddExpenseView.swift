import SwiftUI
import Combine

// MARK: - Add Expense View
struct AddExpenseView: View {
    @ObservedObject var viewModel: BudgetViewModel
    let trip: Trip
    let currentParticipant: Participant
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            ZStack {
                // Glassmorphic background
                GlasmorphicDesignSystem.backgroundGradient
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        headerSection
                        amountSection
                        categorySection
                        descriptionSection
                        locationSection
                        actionButtons
                    }
                    .padding()
                }
            }
            .navigationTitle("Add Expense")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.clearError()
                }
            } message: {
                Text(viewModel.errorMessage ?? "")
            }
        }
    }
    
    // MARK: - Header Section
    private var headerSection: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(spacing: 12) {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: 40))
                    .foregroundColor(.blue)
                
                Text("Record New Expense")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Add an expense for \(trip.name)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
        }
    }
    
    // MARK: - Amount Section
    private var amountSection: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(alignment: .leading, spacing: 12) {
                Label("Amount", systemImage: "dollarsign.circle")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                HStack {
                    Text("$")
                        .font(.title2)
                        .foregroundColor(.secondary)
                    
                    TextField("0.00", text: $viewModel.newExpenseAmount)
                        .keyboardType(.decimalPad)
                        .font(.title2)
                        .fontWeight(.medium)
                        .textFieldStyle(PlainTextFieldStyle())
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(.ultraThinMaterial)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(.white.opacity(0.2), lineWidth: 1)
                        )
                )
            }
            .padding()
        }
    }
    
    // MARK: - Category Section
    private var categorySection: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                Label("Category", systemImage: "tag")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 2), spacing: 12) {
                    ForEach(ExpenseCategory.allCases, id: \.self) { category in
                        categoryButton(category)
                    }
                }
            }
            .padding()
        }
    }
    
    private func categoryButton(_ category: ExpenseCategory) -> some View {
        Button {
            viewModel.newExpenseCategory = category
        } label: {
            HStack {
                Image(systemName: viewModel.categoryIcon(for: category))
                    .foregroundColor(Color(viewModel.categoryColor(for: category)))
                
                Text(category.displayName)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Spacer()
                
                if viewModel.newExpenseCategory == category {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.blue)
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(viewModel.newExpenseCategory == category ? .blue.opacity(0.1) : .ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(
                                viewModel.newExpenseCategory == category ? .blue.opacity(0.3) : .white.opacity(0.2),
                                lineWidth: 1
                            )
                    )
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    // MARK: - Description Section
    private var descriptionSection: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(alignment: .leading, spacing: 12) {
                Label("Description", systemImage: "text.alignleft")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                TextField("What was this expense for?", text: $viewModel.newExpenseDescription, axis: .vertical)
                    .lineLimit(3...6)
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(.ultraThinMaterial)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(.white.opacity(0.2), lineWidth: 1)
                            )
                    )
                
                // Quick description suggestions
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(suggestionTexts(for: viewModel.newExpenseCategory), id: \.self) { suggestion in
                            Button(suggestion) {
                                viewModel.newExpenseDescription = suggestion
                            }
                            .font(.caption)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(
                                Capsule()
                                    .fill(.ultraThinMaterial)
                                    .overlay(
                                        Capsule()
                                            .stroke(.white.opacity(0.2), lineWidth: 1)
                                    )
                            )
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .padding()
        }
    }
    
    // MARK: - Location Section
    private var locationSection: some View {
        GlasmorphicDesignSystem.createGlassCard {
            HStack {
                Image(systemName: "location")
                    .foregroundColor(.blue)
                
                VStack(alignment: .leading) {
                    Text("Location")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    
                    Text("Current location will be saved")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Image(systemName: "checkmark.circle.fill")
                    .foregroundColor(.green)
            }
            .padding()
        }
    }
    
    // MARK: - Action Buttons
    private var actionButtons: some View {
        VStack(spacing: 12) {
            Button {
                viewModel.addExpense(for: trip.id, participantId: currentParticipant.id)
            } label: {
                HStack {
                    if viewModel.isLoading {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(0.8)
                    } else {
                        Image(systemName: "plus.circle.fill")
                    }
                    
                    Text(viewModel.isLoading ? "Adding..." : "Add Expense")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(viewModel.isAddExpenseFormValid ? .blue : .gray)
                )
                .foregroundColor(.white)
            }
            .disabled(!viewModel.isAddExpenseFormValid || viewModel.isLoading)
            
            Button("Clear Form") {
                viewModel.clearExpenseForm()
            }
            .font(.subheadline)
            .foregroundColor(.secondary)
        }
    }
    
    // MARK: - Helper Methods
    private func suggestionTexts(for category: ExpenseCategory) -> [String] {
        switch category {
        case .fuel:
            return ["Gas station fill-up", "Diesel refuel", "Highway service station"]
        case .food:
            return ["Restaurant meal", "Fast food", "Groceries", "Coffee break", "Snacks"]
        case .accommodation:
            return ["Hotel night", "Motel stay", "Camping fees", "Airbnb"]
        case .activities:
            return ["Attraction entry", "Tour guide", "Activity booking", "Entertainment"]
        case .other:
            return ["Parking fee", "Toll road", "Emergency repair", "Miscellaneous"]
        }
    }
}

// MARK: - Preview
struct AddExpenseView_Previews: PreviewProvider {
    static var previews: some View {
        let mockTrip = Trip(
            name: "Sample Trip",
            code: "ABC123",
            createdBy: UUID(),
            participants: [],
            destinations: []
        )
        
        let mockParticipant = Participant(
            userId: UUID(),
            user: User(
                id: UUID(),
                username: "Test User",
                email: "test@example.com",
                city: "Test City",
                dateOfBirth: Date(),
                age: 25
            )
        )
        
        AddExpenseView(
            viewModel: BudgetViewModel(
                budgetService: MockBudgetService(),
                locationService: MockLocationService()
            ),
            trip: mockTrip,
            currentParticipant: mockParticipant
        )
    }
}