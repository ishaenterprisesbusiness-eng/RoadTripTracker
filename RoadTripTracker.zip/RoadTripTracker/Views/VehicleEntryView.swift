import SwiftUI

// MARK: - Vehicle Entry View
struct VehicleEntryView: View {
    @StateObject private var viewModel = VehicleEntryViewModel()
    @Environment(\.dismiss) private var dismiss
    
    @State private var showingVehicleTypePicker = false
    
    var body: some View {
        ZStack {
            // Background
            LiquidGlassBackground()
            
            ScrollView {
                VStack(spacing: 24) {
                    // Header
                    headerSection
                    
                    // Form Content
                    LiquidGlassCard {
                        VStack(spacing: 20) {
                            formFields
                        }
                    }
                    
                    // Action Buttons
                    actionButtons
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 100)
            }
        }
        .navigationBarHidden(true)
        .alert("Success", isPresented: $viewModel.showingSuccessAlert) {
            Button("OK") {
                dismiss()
            }
        } message: {
            Text("Vehicle details have been saved successfully!")
        }
        .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
            Button("OK") {
                viewModel.errorMessage = nil
            }
        } message: {
            if let errorMessage = viewModel.errorMessage {
                Text(errorMessage)
            }
        }
        .sheet(isPresented: $showingVehicleTypePicker) {
            vehicleTypePickerSheet
        }
    }
    
    // MARK: - Header Section
    private var headerSection: some View {
        VStack(spacing: 16) {
            LiquidGlassNavigationBar(
                title: "Vehicle Details",
                leadingAction: { dismiss() },
                leadingIcon: "xmark"
            )
            
            VStack(spacing: 8) {
                Image(systemName: "car.fill")
                    .font(.system(size: 48))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                
                Text("Tell us about your vehicle")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                Text("This information helps other participants identify your vehicle during the trip")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
            }
        }
    }
    
    // MARK: - Form Fields
    private var formFields: some View {
        VStack(spacing: 20) {
            // Vehicle Make
            VStack(alignment: .leading, spacing: 4) {
                LiquidGlassTextField(
                    title: "Vehicle Make",
                    text: $viewModel.make,
                    icon: "car.side"
                )
                
                if let error = viewModel.makeError {
                    Text(error)
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.leading, 4)
                }
            }
            
            // Vehicle Model
            VStack(alignment: .leading, spacing: 4) {
                LiquidGlassTextField(
                    title: "Vehicle Model",
                    text: $viewModel.model,
                    icon: "car.side.fill"
                )
                
                if let error = viewModel.modelError {
                    Text(error)
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.leading, 4)
                }
            }
            
            // Vehicle Number/License Plate
            VStack(alignment: .leading, spacing: 4) {
                LiquidGlassTextField(
                    title: "License Plate / Vehicle Number",
                    text: $viewModel.vehicleNumber,
                    icon: "rectangle.and.text.magnifyingglass"
                )
                
                if let error = viewModel.vehicleNumberError {
                    Text(error)
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.leading, 4)
                }
            }
            
            // Vehicle Type Picker
            VStack(alignment: .leading, spacing: 8) {
                Text("Vehicle Type")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Button(action: { showingVehicleTypePicker = true }) {
                    HStack(spacing: 12) {
                        Image(systemName: vehicleTypeIcon(for: viewModel.selectedVehicleType))
                            .foregroundColor(.blue)
                            .frame(width: 20)
                        
                        Text(viewModel.selectedVehicleType.displayName)
                            .foregroundColor(.primary)
                        
                        Spacer()
                        
                        Image(systemName: "chevron.down")
                            .foregroundColor(.secondary)
                            .font(.system(size: 14))
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(.ultraThinMaterial)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(.white.opacity(0.2), lineWidth: 1)
                            )
                    )
                }
            }
            
            // Odometer Reading
            VStack(alignment: .leading, spacing: 4) {
                LiquidGlassTextField(
                    title: "Odometer Reading (km)",
                    text: $viewModel.odometerReading,
                    icon: "speedometer"
                )
                .keyboardType(.numberPad)
                
                if let error = viewModel.odometerError {
                    Text(error)
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.leading, 4)
                } else {
                    Text("Current mileage on your vehicle")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.leading, 4)
                }
            }
            
            // Vehicle Color (Optional)
            LiquidGlassTextField(
                title: "Vehicle Color (Optional)",
                text: $viewModel.color,
                icon: "paintpalette"
            )
        }
    }
    
    // MARK: - Action Buttons
    private var actionButtons: some View {
        VStack(spacing: 16) {
            // Save Button
            LiquidGlassButton(
                title: viewModel.isLoading ? "Saving..." : "Save Vehicle Details",
                icon: viewModel.isLoading ? nil : "checkmark.circle.fill",
                style: .primary
            ) {
                Task {
                    await viewModel.saveVehicleDetails()
                }
            }
            .disabled(viewModel.isLoading || !viewModel.isFormValid)
            .opacity(viewModel.isLoading || !viewModel.isFormValid ? 0.6 : 1.0)
            
            // Clear Form Button
            LiquidGlassButton(
                title: "Clear Form",
                icon: "trash",
                style: .secondary
            ) {
                viewModel.clearForm()
            }
            .disabled(viewModel.isLoading)
        }
    }
    
    // MARK: - Vehicle Type Picker Sheet
    private var vehicleTypePickerSheet: some View {
        NavigationView {
            ZStack {
                LiquidGlassBackground()
                
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(VehicleType.allCases, id: \.self) { vehicleType in
                            vehicleTypeRow(vehicleType)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                }
            }
            .navigationTitle("Select Vehicle Type")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        showingVehicleTypePicker = false
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }
    
    // MARK: - Vehicle Type Row
    private func vehicleTypeRow(_ vehicleType: VehicleType) -> some View {
        Button(action: {
            viewModel.selectedVehicleType = vehicleType
            showingVehicleTypePicker = false
        }) {
            HStack(spacing: 16) {
                Image(systemName: vehicleTypeIcon(for: vehicleType))
                    .font(.system(size: 24))
                    .foregroundColor(.blue)
                    .frame(width: 32)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(vehicleType.displayName)
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Text(vehicleTypeDescription(for: vehicleType))
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                if viewModel.selectedVehicleType == vehicleType {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.blue)
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(
                                viewModel.selectedVehicleType == vehicleType ? .blue.opacity(0.5) : .white.opacity(0.2),
                                lineWidth: viewModel.selectedVehicleType == vehicleType ? 2 : 1
                            )
                    )
            )
        }
        .buttonStyle(.plain)
    }
    
    // MARK: - Helper Methods
    private func vehicleTypeIcon(for type: VehicleType) -> String {
        switch type {
        case .caravan:
            return "truck.box"
        case .fourWDUte:
            return "truck.pickup"
        case .camperVan:
            return "bus"
        case .suv:
            return "car.side.fill"
        case .sedan:
            return "car.fill"
        case .hatchback:
            return "car.rear.fill"
        case .other:
            return "car.circle"
        }
    }
    
    private func vehicleTypeDescription(for type: VehicleType) -> String {
        switch type {
        case .caravan:
            return "Towed recreational vehicle"
        case .fourWDUte:
            return "Four-wheel drive utility vehicle"
        case .camperVan:
            return "Self-contained camping vehicle"
        case .suv:
            return "Sport utility vehicle"
        case .sedan:
            return "Four-door passenger car"
        case .hatchback:
            return "Compact car with rear hatch"
        case .other:
            return "Other vehicle type"
        }
    }
}

// MARK: - Preview
#Preview {
    NavigationView {
        VehicleEntryView()
    }
}