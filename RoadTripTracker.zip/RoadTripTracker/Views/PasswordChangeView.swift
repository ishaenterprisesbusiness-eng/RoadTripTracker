import SwiftUI

struct PasswordChangeView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var authViewModel: AuthenticationViewModel
    
    @State private var currentPassword = ""
    @State private var newPassword = ""
    @State private var confirmPassword = ""
    
    @State private var isLoading = false
    @State private var showingError = false
    @State private var showingSuccess = false
    @State private var errorMessage = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                LiquidGlassBackground()
                
                ScrollView {
                    VStack(spacing: 24) {
                        // Header
                        LiquidGlassCard {
                            VStack(spacing: 16) {
                                HStack {
                                    Image(systemName: "lock.shield")
                                        .font(.system(size: 32))
                                        .foregroundColor(.blue)
                                    
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text("Change Password")
                                            .font(.title2)
                                            .fontWeight(.bold)
                                            .foregroundColor(.primary)
                                        
                                        Text("Update your account password")
                                            .font(.subheadline)
                                            .foregroundColor(.secondary)
                                    }
                                    
                                    Spacer()
                                }
                            }
                        }
                        
                        // Password Fields
                        LiquidGlassCard {
                            VStack(spacing: 20) {
                                Text("Password Information")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.primary)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                
                                VStack(spacing: 16) {
                                    // Current Password
                                    LiquidGlassSecureField(
                                        title: "Current Password",
                                        text: $currentPassword,
                                        icon: "lock"
                                    )
                                    
                                    // New Password
                                    LiquidGlassSecureField(
                                        title: "New Password",
                                        text: $newPassword,
                                        icon: "lock.badge.clock"
                                    )
                                    
                                    // Confirm New Password
                                    LiquidGlassSecureField(
                                        title: "Confirm New Password",
                                        text: $confirmPassword,
                                        icon: "lock.badge.clock"
                                    )
                                    
                                    // Password Requirements
                                    passwordRequirementsSection
                                }
                            }
                        }
                        
                        // Change Password Button
                        LiquidGlassButton(
                            title: isLoading ? "Changing Password..." : "Change Password",
                            icon: "checkmark.shield",
                            style: .primary
                        ) {
                            Task {
                                await changePassword()
                            }
                        }
                        .disabled(isLoading || !isFormValid)
                        .opacity(isLoading || !isFormValid ? 0.6 : 1.0)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .padding(.bottom, 100)
                }
            }
            .navigationTitle("Change Password")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .alert("Error", isPresented: $showingError) {
                Button("OK") { }
            } message: {
                Text(errorMessage)
            }
            .alert("Success", isPresented: $showingSuccess) {
                Button("OK") {
                    dismiss()
                }
            } message: {
                Text("Your password has been changed successfully.")
            }
        }
    }
    
    // MARK: - Password Requirements Section
    
    private var passwordRequirementsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Password Requirements")
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(.secondary)
            
            VStack(alignment: .leading, spacing: 4) {
                requirementRow(
                    text: "At least 8 characters",
                    isValid: newPassword.count >= 8
                )
                
                requirementRow(
                    text: "Contains uppercase letter",
                    isValid: newPassword.range(of: "[A-Z]", options: .regularExpression) != nil
                )
                
                requirementRow(
                    text: "Contains lowercase letter",
                    isValid: newPassword.range(of: "[a-z]", options: .regularExpression) != nil
                )
                
                requirementRow(
                    text: "Contains number",
                    isValid: newPassword.range(of: "[0-9]", options: .regularExpression) != nil
                )
                
                requirementRow(
                    text: "Passwords match",
                    isValid: !newPassword.isEmpty && newPassword == confirmPassword
                )
            }
        }
        .padding(.top, 8)
    }
    
    private func requirementRow(text: String, isValid: Bool) -> some View {
        HStack(spacing: 8) {
            Image(systemName: isValid ? "checkmark.circle.fill" : "circle")
                .font(.system(size: 14))
                .foregroundColor(isValid ? .green : .secondary)
            
            Text(text)
                .font(.caption)
                .foregroundColor(isValid ? .primary : .secondary)
            
            Spacer()
        }
    }
    
    // MARK: - Computed Properties
    
    private var isFormValid: Bool {
        !currentPassword.isEmpty &&
        !newPassword.isEmpty &&
        !confirmPassword.isEmpty &&
        newPassword == confirmPassword &&
        isPasswordValid(newPassword) &&
        currentPassword != newPassword
    }
    
    private func isPasswordValid(_ password: String) -> Bool {
        password.count >= 8 &&
        password.range(of: "[A-Z]", options: .regularExpression) != nil &&
        password.range(of: "[a-z]", options: .regularExpression) != nil &&
        password.range(of: "[0-9]", options: .regularExpression) != nil
    }
    
    // MARK: - Methods
    
    private func changePassword() async {
        isLoading = true
        errorMessage = ""
        
        do {
            // TODO: Implement password change via AuthenticationManager
            // await authViewModel.changePassword(currentPassword: currentPassword, newPassword: newPassword)
            
            // Simulate API call
            try await Task.sleep(nanoseconds: 2_000_000_000) // 2 second delay
            
            // Simulate success
            showingSuccess = true
            
        } catch {
            errorMessage = "Failed to change password: \(error.localizedDescription)"
            showingError = true
        }
        
        isLoading = false
    }
}

#Preview {
    PasswordChangeView()
        .environmentObject(AuthenticationViewModel())
}