import SwiftUI
import MapKit
import CoreLocation

struct AccommodationDetailView: View {
    let accommodation: Accommodation
    let trip: Trip?
    let onAddToTrip: (Accommodation) -> Void
    
    @StateObject private var viewModel = AccommodationViewModel()
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    
    @State private var showingAvailabilityCheck = false
    @State private var checkInDate = Date()
    @State private var checkOutDate = Date().addingTimeInterval(86400) // Next day
    @State private var guests = 2
    @State private var showingBookingOptions = false
    @State private var region: MKCoordinateRegion
    
    init(accommodation: Accommodation, trip: Trip? = nil, onAddToTrip: @escaping (Accommodation) -> Void) {
        self.accommodation = accommodation
        self.trip = trip
        self.onAddToTrip = onAddToTrip
        
        // Initialize map region
        self._region = State(initialValue: MKCoordinateRegion(
            center: accommodation.coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        ))
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    headerSection
                    detailsSection
                    amenitiesSection
                    locationSection
                    availabilitySection
                    bookingSection
                    
                    if trip != nil {
                        addToTripSection
                    }
                }
                .padding()
            }
            .navigationTitle(accommodation.name)
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
            .sheet(isPresented: $showingAvailabilityCheck) {
                availabilityCheckView
            }
            .sheet(isPresented: $showingBookingOptions) {
                bookingOptionsView
            }
        }
        .onAppear {
            viewModel.loadBookingInfo(for: accommodation)
        }
    }
    
    // MARK: - View Sections
    
    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: accommodation.type.icon)
                    .font(.title)
                    .foregroundColor(.blue)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(accommodation.type.displayName)
                        .font(.subheadline)
                        .foregroundColor(.blue)
                        .fontWeight(.medium)
                    
                    Text(accommodation.name)
                        .font(.title2)
                        .fontWeight(.bold)
                }
                
                Spacer()
            }
            
            Text(accommodation.address)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            HStack(spacing: 16) {
                if let rating = accommodation.rating {
                    HStack(spacing: 4) {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                        Text(String(format: "%.1f", rating))
                            .fontWeight(.medium)
                    }
                }
                
                if let priceRange = accommodation.priceRange {
                    Text(priceRange.displayName)
                        .fontWeight(.medium)
                        .foregroundColor(.green)
                }
                
                if let distance = accommodation.distance {
                    Text(String(format: "%.1f km away", distance))
                        .foregroundColor(.secondary)
                }
                
                Spacer()
            }
            .font(.subheadline)
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
    
    private var detailsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Details")
                .font(.headline)
                .fontWeight(.semibold)
            
            VStack(spacing: 8) {
                if let checkIn = accommodation.checkInTime {
                    DetailRow(icon: "clock", title: "Check-in", value: checkIn)
                }
                
                if let checkOut = accommodation.checkOutTime {
                    DetailRow(icon: "clock", title: "Check-out", value: checkOut)
                }
                
                if let phone = accommodation.phoneNumber {
                    DetailRow(icon: "phone", title: "Phone", value: phone) {
                        if let url = URL(string: "tel:\(phone)") {
                            openURL(url)
                        }
                    }
                }
                
                if let website = accommodation.website {
                    DetailRow(icon: "globe", title: "Website", value: website.absoluteString) {
                        openURL(website)
                    }
                }
            }
        }
    }
    
    private var amenitiesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Amenities")
                .font(.headline)
                .fontWeight(.semibold)
            
            if accommodation.amenities.isEmpty {
                Text("No amenities listed")
                    .foregroundColor(.secondary)
                    .font(.subheadline)
            } else {
                LazyVGrid(columns: [
                    GridItem(.flexible()),
                    GridItem(.flexible())
                ], spacing: 12) {
                    ForEach(accommodation.amenities, id: \.self) { amenity in
                        HStack(spacing: 8) {
                            Image(systemName: amenity.icon)
                                .foregroundColor(.blue)
                                .frame(width: 20)
                            
                            Text(amenity.displayName)
                                .font(.subheadline)
                            
                            Spacer()
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                    }
                }
            }
        }
    }
    
    private var locationSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Location")
                .font(.headline)
                .fontWeight(.semibold)
            
            Map(coordinateRegion: .constant(region), annotationItems: [accommodation]) { accommodation in
                MapPin(coordinate: accommodation.coordinate, tint: .blue)
            }
            .frame(height: 200)
            .cornerRadius(12)
            
            Button("Get Directions") {
                openDirections()
            }
            .buttonStyle(.bordered)
        }
    }
    
    private var availabilitySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Availability")
                .font(.headline)
                .fontWeight(.semibold)
            
            if let availability = viewModel.availability {
                availabilityInfo(availability)
            } else {
                Button("Check Availability") {
                    showingAvailabilityCheck = true
                }
                .buttonStyle(.bordered)
            }
        }
    }
    
    private var bookingSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Booking")
                .font(.headline)
                .fontWeight(.semibold)
            
            if let bookingInfo = viewModel.bookingInfo {
                bookingInfoView(bookingInfo)
            } else if viewModel.isLoading {
                HStack {
                    ProgressView()
                        .scaleEffect(0.8)
                    Text("Loading booking information...")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
            } else {
                Text("Booking information unavailable")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
    }
    
    private var addToTripSection: some View {
        VStack(spacing: 12) {
            Button("Add to Trip") {
                onAddToTrip(accommodation)
                dismiss()
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            
            Text("This will add the accommodation as a waypoint to your trip")
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(.top)
    }
    
    // MARK: - Helper Views
    
    private func availabilityInfo(_ availability: AccommodationAvailability) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: availability.isAvailable ? "checkmark.circle.fill" : "xmark.circle.fill")
                    .foregroundColor(availability.isAvailable ? .green : .red)
                
                Text(availability.isAvailable ? "Available" : "Not Available")
                    .fontWeight(.medium)
                    .foregroundColor(availability.isAvailable ? .green : .red)
                
                Spacer()
            }
            
            if availability.isAvailable {
                if let rooms = availability.availableRooms {
                    Text("\(rooms) rooms available")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                if let price = availability.pricePerNight {
                    Text("From \(availability.currency) \(String(format: "%.0f", price)) per night")
                        .font(.subheadline)
                        .fontWeight(.medium)
                }
            }
            
            Button("Check Different Dates") {
                showingAvailabilityCheck = true
            }
            .font(.caption)
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(8)
    }
    
    private func bookingInfoView(_ bookingInfo: AccommodationBookingInfo) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            if !bookingInfo.bookingPlatforms.isEmpty {
                Text("Compare Prices")
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                ForEach(bookingInfo.bookingPlatforms) { platform in
                    HStack {
                        Text(platform.name)
                            .fontWeight(.medium)
                        
                        Spacer()
                        
                        if let price = platform.price {
                            Text("\(platform.currency) \(String(format: "%.0f", price))")
                                .fontWeight(.medium)
                        }
                        
                        Button("Book") {
                            openURL(platform.url)
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                    }
                    .padding(.vertical, 4)
                }
            }
            
            if bookingInfo.directBookingAvailable {
                Button("Book Direct") {
                    showingBookingOptions = true
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }
    
    private var availabilityCheckView: some View {
        NavigationView {
            Form {
                Section("Check-in") {
                    DatePicker("Date", selection: $checkInDate, displayedComponents: .date)
                }
                
                Section("Check-out") {
                    DatePicker("Date", selection: $checkOutDate, displayedComponents: .date)
                }
                
                Section("Guests") {
                    Stepper("Guests: \(guests)", value: $guests, in: 1...10)
                }
            }
            .navigationTitle("Check Availability")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        showingAvailabilityCheck = false
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Check") {
                        viewModel.checkAvailability(
                            for: accommodation,
                            checkIn: checkInDate,
                            checkOut: checkOutDate,
                            guests: guests
                        )
                        showingAvailabilityCheck = false
                    }
                    .fontWeight(.semibold)
                }
            }
        }
    }
    
    private var bookingOptionsView: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Contact Information")
                    .font(.headline)
                
                if let phone = accommodation.phoneNumber {
                    Button("Call \(phone)") {
                        if let url = URL(string: "tel:\(phone)") {
                            openURL(url)
                        }
                    }
                    .buttonStyle(.bordered)
                }
                
                if let website = accommodation.website {
                    Button("Visit Website") {
                        openURL(website)
                    }
                    .buttonStyle(.bordered)
                }
                
                if let bookingURL = accommodation.bookingURL {
                    Button("Book Online") {
                        openURL(bookingURL)
                    }
                    .buttonStyle(.borderedProminent)
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("Booking Options")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        showingBookingOptions = false
                    }
                }
            }
        }
    }
    
    // MARK: - Methods
    
    private func openDirections() {
        let placemark = MKPlacemark(coordinate: accommodation.coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = accommodation.name
        mapItem.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving])
    }
}

// MARK: - Detail Row View
struct DetailRow: View {
    let icon: String
    let title: String
    let value: String
    let action: (() -> Void)?
    
    init(icon: String, title: String, value: String, action: (() -> Void)? = nil) {
        self.icon = icon
        self.title = title
        self.value = value
        self.action = action
    }
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.blue)
                .frame(width: 20)
            
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
            
            if let action = action {
                Button(value) {
                    action()
                }
                .font(.subheadline)
            } else {
                Text(value)
                    .font(.subheadline)
                    .fontWeight(.medium)
            }
        }
    }
}

// MARK: - Accommodation MapKit Extension
extension Accommodation: Identifiable {
    // Already conforms to Identifiable through the protocol
}

// MARK: - Preview
struct AccommodationDetailView_Previews: PreviewProvider {
    static let sampleAccommodation = Accommodation(
        id: "sample",
        name: "Sample Hotel",
        address: "123 Main St, City, State",
        coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
        type: .hotel,
        rating: 4.2,
        priceRange: .moderate,
        amenities: [.wifi, .parking, .pool, .gym],
        phoneNumber: "+1-555-0123",
        checkInTime: "3:00 PM",
        checkOutTime: "11:00 AM"
    )
    
    static var previews: some View {
        AccommodationDetailView(accommodation: sampleAccommodation) { _ in
            print("Add to trip tapped")
        }
    }
}