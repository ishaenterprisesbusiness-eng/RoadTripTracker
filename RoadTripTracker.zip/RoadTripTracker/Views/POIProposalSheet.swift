import SwiftUI

struct POIProposalSheet: View {
    let poi: PointOfInterest
    let viewModel: POIViewModel
    
    @Environment(\.dismiss) private var dismiss
    @State private var selectedInsertionIndex = 0
    @State private var proposalMessage = ""
    @State private var isSubmitting = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // POI Summary
                poiSummaryView
                
                // Insertion Point Selection
                insertionPointSection
                
                // Message Section
                messageSection
                
                Spacer()
                
                // Submit Button
                submitButton
            }
            .padding()
            .navigationTitle("Propose Stop")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
    }
}    // MARK
: - POI Summary View
    
    private var poiSummaryView: some View {
        HStack(spacing: 12) {
            Image(systemName: poi.category.iconName)
                .font(.title)
                .foregroundColor(.accentColor)
                .frame(width: 40, height: 40)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(poi.name)
                    .font(.headline)
                    .lineLimit(2)
                
                Text(poi.category.displayName)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color.accentColor.opacity(0.1))
                    .cornerRadius(4)
                
                if let rating = poi.rating {
                    HStack {
                        Text(String(format: "%.1f", rating))
                            .font(.caption)
                            .fontWeight(.medium)
                        
                        HStack(spacing: 1) {
                            ForEach(0..<5) { index in
                                Image(systemName: index < Int(rating) ? "star.fill" : "star")
                                    .font(.caption2)
                                    .foregroundColor(.orange)
                            }
                        }
                    }
                }
            }
            
            Spacer()
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
    
    // MARK: - Insertion Point Section
    
    private var insertionPointSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Add as stop after:")
                .font(.headline)
            
            if let trip = viewModel.currentTrip {
                VStack(spacing: 8) {
                    ForEach(Array(trip.destinations.enumerated()), id: \.offset) { index, destination in
                        HStack {
                            Button(action: { selectedInsertionIndex = index + 1 }) {
                                HStack {
                                    Image(systemName: selectedInsertionIndex == index + 1 ? "checkmark.circle.fill" : "circle")
                                        .foregroundColor(selectedInsertionIndex == index + 1 ? .accentColor : .secondary)
                                    
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(destination.name)
                                            .font(.subheadline)
                                            .fontWeight(.medium)
                                        
                                        Text("Stop \(index + 1)")
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                    
                                    Spacer()
                                }
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        .padding(.vertical, 4)
                    }
                    
                    // Option to add at the end
                    HStack {
                        Button(action: { selectedInsertionIndex = trip.destinations.count }) {
                            HStack {
                                Image(systemName: selectedInsertionIndex == trip.destinations.count ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(selectedInsertionIndex == trip.destinations.count ? .accentColor : .secondary)
                                
                                Text("At the end of the trip")
                                    .font(.subheadline)
                                    .fontWeight(.medium)
                                
                                Spacer()
                            }
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    .padding(.vertical, 4)
                }
            }
        }
    }
    
    // MARK: - Message Section
    
    private var messageSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Message (Optional)")
                .font(.headline)
            
            TextField("Why should we visit this place?", text: $proposalMessage, axis: .vertical)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .lineLimit(3...6)
        }
    }
    
    // MARK: - Submit Button
    
    private var submitButton: some View {
        Button(action: submitProposal) {
            HStack {
                if isSubmitting {
                    ProgressView()
                        .scaleEffect(0.8)
                        .tint(.white)
                } else {
                    Image(systemName: "paperplane.fill")
                }
                
                Text(isSubmitting ? "Proposing..." : "Propose Stop")
            }
            .font(.headline)
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.accentColor)
            .cornerRadius(12)
        }
        .disabled(isSubmitting)
    }
    
    // MARK: - Actions
    
    private func submitProposal() {
        isSubmitting = true
        
        Task {
            await viewModel.proposePOI(
                poi,
                insertionIndex: selectedInsertionIndex,
                message: proposalMessage.isEmpty ? nil : proposalMessage
            )
            
            await MainActor.run {
                isSubmitting = false
                dismiss()
            }
        }
    }
}