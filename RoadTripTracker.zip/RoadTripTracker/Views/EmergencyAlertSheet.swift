import SwiftUI

// MARK: - Emergency Alert Sheet
struct EmergencyAlertSheet: View {
    @ObservedObject var viewModel: EmergencyViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var showingConfirmation = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                // Warning Header
                VStack(spacing: 16) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 64))
                        .foregroundColor(.red)
                    
                    Text("Emergency Alert")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                    
                    Text("This will immediately notify all trip participants and your emergency contacts.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                        .padding(.horizontal)
                }
                .padding(.top)
                
                // Message Input
                VStack(alignment: .leading, spacing: 8) {
                    Text("Optional Message")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    TextField("Describe your emergency (optional)", text: $viewModel.emergencyMessage, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .lineLimit(3...6)
                }
                .padding(.horizontal)
                
                Spacer()
                
                // Action Buttons
                VStack(spacing: 16) {
                    // Panic Button
                    Button("SEND EMERGENCY ALERT") {
                        showingConfirmation = true
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 56)
                    .background(Color.red)
                    .cornerRadius(12)
                    .shadow(color: .red.opacity(0.3), radius: 4, x: 0, y: 2)
                    
                    // Cancel Button
                    Button("Cancel") {
                        dismiss()
                    }
                    .font(.body)
                    .foregroundColor(.blue)
                    .frame(maxWidth: .infinity)
                    .frame(height: 44)
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            .navigationTitle("Emergency")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden()
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .confirmationDialog("Send Emergency Alert", isPresented: $showingConfirmation) {
                Button("Send Alert", role: .destructive) {
                    viewModel.triggerPanicAlert()
                    dismiss()
                }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("Are you sure you want to send an emergency alert? This will notify all trip participants and your emergency contacts immediately.")
            }
        }
    }
}

// MARK: - Breakdown Assistance Sheet
struct BreakdownAssistanceSheet: View {
    @ObservedObject var viewModel: EmergencyViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var breakdownType = BreakdownType.mechanical
    @State private var description = ""
    @State private var showingConfirmation = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                // Header
                VStack(spacing: 16) {
                    Image(systemName: "car.fill")
                        .font(.system(size: 48))
                        .foregroundColor(.orange)
                    
                    Text("Breakdown Assistance")
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Text("Request help from nearby mechanics and towing services.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                        .padding(.horizontal)
                }
                .padding(.top)
                
                // Breakdown Type Selection
                VStack(alignment: .leading, spacing: 12) {
                    Text("Type of Problem")
                        .font(.headline)
                    
                    Picker("Breakdown Type", selection: $breakdownType) {
                        ForEach(BreakdownType.allCases, id: \.self) { type in
                            Text(type.displayName).tag(type)
                        }
                    }
                    .pickerStyle(.segmented)
                }
                .padding(.horizontal)
                
                // Description Input
                VStack(alignment: .leading, spacing: 8) {
                    Text("Description (Optional)")
                        .font(.headline)
                    
                    TextField("Describe the problem", text: $description, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .lineLimit(3...6)
                }
                .padding(.horizontal)
                
                Spacer()
                
                // Action Buttons
                VStack(spacing: 16) {
                    Button("Request Assistance") {
                        showingConfirmation = true
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 56)
                    .background(Color.orange)
                    .cornerRadius(12)
                    
                    Button("Cancel") {
                        dismiss()
                    }
                    .font(.body)
                    .foregroundColor(.blue)
                    .frame(maxWidth: .infinity)
                    .frame(height: 44)
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            .navigationTitle("Breakdown")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden()
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .confirmationDialog("Request Breakdown Assistance", isPresented: $showingConfirmation) {
                Button("Request Help") {
                    viewModel.requestBreakdownAssistance()
                    dismiss()
                }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("This will notify trip participants and find nearby breakdown services.")
            }
        }
    }
}

// MARK: - Emergency Services Sheet
struct EmergencyServicesSheet: View {
    @ObservedObject var viewModel: EmergencyViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var selectedServiceType: EmergencyServiceType?
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Service Type Filter
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ServiceTypeButton(
                            type: nil,
                            title: "All",
                            icon: "list.bullet",
                            isSelected: selectedServiceType == nil
                        ) {
                            selectedServiceType = nil
                        }
                        
                        ForEach([EmergencyServiceType.hospital, .police, .fireStation, .mechanic, .towingService], id: \.self) { type in
                            ServiceTypeButton(
                                type: type,
                                title: type.displayName,
                                icon: type.icon,
                                isSelected: selectedServiceType == type
                            ) {
                                selectedServiceType = type
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical, 12)
                .background(Color(UIColor.systemBackground))
                
                Divider()
                
                // Services List
                if viewModel.isLoadingServices {
                    VStack(spacing: 16) {
                        ProgressView()
                        Text("Finding emergency services...")
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(filteredServices) { service in
                            EmergencyServiceDetailRow(service: service) {
                                viewModel.callEmergencyService(service)
                            } onDirections: {
                                viewModel.getDirectionsToService(service)
                            }
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Emergency Services")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Done") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Refresh") {
                        viewModel.loadNearbyEmergencyServices()
                    }
                }
            }
        }
        .onAppear {
            if viewModel.nearbyEmergencyServices.isEmpty {
                viewModel.loadNearbyEmergencyServices()
            }
        }
    }
    
    private var filteredServices: [EmergencyService] {
        if let selectedType = selectedServiceType {
            return viewModel.nearbyEmergencyServices.filter { $0.type == selectedType }
        }
        return viewModel.nearbyEmergencyServices
    }
}

// MARK: - Service Type Button
struct ServiceTypeButton: View {
    let type: EmergencyServiceType?
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.caption)
                Text(title)
                    .font(.caption)
                    .fontWeight(.medium)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(isSelected ? Color.blue : Color(UIColor.systemGray5))
            .foregroundColor(isSelected ? .white : .primary)
            .cornerRadius(16)
        }
    }
}

// MARK: - Emergency Service Detail Row
struct EmergencyServiceDetailRow: View {
    let service: EmergencyService
    let onCall: () -> Void
    let onDirections: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: service.type.icon)
                    .font(.title2)
                    .foregroundColor(service.type.color)
                    .frame(width: 32, height: 32)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(service.name)
                        .font(.headline)
                    
                    Text(service.type.displayName)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                if service.isOpen24Hours {
                    Text("24/7")
                        .font(.caption)
                        .fontWeight(.medium)
                        .foregroundColor(.green)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.green.opacity(0.1))
                        .cornerRadius(8)
                }
            }
            
            Text(service.address)
                .font(.body)
                .foregroundColor(.secondary)
            
            HStack {
                Text("\(Int(service.distance))m away")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                HStack(spacing: 12) {
                    Button("Call") {
                        onCall()
                    }
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(Color.green)
                    .cornerRadius(8)
                    
                    Button("Directions") {
                        onDirections()
                    }
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(Color.blue)
                    .cornerRadius(8)
                }
            }
        }
        .padding(.vertical, 8)
    }
}

// MARK: - Breakdown Type
enum BreakdownType: String, CaseIterable {
    case mechanical = "mechanical"
    case electrical = "electrical"
    case tire = "tire"
    case fuel = "fuel"
    case accident = "accident"
    case other = "other"
    
    var displayName: String {
        switch self {
        case .mechanical: return "Mechanical"
        case .electrical: return "Electrical"
        case .tire: return "Tire"
        case .fuel: return "Fuel"
        case .accident: return "Accident"
        case .other: return "Other"
        }
    }
}

// MARK: - Emergency Service Type Extensions
extension EmergencyServiceType {
    var displayName: String {
        switch self {
        case .hospital: return "Hospital"
        case .police: return "Police"
        case .fireStation: return "Fire"
        case .mechanic: return "Mechanic"
        case .towingService: return "Towing"
        }
    }
    
    var icon: String {
        switch self {
        case .hospital: return "cross.circle.fill"
        case .police: return "shield.fill"
        case .fireStation: return "flame.fill"
        case .mechanic: return "wrench.fill"
        case .towingService: return "car.fill"
        }
    }
    
    var color: Color {
        switch self {
        case .hospital: return .red
        case .police: return .blue
        case .fireStation: return .red
        case .mechanic: return .orange
        case .towingService: return .orange
        }
    }
}

// MARK: - Preview
struct EmergencyAlertSheet_Previews: PreviewProvider {
    static var previews: some View {
        EmergencyAlertSheet(viewModel: EmergencyViewModel(
            emergencyService: MockEmergencyService(),
            locationManager: LocationManager()
        ))
    }
}