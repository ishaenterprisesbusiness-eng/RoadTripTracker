import SwiftUI

// MARK: - Launch Screen View
struct LaunchScreenView: View {
    @StateObject private var integrationManager = AppIntegrationManager.shared
    @StateObject private var accessibilityManager = AccessibilityManager.shared
    @State private var logoScale: CGFloat = 0.8
    @State private var logoOpacity: Double = 0
    @State private var backgroundOpacity: Double = 0
    @State private var particleOpacity: Double = 0
    @State private var progressBarWidth: CGFloat = 0
    @State private var showProgressText = false
    
    var body: some View {
        ZStack {
            // Dynamic background
            backgroundGradient
                .ignoresSafeArea()
                .opacity(backgroundOpacity)
            
            // Animated particles
            particleSystem
                .opacity(particleOpacity)
            
            VStack(spacing: 40) {
                Spacer()
                
                // App logo and branding
                logoSection
                
                Spacer()
                
                // Progress section
                progressSection
                
                Spacer(minLength: 100)
            }
            .padding(.horizontal, 40)
        }
        .preferredColorScheme(.dark)
        .onAppear {
            startLaunchAnimation()
            Task {
                await integrationManager.initializeApp()
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Road Trip Tracker is starting up")
        .accessibilityValue("Progress: \(Int(integrationManager.initializationProgress * 100)) percent")
    }
    
    // MARK: - Background Gradient
    private var backgroundGradient: some View {
        ZStack {
            // Base gradient
            LinearGradient(
                colors: [
                    Color(red: 0.05, green: 0.1, blue: 0.2),
                    Color(red: 0.1, green: 0.15, blue: 0.3),
                    Color(red: 0.15, green: 0.2, blue: 0.4)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            
            // Overlay gradients for depth
            RadialGradient(
                colors: [
                    .blue.opacity(0.3),
                    .purple.opacity(0.2),
                    .clear
                ],
                center: .topTrailing,
                startRadius: 0,
                endRadius: 400
            )
            
            RadialGradient(
                colors: [
                    .cyan.opacity(0.2),
                    .blue.opacity(0.1),
                    .clear
                ],
                center: .bottomLeading,
                startRadius: 0,
                endRadius: 300
            )
        }
    }
    
    // MARK: - Particle System
    private var particleSystem: some View {
        ZStack {
            ForEach(0..<50, id: \.self) { index in
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [
                                .white.opacity(0.6),
                                .blue.opacity(0.4),
                                .clear
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: CGFloat.random(in: 1...4))
                    .position(
                        x: CGFloat.random(in: 0...UIScreen.main.bounds.width),
                        y: CGFloat.random(in: 0...UIScreen.main.bounds.height)
                    )
                    .animation(
                        .easeInOut(duration: Double.random(in: 3...8))
                        .repeatForever(autoreverses: true)
                        .delay(Double(index) * 0.1),
                        value: particleOpacity
                    )
            }
        }
    }
    
    // MARK: - Logo Section
    private var logoSection: some View {
        VStack(spacing: 24) {
            // App icon/logo
            ZStack {
                // Glassmorphic background
                Circle()
                    .fill(.ultraThinMaterial)
                    .frame(width: 120, height: 120)
                    .overlay(
                        Circle()
                            .stroke(
                                LinearGradient(
                                    colors: [
                                        .white.opacity(0.3),
                                        .blue.opacity(0.2),
                                        .clear
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ),
                                lineWidth: 2
                            )
                    )
                    .shadow(color: .black.opacity(0.3), radius: 20, x: 0, y: 10)
                
                // App icon
                Image(systemName: "car.2.fill")
                    .font(.system(size: 48, weight: .medium))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.white, .blue.opacity(0.8)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                
                // Animated ring
                Circle()
                    .stroke(
                        LinearGradient(
                            colors: [
                                .blue.opacity(0.8),
                                .purple.opacity(0.6),
                                .pink.opacity(0.4),
                                .clear
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 3
                    )
                    .frame(width: 140, height: 140)
                    .rotationEffect(.degrees(logoScale * 360))
                    .opacity(logoOpacity * 0.7)
            }
            .scaleEffect(logoScale)
            .opacity(logoOpacity)
            
            // App name
            VStack(spacing: 8) {
                Text("Road Trip Tracker")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.white, .blue.opacity(0.9)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                
                Text("Adventure Awaits")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.8))
                    .fontWeight(.medium)
            }
            .opacity(logoOpacity)
        }
    }
    
    // MARK: - Progress Section
    private var progressSection: some View {
        VStack(spacing: 20) {
            // Progress bar
            VStack(spacing: 12) {
                ZStack(alignment: .leading) {
                    // Background track
                    RoundedRectangle(cornerRadius: 8)
                        .fill(.ultraThinMaterial)
                        .frame(height: 8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(.white.opacity(0.2), lineWidth: 1)
                        )
                    
                    // Progress fill
                    RoundedRectangle(cornerRadius: 8)
                        .fill(
                            LinearGradient(
                                colors: [
                                    .blue,
                                    .purple,
                                    .pink
                                ],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: progressBarWidth, height: 8)
                        .shadow(color: .blue.opacity(0.5), radius: 4, x: 0, y: 0)
                }
                .frame(maxWidth: 280)
                
                // Progress percentage
                Text("\(Int(integrationManager.initializationProgress * 100))%")
                    .font(.caption)
                    .fontWeight(.semibold)
                    .foregroundColor(.white.opacity(0.9))
                    .opacity(showProgressText ? 1 : 0)
            }
            
            // Status text
            Text(integrationManager.currentInitializationStep)
                .font(.subheadline)
                .foregroundColor(.white.opacity(0.8))
                .multilineTextAlignment(.center)
                .opacity(showProgressText ? 1 : 0)
                .accessibilityLabel("Current step: \(integrationManager.currentInitializationStep)")
        }
        .onChange(of: integrationManager.initializationProgress) { progress in
            updateProgressBar(progress: progress)
        }
    }
    
    // MARK: - Animations
    private func startLaunchAnimation() {
        // Background fade in
        withAnimation(.easeOut(duration: 1.0)) {
            backgroundOpacity = 1
        }
        
        // Particles fade in
        withAnimation(.easeOut(duration: 1.5).delay(0.3)) {
            particleOpacity = 1
        }
        
        // Logo animation
        withAnimation(.spring(response: 0.8, dampingFraction: 0.6).delay(0.5)) {
            logoScale = 1.0
            logoOpacity = 1.0
        }
        
        // Progress section
        withAnimation(.easeOut(duration: 0.5).delay(1.0)) {
            showProgressText = true
        }
        
        // Continuous logo rotation (if not reduce motion)
        if !accessibilityManager.isReduceMotionEnabled {
            withAnimation(.linear(duration: 10).repeatForever(autoreverses: false)) {
                logoScale = 1.1
            }
        }
    }
    
    private func updateProgressBar(progress: Double) {
        let targetWidth = 280 * CGFloat(progress)
        
        let animation = accessibilityManager.shouldReduceAnimations() 
            ? .linear(duration: 0.1)
            : .spring(response: 0.5, dampingFraction: 0.8)
        
        withAnimation(animation) {
            progressBarWidth = targetWidth
        }
        
        // Haptic feedback for progress milestones
        if progress >= 0.25 && progress < 0.26 ||
           progress >= 0.5 && progress < 0.51 ||
           progress >= 0.75 && progress < 0.76 ||
           progress >= 1.0 {
            let impactFeedback = UIImpactFeedbackGenerator(style: .light)
            impactFeedback.impactOccurred()
        }
    }
}

// MARK: - Launch Screen Wrapper
struct LaunchScreenWrapper<Content: View>: View {
    @StateObject private var integrationManager = AppIntegrationManager.shared
    let content: Content
    
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        ZStack {
            if integrationManager.isAppReady {
                content
                    .transition(.opacity.combined(with: .scale))
            } else {
                LaunchScreenView()
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.8), value: integrationManager.isAppReady)
    }
}

#Preview {
    LaunchScreenView()
}