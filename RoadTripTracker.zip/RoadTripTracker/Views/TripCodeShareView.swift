import SwiftUI

struct TripCodeShareView: View {
    let trip: Trip
    @Environment(\.dismiss) private var dismiss
    @State private var showingShareSheet = false
    
    var body: some View {
        NavigationView {
            ZStack {
                LiquidGlassBackground()
                
                ScrollView {
                    VStack(spacing: 32) {
                        headerSection
                        tripCodeSection
                        shareOptionsSection
                        participantsSection
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 40)
                }
            }
            .navigationTitle("Share Trip")
            .navigationBarTitleDisplayMode(.large)
            .navigationBarBackButtonHidden()
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Done") {
                        dismiss()
                    }
                    .foregroundColor(.blue)
                }
            }
        }
        .sheet(isPresented: $showingShareSheet) {
            ShareSheet(items: [shareText])
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 16) {
            Image(systemName: "square.and.arrow.up.circle.fill")
                .font(.system(size: 64))
                .foregroundStyle(
                    LinearGradient(
                        colors: [.green, .blue],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            
            VStack(spacing: 8) {
                Text("Share Your Trip")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                Text("Share the trip code below with friends and family to invite them to join your road trip")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
    }
    
    private var tripCodeSection: some View {
        LiquidGlassCard {
            VStack(spacing: 24) {
                VStack(spacing: 12) {
                    Text("Trip Code")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Text(trip.name)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                // Large trip code display
                LiquidGlassCard(style: .secondary) {
                    Text(trip.code)
                        .font(.system(size: 48, weight: .bold, design: .monospaced))
                        .foregroundColor(.primary)
                        .tracking(8)
                        .padding(.vertical, 20)
                }
                
                HStack(spacing: 16) {
                    LiquidGlassButton(
                        title: "Copy Code",
                        icon: "doc.on.doc",
                        style: .secondary
                    ) {
                        UIPasteboard.general.string = trip.code
                        // Show haptic feedback
                        let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
                        impactFeedback.impactOccurred()
                    }
                    
                    LiquidGlassButton(
                        title: "Share",
                        icon: "square.and.arrow.up",
                        style: .primary
                    ) {
                        showingShareSheet = true
                    }
                }
            }
        }
    }
    
    private var shareOptionsSection: some View {
        LiquidGlassCard {
            VStack(spacing: 20) {
                HStack {
                    Image(systemName: "info.circle.fill")
                        .font(.title2)
                        .foregroundColor(.blue)
                    
                    Text("How to Share")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Spacer()
                }
                
                VStack(spacing: 12) {
                    shareInstructionRow(
                        icon: "message.fill",
                        title: "Text Message",
                        description: "Send the trip code via SMS or messaging apps"
                    )
                    
                    shareInstructionRow(
                        icon: "envelope.fill",
                        title: "Email",
                        description: "Email the trip details to participants"
                    )
                    
                    shareInstructionRow(
                        icon: "person.2.fill",
                        title: "In Person",
                        description: "Show the code on your screen for others to enter"
                    )
                }
            }
        }
    }
    
    private var participantsSection: some View {
        LiquidGlassCard {
            VStack(spacing: 20) {
                HStack {
                    Image(systemName: "person.3.fill")
                        .font(.title2)
                        .foregroundColor(.green)
                    
                    Text("Current Participants")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Text("\(trip.participants.count)")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.green)
                }
                
                if trip.participants.isEmpty {
                    VStack(spacing: 8) {
                        Image(systemName: "person.badge.plus")
                            .font(.title)
                            .foregroundColor(.secondary)
                        
                        Text("No participants yet")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Text("Share the trip code to invite others")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 16)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(trip.participants) { participant in
                            ParticipantRow(participant: participant)
                        }
                    }
                }
            }
        }
    }
    
    private func shareInstructionRow(icon: String, title: String, description: String) -> some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(.blue)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                Text(description)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
    }
    
    private var shareText: String {
        """
        🚗 Join my road trip: \(trip.name)
        
        Trip Code: \(trip.code)
        
        Download the Road Trip Tracker app and enter this code to join the adventure!
        """
    }
}

// MARK: - Participant Row
struct ParticipantRow: View {
    let participant: Participant
    
    var body: some View {
        HStack(spacing: 16) {
            // Profile image placeholder
            Circle()
                .fill(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 40, height: 40)
                .overlay(
                    Text(String(participant.user.username.prefix(1)).uppercased())
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                )
            
            VStack(alignment: .leading, spacing: 4) {
                Text(participant.user.username)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                if let vehicle = participant.user.vehicle {
                    Text("\(vehicle.make) \(vehicle.model)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                } else {
                    Text("No vehicle info")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            // Status indicator
            statusIndicator(for: participant.status)
        }
        .padding(.vertical, 4)
    }
    
    private func statusIndicator(for status: ParticipantStatus) -> some View {
        HStack(spacing: 4) {
            Circle()
                .fill(statusColor(for: status))
                .frame(width: 8, height: 8)
            
            Text(status.displayName)
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(statusColor(for: status))
        }
    }
    
    private func statusColor(for status: ParticipantStatus) -> Color {
        switch status {
        case .invited:
            return .orange
        case .joined:
            return .green
        case .active:
            return .blue
        case .inactive:
            return .gray
        case .left:
            return .red
        }
    }
}

// MARK: - Share Sheet
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// MARK: - Participant Status Extension
extension ParticipantStatus {
    var displayName: String {
        switch self {
        case .invited:
            return "Invited"
        case .joined:
            return "Joined"
        case .active:
            return "Active"
        case .inactive:
            return "Inactive"
        case .left:
            return "Left"
        }
    }
}

#Preview {
    TripCodeShareView(trip: Trip(
        name: "Weekend Getaway",
        code: "ABC123",
        createdBy: UUID(),
        participants: [
            Participant(
                userId: UUID(),
                user: User(
                    username: "John Doe",
                    email: "john@example.com",
                    city: "Sydney",
                    dateOfBirth: Date(),
                    vehicle: Vehicle(
                        make: "Toyota",
                        model: "Camry",
                        vehicleNumber: "ABC123",
                        odometerReading: 50000,
                        type: .sedan
                    )
                )
            )
        ]
    ))
}