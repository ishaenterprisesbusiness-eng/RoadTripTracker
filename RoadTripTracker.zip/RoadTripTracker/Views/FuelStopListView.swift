import SwiftUI
import MapKit

struct FuelStopListView: View {
    @StateObject private var viewModel: FuelStopViewModel
    @State private var showingGasStationSearch = false
    @State private var proposalNotes = ""
    
    init(fuelStopService: FuelStopServiceProtocol, locationManager: LocationManager) {
        self._viewModel = StateObject(wrappedValue: FuelStopViewModel(fuelStopService: fuelStopService, locationManager: locationManager))
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Active Fuel Stop Section
                if let activeFuelStop = viewModel.activeFuelStop {
                    activeFuelStopSection(activeFuelStop)
                }
                
                // Proposed Fuel Stops Section
                if !viewModel.proposedFuelStops.isEmpty {
                    proposedFuelStopsSection
                }
                
                // Nearby Gas Stations Section
                nearbyGasStationsSection
                
                Spacer()
            }
            .navigationTitle("Fuel Stops")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Find Stations") {
                        Task {
                            await viewModel.searchNearbyGasStations()
                        }
                    }
                }
            }
            .sheet(isPresented: $viewModel.showingProposalSheet) {
                fuelStopProposalSheet
            }
            .sheet(isPresented: $viewModel.showingCheckInSheet) {
                fuelStopCheckInSheet
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.errorMessage = nil
                }
            } message: {
                Text(viewModel.errorMessage ?? "")
            }
        }
    }
    
    // MARK: - Active Fuel Stop Section
    
    @ViewBuilder
    private func activeFuelStopSection(_ fuelStop: FuelStop) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "fuelpump.fill")
                    .foregroundColor(.blue)
                Text("Active Fuel Stop")
                    .font(.headline)
                Spacer()
                Text(fuelStop.proposalStatus.displayName)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.blue.opacity(0.2))
                    .cornerRadius(8)
            }
            
            gasStationCard(fuelStop.gasStation, showProposalButton: false)
            
            // Check-in Status
            checkInStatusView(fuelStop)
            
            // Action Buttons
            HStack(spacing: 12) {
                if !viewModel.isParticipantCheckedIn(UUID()) { // Replace with actual participant ID
                    Button("Check In") {
                        viewModel.showCheckInSheet()
                    }
                    .buttonStyle(.borderedProminent)
                } else if !viewModel.isParticipantReady(UUID()) { // Replace with actual participant ID
                    Button("Ready to Continue") {
                        Task {
                            await viewModel.markReadyToContinue()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                }
                
                Spacer()
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal)
    }
    
    // MARK: - Proposed Fuel Stops Section
    
    @ViewBuilder
    private var proposedFuelStopsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "clock.fill")
                    .foregroundColor(.orange)
                Text("Proposed Fuel Stops")
                    .font(.headline)
                Spacer()
            }
            .padding(.horizontal)
            
            ForEach(viewModel.proposedFuelStops) { fuelStop in
                proposedFuelStopCard(fuelStop)
            }
        }
    }
    
    @ViewBuilder
    private func proposedFuelStopCard(_ fuelStop: FuelStop) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(fuelStop.gasStation.name)
                    .font(.headline)
                Spacer()
                Text(fuelStop.proposalStatus.displayName)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(statusColor(for: fuelStop.proposalStatus).opacity(0.2))
                    .foregroundColor(statusColor(for: fuelStop.proposalStatus))
                    .cornerRadius(8)
            }
            
            Text(fuelStop.gasStation.address)
                .font(.caption)
                .foregroundColor(.secondary)
            
            if let notes = fuelStop.notes {
                Text(notes)
                    .font(.caption)
                    .padding(8)
                    .background(Color(.systemGray5))
                    .cornerRadius(8)
            }
            
            // Approval Status
            HStack {
                Label("\(fuelStop.approvals.count) approved", systemImage: "checkmark.circle.fill")
                    .foregroundColor(.green)
                    .font(.caption)
                
                Label("\(fuelStop.rejections.count) rejected", systemImage: "xmark.circle.fill")
                    .foregroundColor(.red)
                    .font(.caption)
                
                Spacer()
            }
            
            // Action Buttons
            if fuelStop.proposalStatus == .pending {
                HStack(spacing: 12) {
                    Button("Approve") {
                        Task {
                            await viewModel.approveFuelStop(fuelStop)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    
                    Button("Reject") {
                        Task {
                            await viewModel.rejectFuelStop(fuelStop)
                        }
                    }
                    .buttonStyle(.bordered)
                    
                    Spacer()
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
        .padding(.horizontal)
    }
    
    // MARK: - Nearby Gas Stations Section
    
    @ViewBuilder
    private var nearbyGasStationsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "location.fill")
                    .foregroundColor(.green)
                Text("Nearby Gas Stations")
                    .font(.headline)
                Spacer()
                
                if viewModel.isLoading {
                    ProgressView()
                        .scaleEffect(0.8)
                }
            }
            .padding(.horizontal)
            
            if viewModel.nearbyGasStations.isEmpty && !viewModel.isLoading {
                Text("No gas stations found. Tap 'Find Stations' to search.")
                    .foregroundColor(.secondary)
                    .padding()
            } else {
                ForEach(viewModel.nearbyGasStations) { gasStation in
                    gasStationCard(gasStation, showProposalButton: true)
                }
            }
        }
    }
    
    @ViewBuilder
    private func gasStationCard(_ gasStation: GasStation, showProposalButton: Bool) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(gasStation.name)
                        .font(.headline)
                    
                    if let brand = gasStation.brand {
                        Text(brand)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Spacer()
                
                if let rating = gasStation.rating {
                    HStack(spacing: 2) {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                            .font(.caption)
                        Text(String(format: "%.1f", rating))
                            .font(.caption)
                    }
                }
            }
            
            Text(gasStation.address)
                .font(.caption)
                .foregroundColor(.secondary)
            
            // Amenities
            if !gasStation.amenities.isEmpty {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 8) {
                    ForEach(gasStation.amenities.prefix(8), id: \.self) { amenity in
                        HStack(spacing: 4) {
                            Image(systemName: amenity.icon)
                                .font(.caption2)
                            Text(amenity.displayName)
                                .font(.caption2)
                        }
                        .foregroundColor(.secondary)
                    }
                }
            }
            
            if showProposalButton {
                Button("Propose as Fuel Stop") {
                    viewModel.showProposalSheet(for: gasStation)
                }
                .buttonStyle(.bordered)
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
        .padding(.horizontal)
    }
    
    // MARK: - Check-in Status View
    
    @ViewBuilder
    private func checkInStatusView(_ fuelStop: FuelStop) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Check-in Status")
                .font(.subheadline)
                .fontWeight(.medium)
            
            if fuelStop.checkIns.isEmpty {
                Text("No participants checked in yet")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                ForEach(fuelStop.checkIns) { checkIn in
                    HStack {
                        Image(systemName: checkIn.isReadyToContinue ? "checkmark.circle.fill" : "clock.circle.fill")
                            .foregroundColor(checkIn.isReadyToContinue ? .green : .orange)
                        
                        Text("Participant") // Replace with actual participant name
                            .font(.caption)
                        
                        Spacer()
                        
                        Text(checkIn.isReadyToContinue ? "Ready" : "Fueling")
                            .font(.caption)
                            .foregroundColor(checkIn.isReadyToContinue ? .green : .orange)
                    }
                }
            }
        }
        .padding(12)
        .background(Color(.systemGray5))
        .cornerRadius(8)
    }
    
    // MARK: - Sheets
    
    @ViewBuilder
    private var fuelStopProposalSheet: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                if let gasStation = viewModel.selectedGasStation {
                    gasStationCard(gasStation, showProposalButton: false)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Notes (Optional)")
                            .font(.headline)
                        
                        TextField("Add any notes about this fuel stop...", text: $proposalNotes, axis: .vertical)
                            .textFieldStyle(.roundedBorder)
                            .lineLimit(3...6)
                    }
                    
                    Spacer()
                }
            }
            .padding()
            .navigationTitle("Propose Fuel Stop")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        viewModel.showingProposalSheet = false
                        proposalNotes = ""
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Propose") {
                        if let gasStation = viewModel.selectedGasStation {
                            Task {
                                await viewModel.proposeFuelStop(
                                    gasStation: gasStation,
                                    notes: proposalNotes.isEmpty ? nil : proposalNotes
                                )
                                proposalNotes = ""
                            }
                        }
                    }
                    .disabled(viewModel.isLoading)
                }
            }
        }
    }
    
    @ViewBuilder
    private var fuelStopCheckInSheet: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Fuel Amount (Liters)")
                        .font(.headline)
                    
                    TextField("Enter fuel amount", text: $viewModel.fuelAmount)
                        .textFieldStyle(.roundedBorder)
                        .keyboardType(.decimalPad)
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Fuel Cost")
                        .font(.headline)
                    
                    TextField("Enter total cost", text: $viewModel.fuelCost)
                        .textFieldStyle(.roundedBorder)
                        .keyboardType(.decimalPad)
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Notes (Optional)")
                        .font(.headline)
                    
                    TextField("Any additional notes...", text: $viewModel.checkInNotes, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .lineLimit(2...4)
                }
                
                Toggle("Ready to continue", isOn: $viewModel.isReadyToContinue)
                    .font(.headline)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Check In")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        viewModel.showingCheckInSheet = false
                        viewModel.clearCheckInForm()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Check In") {
                        Task {
                            await viewModel.checkInAtFuelStop()
                        }
                    }
                    .disabled(viewModel.isLoading)
                }
            }
        }
    }
    
    // MARK: - Helper Methods
    
    private func statusColor(for status: StopProposalStatus) -> Color {
        switch status {
        case .pending: return .orange
        case .approved: return .green
        case .rejected: return .red
        case .active: return .blue
        case .completed: return .gray
        case .cancelled: return .gray
        }
    }
}

#Preview {
    FuelStopListView(
        fuelStopService: FuelStopService(
            placesService: PlacesService(),
            notificationService: MockNotificationService(),
            routeManager: RouteManager()
        ),
        locationManager: LocationManager()
    )
}

// MARK: - Mock Notification Service for Preview
private class MockNotificationService: NotificationServiceProtocol {
    var notificationPermissionStatus: AnyPublisher<UNAuthorizationStatus, Never> {
        Just(.authorized).eraseToAnyPublisher()
    }
    
    func requestNotificationPermission() async throws -> Bool { true }
    func scheduleLocalNotification(_ notification: LocalNotification) async throws {}
    func cancelNotification(withIdentifier identifier: String) async throws {}
    func cancelAllNotifications() async throws {}
    func sendPushNotification(_ notification: PushNotification) async throws {}
    func registerForRemoteNotifications() async throws -> Data { Data() }
    func handleRemoteNotification(_ userInfo: [AnyHashable: Any]) async {}
}