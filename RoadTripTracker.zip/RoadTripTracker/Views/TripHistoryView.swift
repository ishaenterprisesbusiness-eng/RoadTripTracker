import SwiftUI

struct TripHistoryView: View {
    @StateObject private var profileViewModel = ProfileViewModel()
    @State private var selectedFilter: TripFilter = .all
    @State private var searchText = ""
    
    enum TripFilter: String, CaseIterable {
        case all = "All"
        case completed = "Completed"
        case active = "Active"
        case planning = "Planning"
        case cancelled = "Cancelled"
        
        var tripStatus: TripStatus? {
            switch self {
            case .all: return nil
            case .completed: return .completed
            case .active: return .active
            case .planning: return .planning
            case .cancelled: return .cancelled
            }
        }
    }
    
    var filteredTrips: [Trip] {
        var trips = profileViewModel.recentTrips
        
        // Apply status filter
        if let status = selectedFilter.tripStatus {
            trips = trips.filter { $0.status == status }
        }
        
        // Apply search filter
        if !searchText.isEmpty {
            trips = trips.filter { trip in
                trip.name.localizedCaseInsensitiveContains(searchText) ||
                trip.code.localizedCaseInsensitiveContains(searchText) ||
                trip.destinations.contains { $0.name.localizedCaseInsensitiveContains(searchText) }
            }
        }
        
        return trips
    }
    
    var body: some View {
        ZStack {
            LiquidGlassBackground()
            
            VStack(spacing: 0) {
                // Search and Filter Section
                VStack(spacing: 16) {
                    // Search Bar
                    LiquidGlassTextField(
                        title: "Search trips",
                        text: $searchText,
                        icon: "magnifyingglass"
                    )
                    
                    // Filter Tabs
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(TripFilter.allCases, id: \.self) { filter in
                                FilterTab(
                                    title: filter.rawValue,
                                    isSelected: selectedFilter == filter
                                ) {
                                    selectedFilter = filter
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                
                // Trip List
                if filteredTrips.isEmpty {
                    Spacer()
                    
                    VStack(spacing: 16) {
                        Image(systemName: searchText.isEmpty ? "map.circle" : "magnifyingglass")
                            .font(.system(size: 64))
                            .foregroundColor(.secondary)
                        
                        Text(searchText.isEmpty ? "No trips found" : "No trips match your search")
                            .font(.title2)
                            .fontWeight(.semibold)
                            .foregroundColor(.primary)
                        
                        Text(searchText.isEmpty ? 
                             "Start your first road trip adventure!" : 
                             "Try adjusting your search or filter criteria")
                            .font(.body)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.horizontal, 40)
                    
                    Spacer()
                } else {
                    ScrollView {
                        LazyVStack(spacing: 16) {
                            ForEach(filteredTrips) { trip in
                                NavigationLink(destination: TripDetailView(trip: trip)) {
                                    TripHistoryCard(trip: trip)
                                        .padding(.horizontal, 20)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                        .padding(.top, 20)
                        .padding(.bottom, 100)
                    }
                }
            }
        }
        .navigationTitle("Trip History")
        .navigationBarTitleDisplayMode(.large)
        .refreshable {
            await profileViewModel.refreshData()
        }
        .onAppear {
            Task {
                await profileViewModel.loadTripHistory()
            }
        }
    }
}

// MARK: - Filter Tab Component

struct FilterTab: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(isSelected ? .white : .primary)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(
                    Capsule()
                        .fill(isSelected ? 
                              LinearGradient(colors: [.blue, .purple], startPoint: .leading, endPoint: .trailing) :
                              Color.clear
                        )
                        .overlay(
                            Capsule()
                                .stroke(.white.opacity(0.3), lineWidth: isSelected ? 0 : 1)
                        )
                )
        }
        .animation(.easeInOut(duration: 0.2), value: isSelected)
    }
}

// MARK: - Trip Detail View (Placeholder)

struct TripDetailView: View {
    let trip: Trip
    
    var body: some View {
        ZStack {
            LiquidGlassBackground()
            
            ScrollView {
                VStack(spacing: 24) {
                    // Trip Header
                    LiquidGlassCard {
                        VStack(alignment: .leading, spacing: 16) {
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(trip.name)
                                        .font(.title2)
                                        .fontWeight(.bold)
                                        .foregroundColor(.primary)
                                    
                                    Text("Trip Code: \(trip.code)")
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }
                                
                                Spacer()
                                
                                TripStatusBadge(status: trip.status)
                            }
                            
                            Divider()
                            
                            // Trip Stats
                            HStack(spacing: 20) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Participants")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                    
                                    Text("\(trip.participants.count)")
                                        .font(.title3)
                                        .fontWeight(.semibold)
                                        .foregroundColor(.primary)
                                }
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Destinations")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                    
                                    Text("\(trip.destinations.count)")
                                        .font(.title3)
                                        .fontWeight(.semibold)
                                        .foregroundColor(.primary)
                                }
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Created")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                    
                                    Text(trip.createdAt.formatted(date: .abbreviated, time: .omitted))
                                        .font(.title3)
                                        .fontWeight(.semibold)
                                        .foregroundColor(.primary)
                                }
                                
                                Spacer()
                            }
                        }
                    }
                    
                    // Destinations List
                    if !trip.destinations.isEmpty {
                        LiquidGlassCard {
                            VStack(alignment: .leading, spacing: 16) {
                                Text("Destinations")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.primary)
                                
                                VStack(spacing: 12) {
                                    ForEach(Array(trip.destinations.enumerated()), id: \.element.id) { index, destination in
                                        HStack(spacing: 12) {
                                            // Destination Number
                                            Text("\(index + 1)")
                                                .font(.caption)
                                                .fontWeight(.bold)
                                                .foregroundColor(.white)
                                                .frame(width: 24, height: 24)
                                                .background(
                                                    Circle()
                                                        .fill(LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                                                )
                                            
                                            VStack(alignment: .leading, spacing: 2) {
                                                Text(destination.name)
                                                    .font(.subheadline)
                                                    .fontWeight(.medium)
                                                    .foregroundColor(.primary)
                                                
                                                Text(destination.address)
                                                    .font(.caption)
                                                    .foregroundColor(.secondary)
                                                    .lineLimit(1)
                                            }
                                            
                                            Spacer()
                                            
                                            Image(systemName: destination.type.iconName)
                                                .font(.system(size: 16))
                                                .foregroundColor(.secondary)
                                        }
                                        
                                        if index < trip.destinations.count - 1 {
                                            Divider()
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    // Participants List
                    if !trip.participants.isEmpty {
                        LiquidGlassCard {
                            VStack(alignment: .leading, spacing: 16) {
                                Text("Participants")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.primary)
                                
                                VStack(spacing: 12) {
                                    ForEach(trip.participants) { participant in
                                        HStack(spacing: 12) {
                                            // Profile Image Placeholder
                                            Circle()
                                                .fill(LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                                                .frame(width: 40, height: 40)
                                                .overlay(
                                                    Text(String(participant.user.username.prefix(1)).uppercased())
                                                        .font(.subheadline)
                                                        .fontWeight(.bold)
                                                        .foregroundColor(.white)
                                                )
                                            
                                            VStack(alignment: .leading, spacing: 2) {
                                                Text(participant.user.username)
                                                    .font(.subheadline)
                                                    .fontWeight(.medium)
                                                    .foregroundColor(.primary)
                                                
                                                if let vehicle = participant.user.vehicle {
                                                    Text("\(vehicle.make) \(vehicle.model)")
                                                        .font(.caption)
                                                        .foregroundColor(.secondary)
                                                }
                                            }
                                            
                                            Spacer()
                                            
                                            Text(participant.status.displayName)
                                                .font(.caption)
                                                .fontWeight(.medium)
                                                .foregroundColor(participant.status.textColor)
                                                .padding(.horizontal, 8)
                                                .padding(.vertical, 2)
                                                .background(
                                                    Capsule()
                                                        .fill(participant.status.backgroundColor)
                                                )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 100)
            }
        }
        .navigationTitle("Trip Details")
        .navigationBarTitleDisplayMode(.large)
    }
}

// MARK: - Extensions

extension DestinationType {
    var iconName: String {
        switch self {
        case .start: return "play.circle"
        case .waypoint: return "location"
        case .fuel: return "fuelpump"
        case .food: return "fork.knife"
        case .accommodation: return "bed.double"
        case .attraction: return "star"
        case .end: return "flag.checkered"
        }
    }
}

extension ParticipantStatus {
    var displayName: String {
        switch self {
        case .invited: return "Invited"
        case .joined: return "Joined"
        case .active: return "Active"
        case .inactive: return "Inactive"
        case .left: return "Left"
        }
    }
    
    var backgroundColor: Color {
        switch self {
        case .invited: return .orange.opacity(0.2)
        case .joined: return .blue.opacity(0.2)
        case .active: return .green.opacity(0.2)
        case .inactive: return .gray.opacity(0.2)
        case .left: return .red.opacity(0.2)
        }
    }
    
    var textColor: Color {
        switch self {
        case .invited: return .orange
        case .joined: return .blue
        case .active: return .green
        case .inactive: return .gray
        case .left: return .red
        }
    }
}

#Preview {
    NavigationView {
        TripHistoryView()
    }
}