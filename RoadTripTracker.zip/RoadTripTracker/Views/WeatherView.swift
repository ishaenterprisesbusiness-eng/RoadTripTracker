import SwiftUI
import CoreLocation

struct WeatherView: View {
    @StateObject private var weatherViewModel = WeatherViewModel()
    let coordinate: CLLocationCoordinate2D
    let locationName: String
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Current Weather Section
                if let currentWeather = weatherViewModel.currentWeather {
                    CurrentWeatherCard(weather: currentWeather, locationName: locationName)
                        .glassmorphicCard()
                }
                
                // Weather Alerts Section
                if !weatherViewModel.weatherAlerts.isEmpty {
                    WeatherAlertsSection(alerts: weatherViewModel.weatherAlerts)
                        .glassmorphicCard()
                }
                
                // Weather Recommendations Section
                if !weatherViewModel.weatherRecommendations.isEmpty {
                    WeatherRecommendationsSection(recommendations: weatherViewModel.weatherRecommendations)
                        .glassmorphicCard()
                }
                
                // Weather Stop Recommendations Section
                if !weatherViewModel.weatherStopRecommendations.isEmpty {
                    WeatherStopRecommendationsSection(recommendations: weatherViewModel.weatherStopRecommendations)
                        .glassmorphicCard()
                }
                
                // Weather Forecast Section
                if !weatherViewModel.weatherForecast.isEmpty {
                    WeatherForecastSection(forecast: weatherViewModel.weatherForecast)
                        .glassmorphicCard()
                }
            }
            .padding()
        }
        .navigationTitle("Weather")
        .navigationBarTitleDisplayMode(.large)
        .task {
            await loadWeatherData()
        }
        .refreshable {
            await refreshWeatherData()
        }
        .alert("Weather Error", isPresented: $weatherViewModel.showingError) {
            Button("OK") {
                weatherViewModel.showingError = false
            }
        } message: {
            Text(weatherViewModel.errorMessage ?? "Unknown error occurred")
        }
        .overlay {
            if weatherViewModel.isLoading {
                ProgressView("Loading weather...")
                    .glassmorphicCard()
            }
        }
    }
    
    private func loadWeatherData() async {
        await weatherViewModel.loadCurrentWeather(for: coordinate)
        await weatherViewModel.loadWeatherForecast(for: coordinate)
        await weatherViewModel.loadWeatherAlerts(for: coordinate)
    }
    
    private func refreshWeatherData() async {
        await weatherViewModel.refreshWeatherData(for: coordinate)
    }
}

// MARK: - Current Weather Card
struct CurrentWeatherCard: View {
    let weather: WeatherData
    let locationName: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                VStack(alignment: .leading) {
                    Text(locationName)
                        .font(.title2)
                        .fontWeight(.semibold)
                    
                    Text(weather.description.capitalized)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Image(systemName: WeatherViewModel().getWeatherIcon(for: weather.condition))
                    .font(.system(size: 40))
                    .foregroundColor(.primary)
            }
            
            HStack {
                VStack(alignment: .leading) {
                    Text("\(Int(weather.temperature))°C")
                        .font(.system(size: 48, weight: .thin))
                    
                    Text("Feels like \(Int(weather.feelsLike))°C")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 8) {
                    WeatherDetailRow(icon: "humidity", label: "Humidity", value: "\(Int(weather.humidity))%")
                    WeatherDetailRow(icon: "wind", label: "Wind", value: "\(Int(weather.windSpeed)) km/h")
                    WeatherDetailRow(icon: "eye", label: "Visibility", value: "\(weather.visibility, specifier: "%.1f") km")
                }
            }
        }
        .padding()
    }
}

// MARK: - Weather Detail Row
struct WeatherDetailRow: View {
    let icon: String
    let label: String
    let value: String
    
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundColor(.secondary)
                .frame(width: 16)
            
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)
            
            Text(value)
                .font(.caption)
                .fontWeight(.medium)
        }
    }
}

// MARK: - Weather Alerts Section
struct WeatherAlertsSection: View {
    let alerts: [WeatherAlert]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.orange)
                
                Text("Weather Alerts")
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            
            ForEach(alerts) { alert in
                WeatherAlertCard(alert: alert)
            }
        }
        .padding()
    }
}

// MARK: - Weather Alert Card
struct WeatherAlertCard: View {
    let alert: WeatherAlert
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(alert.title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Text(alert.severity.rawValue.capitalized)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(severityColor.opacity(0.2))
                    .foregroundColor(severityColor)
                    .clipShape(Capsule())
            }
            
            Text(alert.description)
                .font(.caption)
                .foregroundColor(.secondary)
            
            HStack {
                Text("From: \(alert.startTime, style: .time)")
                Text("To: \(alert.endTime, style: .time)")
            }
            .font(.caption2)
            .foregroundColor(.secondary)
        }
        .padding(12)
        .background(Color.secondary.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
    
    private var severityColor: Color {
        switch alert.severity {
        case .minor:
            return .blue
        case .moderate:
            return .yellow
        case .severe:
            return .orange
        case .extreme:
            return .red
        }
    }
}

// MARK: - Weather Recommendations Section
struct WeatherRecommendationsSection: View {
    let recommendations: [WeatherRecommendation]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "lightbulb.fill")
                    .foregroundColor(.yellow)
                
                Text("Recommendations")
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            
            ForEach(recommendations) { recommendation in
                WeatherRecommendationCard(recommendation: recommendation)
            }
        }
        .padding()
    }
}

// MARK: - Weather Recommendation Card
struct WeatherRecommendationCard: View {
    let recommendation: WeatherRecommendation
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: recommendationIcon)
                .font(.title3)
                .foregroundColor(priorityColor)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(recommendation.title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                Text(recommendation.message)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
        .padding(12)
        .background(Color.secondary.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
    
    private var recommendationIcon: String {
        switch recommendation.type {
        case .drivingCondition:
            return "car.fill"
        case .clothing:
            return "tshirt.fill"
        case .hydration:
            return "drop.fill"
        case .sunProtection:
            return "sun.max.fill"
        case .stopRecommendation:
            return "mappin.circle.fill"
        }
    }
    
    private var priorityColor: Color {
        switch recommendation.priority {
        case .low:
            return .green
        case .medium:
            return .orange
        case .high:
            return .red
        }
    }
}

// MARK: - Weather Forecast Section
struct WeatherForecastSection: View {
    let forecast: [WeatherData]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "calendar")
                    .foregroundColor(.blue)
                
                Text("5-Day Forecast")
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 16) {
                    ForEach(Array(forecast.enumerated()), id: \.offset) { index, weather in
                        WeatherForecastCard(weather: weather, isToday: index == 0)
                    }
                }
                .padding(.horizontal)
            }
        }
        .padding()
    }
}

// MARK: - Weather Forecast Card
struct WeatherForecastCard: View {
    let weather: WeatherData
    let isToday: Bool
    
    var body: some View {
        VStack(spacing: 8) {
            Text(isToday ? "Today" : dayOfWeek)
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.secondary)
            
            Image(systemName: WeatherViewModel().getWeatherIcon(for: weather.condition))
                .font(.title2)
                .foregroundColor(.primary)
            
            Text("\(Int(weather.temperature))°")
                .font(.subheadline)
                .fontWeight(.semibold)
            
            Text(weather.condition.rawValue.capitalized)
                .font(.caption2)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(width: 80)
        .padding(.vertical, 12)
        .background(Color.secondary.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
    
    private var dayOfWeek: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE"
        return formatter.string(from: weather.timestamp)
    }
}

// MARK: - Weather Stop Recommendations Section
struct WeatherStopRecommendationsSection: View {
    let recommendations: [WeatherStopRecommendation]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.orange)
                
                Text("Stop Recommendations")
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            
            ForEach(recommendations) { recommendation in
                WeatherStopRecommendationCard(recommendation: recommendation)
            }
        }
        .padding()
    }
}

// MARK: - Weather Stop Recommendation Card
struct WeatherStopRecommendationCard: View {
    let recommendation: WeatherStopRecommendation
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(recommendation.title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Text(recommendation.priority.rawValue.capitalized)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(priorityColor.opacity(0.2))
                    .foregroundColor(priorityColor)
                    .clipShape(Capsule())
            }
            
            Text(recommendation.description)
                .font(.caption)
                .foregroundColor(.secondary)
            
            HStack {
                Text("Recommended stops:")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                
                HStack(spacing: 4) {
                    ForEach(recommendation.recommendedStopTypes, id: \.self) { stopType in
                        Text(stopType.rawValue.capitalized)
                            .font(.caption2)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.blue.opacity(0.1))
                            .foregroundColor(.blue)
                            .clipShape(Capsule())
                    }
                }
            }
            
            if recommendation.estimatedWaitTime > 0 {
                HStack {
                    Image(systemName: "clock")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    
                    Text("Estimated wait: \(formatWaitTime(recommendation.estimatedWaitTime))")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(12)
        .background(priorityColor.opacity(0.05))
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(priorityColor.opacity(0.3), lineWidth: 1)
        )
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
    
    private var priorityColor: Color {
        switch recommendation.priority {
        case .low:
            return .green
        case .medium:
            return .orange
        case .high:
            return .red
        case .critical:
            return .purple
        }
    }
    
    private func formatWaitTime(_ timeInterval: TimeInterval) -> String {
        let hours = Int(timeInterval) / 3600
        let minutes = (Int(timeInterval) % 3600) / 60
        
        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }
}

// MARK: - Preview
struct WeatherView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            WeatherView(
                coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
                locationName: "San Francisco"
            )
        }
    }
}