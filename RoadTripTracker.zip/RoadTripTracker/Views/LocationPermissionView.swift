import SwiftUI
import CoreLocation

struct LocationPermissionView: View {
    @StateObject private var serviceContainer = ServiceContainer.shared
    @State private var isRequestingPermission = false
    @State private var showSettings = false
    @State private var permissionStatus: CLAuthorizationStatus = .notDetermined
    
    let onPermissionGranted: () -> Void
    let onPermissionDenied: () -> Void
    
    var body: some View {
        ZStack {
            // Liquid glass background
            LiquidGlassBackground()
            
            VStack(spacing: 32) {
                // Icon
                Image(systemName: "location.circle.fill")
                    .font(.system(size: 80))
                    .foregroundStyle(.blue.gradient)
                    .shadow(color: .blue.opacity(0.3), radius: 20, x: 0, y: 10)
                
                VStack(spacing: 16) {
                    Text("Location Access Required")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                    
                    Text("Road Trip Tracker needs access to your location to share your position with your group and provide real-time tracking.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                        .padding(.horizontal)
                }
                
                VStack(spacing: 16) {
                    // Features list
                    VStack(alignment: .leading, spacing: 12) {
                        PermissionFeatureRow(
                            icon: "location.fill",
                            title: "Real-time Tracking",
                            description: "Share your location with trip participants"
                        )
                        
                        PermissionFeatureRow(
                            icon: "bell.fill",
                            title: "Arrival Notifications",
                            description: "Get notified when approaching destinations"
                        )
                        
                        PermissionFeatureRow(
                            icon: "map.fill",
                            title: "Route Optimization",
                            description: "Calculate distances and optimize routes"
                        )
                    }
                    .padding(.horizontal)
                }
                
                Spacer()
                
                VStack(spacing: 16) {
                    // Primary action button
                    Button(action: requestLocationPermission) {
                        HStack {
                            if isRequestingPermission {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    .scaleEffect(0.8)
                            } else {
                                Image(systemName: "location.fill")
                            }
                            
                            Text(buttonTitle)
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(
                            LiquidGlassButton(isPressed: false)
                        )
                        .foregroundColor(.white)
                    }
                    .disabled(isRequestingPermission)
                    
                    // Secondary action for denied permission
                    if permissionStatus == .denied || permissionStatus == .restricted {
                        Button("Open Settings") {
                            showSettings = true
                        }
                        .font(.body)
                        .foregroundColor(.blue)
                    }
                    
                    // Skip option (if applicable)
                    Button("Skip for Now") {
                        onPermissionDenied()
                    }
                    .font(.body)
                    .foregroundColor(.secondary)
                }
                .padding(.horizontal, 32)
            }
            .padding(.vertical, 32)
        }
        .onAppear {
            permissionStatus = serviceContainer.locationService.authorizationStatus
        }
        .onReceive(serviceContainer.locationService.authorizationUpdates) { status in
            permissionStatus = status
            handlePermissionStatusChange(status)
        }
        .sheet(isPresented: $showSettings) {
            SettingsRedirectView()
        }
    }
    
    private var buttonTitle: String {
        switch permissionStatus {
        case .notDetermined:
            return isRequestingPermission ? "Requesting..." : "Allow Location Access"
        case .denied, .restricted:
            return "Permission Denied"
        case .authorizedWhenInUse, .authorizedAlways:
            return "Permission Granted"
        @unknown default:
            return "Allow Location Access"
        }
    }
    
    private func requestLocationPermission() {
        guard !isRequestingPermission else { return }
        
        isRequestingPermission = true
        
        Task {
            do {
                try await serviceContainer.locationService.requestLocationPermission()
                await MainActor.run {
                    isRequestingPermission = false
                }
            } catch {
                await MainActor.run {
                    isRequestingPermission = false
                }
            }
        }
    }
    
    private func handlePermissionStatusChange(_ status: CLAuthorizationStatus) {
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
            onPermissionGranted()
        case .denied, .restricted:
            // Permission was denied, but don't automatically call onPermissionDenied
            // Let user decide to skip or open settings
            break
        default:
            break
        }
    }
}

// MARK: - Permission Feature Row
struct PermissionFeatureRow: View {
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(.blue)
                .frame(width: 24, height: 24)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                    .fontWeight(.medium)
                
                Text(description)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
    }
}

// MARK: - Settings Redirect View
struct SettingsRedirectView: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                Image(systemName: "gear")
                    .font(.system(size: 60))
                    .foregroundColor(.blue)
                
                VStack(spacing: 16) {
                    Text("Open Settings")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("To enable location access, please go to Settings > Privacy & Security > Location Services and enable location access for Road Trip Tracker.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                }
                
                Button("Open Settings") {
                    if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                        UIApplication.shared.open(settingsURL)
                    }
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Location Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

#Preview {
    LocationPermissionView(
        onPermissionGranted: {},
        onPermissionDenied: {}
    )
}