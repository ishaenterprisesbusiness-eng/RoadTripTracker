import SwiftUI
import Combine

// MARK: - Budget Settings View
struct BudgetSettingsView: View {
    @ObservedObject var viewModel: BudgetViewModel
    let trip: Trip
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            ZStack {
                // Glassmorphic background
                GlasmorphicDesignSystem.backgroundGradient
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        headerSection
                        totalBudgetSection
                        perPersonBudgetSection
                        budgetTipsSection
                        actionButtons
                    }
                    .padding()
                }
            }
            .navigationTitle("Budget Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.clearError()
                }
            } message: {
                Text(viewModel.errorMessage ?? "")
            }
        }
    }
    
    // MARK: - Header Section
    private var headerSection: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(spacing: 12) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 40))
                    .foregroundColor(.blue)
                
                Text("Trip Budget Setup")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Set spending limits for \(trip.name)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
        }
    }
    
    // MARK: - Total Budget Section
    private var totalBudgetSection: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                Label("Total Trip Budget", systemImage: "dollarsign.circle.fill")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Text("Set the maximum amount you want to spend on this entire trip.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                HStack {
                    Text("$")
                        .font(.title2)
                        .foregroundColor(.secondary)
                    
                    TextField("0.00", text: $viewModel.totalBudget)
                        .keyboardType(.decimalPad)
                        .font(.title2)
                        .fontWeight(.medium)
                        .textFieldStyle(PlainTextFieldStyle())
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(.ultraThinMaterial)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(.white.opacity(0.2), lineWidth: 1)
                        )
                )
                
                // Quick budget suggestions
                budgetSuggestions
            }
            .padding()
        }
    }
    
    private var budgetSuggestions: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Quick Suggestions")
                .font(.caption)
                .foregroundColor(.secondary)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(suggestedBudgets, id: \.self) { amount in
                        Button("$\(Int(amount))") {
                            viewModel.totalBudget = String(format: "%.0f", amount)
                        }
                        .font(.caption)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(
                            Capsule()
                                .fill(.ultraThinMaterial)
                                .overlay(
                                    Capsule()
                                        .stroke(.white.opacity(0.2), lineWidth: 1)
                                )
                        )
                    }
                }
                .padding(.horizontal)
            }
        }
    }
    
    // MARK: - Per Person Budget Section
    private var perPersonBudgetSection: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Label("Per Person Budget", systemImage: "person.circle.fill")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Text("Optional")
                        .font(.caption)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(
                            Capsule()
                                .fill(.orange.opacity(0.2))
                        )
                        .foregroundColor(.orange)
                }
                
                Text("Set individual spending limits for each participant.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                HStack {
                    Text("$")
                        .font(.title2)
                        .foregroundColor(.secondary)
                    
                    TextField("Optional", text: $viewModel.perPersonBudget)
                        .keyboardType(.decimalPad)
                        .font(.title2)
                        .fontWeight(.medium)
                        .textFieldStyle(PlainTextFieldStyle())
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(.ultraThinMaterial)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(.white.opacity(0.2), lineWidth: 1)
                        )
                )
                
                if !viewModel.totalBudget.isEmpty, let totalBudget = Double(viewModel.totalBudget) {
                    let participantCount = max(1, trip.participants.count)
                    let suggestedPerPerson = totalBudget / Double(participantCount)
                    
                    Button("Suggest: $\(String(format: "%.0f", suggestedPerPerson)) per person") {
                        viewModel.perPersonBudget = String(format: "%.0f", suggestedPerPerson)
                    }
                    .font(.caption)
                    .foregroundColor(.blue)
                }
            }
            .padding()
        }
    }
    
    // MARK: - Budget Tips Section
    private var budgetTipsSection: some View {
        GlasmorphicDesignSystem.createGlassCard {
            VStack(alignment: .leading, spacing: 12) {
                Label("Budget Tips", systemImage: "lightbulb.fill")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                VStack(alignment: .leading, spacing: 8) {
                    tipRow(icon: "fuelpump.fill", text: "Factor in fuel costs based on distance and vehicle efficiency", color: .blue)
                    tipRow(icon: "fork.knife", text: "Budget for meals - restaurants vs. groceries can vary significantly", color: .orange)
                    tipRow(icon: "bed.double.fill", text: "Include accommodation costs if staying overnight", color: .purple)
                    tipRow(icon: "exclamationmark.triangle.fill", text: "Add 10-20% buffer for unexpected expenses", color: .red)
                }
            }
            .padding()
        }
    }
    
    private func tipRow(icon: String, text: String, color: Color) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(color)
                .frame(width: 16)
            
            Text(text)
                .font(.caption)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
    
    // MARK: - Action Buttons
    private var actionButtons: some View {
        VStack(spacing: 12) {
            Button {
                viewModel.createBudget(for: trip.id)
            } label: {
                HStack {
                    if viewModel.isLoading {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(0.8)
                    } else {
                        Image(systemName: "checkmark.circle.fill")
                    }
                    
                    Text(viewModel.isLoading ? "Setting up..." : "Set Budget")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(isFormValid ? .blue : .gray)
                )
                .foregroundColor(.white)
            }
            .disabled(!isFormValid || viewModel.isLoading)
            
            Button("Clear All") {
                viewModel.totalBudget = ""
                viewModel.perPersonBudget = ""
            }
            .font(.subheadline)
            .foregroundColor(.secondary)
        }
    }
    
    // MARK: - Computed Properties
    private var isFormValid: Bool {
        guard let totalBudget = Double(viewModel.totalBudget), totalBudget > 0 else {
            return false
        }
        
        if !viewModel.perPersonBudget.isEmpty {
            guard let perPersonBudget = Double(viewModel.perPersonBudget), perPersonBudget > 0 else {
                return false
            }
        }
        
        return true
    }
    
    private var suggestedBudgets: [Double] {
        let tripDuration = estimatedTripDuration
        let participantCount = max(1, trip.participants.count)
        
        // Base suggestions on trip duration and participant count
        let baseAmounts = [500, 1000, 1500, 2000, 3000, 5000]
        return baseAmounts.map { $0 * Double(participantCount) }
    }
    
    private var estimatedTripDuration: Int {
        // Simple estimation based on number of destinations
        // In a real app, this could be more sophisticated
        return max(1, trip.destinations.count)
    }
}

// MARK: - Preview
struct BudgetSettingsView_Previews: PreviewProvider {
    static var previews: some View {
        let mockTrip = Trip(
            name: "Sample Trip",
            code: "ABC123",
            createdBy: UUID(),
            participants: [
                Participant(
                    userId: UUID(),
                    user: User(
                        id: UUID(),
                        username: "User 1",
                        email: "user1@example.com",
                        city: "City 1",
                        dateOfBirth: Date(),
                        age: 25
                    )
                ),
                Participant(
                    userId: UUID(),
                    user: User(
                        id: UUID(),
                        username: "User 2",
                        email: "user2@example.com",
                        city: "City 2",
                        dateOfBirth: Date(),
                        age: 30
                    )
                )
            ],
            destinations: []
        )
        
        BudgetSettingsView(
            viewModel: BudgetViewModel(
                budgetService: MockBudgetService(),
                locationService: MockLocationService()
            ),
            trip: mockTrip
        )
    }
}