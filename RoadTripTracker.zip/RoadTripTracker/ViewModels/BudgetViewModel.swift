import Foundation
import Combine
import CoreLocation

// MARK: - Budget View Model
@MainActor
class BudgetViewModel: ObservableObject {
    
    // MARK: - Published Properties
    @Published var budgetSummary: BudgetSummary?
    @Published var expenses: [Expense] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showingAddExpense = false
    @Published var showingBudgetSettings = false
    
    // Form properties for adding expenses
    @Published var newExpenseAmount: String = ""
    @Published var newExpenseCategory: ExpenseCategory = .fuel
    @Published var newExpenseDescription: String = ""
    @Published var selectedParticipantId: UUID?
    
    // Budget settings
    @Published var totalBudget: String = ""
    @Published var perPersonBudget: String = ""
    
    // MARK: - Private Properties
    private let budgetService: BudgetServiceProtocol
    private let locationService: LocationServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    private var currentTripId: UUID?
    
    // MARK: - Computed Properties
    var budgetUtilizationPercentage: Double {
        guard let summary = budgetSummary, summary.totalBudget > 0 else { return 0 }
        return summary.totalSpent / summary.totalBudget
    }
    
    var budgetStatusColor: String {
        let percentage = budgetUtilizationPercentage
        if percentage >= 0.9 { return "red" }
        else if percentage >= 0.8 { return "orange" }
        else if percentage >= 0.6 { return "yellow" }
        else { return "green" }
    }
    
    var isAddExpenseFormValid: Bool {
        guard let amount = Double(newExpenseAmount), amount > 0 else { return false }
        return !newExpenseDescription.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    // MARK: - Initialization
    init(budgetService: BudgetServiceProtocol, locationService: LocationServiceProtocol) {
        self.budgetService = budgetService
        self.locationService = locationService
        setupBudgetUpdates()
    }
    
    // MARK: - Public Methods
    func loadBudgetSummary(for tripId: UUID) {
        currentTripId = tripId
        isLoading = true
        errorMessage = nil
        
        Task {
            do {
                let summary = try await budgetService.getBudgetSummary(for: tripId)
                await MainActor.run {
                    self.budgetSummary = summary
                    self.totalBudget = String(format: "%.2f", summary.totalBudget)
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
    
    func createBudget(for tripId: UUID) {
        guard let totalBudgetValue = Double(totalBudget), totalBudgetValue > 0 else {
            errorMessage = "Please enter a valid total budget"
            return
        }
        
        let perPersonBudgetValue = Double(perPersonBudget)
        isLoading = true
        errorMessage = nil
        
        Task {
            do {
                let budget = try await budgetService.createBudget(
                    for: tripId,
                    totalBudget: totalBudgetValue,
                    perPersonBudget: perPersonBudgetValue
                )
                
                await MainActor.run {
                    self.showingBudgetSettings = false
                    self.isLoading = false
                }
                
                // Reload summary
                loadBudgetSummary(for: tripId)
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
    
    func addExpense(for tripId: UUID, participantId: UUID) {
        guard let amount = Double(newExpenseAmount), amount > 0 else {
            errorMessage = "Please enter a valid amount"
            return
        }
        
        guard !newExpenseDescription.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            errorMessage = "Please enter a description"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        Task {
            do {
                let currentLocation = try? await locationService.getCurrentLocation()
                
                let expense = Expense(
                    amount: amount,
                    category: newExpenseCategory,
                    description: newExpenseDescription.trimmingCharacters(in: .whitespacesAndNewlines),
                    participantId: participantId,
                    location: currentLocation?.coordinate
                )
                
                try await budgetService.addExpense(expense, to: tripId)
                
                await MainActor.run {
                    self.clearExpenseForm()
                    self.showingAddExpense = false
                    self.isLoading = false
                }
                
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
    
    func updateExpense(_ expense: Expense) {
        isLoading = true
        errorMessage = nil
        
        Task {
            do {
                try await budgetService.updateExpense(expense)
                await MainActor.run {
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
    
    func deleteExpense(_ expenseId: UUID, from tripId: UUID) {
        isLoading = true
        errorMessage = nil
        
        Task {
            do {
                try await budgetService.deleteExpense(expenseId, from: tripId)
                await MainActor.run {
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
    
    func clearExpenseForm() {
        newExpenseAmount = ""
        newExpenseCategory = .fuel
        newExpenseDescription = ""
        selectedParticipantId = nil
    }
    
    func clearError() {
        errorMessage = nil
    }
    
    // MARK: - Helper Methods
    func formattedAmount(_ amount: Double) -> String {
        return String(format: "%.2f", amount)
    }
    
    func categoryIcon(for category: ExpenseCategory) -> String {
        switch category {
        case .fuel: return "fuelpump.fill"
        case .food: return "fork.knife"
        case .accommodation: return "bed.double.fill"
        case .activities: return "figure.hiking"
        case .other: return "ellipsis.circle.fill"
        }
    }
    
    func categoryColor(for category: ExpenseCategory) -> String {
        switch category {
        case .fuel: return "blue"
        case .food: return "orange"
        case .accommodation: return "purple"
        case .activities: return "green"
        case .other: return "gray"
        }
    }
    
    // MARK: - Private Methods
    private func setupBudgetUpdates() {
        budgetService.budgetUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] update in
                self?.handleBudgetUpdate(update)
            }
            .store(in: &cancellables)
    }
    
    private func handleBudgetUpdate(_ update: BudgetUpdate) {
        budgetSummary = update.summary
        
        // Show success message for expense operations
        switch update.updateType {
        case .expenseAdded:
            // Could show a toast or temporary success message
            break
        case .expenseUpdated:
            // Could show update confirmation
            break
        case .expenseDeleted:
            // Could show deletion confirmation
            break
        case .budgetUpdated:
            // Budget settings updated
            break
        }
    }
}

// MARK: - Budget Summary Extensions
extension BudgetSummary {
    var spentPercentage: Double {
        guard totalBudget > 0 else { return 0 }
        return totalSpent / totalBudget
    }
    
    var isOverBudget: Bool {
        return totalSpent > totalBudget
    }
    
    var statusMessage: String {
        if isOverBudget {
            return "Over budget by $\(String(format: "%.2f", totalSpent - totalBudget))"
        } else if spentPercentage >= 0.9 {
            return "Approaching budget limit"
        } else if spentPercentage >= 0.8 {
            return "80% of budget used"
        } else {
            return "Within budget"
        }
    }
}