import Foundation
import Combine
import CoreLocation
import MapKit

@MainActor
class TripDashboardViewModel: ObservableObject {
    // MARK: - Published Properties
    @Published var activeTrip: Trip?
    @Published var timeToNextDestination: TimeInterval = 0
    @Published var timeToFinalDestination: TimeInterval = 0
    @Published var totalKilometersRemaining: Double = 0
    @Published var activeVehicleCount: Int = 0
    @Published var nextDestination: Destination?
    @Published var finalDestination: Destination?
    @Published var currentUserLocation: CLLocation?
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var showingError: Bool = false
    
    // Real-time metrics
    @Published var averageSpeed: Double = 0
    @Published var estimatedArrivalNext: Date?
    @Published var estimatedArrivalFinal: Date?
    @Published var distanceToNext: Double = 0
    @Published var distanceToFinal: Double = 0
    @Published var participantStatuses: [UUID: ParticipantDashboardStatus] = [:]
    
    // MARK: - Private Properties
    private let tripService: TripServiceProtocol
    private let locationManager: LocationServiceProtocol
    private let distanceCalculationService: DistanceCalculationService
    private let mapService: MapServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    private var updateTimer: Timer?
    
    // MARK: - Initialization
    init(
        tripService: TripServiceProtocol? = nil,
        locationManager: LocationServiceProtocol? = nil,
        distanceCalculationService: DistanceCalculationService? = nil,
        mapService: MapServiceProtocol? = nil
    ) {
        self.tripService = tripService ?? ServiceContainer.shared.tripService
        self.locationManager = locationManager ?? ServiceContainer.shared.locationManager
        self.distanceCalculationService = distanceCalculationService ?? ServiceContainer.shared.distanceCalculationService
        self.mapService = mapService ?? ServiceContainer.shared.mapService
        
        setupSubscriptions()
        startRealTimeUpdates()
    }
    
    deinit {
        updateTimer?.invalidate()
    }
    
    // MARK: - Setup
    
    private func setupSubscriptions() {
        // Subscribe to trip updates
        tripService.tripUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] trip in
                self?.activeTrip = trip
                if let trip = trip {
                    Task {
                        await self?.updateTripMetrics(for: trip)
                    }
                }
            }
            .store(in: &cancellables)
        
        // Subscribe to location updates
        locationManager.locationUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] location in
                self?.currentUserLocation = location
                if let trip = self?.activeTrip {
                    Task {
                        await self?.updateTripMetrics(for: trip)
                    }
                }
            }
            .store(in: &cancellables)
        
        // Subscribe to distance calculation updates
        distanceCalculationService.$distanceCalculations
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                if let trip = self?.activeTrip {
                    Task {
                        await self?.updateDistanceMetrics(for: trip)
                    }
                }
            }
            .store(in: &cancellables)
    }
    
    private func startRealTimeUpdates() {
        updateTimer = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { [weak self] _ in
            Task { @MainActor in
                if let trip = self?.activeTrip {
                    await self?.updateTripMetrics(for: trip)
                }
            }
        }
    }
    
    // MARK: - Public Methods
    
    func loadDashboard() async {
        isLoading = true
        
        do {
            // Get active trip
            activeTrip = tripService.activeTrip
            
            if let trip = activeTrip {
                await updateTripMetrics(for: trip)
            }
        } catch {
            handleError(error)
        }
        
        isLoading = false
    }
    
    func refreshMetrics() async {
        guard let trip = activeTrip else { return }
        await updateTripMetrics(for: trip)
    }
    
    // MARK: - Private Methods
    
    private func updateTripMetrics(for trip: Trip) async {
        // Update basic trip information
        updateBasicMetrics(for: trip)
        
        // Update distance and time calculations
        await updateDistanceMetrics(for: trip)
        
        // Update participant statuses
        updateParticipantStatuses(for: trip)
        
        // Calculate estimated arrival times
        calculateEstimatedArrivals(for: trip)
    }
    
    private func updateBasicMetrics(for trip: Trip) {
        // Set next and final destinations
        if trip.currentDestinationIndex < trip.destinations.count {
            nextDestination = trip.destinations[trip.currentDestinationIndex]
        } else {
            nextDestination = nil
        }
        
        finalDestination = trip.destinations.last
        
        // Count active vehicles (participants with location sharing enabled)
        activeVehicleCount = trip.participants.filter { participant in
            participant.isLocationSharingEnabled && 
            participant.status == .active &&
            participant.currentLocation != nil
        }.count
    }
    
    private func updateDistanceMetrics(for trip: Trip) async {
        guard let userLocation = currentUserLocation else { return }
        
        // Calculate distance to next destination
        if let next = nextDestination {
            distanceToNext = calculateStraightLineDistance(
                from: userLocation.coordinate,
                to: next.coordinate
            ) / 1000 // Convert to kilometers
            
            // Calculate driving distance and time
            if let drivingDistance = await calculateDrivingDistance(
                from: userLocation.coordinate,
                to: next.coordinate
            ) {
                distanceToNext = drivingDistance / 1000
                timeToNextDestination = calculateTravelTime(distance: drivingDistance)
            }
        }
        
        // Calculate distance to final destination
        if let final = finalDestination, final.id != nextDestination?.id {
            distanceToFinal = calculateStraightLineDistance(
                from: userLocation.coordinate,
                to: final.coordinate
            ) / 1000 // Convert to kilometers
            
            // Calculate driving distance and time
            if let drivingDistance = await calculateDrivingDistance(
                from: userLocation.coordinate,
                to: final.coordinate
            ) {
                distanceToFinal = drivingDistance / 1000
                timeToFinalDestination = calculateTravelTime(distance: drivingDistance)
            }
        } else {
            distanceToFinal = distanceToNext
            timeToFinalDestination = timeToNextDestination
        }
        
        // Calculate total kilometers remaining (sum of all remaining segments)
        totalKilometersRemaining = await calculateTotalRemainingDistance(for: trip)
    }
    
    private func updateParticipantStatuses(for trip: Trip) {
        var statuses: [UUID: ParticipantDashboardStatus] = [:]
        
        for participant in trip.participants {
            let status = ParticipantDashboardStatus(
                participant: participant,
                distanceToNext: getParticipantDistanceToNext(participant, trip: trip),
                distanceToFinal: getParticipantDistanceToFinal(participant, trip: trip),
                isActive: participant.isLocationSharingEnabled && participant.currentLocation != nil,
                lastUpdate: participant.lastLocationUpdate ?? Date()
            )
            statuses[participant.id] = status
        }
        
        participantStatuses = statuses
    }
    
    private func calculateEstimatedArrivals(for trip: Trip) {
        let now = Date()
        
        if timeToNextDestination > 0 {
            estimatedArrivalNext = now.addingTimeInterval(timeToNextDestination)
        }
        
        if timeToFinalDestination > 0 {
            estimatedArrivalFinal = now.addingTimeInterval(timeToFinalDestination)
        }
    }
    
    private func calculateStraightLineDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        return fromLocation.distance(from: toLocation)
    }
    
    private func calculateDrivingDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) async -> CLLocationDistance? {
        do {
            let route = try await mapService.calculateRoute(from: from, to: to, waypoints: [])
            return route.distance
        } catch {
            return nil
        }
    }
    
    private func calculateTravelTime(distance: CLLocationDistance) -> TimeInterval {
        // Assume average speed of 60 km/h
        let averageSpeedKmH: Double = 60
        let distanceKm = distance / 1000
        let timeHours = distanceKm / averageSpeedKmH
        return timeHours * 3600 // Convert to seconds
    }
    
    private func calculateTotalRemainingDistance(for trip: Trip) async -> Double {
        guard let userLocation = currentUserLocation,
              trip.currentDestinationIndex < trip.destinations.count else {
            return 0
        }
        
        var totalDistance: Double = 0
        let remainingDestinations = Array(trip.destinations[trip.currentDestinationIndex...])
        
        // Distance from current location to next destination
        if let firstDestination = remainingDestinations.first {
            if let drivingDistance = await calculateDrivingDistance(
                from: userLocation.coordinate,
                to: firstDestination.coordinate
            ) {
                totalDistance += drivingDistance / 1000
            }
        }
        
        // Distance between remaining destinations
        for i in 0..<(remainingDestinations.count - 1) {
            let from = remainingDestinations[i].coordinate
            let to = remainingDestinations[i + 1].coordinate
            
            if let segmentDistance = await calculateDrivingDistance(from: from, to: to) {
                totalDistance += segmentDistance / 1000
            }
        }
        
        return totalDistance
    }
    
    private func getParticipantDistanceToNext(_ participant: Participant, trip: Trip) -> Double {
        guard let nextDest = nextDestination,
              let participantLocation = participant.currentLocation else {
            return 0
        }
        
        return calculateStraightLineDistance(
            from: participantLocation,
            to: nextDest.coordinate
        ) / 1000
    }
    
    private func getParticipantDistanceToFinal(_ participant: Participant, trip: Trip) -> Double {
        guard let finalDest = finalDestination,
              let participantLocation = participant.currentLocation else {
            return 0
        }
        
        return calculateStraightLineDistance(
            from: participantLocation,
            to: finalDest.coordinate
        ) / 1000
    }
    
    private func handleError(_ error: Error) {
        errorMessage = error.localizedDescription
        showingError = true
    }
    
    // MARK: - Computed Properties
    
    var formattedTimeToNext: String {
        formatTimeInterval(timeToNextDestination)
    }
    
    var formattedTimeToFinal: String {
        formatTimeInterval(timeToFinalDestination)
    }
    
    var formattedDistanceToNext: String {
        String(format: "%.1f km", distanceToNext)
    }
    
    var formattedDistanceToFinal: String {
        String(format: "%.1f km", distanceToFinal)
    }
    
    var formattedTotalRemaining: String {
        String(format: "%.1f km", totalKilometersRemaining)
    }
    
    private func formatTimeInterval(_ interval: TimeInterval) -> String {
        let hours = Int(interval) / 3600
        let minutes = Int(interval) % 3600 / 60
        
        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }
}

// MARK: - Participant Dashboard Status
struct ParticipantDashboardStatus {
    let participant: Participant
    let distanceToNext: Double
    let distanceToFinal: Double
    let isActive: Bool
    let lastUpdate: Date
    
    var statusColor: String {
        if !isActive {
            return "gray"
        }
        
        let timeSinceUpdate = Date().timeIntervalSince(lastUpdate)
        if timeSinceUpdate > 300 { // 5 minutes
            return "orange"
        } else if timeSinceUpdate > 600 { // 10 minutes
            return "red"
        } else {
            return "green"
        }
    }
    
    var statusText: String {
        if !isActive {
            return "Offline"
        }
        
        let timeSinceUpdate = Date().timeIntervalSince(lastUpdate)
        if timeSinceUpdate > 600 {
            return "Lost Connection"
        } else if timeSinceUpdate > 300 {
            return "Poor Connection"
        } else {
            return "Active"
        }
    }
}