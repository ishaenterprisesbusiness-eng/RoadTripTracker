import Foundation
import Combine
import CoreLocation

@MainActor
class ProfileViewModel: ObservableObject {
    @Published var recentTrips: [Trip] = []
    @Published var accountStats = AccountStatistics()
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private let tripService: TripServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    
    init(tripService: TripServiceProtocol = ServiceContainer.shared.tripService) {
        self.tripService = tripService
    }
    
    // MARK: - Data Loading
    
    func loadTripHistory() async {
        isLoading = true
        errorMessage = nil
        
        do {
            // Get current user ID (this should come from AuthenticationManager)
            let currentUserId = getCurrentUserId()
            let trips = try await tripService.getTripHistory(for: currentUserId)
            
            // Sort trips by creation date (most recent first)
            recentTrips = trips.sorted { $0.createdAt > $1.createdAt }
            
        } catch {
            errorMessage = "Failed to load trip history: \(error.localizedDescription)"
        }
        
        isLoading = false
    }
    
    func loadAccountStatistics() async {
        do {
            let currentUserId = getCurrentUserId()
            let trips = try await tripService.getTripHistory(for: currentUserId)
            
            let completedTrips = trips.filter { $0.status == .completed }
            let activeTrips = trips.filter { $0.status == .active || $0.status == .planning }
            
            // Calculate total kilometers from completed trips
            let totalKilometers = completedTrips.reduce(0.0) { total, trip in
                return total + calculateTripDistance(trip)
            }
            
            accountStats = AccountStatistics(
                tripsCompleted: completedTrips.count,
                totalKilometers: totalKilometers,
                activeTrips: activeTrips.count,
                totalTrips: trips.count
            )
            
        } catch {
            errorMessage = "Failed to load account statistics: \(error.localizedDescription)"
        }
    }
    
    func refreshData() async {
        await loadTripHistory()
        await loadAccountStatistics()
    }
    
    // MARK: - Private Methods
    
    private func getCurrentUserId() -> UUID {
        // This should be implemented to get the current user ID from AuthenticationManager
        // For now, return a placeholder UUID
        return UUID()
    }
    
    private func calculateTripDistance(_ trip: Trip) -> Double {
        // Calculate total distance for all destinations in the trip
        guard trip.destinations.count > 1 else { return 0.0 }
        
        var totalDistance: Double = 0.0
        
        for i in 0..<(trip.destinations.count - 1) {
            let from = trip.destinations[i].coordinate
            let to = trip.destinations[i + 1].coordinate
            
            let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
            let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
            
            totalDistance += fromLocation.distance(from: toLocation) / 1000.0 // Convert to kilometers
        }
        
        return totalDistance
    }
}

// MARK: - Account Statistics Model

struct AccountStatistics {
    var tripsCompleted: Int = 0
    var totalKilometers: Double = 0.0
    var activeTrips: Int = 0
    var totalTrips: Int = 0
    
    var averageDistancePerTrip: Double {
        guard tripsCompleted > 0 else { return 0.0 }
        return totalKilometers / Double(tripsCompleted)
    }
}