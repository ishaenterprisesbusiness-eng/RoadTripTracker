import Foundation
import SwiftUI
import Combine
import CoreLocation

// MARK: - Driving Statistics View Model
@MainActor
class DrivingStatisticsViewModel: ObservableObject {
    
    // MARK: - Published Properties
    @Published var currentStatistics: DrivingStatistics?
    @Published var isTracking: Bool = false
    @Published var currentSpeed: Double = 0.0
    @Published var speedLimit: Double = 50.0
    @Published var isSpeedingDetected: Bool = false
    @Published var currentRestPeriod: RestPeriod?
    @Published var shouldSuggestBreak: Bool = false
    @Published var performanceSummary: DrivingPerformanceSummary?
    @Published var tripComparisons: [TripComparisonData] = []
    @Published var performanceReport: PerformanceReport?
    @Published var breakSuggestion: BreakSuggestion?
    @Published var speedingAlert: SpeedingIncident?
    
    // UI State
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var showingBreakSuggestion: Bool = false
    @Published var showingSpeedingAlert: Bool = false
    @Published var showingPerformanceReport: Bool = false
    @Published var selectedTripForComparison: UUID?
    
    // MARK: - Private Properties
    private let drivingStatisticsService: DrivingStatisticsServiceProtocol
    private let authenticationManager: AuthenticationManagerProtocol
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Computed Properties
    var currentSpeedKmh: Double {
        return currentSpeed * 3.6
    }
    
    var speedLimitKmh: Double {
        return speedLimit * 3.6
    }
    
    var speedExcessKmh: Double {
        return max(0, currentSpeedKmh - speedLimitKmh)
    }
    
    var isSpeedingWarning: Bool {
        return speedExcessKmh > 5 && speedExcessKmh <= 15
    }
    
    var isSpeedingDanger: Bool {
        return speedExcessKmh > 15
    }
    
    var currentTripDuration: TimeInterval {
        guard let statistics = currentStatistics else { return 0 }
        return Date().timeIntervalSince(statistics.startTime)
    }
    
    var currentTripDurationFormatted: String {
        return formatDuration(currentTripDuration)
    }
    
    var totalRestTimeFormatted: String {
        guard let statistics = currentStatistics else { return "0m" }
        return formatDuration(statistics.totalRestTime)
    }
    
    var averageSpeedFormatted: String {
        guard let statistics = currentStatistics else { return "0 km/h" }
        return String(format: "%.0f km/h", statistics.averageSpeedKmh)
    }
    
    var totalDistanceFormatted: String {
        guard let statistics = currentStatistics else { return "0 km" }
        return String(format: "%.1f km", statistics.totalDistanceKm)
    }
    
    var safetyScoreFormatted: String {
        guard let statistics = currentStatistics else { return "100" }
        let score = drivingStatisticsService.calculateSafetyScore(for: statistics)
        return String(format: "%.0f", score)
    }
    
    var safetyRating: SafetyRating {
        guard let statistics = currentStatistics else { return .excellent }
        let score = drivingStatisticsService.calculateSafetyScore(for: statistics)
        return DrivingPerformanceSummary(participantId: UUID(), safetyScore: score).safetyRating
    }
    
    // MARK: - Initialization
    init(drivingStatisticsService: DrivingStatisticsServiceProtocol, authenticationManager: AuthenticationManagerProtocol) {
        self.drivingStatisticsService = drivingStatisticsService
        self.authenticationManager = authenticationManager
        setupSubscriptions()
    }
    
    // MARK: - Setup
    private func setupSubscriptions() {
        // Subscribe to service updates
        drivingStatisticsService.statisticsUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] statistics in
                self?.currentStatistics = statistics
            }
            .store(in: &cancellables)
        
        drivingStatisticsService.speedingAlerts
            .receive(on: DispatchQueue.main)
            .sink { [weak self] incident in
                self?.speedingAlert = incident
                self?.showingSpeedingAlert = true
            }
            .store(in: &cancellables)
        
        drivingStatisticsService.breakSuggestions
            .receive(on: DispatchQueue.main)
            .sink { [weak self] suggestion in
                self?.breakSuggestion = suggestion
                self?.showingBreakSuggestion = true
            }
            .store(in: &cancellables)
        
        // Mirror service published properties
        drivingStatisticsService.objectWillChange
            .sink { [weak self] in
                DispatchQueue.main.async {
                    self?.isTracking = self?.drivingStatisticsService.isTracking ?? false
                    self?.currentSpeed = self?.drivingStatisticsService.currentSpeed ?? 0.0
                    self?.speedLimit = self?.drivingStatisticsService.speedLimit ?? 50.0
                    self?.isSpeedingDetected = self?.drivingStatisticsService.isSpeedingDetected ?? false
                    self?.currentRestPeriod = self?.drivingStatisticsService.currentRestPeriod
                    self?.shouldSuggestBreak = self?.drivingStatisticsService.shouldSuggestBreak ?? false
                }
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Tracking Management
    func startTracking(for tripId: UUID) async {
        guard let currentUser = authenticationManager.currentUser else {
            errorMessage = "User not authenticated"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            try await drivingStatisticsService.startTracking(for: tripId, participantId: currentUser.id)
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func stopTracking() async {
        isLoading = true
        errorMessage = nil
        
        do {
            try await drivingStatisticsService.stopTracking()
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func pauseTracking() async {
        do {
            try await drivingStatisticsService.pauseTracking()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func resumeTracking() async {
        do {
            try await drivingStatisticsService.resumeTracking()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    // MARK: - Rest Period Management
    func startManualBreak(type: RestType, location: CLLocationCoordinate2D) async {
        do {
            try await drivingStatisticsService.startManualRestPeriod(type: type, location: location)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func endCurrentBreak() async {
        do {
            try await drivingStatisticsService.endCurrentRestPeriod()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func dismissBreakSuggestion() async {
        await drivingStatisticsService.dismissBreakSuggestion()
        showingBreakSuggestion = false
        breakSuggestion = nil
    }
    
    func acceptBreakSuggestion() async {
        guard let suggestion = breakSuggestion else { return }
        
        // Start automatic break
        if let location = currentStatistics?.restPeriods.last?.location {
            await startManualBreak(type: .automatic, location: location)
        }
        
        await dismissBreakSuggestion()
    }
    
    // MARK: - Speed Management
    func updateSpeedLimit(_ speedLimitKmh: Double) async {
        await drivingStatisticsService.updateSpeedLimit(speedLimitKmh)
    }
    
    func dismissSpeedingAlert() {
        showingSpeedingAlert = false
        speedingAlert = nil
    }
    
    // MARK: - Performance Analysis
    func loadPerformanceSummary() async {
        guard let currentUser = authenticationManager.currentUser else {
            errorMessage = "User not authenticated"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            performanceSummary = try await drivingStatisticsService.getPerformanceSummary(for: currentUser.id)
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func loadTripComparisons(limit: Int = 10) async {
        guard let currentUser = authenticationManager.currentUser else {
            errorMessage = "User not authenticated"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            tripComparisons = try await drivingStatisticsService.getTripComparisons(for: currentUser.id, limit: limit)
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func generatePerformanceReport(for tripId: UUID) async {
        guard let currentUser = authenticationManager.currentUser else {
            errorMessage = "User not authenticated"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            performanceReport = try await drivingStatisticsService.generatePerformanceReport(for: tripId, participantId: currentUser.id)
            showingPerformanceReport = true
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func compareWithPreviousTrips() async {
        guard let currentUser = authenticationManager.currentUser,
              let currentStats = currentStatistics else {
            errorMessage = "No current statistics available"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let comparison = try await drivingStatisticsService.compareWithPreviousTrips(current: currentStats, participantId: currentUser.id)
            // Handle comparison results - could update UI state or show comparison view
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    // MARK: - Data Export
    func exportStatistics(format: ExportFormat) async -> Data? {
        guard let currentUser = authenticationManager.currentUser else {
            errorMessage = "User not authenticated"
            return nil
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let data = try await drivingStatisticsService.exportStatistics(for: currentUser.id, format: format)
            isLoading = false
            return data
        } catch {
            errorMessage = error.localizedDescription
            isLoading = false
            return nil
        }
    }
    
    // MARK: - UI Actions
    func selectTripForComparison(_ tripId: UUID) {
        selectedTripForComparison = tripId
    }
    
    func clearSelection() {
        selectedTripForComparison = nil
    }
    
    func dismissPerformanceReport() {
        showingPerformanceReport = false
        performanceReport = nil
    }
    
    func clearError() {
        errorMessage = nil
    }
    
    // MARK: - Helper Methods
    private func formatDuration(_ duration: TimeInterval) -> String {
        let hours = Int(duration) / 3600
        let minutes = Int(duration) % 3600 / 60
        
        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }
    
    func formatSpeed(_ speed: Double) -> String {
        return String(format: "%.0f km/h", speed * 3.6)
    }
    
    func formatDistance(_ distance: CLLocationDistance) -> String {
        if distance >= 1000 {
            return String(format: "%.1f km", distance / 1000)
        } else {
            return String(format: "%.0f m", distance)
        }
    }
    
    func formatSafetyScore(_ score: Double) -> String {
        return String(format: "%.0f", score)
    }
    
    func getSpeedColor() -> Color {
        if isSpeedingDanger {
            return .red
        } else if isSpeedingWarning {
            return .orange
        } else if isSpeedingDetected {
            return .yellow
        } else {
            return .green
        }
    }
    
    func getSafetyColor() -> Color {
        switch safetyRating {
        case .excellent:
            return .green
        case .good:
            return .blue
        case .fair:
            return .yellow
        case .poor:
            return .orange
        case .dangerous:
            return .red
        }
    }
    
    func getBreakUrgencyColor(_ urgency: BreakUrgency) -> Color {
        switch urgency {
        case .low:
            return .blue
        case .medium:
            return .yellow
        case .high:
            return .orange
        case .critical:
            return .red
        }
    }
    
    func getSpeedingSeverityColor(_ severity: SpeedingSeverity) -> Color {
        switch severity {
        case .minor:
            return .yellow
        case .moderate:
            return .orange
        case .serious:
            return .red
        }
    }
    
    // MARK: - Statistics Calculations
    func calculateTripProgress() -> Double {
        guard let statistics = currentStatistics else { return 0.0 }
        
        // This would need trip destination information to calculate actual progress
        // For now, return a placeholder based on time
        let maxTripDuration: TimeInterval = 28800 // 8 hours
        return min(1.0, currentTripDuration / maxTripDuration)
    }
    
    func getRecentSpeedingIncidents() -> [SpeedingIncident] {
        guard let statistics = currentStatistics else { return [] }
        
        let thirtyMinutesAgo = Date().addingTimeInterval(-1800)
        return statistics.speedingIncidents.filter { $0.timestamp >= thirtyMinutesAgo }
    }
    
    func getActiveRestDuration() -> TimeInterval {
        guard let restPeriod = currentRestPeriod else { return 0 }
        return restPeriod.duration
    }
    
    func getActiveRestDurationFormatted() -> String {
        return formatDuration(getActiveRestDuration())
    }
    
    func shouldShowSpeedWarning() -> Bool {
        return isSpeedingDetected && (isSpeedingWarning || isSpeedingDanger)
    }
    
    func getSpeedWarningMessage() -> String {
        if isSpeedingDanger {
            return "Dangerous speeding detected! Slow down immediately."
        } else if isSpeedingWarning {
            return "You're exceeding the speed limit. Please slow down."
        } else {
            return "Speed limit exceeded."
        }
    }
    
    func getBreakRecommendationMessage() -> String {
        guard let suggestion = breakSuggestion else { return "" }
        
        switch suggestion.urgency {
        case .critical:
            return "Critical: Take a break immediately for safety!"
        case .high:
            return "High priority: Consider taking a break soon."
        case .medium:
            return "Suggestion: A break would be beneficial."
        case .low:
            return "Optional: You might want to take a short break."
        }
    }
}