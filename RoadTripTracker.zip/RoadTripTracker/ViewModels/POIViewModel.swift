import Foundation
import CoreLocation
import MapKit
import Combine

@MainActor
class POIViewModel: ObservableObject {
    @Published var nearbyPOIs: [PointOfInterest] = []
    @Published var searchResults: [PointOfInterest] = []
    @Published var selectedPOI: PointOfInterest?
    @Published var proposals: [POIProposal] = []
    @Published var searchFilter = POISearchFilter()
    @Published var searchQuery = ""
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showingPOIDetails = false
    @Published var showingProposalSheet = false
    @Published var showingFilterSheet = false
    
    private let poiService: POIServiceProtocol
    private let locationManager: LocationManagerProtocol
    private var cancellables = Set<AnyCancellable>()
    
    // Current trip context
    @Published var currentTrip: Trip?
    @Published var currentLocation: CLLocationCoordinate2D?
    
    init(poiService: POIServiceProtocol, locationManager: LocationManagerProtocol) {
        self.poiService = poiService
        self.locationManager = locationManager
        
        setupBindings()
    }
    
    // MARK: - Setup
    
    private func setupBindings() {
        // Auto-search when query changes
        $searchQuery
            .debounce(for: .milliseconds(500), scheduler: RunLoop.main)
            .removeDuplicates()
            .sink { [weak self] query in
                if !query.isEmpty {
                    Task {
                        await self?.searchPOIs(query: query)
                    }
                }
            }
            .store(in: &cancellables)
        
        // Auto-discover when filter changes
        $searchFilter
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                Task {
                    await self?.discoverNearbyPOIs()
                }
            }
            .store(in: &cancellables)
    }
    
    // MARK: - POI Discovery
    
    func discoverNearbyPOIs() async {
        guard let location = currentLocation else { return }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let radius = searchFilter.maxDistance ?? 10000 // 10km default
            nearbyPOIs = try await poiService.discoverPOIsNearLocation(
                coordinate: location,
                radius: radius,
                filter: searchFilter
            )
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func discoverPOIsAlongRoute() async {
        guard let trip = currentTrip else { return }
        
        let routeCoordinates = trip.destinations.map { $0.coordinate }
        guard !routeCoordinates.isEmpty else { return }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let radius = searchFilter.maxDistance ?? 5000 // 5km default for route
            nearbyPOIs = try await poiService.discoverPOIsNearRoute(
                route: routeCoordinates,
                radius: radius,
                filter: searchFilter
            )
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func searchPOIs(query: String) async {
        guard let location = currentLocation, !query.isEmpty else {
            searchResults = []
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            searchResults = try await poiService.searchPOIs(
                query: query,
                near: location,
                filter: searchFilter
            )
        } catch {
            errorMessage = error.localizedDescription
            searchResults = []
        }
        
        isLoading = false
    }
    
    // MARK: - POI Details
    
    func loadPOIDetails(for poi: PointOfInterest) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let detailedPOI = try await poiService.getPOIDetails(placeId: poi.placeId)
            selectedPOI = detailedPOI
            showingPOIDetails = true
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    // MARK: - POI Proposals
    
    func proposePOI(_ poi: PointOfInterest, insertionIndex: Int, message: String?) async {
        guard let trip = currentTrip else { return }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let proposal = try await poiService.proposePOI(
                poi: poi,
                for: trip,
                insertionIndex: insertionIndex,
                message: message
            )
            
            proposals.append(proposal)
            showingProposalSheet = false
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func votePOIProposal(_ proposal: POIProposal, vote: VoteType, comment: String?) async {
        guard let trip = currentTrip,
              let currentParticipant = trip.participants.first else { return }
        
        isLoading = true
        errorMessage = nil
        
        do {
            try await poiService.votePOIProposal(
                proposalId: proposal.id,
                participantId: currentParticipant.id,
                vote: vote,
                comment: comment
            )
            
            // Refresh proposals
            await loadPOIProposals()
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func loadPOIProposals() async {
        guard let tripId = currentTrip?.id else { return }
        
        do {
            proposals = try await poiService.getPOIProposals(for: tripId)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    // MARK: - Filter Management
    
    func updateFilter(categories: Set<POICategory>) {
        searchFilter.categories = categories
    }
    
    func updateFilter(minRating: Double?) {
        searchFilter.minRating = minRating
    }
    
    func updateFilter(maxDistance: CLLocationDistance?) {
        searchFilter.maxDistance = maxDistance
    }
    
    func updateFilter(sortBy: POISortOption) {
        searchFilter.sortBy = sortBy
    }
    
    func resetFilter() {
        searchFilter = POISearchFilter()
    }
    
    // MARK: - Utility Methods
    
    func setCurrentTrip(_ trip: Trip) {
        currentTrip = trip
        Task {
            await loadPOIProposals()
            await discoverNearbyPOIs()
        }
    }
    
    func setCurrentLocation(_ location: CLLocationCoordinate2D) {
        currentLocation = location
        Task {
            await discoverNearbyPOIs()
        }
    }
    
    func clearSearch() {
        searchQuery = ""
        searchResults = []
    }
    
    func selectPOI(_ poi: PointOfInterest) {
        selectedPOI = poi
        Task {
            await loadPOIDetails(for: poi)
        }
    }
    
    func clearSelection() {
        selectedPOI = nil
        showingPOIDetails = false
    }
    
    func showProposalSheet(for poi: PointOfInterest) {
        selectedPOI = poi
        showingProposalSheet = true
    }
    
    func hideProposalSheet() {
        showingProposalSheet = false
        selectedPOI = nil
    }
    
    func showFilterSheet() {
        showingFilterSheet = true
    }
    
    func hideFilterSheet() {
        showingFilterSheet = false
    }
    
    // MARK: - Helper Methods
    
    func formatDistance(_ distance: CLLocationDistance) -> String {
        let formatter = MKDistanceFormatter()
        formatter.unitStyle = .abbreviated
        return formatter.string(fromDistance: distance)
    }
    
    func formatRating(_ rating: Double?) -> String {
        guard let rating = rating else { return "No rating" }
        return String(format: "%.1f ⭐", rating)
    }
    
    func formatPriceLevel(_ priceLevel: Int?) -> String {
        guard let priceLevel = priceLevel else { return "" }
        return String(repeating: "$", count: min(priceLevel, 4))
    }
    
    func isOpenNow(_ poi: PointOfInterest) -> String {
        guard let isOpen = poi.isOpen else { return "Hours unknown" }
        return isOpen ? "Open now" : "Closed"
    }
    
    func canProposePOI(_ poi: PointOfInterest) -> Bool {
        guard let trip = currentTrip else { return false }
        
        // Check if POI is already in the trip
        let isAlreadyInTrip = trip.destinations.contains { destination in
            destination.type == .attraction && destination.name == poi.name
        }
        
        // Check if there's already a pending proposal for this POI
        let hasPendingProposal = proposals.contains { proposal in
            proposal.poi.placeId == poi.placeId && proposal.status == .pending
        }
        
        return !isAlreadyInTrip && !hasPendingProposal
    }
    
    func getProposalStatus(for poi: PointOfInterest) -> POIProposalStatus? {
        return proposals.first { $0.poi.placeId == poi.placeId }?.status
    }
    
    func hasUserVoted(for proposal: POIProposal) -> Bool {
        guard let trip = currentTrip,
              let currentParticipant = trip.participants.first else { return false }
        
        return proposal.votes.contains { $0.participantId == currentParticipant.id }
    }
    
    func getUserVote(for proposal: POIProposal) -> VoteType? {
        guard let trip = currentTrip,
              let currentParticipant = trip.participants.first else { return nil }
        
        return proposal.votes.first { $0.participantId == currentParticipant.id }?.vote
    }
}