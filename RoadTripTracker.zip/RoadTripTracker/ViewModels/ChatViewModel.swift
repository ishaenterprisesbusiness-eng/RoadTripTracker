import Foundation
import Combine
import UIKit
import CoreLocation

// MARK: - Chat View Model
@MainActor
class ChatViewModel: ObservableObject {
    
    // MARK: - Published Properties
    @Published var messages: [Message] = []
    @Published var messageText: String = ""
    @Published var isLoading: Bool = false
    @Published var connectionStatus: ConnectionStatus = .disconnected
    @Published var errorMessage: String?
    @Published var showingPhotoPicker: Bool = false
    @Published var showingLocationPicker: Bool = false
    
    // MARK: - Private Properties
    private let chatService: ChatServiceProtocol
    private let photoSharingService: PhotoSharingServiceProtocol
    private let locationManager: LocationManager
    private var subscriptions = Set<AnyCancellable>()
    private var currentTripId: UUID?
    
    // MARK: - Initialization
    init(
        chatService: ChatServiceProtocol = ChatService(),
        photoSharingService: PhotoSharingServiceProtocol = PhotoSharingService(),
        locationManager: LocationManager = LocationManager.shared
    ) {
        self.chatService = chatService
        self.photoSharingService = photoSharingService
        self.locationManager = locationManager
        
        setupSubscriptions()
    }
    
    // MARK: - Public Methods
    
    func loadMessages(for tripId: UUID) async {
        currentTripId = tripId
        isLoading = true
        errorMessage = nil
        
        do {
            // Subscribe to real-time updates
            try await chatService.subscribeToMessages(for: tripId)
            
            // Load existing messages
            let loadedMessages = try await chatService.getMessages(for: tripId, limit: 100, offset: 0)
            messages = loadedMessages.sorted { $0.timestamp < $1.timestamp }
            
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func sendMessage() async {
        guard !messageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              let tripId = currentTripId else { return }
        
        let content = messageText.trimmingCharacters(in: .whitespacesAndNewlines)
        messageText = ""
        
        do {
            _ = try await chatService.sendMessage(content, to: tripId)
        } catch {
            errorMessage = error.localizedDescription
            // Restore message text on failure
            messageText = content
        }
    }
    
    func sendLocationMessage() async {
        guard let tripId = currentTripId else { return }
        
        do {
            let location = try await locationManager.getCurrentLocation()
            _ = try await chatService.sendLocationMessage(location.coordinate, to: tripId)
        } catch {
            errorMessage = "Failed to get current location"
        }
    }
    
    func sendPhotoMessage(_ photo: UIImage, caption: String? = nil) async {
        guard let tripId = currentTripId else { return }
        
        do {
            _ = try await chatService.sendPhotoMessage(photo, caption: caption, to: tripId)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func sendEmergencyMessage(_ content: String) async {
        guard let tripId = currentTripId else { return }
        
        do {
            let location = try await locationManager.getCurrentLocation()
            _ = try await chatService.sendEmergencyMessage(content, location: location.coordinate, to: tripId)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func markMessageAsRead(_ message: Message) async {
        guard let currentUserId = getCurrentUserId() else { return }
        
        // Don't mark own messages as read
        if message.senderId == currentUserId { return }
        
        // Don't mark if already read
        if message.readBy.contains(currentUserId) { return }
        
        do {
            try await chatService.markMessageAsRead(message.id, by: currentUserId)
        } catch {
            // Silently fail for read status updates
        }
    }
    
    func deleteMessage(_ message: Message) async {
        guard let currentUserId = getCurrentUserId(),
              message.senderId == currentUserId else { return }
        
        do {
            try await chatService.deleteMessage(message.id)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func retryFailedMessage(_ message: Message) async {
        guard message.deliveryStatus == .failed else { return }
        
        // Remove the failed message from the list
        messages.removeAll { $0.id == message.id }
        
        // Resend based on message type
        switch message.type {
        case .text:
            messageText = message.content
            await sendMessage()
        case .location:
            if let location = message.location {
                do {
                    _ = try await chatService.sendLocationMessage(location, to: message.tripId)
                } catch {
                    errorMessage = error.localizedDescription
                }
            }
        case .photo:
            // For photo messages, we'd need to store the original image
            // This is a simplified implementation
            errorMessage = "Cannot retry photo messages"
        case .emergency:
            if let location = message.location {
                do {
                    _ = try await chatService.sendEmergencyMessage(message.content, location: location, to: message.tripId)
                } catch {
                    errorMessage = error.localizedDescription
                }
            }
        case .system:
            // System messages shouldn't be retried
            break
        }
    }
    
    func clearError() {
        errorMessage = nil
    }
    
    func disconnect() async {
        guard let tripId = currentTripId else { return }
        
        do {
            try await chatService.unsubscribeFromMessages(for: tripId)
        } catch {
            // Silently fail
        }
        
        currentTripId = nil
        messages.removeAll()
    }
}

// MARK: - Private Methods
private extension ChatViewModel {
    
    func setupSubscriptions() {
        // Subscribe to new messages
        chatService.messageUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] message in
                self?.handleNewMessage(message)
            }
            .store(in: &subscriptions)
        
        // Subscribe to connection status
        chatService.connectionStatus
            .receive(on: DispatchQueue.main)
            .assign(to: \.connectionStatus, on: self)
            .store(in: &subscriptions)
    }
    
    func handleNewMessage(_ message: Message) {
        // Check if message already exists (avoid duplicates)
        if !messages.contains(where: { $0.id == message.id }) {
            // Insert message in chronological order
            if let index = messages.firstIndex(where: { $0.timestamp > message.timestamp }) {
                messages.insert(message, at: index)
            } else {
                messages.append(message)
            }
        } else {
            // Update existing message (for delivery status updates)
            if let index = messages.firstIndex(where: { $0.id == message.id }) {
                messages[index] = message
            }
        }
    }
    
    func getCurrentUserId() -> UUID? {
        // This should get the current user ID from authentication service
        // For now, return a placeholder
        return UUID()
    }
}

// MARK: - Helper Extensions
extension ChatViewModel {
    
    func isMessageFromCurrentUser(_ message: Message) -> Bool {
        guard let currentUserId = getCurrentUserId() else { return false }
        return message.senderId == currentUserId
    }
    
    func getMessageStatusText(_ message: Message) -> String {
        switch message.deliveryStatus {
        case .sending:
            return "Sending..."
        case .sent:
            return "Sent"
        case .delivered:
            return "Delivered"
        case .failed:
            return "Failed"
        }
    }
    
    func getReadStatusText(_ message: Message) -> String {
        let readCount = message.readBy.count
        if readCount == 0 {
            return ""
        } else if readCount == 1 {
            return "Read by 1 person"
        } else {
            return "Read by \(readCount) people"
        }
    }
    
    func shouldShowTimestamp(_ message: Message, previousMessage: Message?) -> Bool {
        guard let previousMessage = previousMessage else { return true }
        
        let timeDifference = message.timestamp.timeIntervalSince(previousMessage.timestamp)
        return timeDifference > 300 // Show timestamp if more than 5 minutes apart
    }
    
    func formatMessageTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        
        if Calendar.current.isDateInToday(date) {
            formatter.timeStyle = .short
            return formatter.string(from: date)
        } else if Calendar.current.isDateInYesterday(date) {
            return "Yesterday"
        } else {
            formatter.dateStyle = .short
            return formatter.string(from: date)
        }
    }
}