import Foundation
import Combine

// MARK: - Vehicle Entry View Model
@MainActor
class VehicleEntryViewModel: ObservableObject {
    // MARK: - Published Properties
    @Published var make: String = ""
    @Published var model: String = ""
    @Published var vehicleNumber: String = ""
    @Published var odometerReading: String = ""
    @Published var selectedVehicleType: VehicleType = .sedan
    @Published var color: String = ""
    
    // MARK: - Validation Properties
    @Published var makeError: String?
    @Published var modelError: String?
    @Published var vehicleNumberError: String?
    @Published var odometerError: String?
    
    // MARK: - State Properties
    @Published var isLoading = false
    @Published var showingSuccessAlert = false
    @Published var errorMessage: String?
    
    // MARK: - Computed Properties
    var isFormValid: Bool {
        return !make.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
               !model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
               !vehicleNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
               isValidOdometerReading &&
               makeError == nil &&
               modelError == nil &&
               vehicleNumberError == nil &&
               odometerError == nil
    }
    
    private var isValidOdometerReading: Bool {
        guard let reading = Int(odometerReading.trimmingCharacters(in: .whitespacesAndNewlines)) else {
            return false
        }
        return reading >= 0
    }
    
    // MARK: - Services
    private let authenticationService: AuthenticationServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Initialization
    init(authenticationService: AuthenticationServiceProtocol = ServiceContainer.shared.authenticationService) {
        self.authenticationService = authenticationService
        setupValidation()
        loadExistingVehicleData()
    }
    
    // MARK: - Public Methods
    func saveVehicleDetails() async {
        guard isFormValid else {
            validateAllFields()
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let vehicle = Vehicle(
                make: make.trimmingCharacters(in: .whitespacesAndNewlines),
                model: model.trimmingCharacters(in: .whitespacesAndNewlines),
                vehicleNumber: vehicleNumber.trimmingCharacters(in: .whitespacesAndNewlines),
                odometerReading: Int(odometerReading.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 0,
                type: selectedVehicleType,
                color: color.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : color.trimmingCharacters(in: .whitespacesAndNewlines)
            )
            
            try await authenticationService.updateUserVehicle(vehicle)
            showingSuccessAlert = true
            
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func clearForm() {
        make = ""
        model = ""
        vehicleNumber = ""
        odometerReading = ""
        selectedVehicleType = .sedan
        color = ""
        clearErrors()
    }
    
    // MARK: - Private Methods
    private func setupValidation() {
        // Validate make field
        $make
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .sink { [weak self] value in
                self?.validateMake(value)
            }
            .store(in: &cancellables)
        
        // Validate model field
        $model
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .sink { [weak self] value in
                self?.validateModel(value)
            }
            .store(in: &cancellables)
        
        // Validate vehicle number field
        $vehicleNumber
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .sink { [weak self] value in
                self?.validateVehicleNumber(value)
            }
            .store(in: &cancellables)
        
        // Validate odometer reading field
        $odometerReading
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .sink { [weak self] value in
                self?.validateOdometerReading(value)
            }
            .store(in: &cancellables)
    }
    
    private func validateMake(_ value: String) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if trimmed.isEmpty {
            makeError = "Vehicle make is required"
        } else if trimmed.count < 2 {
            makeError = "Vehicle make must be at least 2 characters"
        } else if trimmed.count > 50 {
            makeError = "Vehicle make must be less than 50 characters"
        } else {
            makeError = nil
        }
    }
    
    private func validateModel(_ value: String) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if trimmed.isEmpty {
            modelError = "Vehicle model is required"
        } else if trimmed.count < 1 {
            modelError = "Vehicle model must be at least 1 character"
        } else if trimmed.count > 50 {
            modelError = "Vehicle model must be less than 50 characters"
        } else {
            modelError = nil
        }
    }
    
    private func validateVehicleNumber(_ value: String) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if trimmed.isEmpty {
            vehicleNumberError = "Vehicle number is required"
        } else if trimmed.count < 3 {
            vehicleNumberError = "Vehicle number must be at least 3 characters"
        } else if trimmed.count > 20 {
            vehicleNumberError = "Vehicle number must be less than 20 characters"
        } else {
            vehicleNumberError = nil
        }
    }
    
    private func validateOdometerReading(_ value: String) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if trimmed.isEmpty {
            odometerError = "Odometer reading is required"
        } else if Int(trimmed) == nil {
            odometerError = "Odometer reading must be a valid number"
        } else if let reading = Int(trimmed), reading < 0 {
            odometerError = "Odometer reading cannot be negative"
        } else if let reading = Int(trimmed), reading > 9999999 {
            odometerError = "Odometer reading seems too high"
        } else {
            odometerError = nil
        }
    }
    
    private func validateAllFields() {
        validateMake(make)
        validateModel(model)
        validateVehicleNumber(vehicleNumber)
        validateOdometerReading(odometerReading)
    }
    
    private func clearErrors() {
        makeError = nil
        modelError = nil
        vehicleNumberError = nil
        odometerError = nil
        errorMessage = nil
    }
    
    private func loadExistingVehicleData() {
        Task {
            do {
                if let currentUser = try await authenticationService.getCurrentUser(),
                   let vehicle = currentUser.vehicle {
                    await MainActor.run {
                        self.make = vehicle.make
                        self.model = vehicle.model
                        self.vehicleNumber = vehicle.vehicleNumber
                        self.odometerReading = String(vehicle.odometerReading)
                        self.selectedVehicleType = vehicle.type
                        self.color = vehicle.color ?? ""
                    }
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "Failed to load existing vehicle data"
                }
            }
        }
    }
}