import Foundation
import Combine
import CoreLocation
import MapKit

@MainActor
class TripViewModel: ObservableObject {
    @Published var trip: Trip?
    @Published var activeTrip: Trip?
    @Published var recentTrips: [Trip] = []
    @Published var selectedDestination: Destination?
    @Published var viewMode: TripViewMode = .list
    @Published var mapRegion = MKCoordinateRegion()
    @Published var estimatedArrivalTimes: [UUID: Date] = [:]
    @Published var routePolyline: MKPolyline?
    @Published var currentRoute: Route?
    @Published var currentUserLocation: CLLocation?
    @Published var isLoadingRoute: Bool = false
    @Published var isLoadingTrips: Bool = false
    @Published var errorMessage: String?
    @Published var showingError: Bool = false
    
    private let tripService: TripServiceProtocol
    private let mapService: MapServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    
    init(tripService: TripServiceProtocol? = nil, mapService: MapServiceProtocol? = nil) {
        self.tripService = tripService ?? ServiceContainer.shared.tripService
        self.mapService = mapService ?? ServiceContainer.shared.mapService
        
        setupTripUpdates()
    }
    
    // MARK: - Setup
    
    private func setupTripUpdates() {
        tripService.tripUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] trip in
                self?.trip = trip
                if let trip = trip {
                    self?.updateMapRegion(for: trip)
                    Task {
                        await self?.calculateEstimatedArrivalTimes()
                        await self?.loadRoute()
                    }
                }
            }
            .store(in: &cancellables)
    }
    
    // MARK: - View Mode Management
    
    func setViewMode(_ mode: TripViewMode) {
        viewMode = mode
        
        if mode == .map, let trip = trip {
            updateMapRegion(for: trip)
        }
    }
    
    // MARK: - Map Management
    
    func updateMapRegion(for trip: Trip) {
        guard !trip.destinations.isEmpty else { return }
        
        let coordinates = trip.destinations.map { $0.coordinate }
        let region = calculateRegion(for: coordinates)
        mapRegion = region
    }
    
    private func calculateRegion(for coordinates: [CLLocationCoordinate2D]) -> MKCoordinateRegion {
        guard !coordinates.isEmpty else {
            return MKCoordinateRegion(
                center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
                span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
            )
        }
        
        let minLat = coordinates.map { $0.latitude }.min() ?? 0
        let maxLat = coordinates.map { $0.latitude }.max() ?? 0
        let minLon = coordinates.map { $0.longitude }.min() ?? 0
        let maxLon = coordinates.map { $0.longitude }.max() ?? 0
        
        let center = CLLocationCoordinate2D(
            latitude: (minLat + maxLat) / 2,
            longitude: (minLon + maxLon) / 2
        )
        
        let span = MKCoordinateSpan(
            latitudeDelta: max(maxLat - minLat, 0.01) * 1.2,
            longitudeDelta: max(maxLon - minLon, 0.01) * 1.2
        )
        
        return MKCoordinateRegion(center: center, span: span)
    }
    
    // MARK: - Route Management
    
    func loadRoute() async {
        guard let trip = trip, trip.destinations.count > 1 else { return }
        
        isLoadingRoute = true
        
        do {
            let route = try await calculateRoute(for: trip.destinations)
            routePolyline = route.polyline
        } catch {
            handleError(error)
        }
        
        isLoadingRoute = false
    }
    
    private func calculateRoute(for destinations: [Destination]) async throws -> MKRoute {
        guard destinations.count > 1 else {
            throw TripViewError.insufficientDestinations
        }
        
        // Create waypoints from destinations
        let waypoints = destinations.map { destination in
            MKMapItem(placemark: MKPlacemark(coordinate: destination.coordinate))
        }
        
        // Calculate route through all waypoints
        let request = MKDirections.Request()
        request.source = waypoints.first
        request.destination = waypoints.last
        
        // For now, we'll calculate a simple route between first and last destination
        // In a more advanced implementation, you would calculate routes between all waypoints
        let directions = MKDirections(request: request)
        let response = try await directions.calculate()
        
        guard let route = response.routes.first else {
            throw TripViewError.routeCalculationFailed
        }
        
        return route
    }
    
    // MARK: - Estimated Arrival Times
    
    func calculateEstimatedArrivalTimes() async {
        guard let trip = trip else { return }
        
        var arrivalTimes: [UUID: Date] = [:]
        var currentTime = Date()
        
        for (index, destination) in trip.destinations.enumerated() {
            if index == 0 {
                // First destination - use current time or planned arrival
                arrivalTimes[destination.id] = destination.plannedArrival ?? currentTime
                currentTime = destination.plannedArrival ?? currentTime
            } else {
                let previousDestination = trip.destinations[index - 1]
                let travelTime = calculateTravelTime(
                    from: previousDestination.coordinate,
                    to: destination.coordinate
                )
                
                // Add planned duration at previous destination
                if let duration = previousDestination.plannedDuration {
                    currentTime = currentTime.addingTimeInterval(duration)
                }
                
                // Add travel time
                currentTime = currentTime.addingTimeInterval(travelTime)
                arrivalTimes[destination.id] = currentTime
            }
        }
        
        estimatedArrivalTimes = arrivalTimes
    }
    
    private func calculateTravelTime(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> TimeInterval {
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        let distance = fromLocation.distance(from: toLocation)
        
        // Assume average speed of 60 km/h
        let averageSpeedKmH: Double = 60
        let distanceKm = distance / 1000
        let timeHours = distanceKm / averageSpeedKmH
        
        return timeHours * 3600 // Convert to seconds
    }
    
    // MARK: - Destination Selection
    
    func selectDestination(_ destination: Destination) {
        selectedDestination = destination
        
        // Update map region to focus on selected destination
        mapRegion = MKCoordinateRegion(
            center: destination.coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        )
    }
    
    func deselectDestination() {
        selectedDestination = nil
        
        // Reset map region to show all destinations
        if let trip = trip {
            updateMapRegion(for: trip)
        }
    }
    
    // MARK: - Trip Statistics
    
    var totalDistance: CLLocationDistance {
        guard let trip = trip, trip.destinations.count > 1 else { return 0 }
        
        var totalDistance: CLLocationDistance = 0
        
        for i in 0..<(trip.destinations.count - 1) {
            let from = CLLocation(
                latitude: trip.destinations[i].coordinate.latitude,
                longitude: trip.destinations[i].coordinate.longitude
            )
            let to = CLLocation(
                latitude: trip.destinations[i + 1].coordinate.latitude,
                longitude: trip.destinations[i + 1].coordinate.longitude
            )
            totalDistance += from.distance(from: to)
        }
        
        return totalDistance
    }
    
    var totalEstimatedDuration: TimeInterval {
        guard let trip = trip else { return 0 }
        
        let travelTime = calculateTravelTime(from: trip.destinations.first?.coordinate ?? CLLocationCoordinate2D(), to: trip.destinations.last?.coordinate ?? CLLocationCoordinate2D())
        let stopDuration = trip.destinations.compactMap { $0.plannedDuration }.reduce(0, +)
        
        return travelTime + stopDuration
    }
    
    var currentDestination: Destination? {
        guard let trip = trip,
              trip.currentDestinationIndex < trip.destinations.count else { return nil }
        return trip.destinations[trip.currentDestinationIndex]
    }
    
    var nextDestination: Destination? {
        guard let trip = trip,
              trip.currentDestinationIndex + 1 < trip.destinations.count else { return nil }
        return trip.destinations[trip.currentDestinationIndex + 1]
    }
    
    // MARK: - Error Handling
    
    private func handleError(_ error: Error) {
        errorMessage = error.localizedDescription
        showingError = true
    }
    
    // MARK: - Public Methods for Views
    
    func loadActiveTrip() async {
        isLoadingTrips = true
        
        // Get active trip from trip service
        activeTrip = tripService.activeTrip
        
        // Also load recent trips
        await loadRecentTrips()
        
        isLoadingTrips = false
    }
    
    func loadRecentTrips() async {
        do {
            // This would need to be implemented with a proper user ID from AuthenticationManager
            let userId = UUID() // Placeholder
            let trips = try await tripService.getTripHistory(for: userId)
            recentTrips = Array(trips.prefix(5)) // Show only 5 most recent
        } catch {
            handleError(error)
        }
    }
    

}

// MARK: - Trip View Mode

enum TripViewMode: String, CaseIterable {
    case list = "list"
    case map = "map"
    
    var displayName: String {
        switch self {
        case .list: return "List"
        case .map: return "Map"
        }
    }
    
    var systemImage: String {
        switch self {
        case .list: return "list.bullet"
        case .map: return "map"
        }
    }
}

// MARK: - Trip View Error

enum TripViewError: LocalizedError {
    case insufficientDestinations
    case routeCalculationFailed
    case noActiveTrip
    
    var errorDescription: String? {
        switch self {
        case .insufficientDestinations:
            return "At least two destinations are required to calculate a route"
        case .routeCalculationFailed:
            return "Failed to calculate route between destinations"
        case .noActiveTrip:
            return "No active trip found"
        }
    }
}