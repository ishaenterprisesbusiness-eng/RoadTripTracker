import Foundation
import CoreLocation
import Combine

// MARK: - Food Stop View Model
@MainActor
class FoodStopViewModel: ObservableObject {
    @Published var nearbyRestaurants: [Restaurant] = []
    @Published var proposedFoodStops: [FoodStop] = []
    @Published var activeFoodStop: FoodStop?
    @Published var currentOrder: FoodOrder?
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showingProposalSheet = false
    @Published var showingOrderSheet = false
    @Published var selectedRestaurant: Restaurant?
    @Published var selectedCuisineFilter: CuisineType?
    
    // Order form properties
    @Published var orderItems: [OrderItem] = []
    @Published var specialInstructions: String = ""
    @Published var isReadyToContinue = false
    
    private let foodStopService: FoodStopServiceProtocol
    private let locationManager: LocationManager
    private var cancellables = Set<AnyCancellable>()
    
    private var currentTripId: UUID?
    private var currentParticipantId: UUID?
    
    init(foodStopService: FoodStopServiceProtocol, locationManager: LocationManager) {
        self.foodStopService = foodStopService
        self.locationManager = locationManager
        
        setupSubscriptions()
    }
    
    // MARK: - Setup
    
    private func setupSubscriptions() {
        // Subscribe to food stop updates
        foodStopService.foodStopUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] foodStop in
                self?.handleFoodStopUpdate(foodStop)
            }
            .store(in: &cancellables)
        
        // Subscribe to order updates
        foodStopService.orderUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] order in
                self?.handleOrderUpdate(order)
            }
            .store(in: &cancellables)
        
        // Subscribe to approach notifications
        foodStopService.approachingFoodStopNotifications
            .receive(on: DispatchQueue.main)
            .sink { [weak self] notification in
                self?.handleApproachNotification(notification)
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Public Methods
    
    func setTripContext(tripId: UUID, participantId: UUID) {
        self.currentTripId = tripId
        self.currentParticipantId = participantId
        
        Task {
            await loadFoodStopsForTrip()
            await startLocationMonitoring()
        }
    }
    
    func searchNearbyRestaurants() async {
        guard let location = locationManager.currentLocation else {
            errorMessage = "Location not available"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let restaurants = try await foodStopService.findNearbyRestaurants(
                coordinate: location.coordinate,
                radius: 10000, // 10km radius
                cuisineFilter: selectedCuisineFilter
            )
            
            nearbyRestaurants = restaurants
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func searchRestaurantsAlongRoute(_ route: [CLLocationCoordinate2D]) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let restaurants = try await foodStopService.findRestaurantsAlongRoute(
                route: route,
                searchRadius: 5000, // 5km from route
                cuisineFilter: selectedCuisineFilter
            )
            
            nearbyRestaurants = restaurants
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func proposeFoodStop(restaurant: Restaurant, notes: String? = nil) async {
        guard let tripId = currentTripId,
              let participantId = currentParticipantId else {
            errorMessage = "Trip context not set"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let foodStop = try await foodStopService.proposeFoodStop(
                restaurant: restaurant,
                tripId: tripId,
                proposedBy: participantId,
                notes: notes
            )
            
            // Add to proposed food stops if not already there
            if !proposedFoodStops.contains(where: { $0.id == foodStop.id }) {
                proposedFoodStops.append(foodStop)
            }
            
            showingProposalSheet = false
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func approveFoodStop(_ foodStop: FoodStop) async {
        guard let participantId = currentParticipantId else {
            errorMessage = "Participant context not set"
            return
        }
        
        do {
            try await foodStopService.approveFoodStop(
                foodStopId: foodStop.id,
                participantId: participantId
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func rejectFoodStop(_ foodStop: FoodStop, reason: String? = nil) async {
        guard let participantId = currentParticipantId else {
            errorMessage = "Participant context not set"
            return
        }
        
        do {
            try await foodStopService.rejectFoodStop(
                foodStopId: foodStop.id,
                participantId: participantId,
                reason: reason
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func placeOrder() async {
        guard let foodStop = activeFoodStop,
              let participantId = currentParticipantId,
              !orderItems.isEmpty else {
            errorMessage = "No active food stop, participant context, or order items"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let order = try await foodStopService.placeOrder(
                foodStopId: foodStop.id,
                participantId: participantId,
                items: orderItems,
                specialInstructions: specialInstructions.isEmpty ? nil : specialInstructions
            )
            
            currentOrder = order
            
            // Clear form
            clearOrderForm()
            showingOrderSheet = false
            
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func markReadyToContinue() async {
        guard let foodStop = activeFoodStop,
              let participantId = currentParticipantId else {
            errorMessage = "No active food stop or participant context"
            return
        }
        
        do {
            try await foodStopService.markReadyToContinue(
                foodStopId: foodStop.id,
                participantId: participantId
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func cancelFoodStop(_ foodStop: FoodStop, reason: String? = nil) async {
        guard let participantId = currentParticipantId else {
            errorMessage = "Participant context not set"
            return
        }
        
        do {
            try await foodStopService.cancelFoodStop(
                foodStopId: foodStop.id,
                cancelledBy: participantId,
                reason: reason
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    // MARK: - Order Management
    
    func addOrderItem(name: String, quantity: Int = 1, price: Double? = nil) {
        let item = OrderItem(name: name, quantity: quantity, price: price)
        orderItems.append(item)
    }
    
    func removeOrderItem(at index: Int) {
        guard index < orderItems.count else { return }
        orderItems.remove(at: index)
    }
    
    func updateOrderItemQuantity(at index: Int, quantity: Int) {
        guard index < orderItems.count else { return }
        orderItems[index].quantity = max(1, quantity)
    }
    
    func getTotalOrderCost() -> Double {
        return orderItems.reduce(0) { total, item in
            total + (item.price ?? 0) * Double(item.quantity)
        }
    }
    
    // MARK: - UI Helper Methods
    
    func showProposalSheet(for restaurant: Restaurant) {
        selectedRestaurant = restaurant
        showingProposalSheet = true
    }
    
    func showOrderSheet() {
        showingOrderSheet = true
    }
    
    func clearOrderForm() {
        orderItems.removeAll()
        specialInstructions = ""
        isReadyToContinue = false
    }
    
    func isParticipantOrdered(_ participantId: UUID) -> Bool {
        guard let foodStop = activeFoodStop else { return false }
        return foodStop.orders.contains { $0.participantId == participantId }
    }
    
    func isParticipantReady(_ participantId: UUID) -> Bool {
        guard let foodStop = activeFoodStop else { return false }
        return foodStop.orders.first { $0.participantId == participantId }?.isReadyToContinue ?? false
    }
    
    func getOrderInfo(for participantId: UUID) -> FoodOrder? {
        return activeFoodStop?.orders.first { $0.participantId == participantId }
    }
    
    func getOrderStatusColor(_ status: OrderStatus) -> String {
        return status.color
    }
    
    func formatPriceLevel(_ level: Int?) -> String {
        guard let level = level else { return "Price not available" }
        return String(repeating: "$", count: min(level, 4))
    }
    
    func formatEstimatedWaitTime(_ timeInterval: TimeInterval?) -> String {
        guard let timeInterval = timeInterval else { return "Unknown" }
        let minutes = Int(timeInterval / 60)
        return "\(minutes) min"
    }
    
    // MARK: - Private Methods
    
    private func loadFoodStopsForTrip() async {
        guard let tripId = currentTripId else { return }
        
        do {
            let foodStops = try await foodStopService.getFoodStopsForTrip(tripId: tripId)
            proposedFoodStops = foodStops.filter { $0.proposalStatus != .completed && $0.proposalStatus != .cancelled }
            activeFoodStop = try await foodStopService.getActiveFoodStop(tripId: tripId)
            
            // Load current participant's order if there's an active food stop
            if let activeFoodStop = activeFoodStop,
               let participantId = currentParticipantId {
                currentOrder = activeFoodStop.orders.first { $0.participantId == participantId }
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    private func startLocationMonitoring() async {
        guard let tripId = currentTripId,
              let location = locationManager.currentLocation else { return }
        
        do {
            try await foodStopService.monitorApproachingFoodStops(
                tripId: tripId,
                participantLocation: location.coordinate
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    private func handleFoodStopUpdate(_ foodStop: FoodStop) {
        // Update proposed food stops
        if let index = proposedFoodStops.firstIndex(where: { $0.id == foodStop.id }) {
            proposedFoodStops[index] = foodStop
        } else if foodStop.proposalStatus != .completed && foodStop.proposalStatus != .cancelled {
            proposedFoodStops.append(foodStop)
        }
        
        // Update active food stop
        if foodStop.proposalStatus == .active {
            activeFoodStop = foodStop
            
            // Update current order if participant has one
            if let participantId = currentParticipantId {
                currentOrder = foodStop.orders.first { $0.participantId == participantId }
            }
        } else if activeFoodStop?.id == foodStop.id && foodStop.proposalStatus == .completed {
            activeFoodStop = nil
            currentOrder = nil
        }
        
        // Remove completed or cancelled stops from proposed list
        proposedFoodStops.removeAll { $0.proposalStatus == .completed || $0.proposalStatus == .cancelled }
    }
    
    private func handleOrderUpdate(_ order: FoodOrder) {
        // Update current order if it belongs to current participant
        if order.participantId == currentParticipantId {
            currentOrder = order
        }
        
        // Update the order in active food stop
        if var foodStop = activeFoodStop,
           let orderIndex = foodStop.orders.firstIndex(where: { $0.id == order.id }) {
            foodStop.orders[orderIndex] = order
            activeFoodStop = foodStop
        }
    }
    
    private func handleApproachNotification(_ notification: FoodStopApproachNotification) {
        // Handle approach notifications - could show alerts or update UI
        print("Approaching food stop: \(notification.restaurant.name)")
        
        if let parkingInfo = notification.parkingInfo {
            print("Parking info: \(parkingInfo.parkingType.displayName) - \(parkingInfo.parkingCost.displayName)")
        }
    }
}