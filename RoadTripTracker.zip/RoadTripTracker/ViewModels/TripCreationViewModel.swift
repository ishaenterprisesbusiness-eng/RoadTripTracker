import Foundation
import Combine
import CoreLocation
import MapKit

@MainActor
class TripCreationViewModel: ObservableObject {
    @Published var tripName: String = ""
    @Published var destinations: [Destination] = []
    @Published var searchText: String = ""
    @Published var searchResults: [PlaceSearchResult] = []
    @Published var isSearching: Bool = false
    @Published var isCreatingTrip: Bool = false
    @Published var errorMessage: String?
    @Published var showingError: Bool = false
    @Published var createdTrip: Trip?
    
    // Trip settings
    @Published var isPublic: Bool = false
    @Published var allowParticipantInvites: Bool = true
    @Published var maxParticipants: Int?
    @Published var totalBudget: Double = 0
    @Published var enableBudgetTracking: Bool = false
    
    private let tripService: TripServiceProtocol
    private let placesService: PlacesServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    private var searchCancellable: AnyCancellable?
    
    init(tripService: TripServiceProtocol, placesService: PlacesServiceProtocol) {
        self.tripService = tripService
        self.placesService = placesService
        
        setupSearchDebouncing()
    }
    
    // MARK: - Search Functionality
    
    private func setupSearchDebouncing() {
        $searchText
            .debounce(for: .milliseconds(500), scheduler: RunLoop.main)
            .removeDuplicates()
            .sink { [weak self] searchText in
                if !searchText.isEmpty {
                    Task {
                        await self?.searchPlaces(query: searchText)
                    }
                } else {
                    self?.searchResults = []
                }
            }
            .store(in: &cancellables)
    }
    
    func searchPlaces(query: String) async {
        guard !query.isEmpty else {
            searchResults = []
            return
        }
        
        isSearching = true
        
        do {
            let results = try await placesService.searchPlaces(query: query, region: nil)
            searchResults = results
        } catch {
            handleError(error)
        }
        
        isSearching = false
    }
    
    // MARK: - Destination Management
    
    func addDestination(from searchResult: PlaceSearchResult) {
        let destination = Destination(
            name: searchResult.name,
            address: searchResult.address,
            coordinate: searchResult.coordinate,
            type: mapToDestinationType(searchResult.category)
        )
        
        destinations.append(destination)
        searchText = ""
        searchResults = []
    }
    
    func addCustomDestination(name: String, address: String, coordinate: CLLocationCoordinate2D) {
        let destination = Destination(
            name: name,
            address: address,
            coordinate: coordinate,
            type: .waypoint
        )
        
        destinations.append(destination)
    }
    
    func removeDestination(at index: Int) {
        guard index < destinations.count else { return }
        destinations.remove(at: index)
    }
    
    func moveDestination(from source: IndexSet, to destination: Int) {
        destinations.move(fromOffsets: source, toOffset: destination)
    }
    
    func updateDestination(_ destination: Destination, at index: Int) {
        guard index < destinations.count else { return }
        destinations[index] = destination
    }
    
    // MARK: - Route Optimization
    
    func optimizeRoute() async {
        guard destinations.count > 2 else { return }
        
        do {
            let optimizedDestinations = try await tripService.optimizeRoute(destinations: destinations)
            destinations = optimizedDestinations
        } catch {
            handleError(error)
        }
    }
    
    // MARK: - Trip Creation
    
    func createTrip() async {
        guard !tripName.isEmpty else {
            showError("Please enter a trip name")
            return
        }
        
        guard !destinations.isEmpty else {
            showError("Please add at least one destination")
            return
        }
        
        isCreatingTrip = true
        
        do {
            let budget = enableBudgetTracking && totalBudget > 0 ? Budget(totalBudget: totalBudget) : nil
            
            let settings = TripSettings(
                isPublic: isPublic,
                allowParticipantInvites: allowParticipantInvites,
                maxParticipants: maxParticipants,
                budget: budget
            )
            
            let trip = try await tripService.createTrip(
                name: tripName,
                destinations: destinations,
                settings: settings
            )
            
            createdTrip = trip
            
        } catch {
            handleError(error)
        }
        
        isCreatingTrip = false
    }
    
    // MARK: - Validation
    
    var canCreateTrip: Bool {
        !tripName.isEmpty && !destinations.isEmpty && !isCreatingTrip
    }
    
    var estimatedTripDistance: CLLocationDistance {
        guard destinations.count > 1 else { return 0 }
        
        var totalDistance: CLLocationDistance = 0
        
        for i in 0..<(destinations.count - 1) {
            let from = CLLocation(
                latitude: destinations[i].coordinate.latitude,
                longitude: destinations[i].coordinate.longitude
            )
            let to = CLLocation(
                latitude: destinations[i + 1].coordinate.latitude,
                longitude: destinations[i + 1].coordinate.longitude
            )
            totalDistance += from.distance(from: to)
        }
        
        return totalDistance
    }
    
    var estimatedTripDuration: TimeInterval {
        // Rough estimate: 60 km/h average speed
        let averageSpeedKmH: Double = 60
        let distanceKm = estimatedTripDistance / 1000
        return (distanceKm / averageSpeedKmH) * 3600 // Convert to seconds
    }
    
    // MARK: - Helper Methods
    
    private func mapToDestinationType(_ category: PlaceCategory) -> DestinationType {
        switch category {
        case .restaurant:
            return .food
        case .gasStation:
            return .fuel
        case .hotel:
            return .accommodation
        case .attraction:
            return .attraction
        default:
            return .waypoint
        }
    }
    
    private func handleError(_ error: Error) {
        errorMessage = error.localizedDescription
        showingError = true
    }
    
    private func showError(_ message: String) {
        errorMessage = message
        showingError = true
    }
    
    // MARK: - Reset
    
    func reset() {
        tripName = ""
        destinations = []
        searchText = ""
        searchResults = []
        isPublic = false
        allowParticipantInvites = true
        maxParticipants = nil
        totalBudget = 0
        enableBudgetTracking = false
        createdTrip = nil
        errorMessage = nil
        showingError = false
    }
}