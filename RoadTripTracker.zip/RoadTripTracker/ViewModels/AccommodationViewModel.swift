import Foundation
import CoreLocation
import Combine

// MARK: - Accommodation View Model
@MainActor
class AccommodationViewModel: ObservableObject {
    @Published var accommodations: [Accommodation] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var searchFilters = AccommodationSearchFilters()
    @Published var selectedAccommodation: Accommodation?
    @Published var bookingInfo: AccommodationBookingInfo?
    @Published var availability: AccommodationAvailability?
    
    private let accommodationService: AccommodationServiceProtocol
    private let tripService: TripServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    
    init(accommodationService: AccommodationServiceProtocol = AccommodationService(), tripService: TripServiceProtocol = TripService()) {
        self.accommodationService = accommodationService
        self.tripService = tripService
    }
    
    // MARK: - Public Methods
    
    func searchAccommodations(near coordinate: CLLocationCoordinate2D, radius: Double = 25000) {
        Task {
            await performSearch(near: coordinate, radius: radius)
        }
    }
    
    func searchAccommodationsAlongRoute(_ route: [CLLocationCoordinate2D]) {
        Task {
            await performRouteSearch(route: route)
        }
    }
    
    func selectAccommodation(_ accommodation: Accommodation) {
        selectedAccommodation = accommodation
        
        // Load additional details
        Task {
            await loadAccommodationDetails(accommodation.id)
        }
    }
    
    func checkAvailability(for accommodation: Accommodation, checkIn: Date, checkOut: Date, guests: Int) {
        Task {
            await performAvailabilityCheck(accommodationId: accommodation.id, checkIn: checkIn, checkOut: checkOut, guests: guests)
        }
    }
    
    func loadBookingInfo(for accommodation: Accommodation) {
        Task {
            await performBookingInfoLoad(accommodationId: accommodation.id)
        }
    }
    
    func addAccommodationToTrip(_ accommodation: Accommodation, trip: Trip) {
        Task {
            await performAddToTrip(accommodation: accommodation, trip: trip)
        }
    }
    
    func updateFilters(_ filters: AccommodationSearchFilters) {
        searchFilters = filters
    }
    
    func clearResults() {
        accommodations = []
        selectedAccommodation = nil
        bookingInfo = nil
        availability = nil
        errorMessage = nil
    }
    
    func getFilteredAccommodations() -> [Accommodation] {
        return accommodations.filter { accommodation in
            // Apply current filters
            if !searchFilters.types.contains(accommodation.type) {
                return false
            }
            
            if let priceRange = searchFilters.priceRange,
               let accommodationPriceRange = accommodation.priceRange {
                if accommodationPriceRange.rawValue < priceRange.lowerBound.rawValue ||
                   accommodationPriceRange.rawValue > priceRange.upperBound.rawValue {
                    return false
                }
            }
            
            if let minRating = searchFilters.minRating,
               let accommodationRating = accommodation.rating {
                if accommodationRating < minRating {
                    return false
                }
            }
            
            if !searchFilters.requiredAmenities.isEmpty {
                let accommodationAmenities = Set(accommodation.amenities)
                if !searchFilters.requiredAmenities.isSubset(of: accommodationAmenities) {
                    return false
                }
            }
            
            if let maxDistance = searchFilters.maxDistance,
               let accommodationDistance = accommodation.distance {
                if accommodationDistance > maxDistance {
                    return false
                }
            }
            
            return true
        }
    }
    
    // MARK: - Private Methods
    
    private func performSearch(near coordinate: CLLocationCoordinate2D, radius: Double) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let results = try await accommodationService.searchAccommodations(
                near: coordinate,
                radius: radius,
                filters: searchFilters
            )
            
            accommodations = results
            
            if results.isEmpty {
                errorMessage = "No accommodations found in this area. Try expanding your search radius or adjusting filters."
            }
        } catch {
            errorMessage = error.localizedDescription
            accommodations = []
        }
        
        isLoading = false
    }
    
    private func performRouteSearch(route: [CLLocationCoordinate2D]) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let results = try await accommodationService.searchAccommodationsAlongRoute(
                route: route,
                filters: searchFilters
            )
            
            accommodations = results
            
            if results.isEmpty {
                errorMessage = "No accommodations found along this route. Try adjusting your filters."
            }
        } catch {
            errorMessage = error.localizedDescription
            accommodations = []
        }
        
        isLoading = false
    }
    
    private func loadAccommodationDetails(_ accommodationId: String) async {
        do {
            let details = try await accommodationService.getAccommodationDetails(accommodationId: accommodationId)
            
            // Update the accommodation in our list with detailed information
            if let index = accommodations.firstIndex(where: { $0.id == accommodationId }) {
                accommodations[index] = details
            }
            
            selectedAccommodation = details
        } catch {
            // Details loading failed, but we can still work with basic info
            print("Failed to load accommodation details: \(error)")
        }
    }
    
    private func performAvailabilityCheck(accommodationId: String, checkIn: Date, checkOut: Date, guests: Int) async {
        do {
            let availabilityResult = try await accommodationService.checkAvailability(
                accommodationId: accommodationId,
                checkIn: checkIn,
                checkOut: checkOut,
                guests: guests
            )
            
            availability = availabilityResult
        } catch {
            errorMessage = "Failed to check availability: \(error.localizedDescription)"
        }
    }
    
    private func performBookingInfoLoad(accommodationId: String) async {
        do {
            let info = try await accommodationService.getBookingInfo(accommodationId: accommodationId)
            bookingInfo = info
        } catch {
            errorMessage = "Failed to load booking information: \(error.localizedDescription)"
        }
    }
    
    private func performAddToTrip(accommodation: Accommodation, trip: Trip) async {
        do {
            let updatedTrip = try await accommodationService.addAccommodationToTrip(
                accommodation: accommodation,
                trip: trip
            )
            
            // Update the trip through the trip service
            try await tripService.updateTrip(updatedTrip)
            
        } catch {
            errorMessage = "Failed to add accommodation to trip: \(error.localizedDescription)"
        }
    }
}

// MARK: - Accommodation Search State
enum AccommodationSearchState {
    case idle
    case searching
    case loaded([Accommodation])
    case error(String)
    
    var isLoading: Bool {
        if case .searching = self {
            return true
        }
        return false
    }
    
    var accommodations: [Accommodation] {
        if case .loaded(let accommodations) = self {
            return accommodations
        }
        return []
    }
    
    var errorMessage: String? {
        if case .error(let message) = self {
            return message
        }
        return nil
    }
}