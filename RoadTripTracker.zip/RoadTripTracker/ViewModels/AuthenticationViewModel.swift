import Foundation
import Combine
import SwiftUI

@MainActor
class AuthenticationViewModel: ObservableObject {
    @Published var currentUser: User?
    @Published var isAuthenticated: Bool = false
    @Published var authenticationState: AuthenticationState = .unauthenticated
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    
    private var cancellables = Set<AnyCancellable>()
    private var authService: AuthenticationServiceProtocol
    
    init(authService: AuthenticationServiceProtocol? = nil) {
        // Use provided service or get from service container
        if let service = authService {
            self.authService = service
        } else {
            // Get from service container
            self.authService = ServiceContainer.shared.authenticationService
        }
        
        setupAuthentication()
    }
    
    // MARK: - Public Methods
    func signUp(username: String, email: String, password: String, city: String, dateOfBirth: Date, vehicle: Vehicle?) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let userData = UserRegistrationData(
                username: username,
                email: email,
                password: password,
                city: city,
                dateOfBirth: dateOfBirth,
                vehicle: vehicle
            )
            
            let user = try await authService.signUp(userData: userData)
            
            // Update UI state based on service state
            updateFromService()
            
        } catch let error as AuthenticationError {
            errorMessage = error.localizedDescription
            authenticationState = .error(error)
        } catch {
            let authError = AuthenticationError.unknown(error.localizedDescription)
            errorMessage = authError.localizedDescription
            authenticationState = .error(authError)
        }
        
        isLoading = false
    }
    
    func signIn(email: String, password: String) async {
        isLoading = true
        errorMessage = nil
        authenticationState = .authenticating
        
        do {
            let user = try await authService.signIn(email: email, password: password)
            
            // Update UI state based on service state
            updateFromService()
            
        } catch let error as AuthenticationError {
            errorMessage = error.localizedDescription
            authenticationState = .error(error)
        } catch {
            let authError = AuthenticationError.unknown(error.localizedDescription)
            errorMessage = authError.localizedDescription
            authenticationState = .error(authError)
        }
        
        isLoading = false
    }
    
    func signOut() async {
        isLoading = true
        
        do {
            try await authService.signOut()
            
            // Update UI state based on service state
            updateFromService()
            
        } catch {
            errorMessage = "Sign out failed: \(error.localizedDescription)"
        }
        
        isLoading = false
    }
    
    func resetPassword(email: String) async {
        isLoading = true
        errorMessage = nil
        
        do {
            try await authService.resetPassword(email: email)
        } catch {
            errorMessage = "Password reset failed: \(error.localizedDescription)"
        }
        
        isLoading = false
    }
    
    func verifyEmail(token: String) async {
        isLoading = true
        errorMessage = nil
        
        do {
            try await authService.verifyEmail(token: token)
            updateFromService()
        } catch {
            errorMessage = "Email verification failed: \(error.localizedDescription)"
        }
        
        isLoading = false
    }
    
    func enableBiometricAuth() async -> Bool {
        do {
            return try await authService.enableBiometricAuth()
        } catch {
            errorMessage = "Failed to enable biometric authentication: \(error.localizedDescription)"
            return false
        }
    }
    
    func authenticateWithBiometrics() async {
        isLoading = true
        errorMessage = nil
        
        do {
            let user = try await authService.authenticateWithBiometrics()
            updateFromService()
        } catch {
            errorMessage = "Biometric authentication failed: \(error.localizedDescription)"
        }
        
        isLoading = false
    }
    
    func clearError() {
        errorMessage = nil
    }
    
    // MARK: - Private Methods
    private func setupAuthentication() {
        // Subscribe to authentication state changes
        authService.authenticationStatePublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] state in
                self?.authenticationState = state
                self?.updateFromService()
            }
            .store(in: &cancellables)
        
        // Initial state sync
        updateFromService()
    }
    
    private func updateFromService() {
        currentUser = authService.currentUser
        isAuthenticated = authService.isAuthenticated
    }
}

// MARK: - Mock Authentication Service (for development)
class MockAuthenticationService: AuthenticationServiceProtocol {
    @Published private(set) var currentUser: User?
    @Published private(set) var isAuthenticated: Bool = false
    @Published private(set) var authenticationState: AuthenticationState = .unauthenticated
    
    var authenticationStatePublisher: AnyPublisher<AuthenticationState, Never> {
        $authenticationState.eraseToAnyPublisher()
    }
    
    func signUp(userData: UserRegistrationData) async throws -> User {
        // Mock implementation
        try await Task.sleep(nanoseconds: 1_000_000_000)
        
        let user = User(
            username: userData.username,
            email: userData.email,
            city: userData.city,
            dateOfBirth: userData.dateOfBirth,
            vehicle: userData.vehicle
        )
        
        authenticationState = .emailVerificationRequired
        return user
    }
    
    func signIn(email: String, password: String) async throws -> User {
        // Mock implementation
        try await Task.sleep(nanoseconds: 1_000_000_000)
        
        let user = User(
            username: "Mock User",
            email: email,
            city: "Mock City",
            dateOfBirth: Date().addingTimeInterval(-25 * 365 * 24 * 60 * 60)
        )
        
        currentUser = user
        isAuthenticated = true
        authenticationState = .authenticated(user)
        
        return user
    }
    
    func signOut() async throws {
        try await Task.sleep(nanoseconds: 500_000_000)
        
        currentUser = nil
        isAuthenticated = false
        authenticationState = .unauthenticated
    }
    
    func resetPassword(email: String) async throws {
        try await Task.sleep(nanoseconds: 1_000_000_000)
        // Mock success
    }
    
    func verifyEmail(token: String) async throws {
        try await Task.sleep(nanoseconds: 1_000_000_000)
        // Mock success
    }
    
    func refreshToken() async throws {
        // Mock success
    }
    
    func enableBiometricAuth() async throws -> Bool {
        return true
    }
    
    func authenticateWithBiometrics() async throws -> User {
        guard let user = currentUser else {
            throw AuthenticationError.biometricAuthFailed
        }
        return user
    }
}