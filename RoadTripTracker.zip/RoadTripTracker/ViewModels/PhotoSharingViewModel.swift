import Foundation
import Combine
import UIKit
import CoreLocation
import Photos

// MARK: - Photo Sharing View Model
@MainActor
class PhotoSharingViewModel: ObservableObject {
    
    // MARK: - Published Properties
    @Published var tripPhotos: [PhotoShare] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var showingPhotoPicker: Bool = false
    @Published var showingCamera: Bool = false
    @Published var selectedPhotos: [PhotoShare] = []
    @Published var isSelectionMode: Bool = false
    @Published var downloadProgress: Double = 0.0
    @Published var isDownloading: Bool = false
    
    // Photo organization
    @Published var groupedPhotos: [PhotoGroup] = []
    @Published var sortOption: PhotoSortOption = .dateDescending
    @Published var filterOption: PhotoFilterOption = .all
    
    // Trip album
    @Published var tripAlbum: TripAlbum?
    @Published var showingAlbumCreation: Bool = false
    
    // MARK: - Private Properties
    private let photoSharingService: PhotoSharingServiceProtocol
    private let locationManager: LocationManager
    private var subscriptions = Set<AnyCancellable>()
    private var currentTripId: UUID?
    
    // Photo cache for performance
    private let photoCache = NSCache<NSString, UIImage>()
    
    // MARK: - Initialization
    init(
        photoSharingService: PhotoSharingServiceProtocol = PhotoSharingService(),
        locationManager: LocationManager = LocationManager.shared
    ) {
        self.photoSharingService = photoSharingService
        self.locationManager = locationManager
        
        setupPhotoCache()
        setupSubscriptions()
    }
    
    // MARK: - Public Methods
    
    func loadTripPhotos(for tripId: UUID) async {
        currentTripId = tripId
        isLoading = true
        errorMessage = nil
        
        do {
            let photos = try await photoSharingService.getTripPhotos(for: tripId)
            tripPhotos = photos
            organizePhotos()
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func sharePhoto(_ photo: UIImage, caption: String? = nil) async {
        guard let tripId = currentTripId else { return }
        
        isLoading = true
        errorMessage = nil
        
        do {
            // Get current location if available
            var location: CLLocationCoordinate2D?
            do {
                let currentLocation = try await locationManager.getCurrentLocation()
                location = currentLocation.coordinate
            } catch {
                // Continue without location if not available
            }
            
            let photoShare = try await photoSharingService.sharePhoto(
                photo,
                caption: caption,
                location: location,
                to: tripId
            )
            
            // Add to local array and reorganize
            tripPhotos.insert(photoShare, at: 0)
            organizePhotos()
            
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func shareMultiplePhotos(_ photos: [UIImage], captions: [String?] = []) async {
        guard let tripId = currentTripId else { return }
        
        isLoading = true
        errorMessage = nil
        
        var location: CLLocationCoordinate2D?
        do {
            let currentLocation = try await locationManager.getCurrentLocation()
            location = currentLocation.coordinate
        } catch {
            // Continue without location
        }
        
        var newPhotos: [PhotoShare] = []
        
        for (index, photo) in photos.enumerated() {
            do {
                let caption = index < captions.count ? captions[index] : nil
                let photoShare = try await photoSharingService.sharePhoto(
                    photo,
                    caption: caption,
                    location: location,
                    to: tripId
                )
                newPhotos.append(photoShare)
            } catch {
                // Continue with other photos if one fails
                continue
            }
        }
        
        // Add all new photos and reorganize
        tripPhotos.insert(contentsOf: newPhotos, at: 0)
        organizePhotos()
        
        isLoading = false
    }
    
    func deletePhoto(_ photoShare: PhotoShare) async {
        do {
            try await photoSharingService.deletePhoto(photoShare.id)
            
            // Remove from local arrays
            tripPhotos.removeAll { $0.id == photoShare.id }
            selectedPhotos.removeAll { $0.id == photoShare.id }
            organizePhotos()
            
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func deleteSelectedPhotos() async {
        let photosToDelete = selectedPhotos
        
        for photo in photosToDelete {
            await deletePhoto(photo)
        }
        
        selectedPhotos.removeAll()
        isSelectionMode = false
    }
    
    func downloadPhoto(_ photoShare: PhotoShare) async -> UIImage? {
        // Check cache first
        let cacheKey = photoShare.photoURL.absoluteString as NSString
        if let cachedImage = photoCache.object(forKey: cacheKey) {
            return cachedImage
        }
        
        do {
            let image = try await photoSharingService.downloadPhoto(from: photoShare.photoURL)
            
            // Cache the image
            photoCache.setObject(image, forKey: cacheKey)
            
            return image
        } catch {
            errorMessage = error.localizedDescription
            return nil
        }
    }
    
    func downloadAllPhotos() async {
        guard let tripId = currentTripId else { return }
        
        isDownloading = true
        downloadProgress = 0.0
        errorMessage = nil
        
        do {
            let images = try await photoSharingService.downloadAllPhotos(for: tripId)
            
            // Save to Photos app
            await saveImagesToPhotosApp(images)
            
            downloadProgress = 1.0
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isDownloading = false
    }
    
    func createTripAlbum() async {
        guard let tripId = currentTripId else { return }
        
        showingAlbumCreation = true
        errorMessage = nil
        
        do {
            let album = try await photoSharingService.createTripAlbum(for: tripId)
            tripAlbum = album
        } catch {
            errorMessage = error.localizedDescription
        }
        
        showingAlbumCreation = false
    }
    
    func togglePhotoSelection(_ photoShare: PhotoShare) {
        if selectedPhotos.contains(where: { $0.id == photoShare.id }) {
            selectedPhotos.removeAll { $0.id == photoShare.id }
        } else {
            selectedPhotos.append(photoShare)
        }
        
        // Exit selection mode if no photos selected
        if selectedPhotos.isEmpty {
            isSelectionMode = false
        }
    }
    
    func selectAllPhotos() {
        selectedPhotos = tripPhotos
    }
    
    func deselectAllPhotos() {
        selectedPhotos.removeAll()
        isSelectionMode = false
    }
    
    func setSortOption(_ option: PhotoSortOption) {
        sortOption = option
        organizePhotos()
    }
    
    func setFilterOption(_ option: PhotoFilterOption) {
        filterOption = option
        organizePhotos()
    }
    
    func clearError() {
        errorMessage = nil
    }
    
    func requestPhotoLibraryPermission() async -> Bool {
        let status = PHPhotoLibrary.authorizationStatus(for: .addOnly)
        
        switch status {
        case .authorized, .limited:
            return true
        case .notDetermined:
            let newStatus = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
            return newStatus == .authorized || newStatus == .limited
        case .denied, .restricted:
            return false
        @unknown default:
            return false
        }
    }
}

// MARK: - Private Methods
private extension PhotoSharingViewModel {
    
    func setupPhotoCache() {
        photoCache.countLimit = 100
        photoCache.totalCostLimit = 100 * 1024 * 1024 // 100MB
    }
    
    func setupSubscriptions() {
        // Subscribe to new photo shares
        photoSharingService.photoUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] photoShare in
                self?.handleNewPhotoShare(photoShare)
            }
            .store(in: &subscriptions)
    }
    
    func handleNewPhotoShare(_ photoShare: PhotoShare) {
        // Check if photo already exists (avoid duplicates)
        if !tripPhotos.contains(where: { $0.id == photoShare.id }) {
            tripPhotos.insert(photoShare, at: 0)
            organizePhotos()
        }
    }
    
    func organizePhotos() {
        var filteredPhotos = tripPhotos
        
        // Apply filter
        switch filterOption {
        case .all:
            break
        case .withLocation:
            filteredPhotos = filteredPhotos.filter { $0.location != nil }
        case .withoutLocation:
            filteredPhotos = filteredPhotos.filter { $0.location == nil }
        case .withCaption:
            filteredPhotos = filteredPhotos.filter { $0.caption != nil && !$0.caption!.isEmpty }
        case .today:
            filteredPhotos = filteredPhotos.filter { Calendar.current.isDateInToday($0.timestamp) }
        case .thisWeek:
            let weekAgo = Calendar.current.date(byAdding: .weekOfYear, value: -1, to: Date()) ?? Date()
            filteredPhotos = filteredPhotos.filter { $0.timestamp >= weekAgo }
        }
        
        // Apply sort
        switch sortOption {
        case .dateAscending:
            filteredPhotos.sort { $0.timestamp < $1.timestamp }
        case .dateDescending:
            filteredPhotos.sort { $0.timestamp > $1.timestamp }
        case .location:
            filteredPhotos.sort { (photo1, photo2) in
                if photo1.location != nil && photo2.location == nil {
                    return true
                } else if photo1.location == nil && photo2.location != nil {
                    return false
                } else {
                    return photo1.timestamp > photo2.timestamp
                }
            }
        }
        
        // Group photos
        groupedPhotos = groupPhotosByDate(filteredPhotos)
    }
    
    func groupPhotosByDate(_ photos: [PhotoShare]) -> [PhotoGroup] {
        let calendar = Calendar.current
        let grouped = Dictionary(grouping: photos) { photo in
            calendar.startOfDay(for: photo.timestamp)
        }
        
        return grouped.map { date, photos in
            PhotoGroup(date: date, photos: photos.sorted { $0.timestamp > $1.timestamp })
        }.sorted { $0.date > $1.date }
    }
    
    func saveImagesToPhotosApp(_ images: [UIImage]) async {
        guard await requestPhotoLibraryPermission() else {
            errorMessage = "Photo library access denied"
            return
        }
        
        for (index, image) in images.enumerated() {
            do {
                try await PHPhotoLibrary.shared().performChanges {
                    PHAssetCreationRequest.creationRequestForAsset(from: image)
                }
                
                // Update progress
                downloadProgress = Double(index + 1) / Double(images.count)
            } catch {
                // Continue with other images if one fails
                continue
            }
        }
    }
}

// MARK: - Photo Group Model
struct PhotoGroup: Identifiable {
    let id = UUID()
    let date: Date
    let photos: [PhotoShare]
    
    var displayDate: String {
        let formatter = DateFormatter()
        
        if Calendar.current.isDateInToday(date) {
            return "Today"
        } else if Calendar.current.isDateInYesterday(date) {
            return "Yesterday"
        } else if Calendar.current.isDate(date, equalTo: Date(), toGranularity: .weekOfYear) {
            formatter.dateFormat = "EEEE"
            return formatter.string(from: date)
        } else {
            formatter.dateStyle = .medium
            return formatter.string(from: date)
        }
    }
}

// MARK: - Photo Sort Options
enum PhotoSortOption: String, CaseIterable {
    case dateDescending = "newest_first"
    case dateAscending = "oldest_first"
    case location = "location"
    
    var displayName: String {
        switch self {
        case .dateDescending:
            return "Newest First"
        case .dateAscending:
            return "Oldest First"
        case .location:
            return "By Location"
        }
    }
}

// MARK: - Photo Filter Options
enum PhotoFilterOption: String, CaseIterable {
    case all = "all"
    case withLocation = "with_location"
    case withoutLocation = "without_location"
    case withCaption = "with_caption"
    case today = "today"
    case thisWeek = "this_week"
    
    var displayName: String {
        switch self {
        case .all:
            return "All Photos"
        case .withLocation:
            return "With Location"
        case .withoutLocation:
            return "Without Location"
        case .withCaption:
            return "With Caption"
        case .today:
            return "Today"
        case .thisWeek:
            return "This Week"
        }
    }
}