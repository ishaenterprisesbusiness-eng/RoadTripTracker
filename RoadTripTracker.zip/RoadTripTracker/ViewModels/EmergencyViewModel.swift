import Foundation
import CoreLocation
import Combine
import SwiftUI

// MARK: - Emergency View Model
@MainActor
class EmergencyViewModel: ObservableObject {
    
    // MARK: - Published Properties
    @Published var isEmergencyActive = false
    @Published var emergencyAlerts: [EmergencyAlert] = []
    @Published var nearbyEmergencyServices: [EmergencyService] = []
    @Published var isLoadingServices = false
    @Published var errorMessage: String?
    @Published var showingEmergencyAlert = false
    @Published var showingBreakdownAssistance = false
    @Published var showingEmergencyServices = false
    @Published var emergencyMessage = ""
    
    // MARK: - Private Properties
    private let emergencyService: EmergencyServiceProtocol
    private let locationManager: LocationManager
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Initialization
    init(emergencyService: EmergencyServiceProtocol, locationManager: LocationManager) {
        self.emergencyService = emergencyService
        self.locationManager = locationManager
        
        setupSubscriptions()
    }
    
    // MARK: - Public Methods
    
    func triggerPanicAlert() {
        Task {
            do {
                guard let location = await getCurrentLocation() else {
                    errorMessage = "Unable to get current location"
                    return
                }
                
                isEmergencyActive = true
                try await emergencyService.triggerEmergencyAlert(
                    location: location.coordinate,
                    message: emergencyMessage.isEmpty ? nil : emergencyMessage
                )
                
                // Provide haptic feedback
                let impactFeedback = UIImpactFeedbackGenerator(style: .heavy)
                impactFeedback.impactOccurred()
                
                showingEmergencyAlert = false
                emergencyMessage = ""
                
            } catch {
                errorMessage = "Failed to send emergency alert: \(error.localizedDescription)"
                isEmergencyActive = false
            }
        }
    }
    
    func requestBreakdownAssistance() {
        Task {
            do {
                guard let location = await getCurrentLocation() else {
                    errorMessage = "Unable to get current location"
                    return
                }
                
                guard let vehicle = getCurrentUserVehicle() else {
                    errorMessage = "Vehicle information not available"
                    return
                }
                
                try await emergencyService.sendBreakdownAssistance(
                    location: location.coordinate,
                    vehicleInfo: vehicle
                )
                
                showingBreakdownAssistance = false
                
            } catch {
                errorMessage = "Failed to request breakdown assistance: \(error.localizedDescription)"
            }
        }
    }
    
    func loadNearbyEmergencyServices() {
        Task {
            do {
                isLoadingServices = true
                
                guard let location = await getCurrentLocation() else {
                    errorMessage = "Unable to get current location"
                    isLoadingServices = false
                    return
                }
                
                nearbyEmergencyServices = try await emergencyService.findNearbyEmergencyServices(
                    location: location.coordinate
                )
                
                isLoadingServices = false
                
            } catch {
                errorMessage = "Failed to load emergency services: \(error.localizedDescription)"
                isLoadingServices = false
            }
        }
    }
    
    func cancelEmergencyAlert() {
        Task {
            do {
                try await emergencyService.cancelEmergencyAlert()
                isEmergencyActive = false
            } catch {
                errorMessage = "Failed to cancel emergency alert: \(error.localizedDescription)"
            }
        }
    }
    
    func callEmergencyService(_ service: EmergencyService) {
        guard let phoneURL = URL(string: "tel://\(service.phoneNumber)") else {
            errorMessage = "Invalid phone number"
            return
        }
        
        if UIApplication.shared.canOpenURL(phoneURL) {
            UIApplication.shared.open(phoneURL)
        } else {
            errorMessage = "Unable to make phone calls on this device"
        }
    }
    
    func getDirectionsToService(_ service: EmergencyService) {
        let mapsURL = URL(string: "http://maps.apple.com/?daddr=\(service.coordinate.latitude),\(service.coordinate.longitude)")!
        UIApplication.shared.open(mapsURL)
    }
    
    func dismissError() {
        errorMessage = nil
    }
    
    // MARK: - Private Methods
    
    private func setupSubscriptions() {
        emergencyService.emergencyAlerts
            .receive(on: DispatchQueue.main)
            .sink { [weak self] alert in
                self?.handleEmergencyAlert(alert)
            }
            .store(in: &cancellables)
    }
    
    private func handleEmergencyAlert(_ alert: EmergencyAlert) {
        emergencyAlerts.append(alert)
        
        // If it's our own alert, update the active state
        if alert.userId == getCurrentUserId() {
            switch alert.status {
            case .active:
                isEmergencyActive = true
            case .cancelled, .resolved:
                isEmergencyActive = false
            case .acknowledged:
                break
            }
        }
    }
    
    private func getCurrentLocation() async -> CLLocation? {
        do {
            return try await locationManager.getCurrentLocation()
        } catch {
            return nil
        }
    }
    
    private func getCurrentUserVehicle() -> Vehicle? {
        // This would get the current user's vehicle from the user service
        // For now, return a mock vehicle
        return Vehicle(
            make: "Toyota",
            model: "Camry",
            vehicleNumber: "ABC123",
            odometerReading: 50000,
            type: .sedan
        )
    }
    
    private func getCurrentUserId() -> UUID {
        // This would get the current user ID from the authentication service
        return UUID()
    }
}

// MARK: - Emergency Alert Display Model
struct EmergencyAlertDisplayModel: Identifiable {
    let id: UUID
    let alert: EmergencyAlert
    let userName: String
    let timeAgo: String
    let locationDescription: String
    
    init(alert: EmergencyAlert, userName: String) {
        self.id = alert.id
        self.alert = alert
        self.userName = userName
        self.timeAgo = RelativeDateTimeFormatter().localizedString(for: alert.timestamp, relativeTo: Date())
        self.locationDescription = "Lat: \(String(format: "%.4f", alert.location.latitude)), Lng: \(String(format: "%.4f", alert.location.longitude))"
    }
    
    var alertTypeIcon: String {
        switch alert.alertType {
        case .panic: return "exclamationmark.triangle.fill"
        case .breakdown: return "car.fill"
        case .accident: return "cross.circle.fill"
        case .medical: return "cross.fill"
        case .other: return "questionmark.circle.fill"
        }
    }
    
    var alertTypeColor: Color {
        switch alert.alertType {
        case .panic: return .red
        case .breakdown: return .orange
        case .accident: return .red
        case .medical: return .red
        case .other: return .blue
        }
    }
    
    var statusColor: Color {
        switch alert.status {
        case .active: return .red
        case .acknowledged: return .orange
        case .resolved: return .green
        case .cancelled: return .gray
        }
    }
}