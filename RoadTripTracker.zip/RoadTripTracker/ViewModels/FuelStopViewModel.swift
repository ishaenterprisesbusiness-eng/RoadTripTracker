import Foundation
import CoreLocation
import Combine

// MARK: - Fuel Stop View Model
@MainActor
class FuelStopViewModel: ObservableObject {
    @Published var nearbyGasStations: [GasStation] = []
    @Published var proposedFuelStops: [FuelStop] = []
    @Published var activeFuelStop: FuelStop?
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showingProposalSheet = false
    @Published var showingCheckInSheet = false
    @Published var selectedGasStation: GasStation?
    
    // Check-in form properties
    @Published var fuelAmount: String = ""
    @Published var fuelCost: String = ""
    @Published var checkInNotes: String = ""
    @Published var isReadyToContinue = false
    
    private let fuelStopService: FuelStopServiceProtocol
    private let locationManager: LocationManager
    private var cancellables = Set<AnyCancellable>()
    
    private var currentTripId: UUID?
    private var currentParticipantId: UUID?
    
    init(fuelStopService: FuelStopServiceProtocol, locationManager: LocationManager) {
        self.fuelStopService = fuelStopService
        self.locationManager = locationManager
        
        setupSubscriptions()
    }
    
    // MARK: - Setup
    
    private func setupSubscriptions() {
        // Subscribe to fuel stop updates
        fuelStopService.fuelStopUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] fuelStop in
                self?.handleFuelStopUpdate(fuelStop)
            }
            .store(in: &cancellables)
        
        // Subscribe to approach notifications
        fuelStopService.approachingFuelStopNotifications
            .receive(on: DispatchQueue.main)
            .sink { [weak self] notification in
                self?.handleApproachNotification(notification)
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Public Methods
    
    func setTripContext(tripId: UUID, participantId: UUID) {
        self.currentTripId = tripId
        self.currentParticipantId = participantId
        
        Task {
            await loadFuelStopsForTrip()
            await startLocationMonitoring()
        }
    }
    
    func searchNearbyGasStations() async {
        guard let location = locationManager.currentLocation else {
            errorMessage = "Location not available"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let gasStations = try await fuelStopService.findNearbyGasStations(
                coordinate: location.coordinate,
                radius: 10000 // 10km radius
            )
            
            nearbyGasStations = gasStations
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func searchGasStationsAlongRoute(_ route: [CLLocationCoordinate2D]) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let gasStations = try await fuelStopService.findGasStationsAlongRoute(
                route: route,
                searchRadius: 5000 // 5km from route
            )
            
            nearbyGasStations = gasStations
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func proposeFuelStop(gasStation: GasStation, notes: String? = nil) async {
        guard let tripId = currentTripId,
              let participantId = currentParticipantId else {
            errorMessage = "Trip context not set"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let fuelStop = try await fuelStopService.proposeFuelStop(
                gasStation: gasStation,
                tripId: tripId,
                proposedBy: participantId,
                notes: notes
            )
            
            // Add to proposed fuel stops if not already there
            if !proposedFuelStops.contains(where: { $0.id == fuelStop.id }) {
                proposedFuelStops.append(fuelStop)
            }
            
            showingProposalSheet = false
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func approveFuelStop(_ fuelStop: FuelStop) async {
        guard let participantId = currentParticipantId else {
            errorMessage = "Participant context not set"
            return
        }
        
        do {
            try await fuelStopService.approveFuelStop(
                fuelStopId: fuelStop.id,
                participantId: participantId
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func rejectFuelStop(_ fuelStop: FuelStop, reason: String? = nil) async {
        guard let participantId = currentParticipantId else {
            errorMessage = "Participant context not set"
            return
        }
        
        do {
            try await fuelStopService.rejectFuelStop(
                fuelStopId: fuelStop.id,
                participantId: participantId,
                reason: reason
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func checkInAtFuelStop() async {
        guard let fuelStop = activeFuelStop,
              let participantId = currentParticipantId else {
            errorMessage = "No active fuel stop or participant context"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let fuelAmountDouble = Double(fuelAmount)
            let fuelCostDouble = Double(fuelCost)
            
            try await fuelStopService.checkInAtFuelStop(
                fuelStopId: fuelStop.id,
                participantId: participantId,
                fuelAmount: fuelAmountDouble,
                fuelCost: fuelCostDouble,
                notes: checkInNotes.isEmpty ? nil : checkInNotes
            )
            
            // Mark as ready if checkbox is checked
            if isReadyToContinue {
                try await fuelStopService.markReadyToContinue(
                    fuelStopId: fuelStop.id,
                    participantId: participantId
                )
            }
            
            // Clear form
            clearCheckInForm()
            showingCheckInSheet = false
            
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func markReadyToContinue() async {
        guard let fuelStop = activeFuelStop,
              let participantId = currentParticipantId else {
            errorMessage = "No active fuel stop or participant context"
            return
        }
        
        do {
            try await fuelStopService.markReadyToContinue(
                fuelStopId: fuelStop.id,
                participantId: participantId
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func cancelFuelStop(_ fuelStop: FuelStop, reason: String? = nil) async {
        guard let participantId = currentParticipantId else {
            errorMessage = "Participant context not set"
            return
        }
        
        do {
            try await fuelStopService.cancelFuelStop(
                fuelStopId: fuelStop.id,
                cancelledBy: participantId,
                reason: reason
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    // MARK: - UI Helper Methods
    
    func showProposalSheet(for gasStation: GasStation) {
        selectedGasStation = gasStation
        showingProposalSheet = true
    }
    
    func showCheckInSheet() {
        showingCheckInSheet = true
    }
    
    func clearCheckInForm() {
        fuelAmount = ""
        fuelCost = ""
        checkInNotes = ""
        isReadyToContinue = false
    }
    
    func isParticipantCheckedIn(_ participantId: UUID) -> Bool {
        guard let fuelStop = activeFuelStop else { return false }
        return fuelStop.checkIns.contains { $0.participantId == participantId }
    }
    
    func isParticipantReady(_ participantId: UUID) -> Bool {
        guard let fuelStop = activeFuelStop else { return false }
        return fuelStop.checkIns.first { $0.participantId == participantId }?.isReadyToContinue ?? false
    }
    
    func getCheckInInfo(for participantId: UUID) -> FuelStopCheckIn? {
        return activeFuelStop?.checkIns.first { $0.participantId == participantId }
    }
    
    // MARK: - Private Methods
    
    private func loadFuelStopsForTrip() async {
        guard let tripId = currentTripId else { return }
        
        do {
            let fuelStops = try await fuelStopService.getFuelStopsForTrip(tripId: tripId)
            proposedFuelStops = fuelStops.filter { $0.proposalStatus != .completed && $0.proposalStatus != .cancelled }
            activeFuelStop = try await fuelStopService.getActiveFuelStop(tripId: tripId)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    private func startLocationMonitoring() async {
        guard let tripId = currentTripId,
              let location = locationManager.currentLocation else { return }
        
        do {
            try await fuelStopService.monitorApproachingFuelStops(
                tripId: tripId,
                participantLocation: location.coordinate
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    private func handleFuelStopUpdate(_ fuelStop: FuelStop) {
        // Update proposed fuel stops
        if let index = proposedFuelStops.firstIndex(where: { $0.id == fuelStop.id }) {
            proposedFuelStops[index] = fuelStop
        } else if fuelStop.proposalStatus != .completed && fuelStop.proposalStatus != .cancelled {
            proposedFuelStops.append(fuelStop)
        }
        
        // Update active fuel stop
        if fuelStop.proposalStatus == .active {
            activeFuelStop = fuelStop
        } else if activeFuelStop?.id == fuelStop.id && fuelStop.proposalStatus == .completed {
            activeFuelStop = nil
        }
        
        // Remove completed or cancelled stops from proposed list
        proposedFuelStops.removeAll { $0.proposalStatus == .completed || $0.proposalStatus == .cancelled }
    }
    
    private func handleApproachNotification(_ notification: FuelStopApproachNotification) {
        // Handle approach notifications - could show alerts or update UI
        print("Approaching fuel stop: \(notification.gasStation.name)")
    }
}