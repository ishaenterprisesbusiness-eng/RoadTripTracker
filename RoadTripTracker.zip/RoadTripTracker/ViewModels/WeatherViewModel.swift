import Foundation
import Combine
import CoreLocation

@MainActor
class WeatherViewModel: ObservableObject {
    // MARK: - Published Properties
    @Published var currentWeather: WeatherData?
    @Published var weatherForecast: [WeatherData] = []
    @Published var weatherAlerts: [WeatherAlert] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var showingError: Bool = false
    
    // Weather for destinations
    @Published var destinationWeather: [UUID: WeatherData] = [:]
    @Published var destinationForecasts: [UUID: [WeatherData]] = [:]
    @Published var destinationAlerts: [UUID: [WeatherAlert]] = [:]
    
    // Weather-based recommendations
    @Published var weatherRecommendations: [WeatherRecommendation] = []
    @Published var weatherStopRecommendations: [WeatherStopRecommendation] = []
    @Published var severeWeatherWarnings: [WeatherAlert] = []
    
    // MARK: - Private Properties
    private let weatherService: WeatherServiceProtocol
    private let notificationService: NotificationServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    private var weatherUpdateTimer: Timer?
    
    // MARK: - Initialization
    init(
        weatherService: WeatherServiceProtocol? = nil,
        notificationService: NotificationServiceProtocol? = nil
    ) {
        self.weatherService = weatherService ?? ServiceContainer.shared.weatherService
        self.notificationService = notificationService ?? ServiceContainer.shared.notificationService
        
        setupWeatherUpdates()
    }
    
    deinit {
        weatherUpdateTimer?.invalidate()
    }
    
    // MARK: - Public Methods
    
    func loadCurrentWeather(for coordinate: CLLocationCoordinate2D) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let weather = try await weatherService.getCurrentWeather(for: coordinate)
            currentWeather = weather
            
            // Check for severe weather and generate recommendations
            await checkForSevereWeather(weather: weather)
            await generateWeatherRecommendations(weather: weather)
            await generateWeatherStopRecommendations(weather: weather, coordinate: coordinate)
            
        } catch {
            errorMessage = error.localizedDescription
            showingError = true
        }
        
        isLoading = false
    }
    
    func loadWeatherForecast(for coordinate: CLLocationCoordinate2D, days: Int = 5) async {
        do {
            let forecast = try await weatherService.getWeatherForecast(for: coordinate, days: days)
            weatherForecast = forecast
            
            // Check forecast for severe weather
            for weather in forecast {
                await checkForSevereWeather(weather: weather)
            }
            
        } catch {
            errorMessage = error.localizedDescription
            showingError = true
        }
    }
    
    func loadWeatherAlerts(for coordinate: CLLocationCoordinate2D) async {
        do {
            let alerts = try await weatherService.getWeatherAlerts(for: coordinate)
            weatherAlerts = alerts
            
            // Filter severe alerts for warnings
            severeWeatherWarnings = alerts.filter { alert in
                alert.severity == .severe || alert.severity == .extreme
            }
            
            // Send notifications for severe weather
            for alert in severeWeatherWarnings {
                await sendSevereWeatherNotification(alert: alert)
            }
            
        } catch {
            errorMessage = error.localizedDescription
            showingError = true
        }
    }
    
    func loadDestinationWeather(for destinations: [Destination]) async {
        for destination in destinations {
            do {
                // Load current weather
                let weather = try await weatherService.getCurrentWeather(for: destination.coordinate)
                destinationWeather[destination.id] = weather
                
                // Load forecast
                let forecast = try await weatherService.getWeatherForecast(for: destination.coordinate, days: 3)
                destinationForecasts[destination.id] = forecast
                
                // Load alerts
                let alerts = try await weatherService.getWeatherAlerts(for: destination.coordinate)
                destinationAlerts[destination.id] = alerts
                
                // Check for severe weather at destination
                await checkForSevereWeather(weather: weather)
                
            } catch {
                print("Failed to load weather for destination \(destination.name): \(error)")
            }
        }
    }
    
    func loadWeatherForApproachingDestinations(destinations: [Destination], currentLocation: CLLocationCoordinate2D, proximityThreshold: CLLocationDistance = 50000) async {
        // Filter destinations within proximity threshold (default 50km)
        let approachingDestinations = destinations.filter { destination in
            let distance = CLLocation(latitude: currentLocation.latitude, longitude: currentLocation.longitude)
                .distance(from: CLLocation(latitude: destination.coordinate.latitude, longitude: destination.coordinate.longitude))
            return distance <= proximityThreshold
        }
        
        await loadDestinationWeather(for: approachingDestinations)
        
        // Send notifications for severe weather at approaching destinations
        for destination in approachingDestinations {
            if let weather = destinationWeather[destination.id],
               let alerts = destinationAlerts[destination.id] {
                
                let severeAlerts = alerts.filter { $0.severity == .severe || $0.severity == .extreme }
                for alert in severeAlerts {
                    await sendApproachingDestinationWeatherAlert(destination: destination, alert: alert)
                }
            }
        }
    }
    
    private func sendApproachingDestinationWeatherAlert(destination: Destination, alert: WeatherAlert) async {
        do {
            await notificationService.sendNotification(
                title: "Weather Alert at \(destination.name)",
                body: "\(alert.title): \(alert.description)",
                userInfo: [
                    "type": "approaching_destination_weather",
                    "destination_id": destination.id.uuidString,
                    "alert_severity": alert.severity.rawValue
                ]
            )
        } catch {
            print("Failed to send approaching destination weather alert: \(error)")
        }
    }
    
    func refreshWeatherData(for coordinate: CLLocationCoordinate2D) async {
        await loadCurrentWeather(for: coordinate)
        await loadWeatherForecast(for: coordinate)
        await loadWeatherAlerts(for: coordinate)
    }
    
    func getWeatherIcon(for condition: WeatherCondition) -> String {
        switch condition {
        case .clear:
            return "sun.max.fill"
        case .partlyCloudy:
            return "cloud.sun.fill"
        case .cloudy:
            return "cloud.fill"
        case .rain:
            return "cloud.rain.fill"
        case .snow:
            return "cloud.snow.fill"
        case .thunderstorm:
            return "cloud.bolt.rain.fill"
        case .fog:
            return "cloud.fog.fill"
        case .unknown:
            return "questionmark.circle.fill"
        }
    }
    
    func getAlertColor(for severity: WeatherAlertSeverity) -> String {
        switch severity {
        case .minor:
            return "blue"
        case .moderate:
            return "yellow"
        case .severe:
            return "orange"
        case .extreme:
            return "red"
        }
    }
    
    // MARK: - Private Methods
    
    private func setupWeatherUpdates() {
        // Update weather every 30 minutes
        weatherUpdateTimer = Timer.scheduledTimer(withTimeInterval: 1800, repeats: true) { [weak self] _ in
            Task { @MainActor in
                await self?.updateWeatherIfNeeded()
            }
        }
    }
    
    private func updateWeatherIfNeeded() async {
        // This method would be called to refresh weather data periodically
        // Implementation depends on current location and active trip
    }
    
    private func checkForSevereWeather(weather: WeatherData) async {
        var shouldAlert = false
        var alertMessage = ""
        
        // Check for severe conditions
        if weather.condition == .thunderstorm {
            shouldAlert = true
            alertMessage = "Thunderstorm conditions detected"
        } else if weather.condition == .snow {
            shouldAlert = true
            alertMessage = "Snow conditions detected"
        } else if weather.windSpeed > 50 { // km/h
            shouldAlert = true
            alertMessage = "High wind conditions detected"
        } else if weather.visibility < 1.0 { // km
            shouldAlert = true
            alertMessage = "Low visibility conditions detected"
        }
        
        if shouldAlert {
            await sendWeatherWarningNotification(message: alertMessage, location: weather.location)
        }
    }
    
    private func generateWeatherRecommendations(weather: WeatherData) async {
        var recommendations: [WeatherRecommendation] = []
        
        // Generate recommendations based on weather conditions
        if weather.condition == .rain {
            recommendations.append(WeatherRecommendation(
                type: .drivingCondition,
                title: "Rainy Conditions",
                message: "Consider reducing speed and increasing following distance",
                priority: .medium
            ))
        }
        
        if weather.temperature < 5 {
            recommendations.append(WeatherRecommendation(
                type: .clothing,
                title: "Cold Weather",
                message: "Pack warm clothing and check tire pressure",
                priority: .medium
            ))
        }
        
        if weather.temperature > 35 {
            recommendations.append(WeatherRecommendation(
                type: .hydration,
                title: "Hot Weather",
                message: "Stay hydrated and check vehicle cooling system",
                priority: .medium
            ))
        }
        
        if weather.uvIndex > 8 {
            recommendations.append(WeatherRecommendation(
                type: .sunProtection,
                title: "High UV Index",
                message: "Use sunscreen and consider UV-protective clothing",
                priority: .low
            ))
        }
        
        weatherRecommendations = recommendations
    }
    
    private func sendSevereWeatherNotification(alert: WeatherAlert) async {
        // Send notification for severe weather alerts
        // Implementation would use the notification service
    }
    
    private func sendWeatherWarningNotification(message: String, location: CLLocationCoordinate2D) async {
        // Send notification for weather warnings
        do {
            await notificationService.sendNotification(
                title: "Weather Warning",
                body: message,
                userInfo: [
                    "type": "weather_warning",
                    "latitude": location.latitude,
                    "longitude": location.longitude
                ]
            )
        } catch {
            print("Failed to send weather warning notification: \(error)")
        }
    }
    
    private func generateWeatherStopRecommendations(weather: WeatherData, coordinate: CLLocationCoordinate2D) async {
        do {
            let recommendations = try await weatherService.getWeatherBasedStopRecommendations(
                for: coordinate,
                currentWeather: weather
            )
            weatherStopRecommendations = recommendations
            
            // Send notifications for high priority recommendations
            for recommendation in recommendations where recommendation.priority == .high || recommendation.priority == .critical {
                await sendWeatherStopRecommendationNotification(recommendation: recommendation)
            }
            
        } catch {
            print("Failed to generate weather stop recommendations: \(error)")
        }
    }
    
    private func sendWeatherStopRecommendationNotification(recommendation: WeatherStopRecommendation) async {
        do {
            await notificationService.sendNotification(
                title: recommendation.title,
                body: recommendation.description,
                userInfo: [
                    "type": "weather_stop_recommendation",
                    "priority": recommendation.priority.rawValue,
                    "recommendation_id": recommendation.id.uuidString
                ]
            )
        } catch {
            print("Failed to send weather stop recommendation notification: \(error)")
        }
    }
}

// MARK: - Weather Recommendation Model
struct WeatherRecommendation: Identifiable {
    let id = UUID()
    let type: RecommendationType
    let title: String
    let message: String
    let priority: RecommendationPriority
    
    enum RecommendationType {
        case drivingCondition
        case clothing
        case hydration
        case sunProtection
        case stopRecommendation
    }
    
    enum RecommendationPriority {
        case low
        case medium
        case high
    }
}