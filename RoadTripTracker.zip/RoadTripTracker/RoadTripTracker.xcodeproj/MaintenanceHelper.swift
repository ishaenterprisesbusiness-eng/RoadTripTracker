#!/usr/bin/env swift

import Foundation

/*
 This script cleans Xcode build artifacts by:
 1. Deleting the Derived Data folder.
 2. Printing terminal commands to clean and build projects.
 3. Reminding the user to check Build Settings, Executable, and Target Type manually in Xcode.
*/

let fileManager = FileManager.default
let derivedDataPath = ("~/Library/Developer/Xcode/DerivedData" as NSString).expandingTildeInPath

print("Attempting to remove Derived Data at:")
print("  \(derivedDataPath)")

do {
    if fileManager.fileExists(atPath: derivedDataPath) {
        try fileManager.removeItem(atPath: derivedDataPath)
        print("✅ Successfully deleted the Derived Data folder.")
    } else {
        print("ℹ️ Derived Data folder does not exist, no deletion needed.")
    }
} catch {
    print("❌ Failed to delete Derived Data folder: \(error.localizedDescription)")
}

print("\n---")
print("To clean build artifacts via command line, you can use the following commands:\n")
print("# Clean build folder for a specific workspace and scheme")
print("xcodebuild clean -workspace YourWorkspace.xcworkspace -scheme YourScheme")
print("\n# Build the project")
print("xcodebuild build -workspace YourWorkspace.xcworkspace -scheme YourScheme\n")

print("---")
print("\n⚠️ REMINDERS (UI/MANUAL STEPS REQUIRED):")
print("- Please check your Build Settings in Xcode to verify configurations.")
print("- Verify the Executable set in your scheme's Run action.")
print("- Confirm the Target Type is correct for your build.")
