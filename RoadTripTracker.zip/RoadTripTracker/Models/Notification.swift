import Foundation
import CoreLocation
import UserNotifications

// MARK: - Notification Models

// MARK: - Basic Notification
struct Notification: Codable, Identifiable {
    let id: UUID
    let type: TripNotificationType
    let title: String
    let message: String
    let tripId: UUID?
    let senderId: UUID?
    let timestamp: Date
    
    init(id: UUID = UUID(), type: TripNotificationType, title: String, message: String, tripId: UUID? = nil, senderId: UUID? = nil, timestamp: Date = Date()) {
        self.id = id
        self.type = type
        self.title = title
        self.message = message
        self.tripId = tripId
        self.senderId = senderId
        self.timestamp = timestamp
    }
}

// MARK: - Trip Notification
struct TripNotification: Codable, Identifiable {
    let id: UUID
    let tripId: UUID
    let type: TripNotificationType
    let title: String
    let message: String
    let timestamp: Date
    let isRead: Bool
    let priority: NotificationPriority
    let data: [String: String]?
    
    init(id: UUID = UUID(), tripId: UUID, type: TripNotificationType, title: String, message: String, timestamp: Date = Date(), isRead: Bool = false, priority: NotificationPriority = .normal, data: [String: String]? = nil) {
        self.id = id
        self.tripId = tripId
        self.type = type
        self.title = title
        self.message = message
        self.timestamp = timestamp
        self.isRead = isRead
        self.priority = priority
        self.data = data
    }
}

// MARK: - Trip Notification Type
enum TripNotificationType: String, Codable, CaseIterable {
    case participantJoined = "participant_joined"
    case participantLeft = "participant_left"
    case approachingDestination = "approaching_destination"
    case destinationReached = "destination_reached"
    case routeUpdated = "route_updated"
    case fuelStopProposed = "fuel_stop_proposed"
    case foodStopProposed = "food_stop_proposed"
    case poiProposal = "poi_proposal"
    case poiDecision = "poi_decision"
    case nearbyPOI = "nearby_poi"
    case emergencyAlert = "emergency_alert"
    case weatherAlert = "weather_alert"
    case budgetAlert = "budget_alert"
    case tripStarted = "trip_started"
    case tripCompleted = "trip_completed"
    case checkInReminder = "check_in_reminder"
    
    var displayName: String {
        switch self {
        case .participantJoined: return "Participant Joined"
        case .participantLeft: return "Participant Left"
        case .approachingDestination: return "Approaching Destination"
        case .destinationReached: return "Destination Reached"
        case .routeUpdated: return "Route Updated"
        case .fuelStopProposed: return "Fuel Stop Proposed"
        case .foodStopProposed: return "Food Stop Proposed"
        case .poiProposal: return "POI Proposal"
        case .poiDecision: return "POI Decision"
        case .nearbyPOI: return "Nearby Attraction"
        case .emergencyAlert: return "Emergency Alert"
        case .weatherAlert: return "Weather Alert"
        case .budgetAlert: return "Budget Alert"
        case .tripStarted: return "Trip Started"
        case .tripCompleted: return "Trip Completed"
        case .checkInReminder: return "Check-in Reminder"
        }
    }
    
    var defaultPriority: NotificationPriority {
        switch self {
        case .emergencyAlert: return .emergency
        case .weatherAlert, .approachingDestination: return .high
        case .participantJoined, .participantLeft, .routeUpdated, .tripStarted, .poiProposal, .poiDecision: return .normal
        case .budgetAlert, .checkInReminder, .nearbyPOI: return .low
        default: return .normal
        }
    }
}

// MARK: - Emergency Notification
struct EmergencyNotification: Codable, Identifiable {
    let id: UUID
    let tripId: UUID
    let participantId: UUID
    let type: EmergencyType
    let message: String
    let location: CLLocationCoordinate2D
    let timestamp: Date
    let isResolved: Bool
    let resolvedAt: Date?
    
    init(id: UUID = UUID(), tripId: UUID, participantId: UUID, type: EmergencyType, message: String, location: CLLocationCoordinate2D, timestamp: Date = Date(), isResolved: Bool = false, resolvedAt: Date? = nil) {
        self.id = id
        self.tripId = tripId
        self.participantId = participantId
        self.type = type
        self.message = message
        self.location = location
        self.timestamp = timestamp
        self.isResolved = isResolved
        self.resolvedAt = resolvedAt
    }
}

// MARK: - Emergency Type
enum EmergencyType: String, Codable, CaseIterable {
    case accident = "accident"
    case breakdown = "breakdown"
    case medical = "medical"
    case security = "security"
    case weather = "weather"
    case other = "other"
    
    var displayName: String {
        switch self {
        case .accident: return "Accident"
        case .breakdown: return "Vehicle Breakdown"
        case .medical: return "Medical Emergency"
        case .security: return "Security Issue"
        case .weather: return "Weather Emergency"
        case .other: return "Other Emergency"
        }
    }
    
    var icon: String {
        switch self {
        case .accident: return "car.fill"
        case .breakdown: return "wrench.fill"
        case .medical: return "cross.fill"
        case .security: return "shield.fill"
        case .weather: return "cloud.bolt.fill"
        case .other: return "exclamationmark.triangle.fill"
        }
    }
}

// MARK: - Location Alert
struct LocationAlert: Codable, Identifiable {
    let id: UUID
    let tripId: UUID
    let participantId: UUID
    let destinationId: UUID
    let alertType: LocationAlertType
    let distance: CLLocationDistance
    let estimatedArrival: Date?
    let timestamp: Date
    let isTriggered: Bool
    
    init(id: UUID = UUID(), tripId: UUID, participantId: UUID, destinationId: UUID, alertType: LocationAlertType, distance: CLLocationDistance, estimatedArrival: Date? = nil, timestamp: Date = Date(), isTriggered: Bool = false) {
        self.id = id
        self.tripId = tripId
        self.participantId = participantId
        self.destinationId = destinationId
        self.alertType = alertType
        self.distance = distance
        self.estimatedArrival = estimatedArrival
        self.timestamp = timestamp
        self.isTriggered = isTriggered
    }
}

// MARK: - Location Alert Type
enum LocationAlertType: String, Codable, CaseIterable {
    case approaching = "approaching"      // 5km away
    case nearby = "nearby"               // 1km away
    case arrived = "arrived"             // 100m away
    case departed = "departed"           // Left the location
    
    var distance: CLLocationDistance {
        switch self {
        case .approaching: return 5000  // 5km
        case .nearby: return 1000       // 1km
        case .arrived: return 100       // 100m
        case .departed: return 200      // 200m (for exit detection)
        }
    }
    
    var displayName: String {
        switch self {
        case .approaching: return "Approaching"
        case .nearby: return "Nearby"
        case .arrived: return "Arrived"
        case .departed: return "Departed"
        }
    }
}

// MARK: - Notification Template
struct NotificationTemplate {
    let type: TripNotificationType
    let titleTemplate: String
    let bodyTemplate: String
    let priority: NotificationPriority
    
    static let templates: [TripNotificationType: NotificationTemplate] = [
        .participantJoined: NotificationTemplate(
            type: .participantJoined,
            titleTemplate: "New Participant",
            bodyTemplate: "{username} has joined {tripName}",
            priority: .normal
        ),
        .participantLeft: NotificationTemplate(
            type: .participantLeft,
            titleTemplate: "Participant Left",
            bodyTemplate: "{username} has left {tripName}",
            priority: .normal
        ),
        .approachingDestination: NotificationTemplate(
            type: .approachingDestination,
            titleTemplate: "Approaching Destination",
            bodyTemplate: "{username} is {distance} from {destinationName}",
            priority: .high
        ),
        .destinationReached: NotificationTemplate(
            type: .destinationReached,
            titleTemplate: "Destination Reached",
            bodyTemplate: "{username} has arrived at {destinationName}",
            priority: .normal
        ),
        .emergencyAlert: NotificationTemplate(
            type: .emergencyAlert,
            titleTemplate: "🚨 EMERGENCY ALERT",
            bodyTemplate: "{username}: {message}",
            priority: .emergency
        ),
        .weatherAlert: NotificationTemplate(
            type: .weatherAlert,
            titleTemplate: "⚠️ Weather Alert",
            bodyTemplate: "{alertType} warning for {location}: {description}",
            priority: .high
        ),
        .budgetAlert: NotificationTemplate(
            type: .budgetAlert,
            titleTemplate: "Budget Alert",
            bodyTemplate: "Trip budget is {percentage}% used ({spent} of {total})",
            priority: .low
        ),
        .tripStarted: NotificationTemplate(
            type: .tripStarted,
            titleTemplate: "Trip Started",
            bodyTemplate: "{tripName} has begun! Safe travels everyone.",
            priority: .normal
        ),
        .tripCompleted: NotificationTemplate(
            type: .tripCompleted,
            titleTemplate: "Trip Completed",
            bodyTemplate: "{tripName} has been completed. Hope you had a great journey!",
            priority: .normal
        ),
        .checkInReminder: NotificationTemplate(
            type: .checkInReminder,
            titleTemplate: "Check-in Reminder",
            bodyTemplate: "Haven't heard from you in a while. Please check in when safe.",
            priority: .low
        ),
        .poiProposal: NotificationTemplate(
            type: .poiProposal,
            titleTemplate: "New POI Proposal",
            bodyTemplate: "{username} proposed adding {poiName} as a stop",
            priority: .normal
        ),
        .poiDecision: NotificationTemplate(
            type: .poiDecision,
            titleTemplate: "POI {decision}",
            bodyTemplate: "{poiName} has been {decision} as a trip stop",
            priority: .normal
        ),
        .nearbyPOI: NotificationTemplate(
            type: .nearbyPOI,
            titleTemplate: "Nearby Attraction",
            bodyTemplate: "{poiName} is nearby - {category} • {distance} away",
            priority: .low
        )
    ]
    
    func generateNotification(with parameters: [String: String]) -> (title: String, body: String) {
        var title = titleTemplate
        var body = bodyTemplate
        
        for (key, value) in parameters {
            title = title.replacingOccurrences(of: "{\(key)}", with: value)
            body = body.replacingOccurrences(of: "{\(key)}", with: value)
        }
        
        return (title: title, body: body)
    }
}

// MARK: - Local Notification
struct LocalNotification {
    let identifier: String
    let title: String
    let body: String
    let sound: UNNotificationSound?
    let badge: NSNumber?
    let userInfo: [AnyHashable: Any]?
    let trigger: UNNotificationTrigger?
    
    init(identifier: String, title: String, body: String, sound: UNNotificationSound? = .default, badge: NSNumber? = nil, userInfo: [AnyHashable: Any]? = nil, trigger: UNNotificationTrigger? = nil) {
        self.identifier = identifier
        self.title = title
        self.body = body
        self.sound = sound
        self.badge = badge
        self.userInfo = userInfo
        self.trigger = trigger
    }
}

// MARK: - Push Notification
struct PushNotification {
    let recipientIds: [UUID]
    let title: String
    let body: String
    let data: [String: Any]?
    let priority: NotificationPriority
    
    init(recipientIds: [UUID], title: String, body: String, data: [String: Any]? = nil, priority: NotificationPriority = .normal) {
        self.recipientIds = recipientIds
        self.title = title
        self.body = body
        self.data = data
        self.priority = priority
    }
}

// MARK: - Notification Priority
enum NotificationPriority: String, Codable, CaseIterable {
    case low = "low"
    case normal = "normal"
    case high = "high"
    case emergency = "emergency"
}

// MARK: - Notification History
struct NotificationHistory: Codable {
    var notifications: [TripNotification]
    var emergencyNotifications: [EmergencyNotification]
    var lastCleanupDate: Date
    
    init() {
        self.notifications = []
        self.emergencyNotifications = []
        self.lastCleanupDate = Date()
    }
    
    mutating func addNotification(_ notification: TripNotification) {
        notifications.append(notification)
        cleanupOldNotifications()
    }
    
    mutating func addEmergencyNotification(_ notification: EmergencyNotification) {
        emergencyNotifications.append(notification)
    }
    
    mutating func markAsRead(_ notificationId: UUID) {
        if let index = notifications.firstIndex(where: { $0.id == notificationId }) {
            notifications[index] = TripNotification(
                id: notifications[index].id,
                tripId: notifications[index].tripId,
                type: notifications[index].type,
                title: notifications[index].title,
                message: notifications[index].message,
                timestamp: notifications[index].timestamp,
                isRead: true,
                priority: notifications[index].priority,
                data: notifications[index].data
            )
        }
    }
    
    private mutating func cleanupOldNotifications() {
        let thirtyDaysAgo = Calendar.current.date(byAdding: .day, value: -30, to: Date()) ?? Date()
        notifications.removeAll { $0.timestamp < thirtyDaysAgo }
        
        let sevenDaysAgo = Calendar.current.date(byAdding: .day, value: -7, to: Date()) ?? Date()
        emergencyNotifications.removeAll { $0.timestamp < sevenDaysAgo && $0.isResolved }
        
        lastCleanupDate = Date()
    }
}