import Foundation
import CoreLocation

// MARK: - Fuel Stop Model
struct FuelStop: Codable, Identifiable {
    let id: UUID
    var tripId: UUID
    var proposedBy: UUID
    var gasStation: GasStation
    var proposalStatus: StopProposalStatus
    var approvals: [UUID] // Participant IDs who approved
    var rejections: [UUID] // Participant IDs who rejected
    var checkIns: [FuelStopCheckIn]
    var proposedTime: Date
    var actualArrivalTime: Date?
    var notes: String?
    
    init(id: UUID = UUID(), tripId: UUID, proposedBy: UUID, gasStation: GasStation, proposalStatus: StopProposalStatus = .pending, approvals: [UUID] = [], rejections: [UUID] = [], checkIns: [FuelStopCheckIn] = [], proposedTime: Date = Date(), actualArrivalTime: Date? = nil, notes: String? = nil) {
        self.id = id
        self.tripId = tripId
        self.proposedBy = proposedBy
        self.gasStation = gasStation
        self.proposalStatus = proposalStatus
        self.approvals = approvals
        self.rejections = rejections
        self.checkIns = checkIns
        self.proposedTime = proposedTime
        self.actualArrivalTime = actualArrivalTime
        self.notes = notes
    }
}

// MARK: - Gas Station Model
struct GasStation: Codable, Identifiable {
    let id: String
    var name: String
    var brand: String?
    var address: String
    var coordinate: CLLocationCoordinate2D
    var phoneNumber: String?
    var isOpen24Hours: Bool
    var currentFuelPrices: [FuelType: Double]?
    var amenities: [GasStationAmenity]
    var rating: Double?
    var distanceFromRoute: CLLocationDistance?
    
    init(id: String, name: String, brand: String? = nil, address: String, coordinate: CLLocationCoordinate2D, phoneNumber: String? = nil, isOpen24Hours: Bool = false, currentFuelPrices: [FuelType: Double]? = nil, amenities: [GasStationAmenity] = [], rating: Double? = nil, distanceFromRoute: CLLocationDistance? = nil) {
        self.id = id
        self.name = name
        self.brand = brand
        self.address = address
        self.coordinate = coordinate
        self.phoneNumber = phoneNumber
        self.isOpen24Hours = isOpen24Hours
        self.currentFuelPrices = currentFuelPrices
        self.amenities = amenities
        self.rating = rating
        self.distanceFromRoute = distanceFromRoute
    }
}

// MARK: - Fuel Stop Check-In
struct FuelStopCheckIn: Codable, Identifiable {
    let id: UUID
    var participantId: UUID
    var checkInTime: Date
    var isReadyToContinue: Bool
    var fuelAmount: Double?
    var fuelCost: Double?
    var notes: String?
    
    init(id: UUID = UUID(), participantId: UUID, checkInTime: Date = Date(), isReadyToContinue: Bool = false, fuelAmount: Double? = nil, fuelCost: Double? = nil, notes: String? = nil) {
        self.id = id
        self.participantId = participantId
        self.checkInTime = checkInTime
        self.isReadyToContinue = isReadyToContinue
        self.fuelAmount = fuelAmount
        self.fuelCost = fuelCost
        self.notes = notes
    }
}

// MARK: - Stop Proposal Status
enum StopProposalStatus: String, Codable, CaseIterable {
    case pending = "pending"
    case approved = "approved"
    case rejected = "rejected"
    case active = "active"
    case completed = "completed"
    case cancelled = "cancelled"
    
    var displayName: String {
        switch self {
        case .pending: return "Pending Approval"
        case .approved: return "Approved"
        case .rejected: return "Rejected"
        case .active: return "Active"
        case .completed: return "Completed"
        case .cancelled: return "Cancelled"
        }
    }
}

// MARK: - Fuel Type
enum FuelType: String, Codable, CaseIterable {
    case regular = "regular"
    case premium = "premium"
    case diesel = "diesel"
    case electric = "electric"
    case lpg = "lpg"
    
    var displayName: String {
        switch self {
        case .regular: return "Regular"
        case .premium: return "Premium"
        case .diesel: return "Diesel"
        case .electric: return "Electric"
        case .lpg: return "LPG"
        }
    }
}

// MARK: - Gas Station Amenity
enum GasStationAmenity: String, Codable, CaseIterable {
    case restroom = "restroom"
    case convenience = "convenience_store"
    case restaurant = "restaurant"
    case carWash = "car_wash"
    case atm = "atm"
    case airPump = "air_pump"
    case evCharging = "ev_charging"
    case wifi = "wifi"
    case parking = "parking"
    
    var displayName: String {
        switch self {
        case .restroom: return "Restroom"
        case .convenience: return "Convenience Store"
        case .restaurant: return "Restaurant"
        case .carWash: return "Car Wash"
        case .atm: return "ATM"
        case .airPump: return "Air Pump"
        case .evCharging: return "EV Charging"
        case .wifi: return "WiFi"
        case .parking: return "Parking"
        }
    }
    
    var icon: String {
        switch self {
        case .restroom: return "toilet"
        case .convenience: return "cart"
        case .restaurant: return "fork.knife"
        case .carWash: return "car.wash"
        case .atm: return "creditcard"
        case .airPump: return "wind"
        case .evCharging: return "bolt.car"
        case .wifi: return "wifi"
        case .parking: return "car"
        }
    }
}