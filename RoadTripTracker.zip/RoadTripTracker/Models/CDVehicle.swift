import Foundation
import CoreData

@objc(CDVehicle)
public class CDVehicle: NSManagedObject {
    
}

extension CDVehicle {
    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDVehicle> {
        return NSFetchRequest<CDVehicle>(entityName: "CDVehicle")
    }
    
    @NSManaged public var id: UUID?
    @NSManaged public var make: String?
    @NSManaged public var model: String?
    @NSManaged public var year: Int16
    @NSManaged public var color: String?
    @NSManaged public var licensePlate: String?
    @NSManaged public var vehicleType: String?
    @NSManaged public var fuelType: String?
    @NSManaged public var seatingCapacity: Int16
    @NSManaged public var fuelCapacity: Double
    @NSManaged public var averageFuelConsumption: Double // L/100km or MPG
    @NSManaged public var isElectric: Bool
    @NSManaged public var batteryCapacity: Double // kWh for electric vehicles
    @NSManaged public var range: Double // km or miles
    @NSManaged public var createdAt: Date?
    @NSManaged public var updatedAt: Date?
    @NSManaged public var owner: CDUser?
}

// MARK: - Computed Properties
extension CDVehicle {
    var displayName: String {
        let makeModel = "\(make ?? "") \(model ?? "")".trimmingCharacters(in: .whitespaces)
        if !makeModel.isEmpty {
            if year > 0 {
                return "\(year) \(makeModel)"
            }
            return makeModel
        }
        return "Vehicle"
    }
    
    var shortDisplayName: String {
        if let make = make, let model = model {
            return "\(make) \(model)"
        }
        return displayName
    }
    
    var fullDescription: String {
        var components: [String] = []
        
        if year > 0 {
            components.append(String(year))
        }
        
        if let make = make, !make.isEmpty {
            components.append(make)
        }
        
        if let model = model, !model.isEmpty {
            components.append(model)
        }
        
        if let color = color, !color.isEmpty {
            components.append("(\(color))")
        }
        
        return components.joined(separator: " ")
    }
    
    var vehicleTypeEnum: VehicleType {
        return VehicleType(rawValue: vehicleType ?? "car") ?? .car
    }
    
    var fuelTypeEnum: FuelType {
        return FuelType(rawValue: fuelType ?? "gasoline") ?? .gasoline
    }
    
    var estimatedRange: Double {
        if isElectric {
            return range
        } else {
            // Calculate range based on fuel capacity and consumption
            if averageFuelConsumption > 0 {
                return (fuelCapacity / averageFuelConsumption) * 100 // Assuming L/100km
            }
            return range
        }
    }
}



// MARK: - Validation
extension CDVehicle {
    func validate() -> [String] {
        var errors: [String] = []
        
        if make?.trimmingCharacters(in: .whitespaces).isEmpty ?? true {
            errors.append("Vehicle make is required")
        }
        
        if model?.trimmingCharacters(in: .whitespaces).isEmpty ?? true {
            errors.append("Vehicle model is required")
        }
        
        if year < 1900 || year > Int16(Calendar.current.component(.year, from: Date()) + 1) {
            errors.append("Invalid vehicle year")
        }
        
        if seatingCapacity < 1 {
            errors.append("Seating capacity must be at least 1")
        }
        
        if fuelCapacity < 0 {
            errors.append("Fuel capacity cannot be negative")
        }
        
        if averageFuelConsumption < 0 {
            errors.append("Fuel consumption cannot be negative")
        }
        
        if isElectric && batteryCapacity <= 0 {
            errors.append("Electric vehicles must have battery capacity")
        }
        
        return errors
    }
    
    var isValid: Bool {
        return validate().isEmpty
    }
}

// MARK: - Factory Methods
extension CDVehicle {
    static func createDefault(for user: CDUser, in context: NSManagedObjectContext) -> CDVehicle {
        let vehicle = CDVehicle(context: context)
        vehicle.id = UUID()
        vehicle.owner = user
        vehicle.vehicleType = "car"
        vehicle.fuelType = "gasoline"
        vehicle.seatingCapacity = 5
        vehicle.fuelCapacity = 50.0
        vehicle.averageFuelConsumption = 8.0
        vehicle.range = 600.0
        vehicle.createdAt = Date()
        vehicle.updatedAt = Date()
        return vehicle
    }
}