import Foundation
import CoreLocation

// MARK: - User Model
struct User: Codable, Identifiable {
    let id: UUID
    var username: String
    var email: String
    var city: String
    var dateOfBirth: Date
    var age: Int
    var vehicleId: UUID?
    var profileImageURL: URL?
    var emergencyContacts: [EmergencyContact]
    
    init(id: UUID = UUID(), username: String, email: String, city: String, dateOfBirth: Date, vehicleId: UUID? = nil, profileImageURL: URL? = nil, emergencyContacts: [EmergencyContact] = []) {
        self.id = id
        self.username = username
        self.email = email
        self.city = city
        self.dateOfBirth = dateOfBirth
        self.age = Calendar.current.dateComponents([.year], from: dateOfBirth, to: Date()).year ?? 0
        self.vehicleId = vehicleId
        self.profileImageURL = profileImageURL
        self.emergencyContacts = emergencyContacts
    }
}

// MARK: - Emergency Contact Model
struct EmergencyContact: Codable, Identifiable {
    let id: UUID
    var name: String
    var relationship: String
    var phoneNumber: String
    var email: String?
    var contactMethod: EmergencyContactMethod
    var isPrimary: Bool
    
    init(id: UUID = UUID(), name: String, relationship: String, phoneNumber: String, email: String? = nil, contactMethod: EmergencyContactMethod = .sms, isPrimary: Bool = false) {
        self.id = id
        self.name = name
        self.relationship = relationship
        self.phoneNumber = phoneNumber
        self.email = email
        self.contactMethod = contactMethod
        self.isPrimary = isPrimary
    }
}

// MARK: - Emergency Contact Method
enum EmergencyContactMethod: String, CaseIterable, Codable {
    case sms = "sms"
    case email = "email"
    case call = "call"
    
    var displayName: String {
        switch self {
        case .sms: return "SMS"
        case .email: return "Email"
        case .call: return "Phone Call"
        }
    }
}

