import Foundation
import CoreLocation

// MARK: - Destination Model (Swift Struct)
struct Destination: Codable, Identifiable {
    let id: UUID
    var name: String
    var latitude: Double
    var longitude: Double
    var order: Int
    var createdAt: Date
    var updatedAt: Date
    var tripId: UUID
    
    init(id: UUID = UUID(), name: String, latitude: Double, longitude: Double, order: Int, createdAt: Date = Date(), updatedAt: Date = Date(), tripId: UUID) {
        self.id = id
        self.name = name
        self.latitude = latitude
        self.longitude = longitude
        self.order = order
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.tripId = tripId
    }
}

// MARK: - Computed Properties
extension Destination {
    var coordinate: CLLocationCoordinate2D {
        return CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
    
    var location: CLLocation {
        return CLLocation(latitude: latitude, longitude: longitude)
    }
}