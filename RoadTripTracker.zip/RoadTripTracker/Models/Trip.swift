import Foundation
import CoreLocation
import MapKit

// MARK: - Trip Model
struct Trip: Codable, Identifiable {
    let id: UUID
    var name: String
    var code: String
    var createdBy: UUID
    var participants: [Participant]
    var destinations: [Destination]
    var currentDestinationIndex: Int
    var status: TripStatus
    var createdAt: Date
    var startedAt: Date?
    var budget: Budget?
    
    init(id: UUID = UUID(), name: String, code: String, createdBy: UUID, participants: [Participant] = [], destinations: [Destination] = [], currentDestinationIndex: Int = 0, status: TripStatus = .planning, createdAt: Date = Date(), startedAt: Date? = nil, budget: Budget? = nil) {
        self.id = id
        self.name = name
        self.code = code
        self.createdBy = createdBy
        self.participants = participants
        self.destinations = destinations
        self.currentDestinationIndex = currentDestinationIndex
        self.status = status
        self.createdAt = createdAt
        self.startedAt = startedAt
        self.budget = budget
    }
}

// MARK: - Trip Status Enum
enum TripStatus: String, Codable, CaseIterable {
    case planning = "planning"
    case active = "active"
    case paused = "paused"
    case completed = "completed"
    case cancelled = "cancelled"
    
    var displayName: String {
        switch self {
        case .planning:
            return "Planning"
        case .active:
            return "Active"
        case .paused:
            return "Paused"
        case .completed:
            return "Completed"
        case .cancelled:
            return "Cancelled"
        }
    }
}

// MARK: - Destination Model
struct Destination: Codable, Identifiable {
    let id: UUID
    var name: String
    var address: String
    var coordinate: CLLocationCoordinate2D
    var plannedArrival: Date?
    var plannedDuration: TimeInterval?
    var type: DestinationType
    var notes: String?
    
    init(id: UUID = UUID(), name: String, address: String, coordinate: CLLocationCoordinate2D, plannedArrival: Date? = nil, plannedDuration: TimeInterval? = nil, type: DestinationType = .waypoint, notes: String? = nil) {
        self.id = id
        self.name = name
        self.address = address
        self.coordinate = coordinate
        self.plannedArrival = plannedArrival
        self.plannedDuration = plannedDuration
        self.type = type
        self.notes = notes
    }
}

// MARK: - Destination Type Enum
enum DestinationType: String, Codable, CaseIterable {
    case start = "start"
    case waypoint = "waypoint"
    case fuel = "fuel"
    case food = "food"
    case accommodation = "accommodation"
    case attraction = "attraction"
    case end = "end"
}

// MARK: - Participant Model
struct Participant: Codable, Identifiable {
    let id: UUID
    let userId: UUID
    var user: User
    var currentLocation: CLLocationCoordinate2D?
    var lastLocationUpdate: Date?
    var isLocationSharingEnabled: Bool
    var status: ParticipantStatus
    
    init(id: UUID = UUID(), userId: UUID, user: User, currentLocation: CLLocationCoordinate2D? = nil, lastLocationUpdate: Date? = nil, isLocationSharingEnabled: Bool = true, status: ParticipantStatus = .joined) {
        self.id = id
        self.userId = userId
        self.user = user
        self.currentLocation = currentLocation
        self.lastLocationUpdate = lastLocationUpdate
        self.isLocationSharingEnabled = isLocationSharingEnabled
        self.status = status
    }
}

// MARK: - Participant Status Enum
enum ParticipantStatus: String, Codable, CaseIterable {
    case invited = "invited"
    case joined = "joined"
    case active = "active"
    case inactive = "inactive"
    case left = "left"
}

// MARK: - Budget Model
struct Budget: Codable {
    var totalBudget: Double
    var perPersonBudget: Double?
    var expenses: [Expense]
    var categories: [ExpenseCategory: Double]
    
    init(totalBudget: Double, perPersonBudget: Double? = nil, expenses: [Expense] = [], categories: [ExpenseCategory: Double] = [:]) {
        self.totalBudget = totalBudget
        self.perPersonBudget = perPersonBudget
        self.expenses = expenses
        self.categories = categories
    }
}

// MARK: - Expense Model
struct Expense: Codable, Identifiable {
    let id: UUID
    var amount: Double
    var category: ExpenseCategory
    var description: String
    var participantId: UUID
    var timestamp: Date
    var location: CLLocationCoordinate2D?
    
    init(id: UUID = UUID(), amount: Double, category: ExpenseCategory, description: String, participantId: UUID, timestamp: Date = Date(), location: CLLocationCoordinate2D? = nil) {
        self.id = id
        self.amount = amount
        self.category = category
        self.description = description
        self.participantId = participantId
        self.timestamp = timestamp
        self.location = location
    }
}

// MARK: - Expense Category Enum
enum ExpenseCategory: String, Codable, CaseIterable {
    case fuel = "fuel"
    case food = "food"
    case accommodation = "accommodation"
    case activities = "activities"
    case other = "other"
    
    var displayName: String {
        switch self {
        case .fuel: return "Fuel"
        case .food: return "Food"
        case .accommodation: return "Accommodation"
        case .activities: return "Activities"
        case .other: return "Other"
        }
    }
}



// MARK: - Distance Calculation Model
struct DistanceCalculation: Codable {
    var fromParticipant: UUID
    var toParticipant: UUID?
    var toDestination: UUID?
    var straightLineDistance: CLLocationDistance
    var drivingDistance: CLLocationDistance?
    var estimatedDrivingTime: TimeInterval?
    var lastUpdated: Date
    
    init(fromParticipant: UUID, toParticipant: UUID? = nil, toDestination: UUID? = nil, straightLineDistance: CLLocationDistance, drivingDistance: CLLocationDistance? = nil, estimatedDrivingTime: TimeInterval? = nil, lastUpdated: Date = Date()) {
        self.fromParticipant = fromParticipant
        self.toParticipant = toParticipant
        self.toDestination = toDestination
        self.straightLineDistance = straightLineDistance
        self.drivingDistance = drivingDistance
        self.estimatedDrivingTime = estimatedDrivingTime
        self.lastUpdated = lastUpdated
    }
}