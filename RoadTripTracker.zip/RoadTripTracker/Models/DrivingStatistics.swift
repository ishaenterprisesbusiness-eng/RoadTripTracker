import Foundation
import CoreLocation

// MARK: - Driving Statistics Model
struct DrivingStatistics: Codable, Identifiable {
    let id: UUID
    let tripId: UUID
    let participantId: UUID
    var totalDistance: CLLocationDistance
    var totalDrivingTime: TimeInterval
    var averageSpeed: Double
    var maxSpeed: Double
    var speedingIncidents: [SpeedingIncident]
    var restPeriods: [RestPeriod]
    var startTime: Date
    var endTime: Date?
    var lastUpdated: Date
    
    init(id: UUID = UUID(), tripId: UUID, participantId: UUID, totalDistance: CLLocationDistance = 0, totalDrivingTime: TimeInterval = 0, averageSpeed: Double = 0, maxSpeed: Double = 0, speedingIncidents: [SpeedingIncident] = [], restPeriods: [RestPeriod] = [], startTime: Date = Date(), endTime: Date? = nil, lastUpdated: Date = Date()) {
        self.id = id
        self.tripId = tripId
        self.participantId = participantId
        self.totalDistance = totalDistance
        self.totalDrivingTime = totalDrivingTime
        self.averageSpeed = averageSpeed
        self.maxSpeed = maxSpeed
        self.speedingIncidents = speedingIncidents
        self.restPeriods = restPeriods
        self.startTime = startTime
        self.endTime = endTime
        self.lastUpdated = lastUpdated
    }
    
    // Computed properties
    var isActive: Bool {
        return endTime == nil
    }
    
    var averageSpeedKmh: Double {
        return averageSpeed * 3.6 // Convert m/s to km/h
    }
    
    var maxSpeedKmh: Double {
        return maxSpeed * 3.6 // Convert m/s to km/h
    }
    
    var totalDistanceKm: Double {
        return totalDistance / 1000.0 // Convert meters to kilometers
    }
    
    var totalDrivingTimeHours: Double {
        return totalDrivingTime / 3600.0 // Convert seconds to hours
    }
    
    var totalRestTime: TimeInterval {
        return restPeriods.reduce(0) { $0 + $1.duration }
    }
    
    var speedingIncidentCount: Int {
        return speedingIncidents.count
    }
}

// MARK: - Speeding Incident Model
struct SpeedingIncident: Codable, Identifiable {
    let id: UUID
    let timestamp: Date
    let location: CLLocationCoordinate2D
    let actualSpeed: Double // m/s
    let speedLimit: Double // m/s
    let duration: TimeInterval
    let severity: SpeedingSeverity
    
    init(id: UUID = UUID(), timestamp: Date, location: CLLocationCoordinate2D, actualSpeed: Double, speedLimit: Double, duration: TimeInterval, severity: SpeedingSeverity) {
        self.id = id
        self.timestamp = timestamp
        self.location = location
        self.actualSpeed = actualSpeed
        self.speedLimit = speedLimit
        self.duration = duration
        self.severity = severity
    }
    
    var speedExcess: Double {
        return actualSpeed - speedLimit
    }
    
    var speedExcessKmh: Double {
        return speedExcess * 3.6
    }
    
    var actualSpeedKmh: Double {
        return actualSpeed * 3.6
    }
    
    var speedLimitKmh: Double {
        return speedLimit * 3.6
    }
}

// MARK: - Speeding Severity Enum
enum SpeedingSeverity: String, Codable, CaseIterable {
    case minor = "minor" // 1-10 km/h over
    case moderate = "moderate" // 11-20 km/h over
    case serious = "serious" // 21+ km/h over
    
    var displayName: String {
        switch self {
        case .minor: return "Minor"
        case .moderate: return "Moderate"
        case .serious: return "Serious"
        }
    }
    
    var color: String {
        switch self {
        case .minor: return "yellow"
        case .moderate: return "orange"
        case .serious: return "red"
        }
    }
    
    static func severity(for speedExcessKmh: Double) -> SpeedingSeverity {
        if speedExcessKmh <= 10 {
            return .minor
        } else if speedExcessKmh <= 20 {
            return .moderate
        } else {
            return .serious
        }
    }
}

// MARK: - Rest Period Model
struct RestPeriod: Codable, Identifiable {
    let id: UUID
    let startTime: Date
    let endTime: Date?
    let location: CLLocationCoordinate2D
    let type: RestType
    
    init(id: UUID = UUID(), startTime: Date, endTime: Date? = nil, location: CLLocationCoordinate2D, type: RestType) {
        self.id = id
        self.startTime = startTime
        self.endTime = endTime
        self.location = location
        self.type = type
    }
    
    var duration: TimeInterval {
        guard let endTime = endTime else {
            return Date().timeIntervalSince(startTime)
        }
        return endTime.timeIntervalSince(startTime)
    }
    
    var durationMinutes: Double {
        return duration / 60.0
    }
    
    var isActive: Bool {
        return endTime == nil
    }
}

// MARK: - Rest Type Enum
enum RestType: String, Codable, CaseIterable {
    case automatic = "automatic" // Detected automatically when stationary
    case manual = "manual" // Manually logged by user
    case fuel = "fuel" // At fuel stop
    case food = "food" // At food stop
    case accommodation = "accommodation" // At accommodation
    
    var displayName: String {
        switch self {
        case .automatic: return "Break"
        case .manual: return "Manual Break"
        case .fuel: return "Fuel Stop"
        case .food: return "Food Stop"
        case .accommodation: return "Accommodation"
        }
    }
    
    var icon: String {
        switch self {
        case .automatic: return "pause.circle"
        case .manual: return "hand.raised"
        case .fuel: return "fuelpump"
        case .food: return "fork.knife"
        case .accommodation: return "bed.double"
        }
    }
}

// MARK: - Driving Performance Summary
struct DrivingPerformanceSummary: Codable {
    let participantId: UUID
    let totalTrips: Int
    let totalDistance: CLLocationDistance
    let totalDrivingTime: TimeInterval
    let averageSpeed: Double
    let bestAverageSpeed: Double
    let totalSpeedingIncidents: Int
    let safetyScore: Double // 0-100 scale
    let lastTripDate: Date?
    
    init(participantId: UUID, totalTrips: Int = 0, totalDistance: CLLocationDistance = 0, totalDrivingTime: TimeInterval = 0, averageSpeed: Double = 0, bestAverageSpeed: Double = 0, totalSpeedingIncidents: Int = 0, safetyScore: Double = 100, lastTripDate: Date? = nil) {
        self.participantId = participantId
        self.totalTrips = totalTrips
        self.totalDistance = totalDistance
        self.totalDrivingTime = totalDrivingTime
        self.averageSpeed = averageSpeed
        self.bestAverageSpeed = bestAverageSpeed
        self.totalSpeedingIncidents = totalSpeedingIncidents
        self.safetyScore = safetyScore
        self.lastTripDate = lastTripDate
    }
    
    var totalDistanceKm: Double {
        return totalDistance / 1000.0
    }
    
    var totalDrivingTimeHours: Double {
        return totalDrivingTime / 3600.0
    }
    
    var averageSpeedKmh: Double {
        return averageSpeed * 3.6
    }
    
    var bestAverageSpeedKmh: Double {
        return bestAverageSpeed * 3.6
    }
    
    var safetyRating: SafetyRating {
        switch safetyScore {
        case 90...100: return .excellent
        case 80..<90: return .good
        case 70..<80: return .fair
        case 60..<70: return .poor
        default: return .dangerous
        }
    }
}

// MARK: - Safety Rating Enum
enum SafetyRating: String, Codable, CaseIterable {
    case excellent = "excellent"
    case good = "good"
    case fair = "fair"
    case poor = "poor"
    case dangerous = "dangerous"
    
    var displayName: String {
        switch self {
        case .excellent: return "Excellent"
        case .good: return "Good"
        case .fair: return "Fair"
        case .poor: return "Poor"
        case .dangerous: return "Dangerous"
        }
    }
    
    var color: String {
        switch self {
        case .excellent: return "green"
        case .good: return "blue"
        case .fair: return "yellow"
        case .poor: return "orange"
        case .dangerous: return "red"
        }
    }
    
    var icon: String {
        switch self {
        case .excellent: return "checkmark.shield"
        case .good: return "shield"
        case .fair: return "exclamationmark.shield"
        case .poor: return "xmark.shield"
        case .dangerous: return "exclamationmark.triangle"
        }
    }
}

// MARK: - Location Data Point
struct LocationDataPoint: Codable {
    let timestamp: Date
    let coordinate: CLLocationCoordinate2D
    let speed: Double // m/s
    let heading: Double
    let accuracy: Double
    
    init(timestamp: Date, coordinate: CLLocationCoordinate2D, speed: Double, heading: Double, accuracy: Double) {
        self.timestamp = timestamp
        self.coordinate = coordinate
        self.speed = speed
        self.heading = heading
        self.accuracy = accuracy
    }
    
    var speedKmh: Double {
        return speed * 3.6
    }
}

// MARK: - Trip Comparison Data
struct TripComparisonData: Codable {
    let tripId: UUID
    let tripName: String
    let date: Date
    let totalDistance: CLLocationDistance
    let totalTime: TimeInterval
    let averageSpeed: Double
    let maxSpeed: Double
    let speedingIncidents: Int
    let restPeriods: Int
    let safetyScore: Double
    
    init(tripId: UUID, tripName: String, date: Date, totalDistance: CLLocationDistance, totalTime: TimeInterval, averageSpeed: Double, maxSpeed: Double, speedingIncidents: Int, restPeriods: Int, safetyScore: Double) {
        self.tripId = tripId
        self.tripName = tripName
        self.date = date
        self.totalDistance = totalDistance
        self.totalTime = totalTime
        self.averageSpeed = averageSpeed
        self.maxSpeed = maxSpeed
        self.speedingIncidents = speedingIncidents
        self.restPeriods = restPeriods
        self.safetyScore = safetyScore
    }
    
    var totalDistanceKm: Double {
        return totalDistance / 1000.0
    }
    
    var totalTimeHours: Double {
        return totalTime / 3600.0
    }
    
    var averageSpeedKmh: Double {
        return averageSpeed * 3.6
    }
    
    var maxSpeedKmh: Double {
        return maxSpeed * 3.6
    }
}