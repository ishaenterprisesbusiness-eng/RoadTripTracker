import Foundation
import CoreLocation
import MapKit

// MARK: - Point of Interest Model
struct PointOfInterest: Codable, Identifiable {
    let id: UUID
    let placeId: String
    var name: String
    var address: String
    var coordinate: CLLocationCoordinate2D
    var category: POICategory
    var subcategory: String?
    var rating: Double?
    var priceLevel: Int?
    var phoneNumber: String?
    var website: URL?
    var openingHours: [String]?
    var isOpen: Bool?
    var photos: [URL]?
    var description: String?
    var reviews: [POIReview]?
    var distanceFromRoute: CLLocationDistance?
    var estimatedVisitDuration: TimeInterval?
    
    init(id: UUID = UUID(), placeId: String, name: String, address: String, coordinate: CLLocationCoordinate2D, category: POICategory, subcategory: String? = nil, rating: Double? = nil, priceLevel: Int? = nil, phoneNumber: String? = nil, website: URL? = nil, openingHours: [String]? = nil, isOpen: Bool? = nil, photos: [URL]? = nil, description: String? = nil, reviews: [POIReview]? = nil, distanceFromRoute: CLLocationDistance? = nil, estimatedVisitDuration: TimeInterval? = nil) {
        self.id = id
        self.placeId = placeId
        self.name = name
        self.address = address
        self.coordinate = coordinate
        self.category = category
        self.subcategory = subcategory
        self.rating = rating
        self.priceLevel = priceLevel
        self.phoneNumber = phoneNumber
        self.website = website
        self.openingHours = openingHours
        self.isOpen = isOpen
        self.photos = photos
        self.description = description
        self.reviews = reviews
        self.distanceFromRoute = distanceFromRoute
        self.estimatedVisitDuration = estimatedVisitDuration
    }
}

// MARK: - POI Category Enum
enum POICategory: String, CaseIterable, Codable {
    case nature = "nature"
    case history = "history"
    case entertainment = "entertainment"
    case shopping = "shopping"
    case culture = "culture"
    case sports = "sports"
    case food = "food"
    case accommodation = "accommodation"
    case services = "services"
    case other = "other"
    
    var displayName: String {
        switch self {
        case .nature: return "Nature"
        case .history: return "History"
        case .entertainment: return "Entertainment"
        case .shopping: return "Shopping"
        case .culture: return "Culture"
        case .sports: return "Sports"
        case .food: return "Food"
        case .accommodation: return "Accommodation"
        case .services: return "Services"
        case .other: return "Other"
        }
    }
    
    var iconName: String {
        switch self {
        case .nature: return "leaf.fill"
        case .history: return "building.columns.fill"
        case .entertainment: return "theatermasks.fill"
        case .shopping: return "bag.fill"
        case .culture: return "paintbrush.fill"
        case .sports: return "sportscourt.fill"
        case .food: return "fork.knife"
        case .accommodation: return "bed.double.fill"
        case .services: return "wrench.and.screwdriver.fill"
        case .other: return "mappin.and.ellipse"
        }
    }
    
    var subcategories: [String] {
        switch self {
        case .nature:
            return ["National Park", "State Park", "Beach", "Lake", "Mountain", "Forest", "Wildlife Reserve", "Botanical Garden"]
        case .history:
            return ["Museum", "Historical Site", "Monument", "Castle", "Archaeological Site", "Heritage Building"]
        case .entertainment:
            return ["Amusement Park", "Theme Park", "Cinema", "Theater", "Concert Hall", "Casino", "Nightclub"]
        case .shopping:
            return ["Shopping Mall", "Outlet", "Market", "Antique Shop", "Souvenir Shop", "Local Crafts"]
        case .culture:
            return ["Art Gallery", "Cultural Center", "Library", "Observatory", "Aquarium", "Zoo"]
        case .sports:
            return ["Stadium", "Sports Complex", "Golf Course", "Ski Resort", "Marina", "Adventure Park"]
        case .food:
            return ["Restaurant", "Cafe", "Local Cuisine", "Food Market", "Brewery", "Winery"]
        case .accommodation:
            return ["Hotel", "Motel", "Resort", "Camping", "Hostel", "Bed & Breakfast"]
        case .services:
            return ["Gas Station", "Hospital", "Pharmacy", "Bank", "Tourist Information"]
        case .other:
            return ["Scenic Viewpoint", "Rest Area", "Visitor Center", "Local Attraction"]
        }
    }
}

// MARK: - POI Review Model
struct POIReview: Codable, Identifiable {
    let id: UUID
    var author: String
    var rating: Double
    var text: String
    var timestamp: Date
    var photos: [URL]?
    
    init(id: UUID = UUID(), author: String, rating: Double, text: String, timestamp: Date, photos: [URL]? = nil) {
        self.id = id
        self.author = author
        self.rating = rating
        self.text = text
        self.timestamp = timestamp
        self.photos = photos
    }
}

// MARK: - POI Proposal Model
struct POIProposal: Codable, Identifiable {
    let id: UUID
    let tripId: UUID
    let proposedBy: UUID
    var poi: PointOfInterest
    var proposalMessage: String?
    var proposedInsertionIndex: Int
    var status: POIProposalStatus
    var votes: [POIVote]
    var createdAt: Date
    var decidedAt: Date?
    
    init(id: UUID = UUID(), tripId: UUID, proposedBy: UUID, poi: PointOfInterest, proposalMessage: String? = nil, proposedInsertionIndex: Int, status: POIProposalStatus = .pending, votes: [POIVote] = [], createdAt: Date = Date(), decidedAt: Date? = nil) {
        self.id = id
        self.tripId = tripId
        self.proposedBy = proposedBy
        self.poi = poi
        self.proposalMessage = proposalMessage
        self.proposedInsertionIndex = proposedInsertionIndex
        self.status = status
        self.votes = votes
        self.createdAt = createdAt
        self.decidedAt = decidedAt
    }
}

// MARK: - POI Proposal Status Enum
enum POIProposalStatus: String, Codable, CaseIterable {
    case pending = "pending"
    case approved = "approved"
    case rejected = "rejected"
    case expired = "expired"
    
    var displayName: String {
        switch self {
        case .pending: return "Pending"
        case .approved: return "Approved"
        case .rejected: return "Rejected"
        case .expired: return "Expired"
        }
    }
}

// MARK: - POI Vote Model
struct POIVote: Codable, Identifiable {
    let id: UUID
    let participantId: UUID
    var vote: VoteType
    var comment: String?
    var timestamp: Date
    
    init(id: UUID = UUID(), participantId: UUID, vote: VoteType, comment: String? = nil, timestamp: Date = Date()) {
        self.id = id
        self.participantId = participantId
        self.vote = vote
        self.comment = comment
        self.timestamp = timestamp
    }
}

// MARK: - Vote Type Enum
enum VoteType: String, Codable, CaseIterable {
    case approve = "approve"
    case reject = "reject"
    case abstain = "abstain"
    
    var displayName: String {
        switch self {
        case .approve: return "Approve"
        case .reject: return "Reject"
        case .abstain: return "Abstain"
        }
    }
}

// MARK: - POI Search Filter
struct POISearchFilter: Codable {
    var categories: Set<POICategory>
    var minRating: Double?
    var maxDistance: CLLocationDistance?
    var priceLevel: Int?
    var isOpenNow: Bool?
    var hasPhotos: Bool?
    var sortBy: POISortOption
    
    init(categories: Set<POICategory> = Set(POICategory.allCases), minRating: Double? = nil, maxDistance: CLLocationDistance? = nil, priceLevel: Int? = nil, isOpenNow: Bool? = nil, hasPhotos: Bool? = nil, sortBy: POISortOption = .distance) {
        self.categories = categories
        self.minRating = minRating
        self.maxDistance = maxDistance
        self.priceLevel = priceLevel
        self.isOpenNow = isOpenNow
        self.hasPhotos = hasPhotos
        self.sortBy = sortBy
    }
}

// MARK: - POI Sort Option Enum
enum POISortOption: String, CaseIterable, Codable {
    case distance = "distance"
    case rating = "rating"
    case name = "name"
    case popularity = "popularity"
    
    var displayName: String {
        switch self {
        case .distance: return "Distance"
        case .rating: return "Rating"
        case .name: return "Name"
        case .popularity: return "Popularity"
        }
    }
}