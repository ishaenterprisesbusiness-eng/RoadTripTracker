import Foundation
import CoreLocation
import MapKit

// MARK: - Accommodation Model
struct Accommodation: Codable, Identifiable {
    let id: String
    let name: String
    let address: String
    let coordinate: CLLocationCoordinate2D
    let type: AccommodationType
    let rating: Double?
    let priceRange: PriceRange?
    let amenities: [Amenity]
    let phoneNumber: String?
    let website: URL?
    let bookingURL: URL?
    let checkInTime: String?
    let checkOutTime: String?
    let photos: [URL]
    let availability: AccommodationAvailability?
    let distance: Double?
    let estimatedTravelTime: TimeInterval?
    
    init(id: String, name: String, address: String, coordinate: CLLocationCoordinate2D, type: AccommodationType, rating: Double? = nil, priceRange: PriceRange? = nil, amenities: [Amenity] = [], phoneNumber: String? = nil, website: URL? = nil, bookingURL: URL? = nil, checkInTime: String? = nil, checkOutTime: String? = nil, photos: [URL] = [], availability: AccommodationAvailability? = nil, distance: Double? = nil, estimatedTravelTime: TimeInterval? = nil) {
        self.id = id
        self.name = name
        self.address = address
        self.coordinate = coordinate
        self.type = type
        self.rating = rating
        self.priceRange = priceRange
        self.amenities = amenities
        self.phoneNumber = phoneNumber
        self.website = website
        self.bookingURL = bookingURL
        self.checkInTime = checkInTime
        self.checkOutTime = checkOutTime
        self.photos = photos
        self.availability = availability
        self.distance = distance
        self.estimatedTravelTime = estimatedTravelTime
    }
}

// MARK: - Accommodation Type
enum AccommodationType: String, CaseIterable, Codable {
    case hotel = "hotel"
    case motel = "motel"
    case resort = "resort"
    case bedAndBreakfast = "bed_and_breakfast"
    case hostel = "hostel"
    case campground = "campground"
    case rvPark = "rv_park"
    case vacation_rental = "vacation_rental"
    case cabin = "cabin"
    case lodge = "lodge"
    
    var displayName: String {
        switch self {
        case .hotel: return "Hotel"
        case .motel: return "Motel"
        case .resort: return "Resort"
        case .bedAndBreakfast: return "Bed & Breakfast"
        case .hostel: return "Hostel"
        case .campground: return "Campground"
        case .rvPark: return "RV Park"
        case .vacation_rental: return "Vacation Rental"
        case .cabin: return "Cabin"
        case .lodge: return "Lodge"
        }
    }
    
    var icon: String {
        switch self {
        case .hotel, .motel, .resort: return "building.2"
        case .bedAndBreakfast: return "house"
        case .hostel: return "person.3"
        case .campground: return "tent"
        case .rvPark: return "car.rear"
        case .vacation_rental: return "house.lodge"
        case .cabin: return "house.lodge.fill"
        case .lodge: return "mountain.2"
        }
    }
}

// MARK: - Price Range
enum PriceRange: Int, CaseIterable, Codable {
    case budget = 1
    case moderate = 2
    case expensive = 3
    case luxury = 4
    
    var displayName: String {
        switch self {
        case .budget: return "$"
        case .moderate: return "$$"
        case .expensive: return "$$$"
        case .luxury: return "$$$$"
        }
    }
    
    var description: String {
        switch self {
        case .budget: return "Budget-friendly"
        case .moderate: return "Moderate pricing"
        case .expensive: return "Expensive"
        case .luxury: return "Luxury"
        }
    }
}

// MARK: - Amenity
enum Amenity: String, CaseIterable, Codable {
    case wifi = "wifi"
    case parking = "parking"
    case pool = "pool"
    case gym = "gym"
    case restaurant = "restaurant"
    case breakfast = "breakfast"
    case petFriendly = "pet_friendly"
    case airConditioning = "air_conditioning"
    case spa = "spa"
    case businessCenter = "business_center"
    case laundry = "laundry"
    case roomService = "room_service"
    case concierge = "concierge"
    case shuttle = "shuttle"
    case beachAccess = "beach_access"
    case skiAccess = "ski_access"
    case electricHookup = "electric_hookup"
    case waterHookup = "water_hookup"
    case sewerHookup = "sewer_hookup"
    case showers = "showers"
    case restrooms = "restrooms"
    case firepit = "firepit"
    case picnicTable = "picnic_table"
    
    var displayName: String {
        switch self {
        case .wifi: return "Wi-Fi"
        case .parking: return "Parking"
        case .pool: return "Pool"
        case .gym: return "Gym"
        case .restaurant: return "Restaurant"
        case .breakfast: return "Breakfast"
        case .petFriendly: return "Pet Friendly"
        case .airConditioning: return "Air Conditioning"
        case .spa: return "Spa"
        case .businessCenter: return "Business Center"
        case .laundry: return "Laundry"
        case .roomService: return "Room Service"
        case .concierge: return "Concierge"
        case .shuttle: return "Shuttle Service"
        case .beachAccess: return "Beach Access"
        case .skiAccess: return "Ski Access"
        case .electricHookup: return "Electric Hookup"
        case .waterHookup: return "Water Hookup"
        case .sewerHookup: return "Sewer Hookup"
        case .showers: return "Showers"
        case .restrooms: return "Restrooms"
        case .firepit: return "Fire Pit"
        case .picnicTable: return "Picnic Table"
        }
    }
    
    var icon: String {
        switch self {
        case .wifi: return "wifi"
        case .parking: return "car"
        case .pool: return "figure.pool.swim"
        case .gym: return "dumbbell"
        case .restaurant: return "fork.knife"
        case .breakfast: return "cup.and.saucer"
        case .petFriendly: return "pawprint"
        case .airConditioning: return "snowflake"
        case .spa: return "leaf"
        case .businessCenter: return "briefcase"
        case .laundry: return "washer"
        case .roomService: return "bell"
        case .concierge: return "person.badge.key"
        case .shuttle: return "bus"
        case .beachAccess: return "beach.umbrella"
        case .skiAccess: return "figure.skiing.downhill"
        case .electricHookup: return "bolt"
        case .waterHookup: return "drop"
        case .sewerHookup: return "pipe.and.drop"
        case .showers: return "shower"
        case .restrooms: return "toilet"
        case .firepit: return "flame"
        case .picnicTable: return "table.furniture"
        }
    }
}

// MARK: - Accommodation Availability
struct AccommodationAvailability: Codable {
    let isAvailable: Bool
    let availableRooms: Int?
    let pricePerNight: Double?
    let currency: String
    let checkInDate: Date?
    let checkOutDate: Date?
    let lastUpdated: Date
    
    init(isAvailable: Bool, availableRooms: Int? = nil, pricePerNight: Double? = nil, currency: String = "USD", checkInDate: Date? = nil, checkOutDate: Date? = nil, lastUpdated: Date = Date()) {
        self.isAvailable = isAvailable
        self.availableRooms = availableRooms
        self.pricePerNight = pricePerNight
        self.currency = currency
        self.checkInDate = checkInDate
        self.checkOutDate = checkOutDate
        self.lastUpdated = lastUpdated
    }
}

// MARK: - Accommodation Search Filters
struct AccommodationSearchFilters: Codable {
    var types: Set<AccommodationType>
    var priceRange: ClosedRange<PriceRange>?
    var minRating: Double?
    var requiredAmenities: Set<Amenity>
    var maxDistance: Double? // in kilometers
    var checkInDate: Date?
    var checkOutDate: Date?
    var guests: Int
    
    init(types: Set<AccommodationType> = Set(AccommodationType.allCases), priceRange: ClosedRange<PriceRange>? = nil, minRating: Double? = nil, requiredAmenities: Set<Amenity> = [], maxDistance: Double? = nil, checkInDate: Date? = nil, checkOutDate: Date? = nil, guests: Int = 1) {
        self.types = types
        self.priceRange = priceRange
        self.minRating = minRating
        self.requiredAmenities = requiredAmenities
        self.maxDistance = maxDistance
        self.checkInDate = checkInDate
        self.checkOutDate = checkOutDate
        self.guests = guests
    }
}