import Foundation

// MARK: - Vehicle Model (Swift Struct)
struct Vehicle: Codable, Identifiable {
    let id: UUID
    var make: String
    var model: String
    var year: Int
    var color: String
    var licensePlate: String
    var vehicleType: VehicleType
    var fuelType: FuelType
    var seatingCapacity: Int
    var fuelCapacity: Double
    var averageFuelConsumption: Double // L/100km or MPG
    var isElectric: Bool
    var batteryCapacity: Double // kWh for electric vehicles
    var range: Double // km or miles
    var createdAt: Date
    var updatedAt: Date
    var ownerId: UUID
    
    init(id: UUID = UUID(), make: String, model: String, year: Int, color: String, licensePlate: String, vehicleType: VehicleType = .car, fuelType: FuelType = .gasoline, seatingCapacity: Int = 5, fuelCapacity: Double = 50.0, averageFuelConsumption: Double = 8.0, isElectric: Bool = false, batteryCapacity: Double = 0.0, range: Double = 600.0, createdAt: Date = Date(), updatedAt: Date = Date(), ownerId: UUID) {
        self.id = id
        self.make = make
        self.model = model
        self.year = year
        self.color = color
        self.licensePlate = licensePlate
        self.vehicleType = vehicleType
        self.fuelType = fuelType
        self.seatingCapacity = seatingCapacity
        self.fuelCapacity = fuelCapacity
        self.averageFuelConsumption = averageFuelConsumption
        self.isElectric = isElectric
        self.batteryCapacity = batteryCapacity
        self.range = range
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.ownerId = ownerId
    }
}

// MARK: - Computed Properties
extension Vehicle {
    var displayName: String {
        let makeModel = "\(make) \(model)".trimmingCharacters(in: .whitespaces)
        if !makeModel.isEmpty {
            if year > 0 {
                return "\(year) \(makeModel)"
            }
            return makeModel
        }
        return "Vehicle"
    }
    
    var shortDisplayName: String {
        return "\(make) \(model)"
    }
    
    var fullDescription: String {
        var components: [String] = []
        
        if year > 0 {
            components.append(String(year))
        }
        
        components.append(make)
        components.append(model)
        
        if !color.isEmpty {
            components.append("(\(color))")
        }
        
        return components.joined(separator: " ")
    }
    
    var estimatedRange: Double {
        if isElectric {
            return range
        } else {
            // Calculate range based on fuel capacity and consumption
            if averageFuelConsumption > 0 {
                return (fuelCapacity / averageFuelConsumption) * 100 // Assuming L/100km
            }
            return range
        }
    }
}

// MARK: - Vehicle Type Enum
enum VehicleType: String, Codable, CaseIterable {
    case car = "car"
    case suv = "suv"
    case truck = "truck"
    case van = "van"
    case motorcycle = "motorcycle"
    case rv = "rv"
    case trailer = "trailer"
    
    var displayName: String {
        switch self {
        case .car: return "Car"
        case .suv: return "SUV"
        case .truck: return "Truck"
        case .van: return "Van"
        case .motorcycle: return "Motorcycle"
        case .rv: return "RV"
        case .trailer: return "Trailer"
        }
    }
    
    var iconName: String {
        switch self {
        case .car: return "car.fill"
        case .suv: return "car.2.fill"
        case .truck: return "truck.box.fill"
        case .van: return "bus.fill"
        case .motorcycle: return "bicycle"
        case .rv: return "bus.doubledecker.fill"
        case .trailer: return "truck.box.badge.plus.fill"
        }
    }
    
    var defaultSeatingCapacity: Int {
        switch self {
        case .car: return 5
        case .suv: return 7
        case .truck: return 3
        case .van: return 8
        case .motorcycle: return 2
        case .rv: return 6
        case .trailer: return 0
        }
    }
}

// MARK: - Fuel Type Enum
enum FuelType: String, Codable, CaseIterable {
    case gasoline = "gasoline"
    case diesel = "diesel"
    case electric = "electric"
    case hybrid = "hybrid"
    case pluginHybrid = "plugin_hybrid"
    case hydrogen = "hydrogen"
    case lpg = "lpg"
    case cng = "cng"
    
    var displayName: String {
        switch self {
        case .gasoline: return "Gasoline"
        case .diesel: return "Diesel"
        case .electric: return "Electric"
        case .hybrid: return "Hybrid"
        case .pluginHybrid: return "Plug-in Hybrid"
        case .hydrogen: return "Hydrogen"
        case .lpg: return "LPG"
        case .cng: return "CNG"
        }
    }
    
    var iconName: String {
        switch self {
        case .gasoline, .diesel: return "fuelpump.fill"
        case .electric: return "bolt.fill"
        case .hybrid, .pluginHybrid: return "leaf.fill"
        case .hydrogen: return "h.circle.fill"
        case .lpg, .cng: return "flame.fill"
        }
    }
    
    var isElectric: Bool {
        return self == .electric || self == .pluginHybrid
    }
    
    var requiresFuel: Bool {
        return self != .electric
    }
}