import Foundation
import CoreLocation

// MARK: - Network Status
enum NetworkStatus {
    case wifi
    case cellular
    case offline
    case other
    case unknown
}

// MARK: - Sync Status
enum SyncStatus {
    case idle
    case syncing
    case failed(Error)
}

// MARK: - Operation Type
enum OfflineOperationType: String, Codable {
    case locationUpdate
    case messageSync
    case photoUpload
    case expenseSync
    case tripUpdate
}

// MARK: - Offline Operation
class OfflineOperation: Codable, Identifiable {
    let id: UUID
    let type: OfflineOperationType
    let data: Data?
    let createdAt: Date
    var retryCount: Int
    var lastAttempt: Date?
    let maxRetries: Int
    
    init(type: OfflineOperationType, data: Data?, maxRetries: Int = 3) {
        self.id = UUID()
        self.type = type
        self.data = data
        self.createdAt = Date()
        self.retryCount = 0
        self.maxRetries = maxRetries
    }
}

// MARK: - Cached Data Models

struct CachedLocationData: Codable {
    let tripId: UUID
    let participantId: UUID
    let latitude: Double
    let longitude: Double
    let timestamp: Date
    let speed: Double?
    let heading: Double?
    let accuracy: Double
}

struct CachedMessageData: Codable {
    let tripId: UUID
    let senderId: UUID
    let content: String
    let type: String
    let timestamp: Date
    let latitude: Double?
    let longitude: Double?
    let photoURL: URL?
}

struct CachedPhotoData: Codable {
    let tripId: UUID
    let sharedBy: UUID
    let caption: String?
    let timestamp: Date
    let latitude: Double
    let longitude: Double
    let localPhotoURL: URL?
    let tags: [String]?
}

struct CachedExpenseData: Codable {
    let tripId: UUID
    let participantId: UUID
    let amount: Double
    let category: String
    let description: String
    let timestamp: Date
    let latitude: Double
    let longitude: Double
}

struct CachedTripData: Codable {
    let tripId: UUID
    let name: String
    let status: String
    let currentDestinationIndex: Int32
    let createdBy: UUID
    let code: String
    let createdAt: Date
}

// MARK: - Participant Location
struct ParticipantLocation: Codable {
    let participantId: UUID
    let location: CLLocationCoordinate2D
    let timestamp: Date
    let speed: Double?
    let heading: Double?
    let accuracy: Double
}

// MARK: - Cache Statistics
struct CacheStatistics {
    let totalCachedItems: Int
    let pendingOperations: Int
    let lastSyncDate: Date?
    let cacheSize: Int64 // in bytes
    let oldestCachedItem: Date?
}

// MARK: - Offline Configuration
struct OfflineConfiguration {
    let maxCacheAge: TimeInterval = 7 * 24 * 60 * 60 // 7 days
    let maxCachedMessages: Int = 100
    let maxCachedPhotos: Int = 50
    let maxRetryAttempts: Int = 3
    let syncBatchSize: Int = 10
    let locationUpdateThreshold: TimeInterval = 30 // seconds
    let compressionQuality: Double = 0.7 // for images
}

// MARK: - Location Service Error
enum LocationServiceError: LocalizedError {
    case permissionDenied
    case timeout
    case unavailable
    case accuracyTooLow
    
    var errorDescription: String? {
        switch self {
        case .permissionDenied:
            return "Location permission denied"
        case .timeout:
            return "Location request timed out"
        case .unavailable:
            return "Location services unavailable"
        case .accuracyTooLow:
            return "Location accuracy too low"
        }
    }
}

// MARK: - Sync Error
enum SyncError: LocalizedError {
    case networkUnavailable
    case cloudKitUnavailable
    case dataCorrupted
    case quotaExceeded
    case authenticationRequired
    
    var errorDescription: String? {
        switch self {
        case .networkUnavailable:
            return "Network connection unavailable"
        case .cloudKitUnavailable:
            return "CloudKit service unavailable"
        case .dataCorrupted:
            return "Cached data is corrupted"
        case .quotaExceeded:
            return "CloudKit quota exceeded"
        case .authenticationRequired:
            return "CloudKit authentication required"
        }
    }
}