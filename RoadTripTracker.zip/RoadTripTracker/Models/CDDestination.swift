import Foundation
import CoreData

@objc(CDDestination)
public class CDDestination: NSManagedObject {
    
}

extension CDDestination {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDDestination> {
        return NSFetchRequest<CDDestination>(entityName: "CDDestination")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var latitude: Double
    @NSManaged public var longitude: Double
    @NSManaged public var order: Int16
    @NSManaged public var createdAt: Date?
    @NSManaged public var updatedAt: Date?
    @NSManaged public var trip: CDTrip?

}

extension CDDestination : Identifiable {

}