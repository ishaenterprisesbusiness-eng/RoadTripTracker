import Foundation
import CoreLocation

// MARK: - Food Stop Model
struct FoodStop: Codable, Identifiable {
    let id: UUID
    var tripId: UUID
    var proposedBy: UUID
    var restaurant: Restaurant
    var proposalStatus: StopProposalStatus
    var approvals: [UUID] // Participant IDs who approved
    var rejections: [UUID] // Participant IDs who rejected
    var orders: [FoodOrder]
    var proposedTime: Date
    var actualArrivalTime: Date?
    var estimatedWaitTime: TimeInterval?
    var notes: String?
    
    init(id: UUID = UUID(), tripId: UUID, proposedBy: UUID, restaurant: Restaurant, proposalStatus: StopProposalStatus = .pending, approvals: [UUID] = [], rejections: [UUID] = [], orders: [FoodOrder] = [], proposedTime: Date = Date(), actualArrivalTime: Date? = nil, estimatedWaitTime: TimeInterval? = nil, notes: String? = nil) {
        self.id = id
        self.tripId = tripId
        self.proposedBy = proposedBy
        self.restaurant = restaurant
        self.proposalStatus = proposalStatus
        self.approvals = approvals
        self.rejections = rejections
        self.orders = orders
        self.proposedTime = proposedTime
        self.actualArrivalTime = actualArrivalTime
        self.estimatedWaitTime = estimatedWaitTime
        self.notes = notes
    }
}

// MARK: - Restaurant Model
struct Restaurant: Codable, Identifiable {
    let id: String
    var name: String
    var cuisine: CuisineType?
    var address: String
    var coordinate: CLLocationCoordinate2D
    var phoneNumber: String?
    var website: URL?
    var openingHours: [String]?
    var priceLevel: Int? // 1-4 scale
    var rating: Double?
    var isOpenNow: Bool?
    var features: [RestaurantFeature]
    var parkingInfo: ParkingInfo?
    var distanceFromRoute: CLLocationDistance?
    var estimatedWaitTime: TimeInterval?
    
    init(id: String, name: String, cuisine: CuisineType? = nil, address: String, coordinate: CLLocationCoordinate2D, phoneNumber: String? = nil, website: URL? = nil, openingHours: [String]? = nil, priceLevel: Int? = nil, rating: Double? = nil, isOpenNow: Bool? = nil, features: [RestaurantFeature] = [], parkingInfo: ParkingInfo? = nil, distanceFromRoute: CLLocationDistance? = nil, estimatedWaitTime: TimeInterval? = nil) {
        self.id = id
        self.name = name
        self.cuisine = cuisine
        self.address = address
        self.coordinate = coordinate
        self.phoneNumber = phoneNumber
        self.website = website
        self.openingHours = openingHours
        self.priceLevel = priceLevel
        self.rating = rating
        self.isOpenNow = isOpenNow
        self.features = features
        self.parkingInfo = parkingInfo
        self.distanceFromRoute = distanceFromRoute
        self.estimatedWaitTime = estimatedWaitTime
    }
}

// MARK: - Food Order Model
struct FoodOrder: Codable, Identifiable {
    let id: UUID
    var participantId: UUID
    var orderStatus: OrderStatus
    var orderTime: Date
    var items: [OrderItem]
    var totalCost: Double?
    var specialInstructions: String?
    var estimatedReadyTime: Date?
    var actualReadyTime: Date?
    var isReadyToContinue: Bool
    
    init(id: UUID = UUID(), participantId: UUID, orderStatus: OrderStatus = .pending, orderTime: Date = Date(), items: [OrderItem] = [], totalCost: Double? = nil, specialInstructions: String? = nil, estimatedReadyTime: Date? = nil, actualReadyTime: Date? = nil, isReadyToContinue: Bool = false) {
        self.id = id
        self.participantId = participantId
        self.orderStatus = orderStatus
        self.orderTime = orderTime
        self.items = items
        self.totalCost = totalCost
        self.specialInstructions = specialInstructions
        self.estimatedReadyTime = estimatedReadyTime
        self.actualReadyTime = actualReadyTime
        self.isReadyToContinue = isReadyToContinue
    }
}

// MARK: - Order Item Model
struct OrderItem: Codable, Identifiable {
    let id: UUID
    var name: String
    var quantity: Int
    var price: Double?
    var customizations: [String]
    
    init(id: UUID = UUID(), name: String, quantity: Int = 1, price: Double? = nil, customizations: [String] = []) {
        self.id = id
        self.name = name
        self.quantity = quantity
        self.price = price
        self.customizations = customizations
    }
}

// MARK: - Parking Info Model
struct ParkingInfo: Codable {
    var hasParking: Bool
    var parkingType: ParkingType
    var parkingCost: ParkingCost
    var maxVehicleSize: VehicleSize?
    var notes: String?
    
    init(hasParking: Bool = false, parkingType: ParkingType = .street, parkingCost: ParkingCost = .unknown, maxVehicleSize: VehicleSize? = nil, notes: String? = nil) {
        self.hasParking = hasParking
        self.parkingType = parkingType
        self.parkingCost = parkingCost
        self.maxVehicleSize = maxVehicleSize
        self.notes = notes
    }
}

// MARK: - Cuisine Type Enum
enum CuisineType: String, Codable, CaseIterable {
    case american = "american"
    case italian = "italian"
    case chinese = "chinese"
    case mexican = "mexican"
    case indian = "indian"
    case japanese = "japanese"
    case thai = "thai"
    case french = "french"
    case mediterranean = "mediterranean"
    case fastFood = "fast_food"
    case pizza = "pizza"
    case seafood = "seafood"
    case steakhouse = "steakhouse"
    case vegetarian = "vegetarian"
    case cafe = "cafe"
    case bakery = "bakery"
    case other = "other"
    
    var displayName: String {
        switch self {
        case .american: return "American"
        case .italian: return "Italian"
        case .chinese: return "Chinese"
        case .mexican: return "Mexican"
        case .indian: return "Indian"
        case .japanese: return "Japanese"
        case .thai: return "Thai"
        case .french: return "French"
        case .mediterranean: return "Mediterranean"
        case .fastFood: return "Fast Food"
        case .pizza: return "Pizza"
        case .seafood: return "Seafood"
        case .steakhouse: return "Steakhouse"
        case .vegetarian: return "Vegetarian"
        case .cafe: return "Cafe"
        case .bakery: return "Bakery"
        case .other: return "Other"
        }
    }
    
    var icon: String {
        switch self {
        case .american: return "flag.fill"
        case .italian: return "leaf.fill"
        case .chinese: return "takeoutbag.and.cupandstraw.fill"
        case .mexican: return "flame.fill"
        case .indian: return "star.fill"
        case .japanese: return "fish.fill"
        case .thai: return "leaf.fill"
        case .french: return "wineglass.fill"
        case .mediterranean: return "sun.max.fill"
        case .fastFood: return "car.fill"
        case .pizza: return "circle.fill"
        case .seafood: return "fish.fill"
        case .steakhouse: return "flame.fill"
        case .vegetarian: return "leaf.fill"
        case .cafe: return "cup.and.saucer.fill"
        case .bakery: return "birthday.cake.fill"
        case .other: return "fork.knife"
        }
    }
}

// MARK: - Restaurant Feature Enum
enum RestaurantFeature: String, Codable, CaseIterable {
    case driveThru = "drive_thru"
    case delivery = "delivery"
    case takeout = "takeout"
    case dineIn = "dine_in"
    case wifi = "wifi"
    case parking = "parking"
    case wheelchairAccessible = "wheelchair_accessible"
    case outdoorSeating = "outdoor_seating"
    case liveMusic = "live_music"
    case bar = "bar"
    case kidsMenu = "kids_menu"
    case vegetarianOptions = "vegetarian_options"
    case veganOptions = "vegan_options"
    case glutenFreeOptions = "gluten_free_options"
    case creditCards = "credit_cards"
    case reservations = "reservations"
    
    var displayName: String {
        switch self {
        case .driveThru: return "Drive-Thru"
        case .delivery: return "Delivery"
        case .takeout: return "Takeout"
        case .dineIn: return "Dine-In"
        case .wifi: return "WiFi"
        case .parking: return "Parking"
        case .wheelchairAccessible: return "Wheelchair Accessible"
        case .outdoorSeating: return "Outdoor Seating"
        case .liveMusic: return "Live Music"
        case .bar: return "Bar"
        case .kidsMenu: return "Kids Menu"
        case .vegetarianOptions: return "Vegetarian Options"
        case .veganOptions: return "Vegan Options"
        case .glutenFreeOptions: return "Gluten-Free Options"
        case .creditCards: return "Credit Cards"
        case .reservations: return "Reservations"
        }
    }
    
    var icon: String {
        switch self {
        case .driveThru: return "car.fill"
        case .delivery: return "shippingbox.fill"
        case .takeout: return "bag.fill"
        case .dineIn: return "fork.knife"
        case .wifi: return "wifi"
        case .parking: return "car"
        case .wheelchairAccessible: return "figure.roll"
        case .outdoorSeating: return "sun.max.fill"
        case .liveMusic: return "music.note"
        case .bar: return "wineglass.fill"
        case .kidsMenu: return "person.2.fill"
        case .vegetarianOptions: return "leaf.fill"
        case .veganOptions: return "leaf.circle.fill"
        case .glutenFreeOptions: return "checkmark.seal.fill"
        case .creditCards: return "creditcard.fill"
        case .reservations: return "calendar"
        }
    }
}

// MARK: - Order Status Enum
enum OrderStatus: String, Codable, CaseIterable {
    case pending = "pending"
    case placed = "placed"
    case preparing = "preparing"
    case ready = "ready"
    case completed = "completed"
    case cancelled = "cancelled"
    
    var displayName: String {
        switch self {
        case .pending: return "Pending"
        case .placed: return "Placed"
        case .preparing: return "Preparing"
        case .ready: return "Ready"
        case .completed: return "Completed"
        case .cancelled: return "Cancelled"
        }
    }
    
    var color: String {
        switch self {
        case .pending: return "orange"
        case .placed: return "blue"
        case .preparing: return "yellow"
        case .ready: return "green"
        case .completed: return "gray"
        case .cancelled: return "red"
        }
    }
}

// MARK: - Parking Type Enum
enum ParkingType: String, Codable, CaseIterable {
    case street = "street"
    case lot = "lot"
    case garage = "garage"
    case valet = "valet"
    case none = "none"
    
    var displayName: String {
        switch self {
        case .street: return "Street Parking"
        case .lot: return "Parking Lot"
        case .garage: return "Parking Garage"
        case .valet: return "Valet Parking"
        case .none: return "No Parking"
        }
    }
}

// MARK: - Parking Cost Enum
enum ParkingCost: String, Codable, CaseIterable {
    case free = "free"
    case paid = "paid"
    case validated = "validated"
    case unknown = "unknown"
    
    var displayName: String {
        switch self {
        case .free: return "Free"
        case .paid: return "Paid"
        case .validated: return "Validated"
        case .unknown: return "Unknown"
        }
    }
}

// MARK: - Vehicle Size Enum
enum VehicleSize: String, Codable, CaseIterable {
    case compact = "compact"
    case standard = "standard"
    case large = "large"
    case oversized = "oversized"
    
    var displayName: String {
        switch self {
        case .compact: return "Compact"
        case .standard: return "Standard"
        case .large: return "Large"
        case .oversized: return "Oversized"
        }
    }
}