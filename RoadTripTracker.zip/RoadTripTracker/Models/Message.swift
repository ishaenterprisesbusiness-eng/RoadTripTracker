import Foundation
import CoreLocation

// MARK: - Message Model
struct Message: Codable, Identifiable {
    let id: UUID
    let tripId: UUID
    let senderId: UUID
    var content: String
    var type: MessageType
    var timestamp: Date
    var location: CLLocationCoordinate2D?
    var photoURL: URL?
    var deliveryStatus: MessageDeliveryStatus
    var readBy: [UUID]
    
    init(id: UUID = UUID(), tripId: UUID, senderId: UUID, content: String, type: MessageType = .text, timestamp: Date = Date(), location: CLLocationCoordinate2D? = nil, photoURL: URL? = nil, deliveryStatus: MessageDeliveryStatus = .sending, readBy: [UUID] = []) {
        self.id = id
        self.tripId = tripId
        self.senderId = senderId
        self.content = content
        self.type = type
        self.timestamp = timestamp
        self.location = location
        self.photoURL = photoURL
        self.deliveryStatus = deliveryStatus
        self.readBy = readBy
    }
}

// MARK: - Message Type Enum
enum MessageType: String, Codable, CaseIterable {
    case text = "text"
    case location = "location"
    case photo = "photo"
    case system = "system"
    case emergency = "emergency"
}

// MARK: - Message Delivery Status Enum
enum MessageDeliveryStatus: String, Codable, CaseIterable {
    case sending = "sending"
    case sent = "sent"
    case delivered = "delivered"
    case failed = "failed"
}

// MARK: - Photo Share Model
struct PhotoShare: Codable, Identifiable {
    let id: UUID
    let tripId: UUID
    let sharedBy: UUID
    var photoURL: URL
    var thumbnailURL: URL?
    var caption: String?
    var location: CLLocationCoordinate2D?
    var timestamp: Date
    var tags: [String]
    
    init(id: UUID = UUID(), tripId: UUID, sharedBy: UUID, photoURL: URL, thumbnailURL: URL? = nil, caption: String? = nil, location: CLLocationCoordinate2D? = nil, timestamp: Date = Date(), tags: [String] = []) {
        self.id = id
        self.tripId = tripId
        self.sharedBy = sharedBy
        self.photoURL = photoURL
        self.thumbnailURL = thumbnailURL
        self.caption = caption
        self.location = location
        self.timestamp = timestamp
        self.tags = tags
    }
}