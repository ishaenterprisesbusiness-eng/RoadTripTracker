import Foundation

// MARK: - App Error
enum AppError: LocalizedError, Equatable {
    case authenticationFailed(String)
    case locationPermissionDenied
    case networkUnavailable
    case tripNotFound
    case invalidTripCode
    case locationSharingFailed
    case routeCalculationFailed
    case weatherDataUnavailable
    case notificationPermissionDenied
    case notificationSchedulingFailed
    case pushNotificationFailed
    case coreDataError(String)
    case cloudKitError(String)
    case validationError(String)
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .authenticationFailed(let message):
            return "Authentication failed: \(message)"
        case .locationPermissionDenied:
            return "Location permission is required for trip tracking"
        case .networkUnavailable:
            return "Network connection is unavailable"
        case .tripNotFound:
            return "Trip not found"
        case .invalidTripCode:
            return "Invalid trip code"
        case .locationSharingFailed:
            return "Failed to share location"
        case .routeCalculationFailed:
            return "Failed to calculate route"
        case .weatherDataUnavailable:
            return "Weather data is currently unavailable"
        case .notificationPermissionDenied:
            return "Notification permission is required for trip alerts"
        case .notificationSchedulingFailed:
            return "Failed to schedule notification"
        case .pushNotificationFailed:
            return "Failed to send push notification"
        case .coreDataError(let message):
            return "Data storage error: \(message)"
        case .cloudKitError(let message):
            return "Cloud sync error: \(message)"
        case .validationError(let message):
            return "Validation error: \(message)"
        case .unknown(let message):
            return "An unexpected error occurred: \(message)"
        }
    }
    
    var failureReason: String? {
        switch self {
        case .authenticationFailed:
            return "Invalid credentials or authentication service unavailable"
        case .locationPermissionDenied:
            return "Location services are disabled or permission was denied"
        case .networkUnavailable:
            return "No internet connection available"
        case .tripNotFound:
            return "The requested trip could not be found"
        case .invalidTripCode:
            return "The trip code is invalid or expired"
        case .locationSharingFailed:
            return "Unable to share location with other participants"
        case .routeCalculationFailed:
            return "Unable to calculate route between destinations"
        case .weatherDataUnavailable:
            return "Weather service is temporarily unavailable"
        case .notificationPermissionDenied:
            return "Notification services are disabled or permission was denied"
        case .notificationSchedulingFailed:
            return "Unable to schedule local notification"
        case .pushNotificationFailed:
            return "Unable to send push notification to participants"
        case .coreDataError:
            return "Local data storage encountered an error"
        case .cloudKitError:
            return "Cloud synchronization encountered an error"
        case .validationError:
            return "Input data validation failed"
        case .unknown:
            return "An unexpected error occurred"
        }
    }
    
    var recoverySuggestion: String? {
        switch self {
        case .authenticationFailed:
            return "Please check your credentials and try again"
        case .locationPermissionDenied:
            return "Please enable location services in Settings"
        case .networkUnavailable:
            return "Please check your internet connection and try again"
        case .tripNotFound:
            return "Please verify the trip exists and try again"
        case .invalidTripCode:
            return "Please check the trip code and try again"
        case .locationSharingFailed:
            return "Please check your location settings and network connection"
        case .routeCalculationFailed:
            return "Please check your destinations and try again"
        case .weatherDataUnavailable:
            return "Please try again later"
        case .notificationPermissionDenied:
            return "Please enable notifications in Settings"
        case .notificationSchedulingFailed:
            return "Please check notification settings and try again"
        case .pushNotificationFailed:
            return "Please check your network connection and try again"
        case .coreDataError:
            return "Please restart the app and try again"
        case .cloudKitError:
            return "Please check your iCloud settings and try again"
        case .validationError:
            return "Please check your input and try again"
        case .unknown:
            return "Please try again or contact support if the problem persists"
        }
    }
}

// MARK: - Error Handler
class ErrorHandler: ObservableObject {
    @Published var currentError: AppError?
    @Published var isShowingError: Bool = false
    
    func handle(_ error: Error) {
        DispatchQueue.main.async {
            if let appError = error as? AppError {
                self.currentError = appError
            } else {
                self.currentError = .unknown(error.localizedDescription)
            }
            self.isShowingError = true
        }
    }
    
    func clearError() {
        currentError = nil
        isShowingError = false
    }
}