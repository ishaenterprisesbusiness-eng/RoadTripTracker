import Foundation

struct PasswordValidation {
    let isValid: Bool
    let errors: [String]
    
    static func validate(_ password: String) -> PasswordValidation {
        var errors: [String] = []
        
        if password.count < 8 {
            errors.append("Password must be at least 8 characters long")
        }
        
        if !password.contains(where: { $0.isUppercase }) {
            errors.append("Password must contain at least one uppercase letter")
        }
        
        if !password.contains(where: { $0.isLowercase }) {
            errors.append("Password must contain at least one lowercase letter")
        }
        
        if !password.contains(where: { $0.isNumber }) {
            errors.append("Password must contain at least one number")
        }
        
        return PasswordValidation(isValid: errors.isEmpty, errors: errors)
    }
}