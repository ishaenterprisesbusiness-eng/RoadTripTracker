import Foundation
import Combine
import CoreLocation
import CoreData

// MARK: - Trip Service Implementation
class TripService: TripServiceProtocol {
    @Published private(set) var activeTrip: Trip?
    
    var tripUpdates: AnyPublisher<Trip?, Never> {
        $activeTrip.eraseToAnyPublisher()
    }
    
    private let persistenceController: PersistenceController
    private let placesService: PlacesServiceProtocol
    private let authenticationManager: AuthenticationManagerProtocol
    private var cancellables = Set<AnyCancellable>()
    
    init(persistenceController: PersistenceController, placesService: PlacesServiceProtocol, authenticationManager: AuthenticationManagerProtocol) {
        self.persistenceController = persistenceController
        self.placesService = placesService
        self.authenticationManager = authenticationManager
    }
    
    // MARK: - Trip Management
    
    func createTrip(name: String, destinations: [Destination], settings: TripSettings) async throws -> Trip {
        let context = persistenceController.container.viewContext
        
        // Generate unique trip code
        let tripCode = generateTripCode()
        
        // Create new trip
        let trip = Trip(
            name: name,
            code: tripCode,
            createdBy: getCurrentUserId(), // This should come from AuthenticationManager
            destinations: destinations,
            status: .planning
        )
        
        // Save to Core Data
        let cdTrip = CDTrip(context: context)
        cdTrip.id = trip.id
        cdTrip.name = trip.name
        cdTrip.code = trip.code
        cdTrip.createdBy = trip.createdBy
        cdTrip.status = trip.status.rawValue
        cdTrip.createdAt = trip.createdAt
        cdTrip.currentDestinationIndex = Int32(trip.currentDestinationIndex)
        
        if let budget = settings.budget {
            cdTrip.totalBudget = budget.totalBudget
        }
        
        // Add destinations
        for destination in destinations {
            let cdDestination = CDDestination(context: context)
            cdDestination.id = destination.id
            cdDestination.name = destination.name
            cdDestination.address = destination.address
            cdDestination.latitude = destination.coordinate.latitude
            cdDestination.longitude = destination.coordinate.longitude
            cdDestination.type = destination.type.rawValue
            cdDestination.notes = destination.notes
            cdDestination.plannedArrival = destination.plannedArrival
            cdDestination.plannedDuration = destination.plannedDuration ?? 0
            cdDestination.trip = cdTrip
        }
        
        do {
            try context.save()
            activeTrip = trip
            return trip
        } catch {
            throw TripServiceError.unknown(error.localizedDescription)
        }
    }
    
    func joinTrip(code: String) async throws -> Trip {
        let context = persistenceController.container.viewContext
        
        // Validate trip code
        guard await (try? validateTripCode(code)) == true else {
            throw TripServiceError.invalidTripCode
        }
        
        // Find trip by code
        let request: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
        request.predicate = NSPredicate(format: "code == %@", code)
        
        do {
            let cdTrips = try context.fetch(request)
            guard let cdTrip = cdTrips.first else {
                throw TripServiceError.tripNotFound
            }
            
            let trip = try convertToTrip(from: cdTrip)
            
            // Check if user is already a participant
            let currentUserId = getCurrentUserId()
            if trip.participants.contains(where: { $0.userId == currentUserId }) {
                throw TripServiceError.alreadyParticipant
            }
            
            // Add current user as participant
            let participant = Participant(
                userId: currentUserId,
                user: getCurrentUser(), // This should come from AuthenticationManager
                status: .joined
            )
            
            let cdParticipant = CDParticipant(context: context)
            cdParticipant.id = participant.id
            cdParticipant.userId = participant.userId
            cdParticipant.status = participant.status.rawValue
            cdParticipant.isLocationSharingEnabled = participant.isLocationSharingEnabled
            cdParticipant.trip = cdTrip
            
            try context.save()
            
            let updatedTrip = try convertToTrip(from: cdTrip)
            activeTrip = updatedTrip
            return updatedTrip
            
        } catch {
            if error is TripServiceError {
                throw error
            }
            throw TripServiceError.unknown(error.localizedDescription)
        }
    }
    
    func leaveTrip(_ tripId: UUID) async throws {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
        
        do {
            let cdTrips = try context.fetch(request)
            guard let cdTrip = cdTrips.first else {
                throw TripServiceError.tripNotFound
            }
            
            let currentUserId = getCurrentUserId()
            
            // Find and remove participant
            if let participantSet = cdTrip.participants as? Set<CDParticipant>,
               let cdParticipant = participantSet.first(where: { $0.userId == currentUserId }) {
                context.delete(cdParticipant)
                try context.save()
                
                if activeTrip?.id == tripId {
                    activeTrip = nil
                }
            } else {
                throw TripServiceError.notParticipant
            }
            
        } catch {
            if error is TripServiceError {
                throw error
            }
            throw TripServiceError.unknown(error.localizedDescription)
        }
    }
    
    func updateTrip(_ trip: Trip) async throws {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", trip.id as CVarArg)
        
        do {
            let cdTrips = try context.fetch(request)
            guard let cdTrip = cdTrips.first else {
                throw TripServiceError.tripNotFound
            }
            
            // Update trip properties
            cdTrip.name = trip.name
            cdTrip.status = trip.status.rawValue
            cdTrip.currentDestinationIndex = Int32(trip.currentDestinationIndex)
            cdTrip.startedAt = trip.startedAt
            
            try context.save()
            activeTrip = trip
            
        } catch {
            throw TripServiceError.unknown(error.localizedDescription)
        }
    }
    
    func deleteTrip(_ tripId: UUID) async throws {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
        
        do {
            let cdTrips = try context.fetch(request)
            guard let cdTrip = cdTrips.first else {
                throw TripServiceError.tripNotFound
            }
            
            // Check permissions
            let currentUserId = getCurrentUserId()
            guard cdTrip.createdBy == currentUserId else {
                throw TripServiceError.insufficientPermissions
            }
            
            context.delete(cdTrip)
            try context.save()
            
            if activeTrip?.id == tripId {
                activeTrip = nil
            }
            
        } catch {
            if error is TripServiceError {
                throw error
            }
            throw TripServiceError.unknown(error.localizedDescription)
        }
    }
    
    func generateTripCode() -> String {
        let characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return String((0..<6).map { _ in characters.randomElement()! })
    }
    
    func validateTripCode(_ code: String) async throws -> Bool {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
        request.predicate = NSPredicate(format: "code == %@", code)
        
        do {
            let count = try context.count(for: request)
            return count > 0
        } catch {
            throw TripServiceError.networkError
        }
    }
    
    func getTripHistory(for userId: UUID) async throws -> [Trip] {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
        request.predicate = NSPredicate(format: "createdBy == %@ OR ANY participants.userId == %@", userId as CVarArg, userId as CVarArg)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CDTrip.createdAt, ascending: false)]
        
        do {
            let cdTrips = try context.fetch(request)
            return try cdTrips.map { try convertToTrip(from: $0) }
        } catch {
            throw TripServiceError.unknown(error.localizedDescription)
        }
    }
    
    // MARK: - Destination Management
    
    func addDestination(_ destination: Destination, to tripId: UUID) async throws {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
        
        do {
            let cdTrips = try context.fetch(request)
            guard let cdTrip = cdTrips.first else {
                throw TripServiceError.tripNotFound
            }
            
            let cdDestination = CDDestination(context: context)
            cdDestination.id = destination.id
            cdDestination.name = destination.name
            cdDestination.address = destination.address
            cdDestination.latitude = destination.coordinate.latitude
            cdDestination.longitude = destination.coordinate.longitude
            cdDestination.type = destination.type.rawValue
            cdDestination.notes = destination.notes
            cdDestination.plannedArrival = destination.plannedArrival
            cdDestination.plannedDuration = destination.plannedDuration ?? 0
            cdDestination.trip = cdTrip
            
            try context.save()
            
            // Update active trip if it's the current one
            if activeTrip?.id == tripId {
                activeTrip = try convertToTrip(from: cdTrip)
            }
            
        } catch {
            throw TripServiceError.unknown(error.localizedDescription)
        }
    }
    
    func removeDestination(_ destinationId: UUID, from tripId: UUID) async throws {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDDestination> = CDDestination.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@ AND trip.id == %@", destinationId as CVarArg, tripId as CVarArg)
        
        do {
            let cdDestinations = try context.fetch(request)
            guard let cdDestination = cdDestinations.first else {
                throw TripServiceError.tripNotFound
            }
            
            context.delete(cdDestination)
            try context.save()
            
            // Update active trip if it's the current one
            if activeTrip?.id == tripId {
                let tripRequest: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
                tripRequest.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
                if let cdTrip = try context.fetch(tripRequest).first {
                    activeTrip = try convertToTrip(from: cdTrip)
                }
            }
            
        } catch {
            throw TripServiceError.unknown(error.localizedDescription)
        }
    }
    
    func reorderDestinations(_ destinations: [Destination], in tripId: UUID) async throws {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
        
        do {
            let cdTrips = try context.fetch(request)
            guard let cdTrip = cdTrips.first else {
                throw TripServiceError.tripNotFound
            }
            
            // Remove existing destinations
            if let existingDestinations = cdTrip.destinations as? Set<CDDestination> {
                for destination in existingDestinations {
                    context.delete(destination)
                }
            }
            
            // Add reordered destinations
            for destination in destinations {
                let cdDestination = CDDestination(context: context)
                cdDestination.id = destination.id
                cdDestination.name = destination.name
                cdDestination.address = destination.address
                cdDestination.latitude = destination.coordinate.latitude
                cdDestination.longitude = destination.coordinate.longitude
                cdDestination.type = destination.type.rawValue
                cdDestination.notes = destination.notes
                cdDestination.plannedArrival = destination.plannedArrival
                cdDestination.plannedDuration = destination.plannedDuration ?? 0
                cdDestination.trip = cdTrip
            }
            
            try context.save()
            
            // Update active trip if it's the current one
            if activeTrip?.id == tripId {
                activeTrip = try convertToTrip(from: cdTrip)
            }
            
        } catch {
            throw TripServiceError.unknown(error.localizedDescription)
        }
    }
    
    // MARK: - Route Optimization
    
    func optimizeRoute(destinations: [Destination]) async throws -> [Destination] {
        guard destinations.count > 2 else {
            return destinations
        }
        
        // Simple optimization using nearest neighbor algorithm
        // In a production app, you might use a more sophisticated algorithm or external service
        
        var optimizedDestinations: [Destination] = []
        var remainingDestinations = destinations
        
        // Start with the first destination
        if let firstDestination = remainingDestinations.first {
            optimizedDestinations.append(firstDestination)
            remainingDestinations.removeFirst()
        }
        
        // Find nearest destinations iteratively
        while !remainingDestinations.isEmpty {
            guard let currentDestination = optimizedDestinations.last else { break }
            
            let nearestDestination = remainingDestinations.min { dest1, dest2 in
                let distance1 = calculateDistance(
                    from: currentDestination.coordinate,
                    to: dest1.coordinate
                )
                let distance2 = calculateDistance(
                    from: currentDestination.coordinate,
                    to: dest2.coordinate
                )
                return distance1 < distance2
            }
            
            if let nearest = nearestDestination {
                optimizedDestinations.append(nearest)
                remainingDestinations.removeAll { $0.id == nearest.id }
            }
        }
        
        return optimizedDestinations
    }
    
    // MARK: - Private Methods
    
    private func getCurrentUserId() -> UUID {
        return authenticationManager.currentUser?.id ?? UUID()
    }
    
    private func getCurrentUser() -> User {
        return authenticationManager.currentUser ?? User(
            id: UUID(),
            username: "Unknown User",
            email: "unknown@example.com",
            city: "Unknown",
            dateOfBirth: Date()
        )
    }
    
    private func convertToTrip(from cdTrip: CDTrip) throws -> Trip {
        guard let id = cdTrip.id,
              let name = cdTrip.name,
              let code = cdTrip.code,
              let createdBy = cdTrip.createdBy,
              let statusString = cdTrip.status,
              let status = TripStatus(rawValue: statusString),
              let createdAt = cdTrip.createdAt else {
            throw TripServiceError.unknown("Invalid trip data")
        }
        
        // Convert destinations
        let destinations: [Destination] = (cdTrip.destinations as? Set<CDDestination>)?.compactMap { cdDestination in
            guard let destId = cdDestination.id,
                  let destName = cdDestination.name,
                  let destAddress = cdDestination.address,
                  let destTypeString = cdDestination.type,
                  let destType = DestinationType(rawValue: destTypeString) else {
                return nil
            }
            
            let coordinate = CLLocationCoordinate2D(
                latitude: cdDestination.latitude,
                longitude: cdDestination.longitude
            )
            
            return Destination(
                id: destId,
                name: destName,
                address: destAddress,
                coordinate: coordinate,
                plannedArrival: cdDestination.plannedArrival,
                plannedDuration: cdDestination.plannedDuration > 0 ? cdDestination.plannedDuration : nil,
                type: destType,
                notes: cdDestination.notes
            )
        } ?? []
        
        // Convert participants
        let participants: [Participant] = (cdTrip.participants as? Set<CDParticipant>)?.compactMap { cdParticipant in
            guard let participantId = cdParticipant.id,
                  let userId = cdParticipant.userId,
                  let statusString = cdParticipant.status,
                  let status = ParticipantStatus(rawValue: statusString) else {
                return nil
            }
            
            // Get user from Core Data or create a placeholder
            let user = getUserById(userId) ?? User(
                id: userId,
                username: "Unknown User",
                email: "unknown@example.com",
                city: "Unknown",
                dateOfBirth: Date()
            )
            
            var currentLocation: CLLocationCoordinate2D?
            if cdParticipant.currentLatitude != 0 || cdParticipant.currentLongitude != 0 {
                currentLocation = CLLocationCoordinate2D(
                    latitude: cdParticipant.currentLatitude,
                    longitude: cdParticipant.currentLongitude
                )
            }
            
            return Participant(
                id: participantId,
                userId: userId,
                user: user,
                currentLocation: currentLocation,
                lastLocationUpdate: cdParticipant.lastLocationUpdate,
                isLocationSharingEnabled: cdParticipant.isLocationSharingEnabled,
                status: status
            )
        } ?? []
        
        // Convert budget if exists
        var budget: Budget?
        if cdTrip.totalBudget > 0 {
            budget = Budget(totalBudget: cdTrip.totalBudget)
        }
        
        return Trip(
            id: id,
            name: name,
            code: code,
            createdBy: createdBy,
            participants: participants,
            destinations: destinations,
            currentDestinationIndex: Int(cdTrip.currentDestinationIndex),
            status: status,
            createdAt: createdAt,
            startedAt: cdTrip.startedAt,
            budget: budget
        )
    }
    
    private func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        return fromLocation.distance(from: toLocation)
    }
    
    private func getUserById(_ userId: UUID) -> User? {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDUser> = CDUser.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", userId as CVarArg)
        
        do {
            let cdUsers = try context.fetch(request)
            guard let cdUser = cdUsers.first else { return nil }
            
            return convertToUser(from: cdUser)
        } catch {
            return nil
        }
    }
    
    private func convertToUser(from cdUser: CDUser) -> User? {
        guard let id = cdUser.id,
              let username = cdUser.username,
              let email = cdUser.email,
              let city = cdUser.city,
              let dateOfBirth = cdUser.dateOfBirth else {
            return nil
        }
        
        var vehicle: Vehicle?
        if let cdVehicle = cdUser.vehicle,
           let make = cdVehicle.make,
           let model = cdVehicle.model,
           let vehicleNumber = cdVehicle.vehicleNumber,
           let typeString = cdVehicle.type,
           let vehicleType = VehicleType(rawValue: typeString) {
            
            vehicle = Vehicle(
                make: make,
                model: model,
                vehicleNumber: vehicleNumber,
                odometerReading: Int(cdVehicle.odometerReading),
                type: vehicleType,
                color: cdVehicle.color
            )
        }
        
        return User(
            id: id,
            username: username,
            email: email,
            city: city,
            dateOfBirth: dateOfBirth,
            vehicle: vehicle,
            profileImageURL: cdUser.profileImageURL
        )
    }
}