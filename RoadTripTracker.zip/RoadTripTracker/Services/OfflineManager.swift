import Foundation
import CoreData
import Network
import Combine
import CloudKit

// MARK: - Offline Manager
@MainActor
class OfflineManager: ObservableObject {
    
    // MARK: - Properties
    static let shared = OfflineManager()
    
    private let persistenceController = PersistenceController.shared
    private let networkMonitor = NWPathMonitor()
    private let monitorQueue = DispatchQueue(label: "NetworkMonitor")
    
    // Publishers
    @Published var isOnline: Bool = false
    @Published var networkStatus: NetworkStatus = .unknown
    @Published var syncStatus: SyncStatus = .idle
    @Published var pendingOperationsCount: Int = 0
    
    // Operation Queue
    private var pendingOperations: [OfflineOperation] = []
    private var syncCancellables = Set<AnyCancellable>()
    
    // MARK: - Initialization
    private init() {
        setupNetworkMonitoring()
        loadPendingOperations()
    }
    
    // MARK: - Network Monitoring
    private func setupNetworkMonitoring() {
        networkMonitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                self?.updateNetworkStatus(path)
            }
        }
        networkMonitor.start(queue: monitorQueue)
    }
    
    private func updateNetworkStatus(_ path: NWPath) {
        let wasOnline = isOnline
        isOnline = path.status == .satisfied
        
        // Determine network type
        if path.usesInterfaceType(.wifi) {
            networkStatus = .wifi
        } else if path.usesInterfaceType(.cellular) {
            networkStatus = .cellular
        } else if isOnline {
            networkStatus = .other
        } else {
            networkStatus = .offline
        }
        
        // Trigger sync when coming back online
        if !wasOnline && isOnline {
            Task {
                await syncPendingOperations()
            }
        }
    }
    
    // MARK: - Operation Management
    func queueOperation(_ operation: OfflineOperation) {
        pendingOperations.append(operation)
        pendingOperationsCount = pendingOperations.count
        savePendingOperations()
        
        // Try to execute immediately if online
        if isOnline {
            Task {
                await executeOperation(operation)
            }
        }
    }
    
    private func executeOperation(_ operation: OfflineOperation) async {
        guard isOnline else { return }
        
        do {
            switch operation.type {
            case .locationUpdate:
                await executeLocationUpdate(operation)
            case .messageSync:
                await executeMessageSync(operation)
            case .photoUpload:
                await executePhotoUpload(operation)
            case .expenseSync:
                await executeExpenseSync(operation)
            case .tripUpdate:
                await executeTripUpdate(operation)
            }
            
            // Remove successful operation
            removeOperation(operation)
            
        } catch {
            print("Failed to execute operation \(operation.id): \(error)")
            // Keep operation in queue for retry
            operation.retryCount += 1
            operation.lastAttempt = Date()
            
            // Remove operation if max retries exceeded
            if operation.retryCount >= operation.maxRetries {
                removeOperation(operation)
            }
        }
    }
    
    private func removeOperation(_ operation: OfflineOperation) {
        pendingOperations.removeAll { $0.id == operation.id }
        pendingOperationsCount = pendingOperations.count
        savePendingOperations()
    }
    
    // MARK: - Sync Operations
    func syncPendingOperations() async {
        guard isOnline && syncStatus != .syncing else { return }
        
        syncStatus = .syncing
        
        let operationsToSync = pendingOperations.filter { operation in
            // Only retry operations that haven't exceeded max retries
            operation.retryCount < operation.maxRetries &&
            // And haven't been attempted recently (exponential backoff)
            (operation.lastAttempt == nil || 
             Date().timeIntervalSince(operation.lastAttempt!) > pow(2.0, Double(operation.retryCount)))
        }
        
        for operation in operationsToSync {
            await executeOperation(operation)
        }
        
        syncStatus = .idle
    }
    
    // MARK: - Specific Operation Executors
    private func executeLocationUpdate(_ operation: OfflineOperation) async {
        guard let data = operation.data,
              let locationData = try? JSONDecoder().decode(CachedLocationData.self, from: data) else {
            return
        }
        
        // Create CloudKit record for location update
        let record = CKRecord(recordType: "ParticipantLocation")
        record["tripId"] = locationData.tripId.uuidString
        record["participantId"] = locationData.participantId.uuidString
        record["latitude"] = locationData.latitude
        record["longitude"] = locationData.longitude
        record["timestamp"] = locationData.timestamp
        record["speed"] = locationData.speed
        record["heading"] = locationData.heading
        record["accuracy"] = locationData.accuracy
        
        let database = CKContainer.default().publicCloudDatabase
        _ = try await database.save(record)
    }
    
    private func executeMessageSync(_ operation: OfflineOperation) async {
        guard let data = operation.data,
              let messageData = try? JSONDecoder().decode(CachedMessageData.self, from: data) else {
            return
        }
        
        // Create CloudKit record for message
        let record = CKRecord(recordType: "Message")
        record["tripId"] = messageData.tripId.uuidString
        record["senderId"] = messageData.senderId.uuidString
        record["content"] = messageData.content
        record["type"] = messageData.type
        record["timestamp"] = messageData.timestamp
        
        if let latitude = messageData.latitude, let longitude = messageData.longitude {
            record["latitude"] = latitude
            record["longitude"] = longitude
        }
        
        if let photoURL = messageData.photoURL {
            record["photoURL"] = photoURL.absoluteString
        }
        
        let database = CKContainer.default().publicCloudDatabase
        _ = try await database.save(record)
    }
    
    private func executePhotoUpload(_ operation: OfflineOperation) async {
        guard let data = operation.data,
              let photoData = try? JSONDecoder().decode(CachedPhotoData.self, from: data) else {
            return
        }
        
        // Upload photo to CloudKit
        let record = CKRecord(recordType: "PhotoShare")
        record["tripId"] = photoData.tripId.uuidString
        record["sharedBy"] = photoData.sharedBy.uuidString
        record["caption"] = photoData.caption
        record["timestamp"] = photoData.timestamp
        record["latitude"] = photoData.latitude
        record["longitude"] = photoData.longitude
        
        // Handle photo asset upload
        if let photoURL = photoData.localPhotoURL,
           FileManager.default.fileExists(atPath: photoURL.path) {
            let asset = CKAsset(fileURL: photoURL)
            record["photoAsset"] = asset
        }
        
        let database = CKContainer.default().publicCloudDatabase
        _ = try await database.save(record)
    }
    
    private func executeExpenseSync(_ operation: OfflineOperation) async {
        guard let data = operation.data,
              let expenseData = try? JSONDecoder().decode(CachedExpenseData.self, from: data) else {
            return
        }
        
        // Create CloudKit record for expense
        let record = CKRecord(recordType: "Expense")
        record["tripId"] = expenseData.tripId.uuidString
        record["participantId"] = expenseData.participantId.uuidString
        record["amount"] = expenseData.amount
        record["category"] = expenseData.category
        record["description"] = expenseData.description
        record["timestamp"] = expenseData.timestamp
        record["latitude"] = expenseData.latitude
        record["longitude"] = expenseData.longitude
        
        let database = CKContainer.default().publicCloudDatabase
        _ = try await database.save(record)
    }
    
    private func executeTripUpdate(_ operation: OfflineOperation) async {
        guard let data = operation.data,
              let tripData = try? JSONDecoder().decode(CachedTripData.self, from: data) else {
            return
        }
        
        // Update trip in CloudKit
        let database = CKContainer.default().publicCloudDatabase
        let recordID = CKRecord.ID(recordName: tripData.tripId.uuidString)
        
        do {
            let record = try await database.record(for: recordID)
            record["name"] = tripData.name
            record["status"] = tripData.status
            record["currentDestinationIndex"] = tripData.currentDestinationIndex
            
            _ = try await database.save(record)
        } catch {
            // If record doesn't exist, create new one
            let record = CKRecord(recordType: "Trip", recordID: recordID)
            record["name"] = tripData.name
            record["status"] = tripData.status
            record["currentDestinationIndex"] = tripData.currentDestinationIndex
            record["createdBy"] = tripData.createdBy.uuidString
            record["code"] = tripData.code
            record["createdAt"] = tripData.createdAt
            
            _ = try await database.save(record)
        }
    }
    
    // MARK: - Persistence
    private func savePendingOperations() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(pendingOperations) {
            UserDefaults.standard.set(encoded, forKey: "PendingOfflineOperations")
        }
    }
    
    private func loadPendingOperations() {
        guard let data = UserDefaults.standard.data(forKey: "PendingOfflineOperations"),
              let operations = try? JSONDecoder().decode([OfflineOperation].self, from: data) else {
            return
        }
        
        pendingOperations = operations
        pendingOperationsCount = pendingOperations.count
    }
    
    // MARK: - Cache Management
    func clearExpiredCache() {
        let context = persistenceController.container.viewContext
        let calendar = Calendar.current
        let cutoffDate = calendar.date(byAdding: .day, value: -7, to: Date()) ?? Date()
        
        // Clear old location data
        let locationRequest: NSFetchRequest<CDParticipant> = CDParticipant.fetchRequest()
        locationRequest.predicate = NSPredicate(format: "lastLocationUpdate < %@", cutoffDate as NSDate)
        
        do {
            let oldParticipants = try context.fetch(locationRequest)
            for participant in oldParticipants {
                participant.currentLatitude = 0
                participant.currentLongitude = 0
                participant.lastLocationUpdate = nil
            }
            
            try context.save()
        } catch {
            print("Failed to clear expired location cache: \(error)")
        }
        
        // Clear old messages (keep last 100 per trip)
        let messageRequest: NSFetchRequest<CDMessage> = CDMessage.fetchRequest()
        messageRequest.sortDescriptors = [NSSortDescriptor(keyPath: \CDMessage.timestamp, ascending: false)]
        
        do {
            let allMessages = try context.fetch(messageRequest)
            let groupedMessages = Dictionary(grouping: allMessages) { $0.trip?.id }
            
            for (_, messages) in groupedMessages {
                if messages.count > 100 {
                    let messagesToDelete = Array(messages.dropFirst(100))
                    for message in messagesToDelete {
                        context.delete(message)
                    }
                }
            }
            
            try context.save()
        } catch {
            print("Failed to clear expired message cache: \(error)")
        }
    }
    
    // MARK: - Network Adaptation
    func adaptToNetworkConditions() {
        switch networkStatus {
        case .wifi:
            // Full sync capabilities
            break
        case .cellular:
            // Reduce data usage - compress images, batch operations
            break
        case .offline:
            // Cache everything locally
            break
        case .other, .unknown:
            // Conservative approach
            break
        }
    }
}