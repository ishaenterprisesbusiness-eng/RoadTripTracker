import Foundation
import MapKit
import CoreData

// MARK: - Map Cache Service
@MainActor
class MapCacheService: ObservableObject {
    
    // MARK: - Properties
    private let persistenceController = PersistenceController.shared
    private let configuration = OfflineConfiguration()
    
    @Published var cachedRegionsCount: Int = 0
    @Published var totalCacheSize: Int64 = 0
    
    // Cache directory
    private lazy var cacheDirectory: URL = {
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let cacheDir = documentsPath.appendingPathComponent("MapCache")
        
        if !FileManager.default.fileExists(atPath: cacheDir.path) {
            try? FileManager.default.createDirectory(at: cacheDir, withIntermediateDirectories: true)
        }
        
        return cacheDir
    }()
    
    // MARK: - Route Caching
    func cacheRoute(_ route: MKRoute, for tripId: UUID) async {
        let routeData = CachedRouteData(
            tripId: tripId,
            polyline: route.polyline,
            distance: route.distance,
            expectedTravelTime: route.expectedTravelTime,
            name: route.name,
            advisoryNotices: route.advisoryNotices,
            cachedAt: Date()
        )
        
        await saveRouteToCache(routeData)
    }
    
    func getCachedRoute(for tripId: UUID) async -> CachedRouteData? {
        return await loadRouteFromCache(tripId: tripId)
    }
    
    private func saveRouteToCache(_ routeData: CachedRouteData) async {
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(routeData)
            let fileURL = cacheDirectory.appendingPathComponent("route_\(routeData.tripId.uuidString).json")
            try data.write(to: fileURL)
            
            await updateCacheStatistics()
            
        } catch {
            print("Failed to save route to cache: \(error)")
        }
    }
    
    private func loadRouteFromCache(tripId: UUID) async -> CachedRouteData? {
        do {
            let fileURL = cacheDirectory.appendingPathComponent("route_\(tripId.uuidString).json")
            let data = try Data(contentsOf: fileURL)
            let decoder = JSONDecoder()
            let routeData = try decoder.decode(CachedRouteData.self, from: data)
            
            // Check if cache is still valid
            if routeData.cachedAt.timeIntervalSinceNow > -configuration.maxCacheAge {
                return routeData
            } else {
                // Remove expired cache
                try? FileManager.default.removeItem(at: fileURL)
                return nil
            }
            
        } catch {
            print("Failed to load route from cache: \(error)")
            return nil
        }
    }
    
    // MARK: - Map Region Caching
    func cacheMapRegion(_ region: MKCoordinateRegion, for identifier: String) async {
        let regionData = CachedMapRegion(
            identifier: identifier,
            center: region.center,
            span: region.span,
            cachedAt: Date()
        )
        
        await saveMapRegionToCache(regionData)
    }
    
    func getCachedMapRegion(for identifier: String) async -> MKCoordinateRegion? {
        if let regionData = await loadMapRegionFromCache(identifier: identifier) {
            return MKCoordinateRegion(center: regionData.center, span: regionData.span)
        }
        return nil
    }
    
    private func saveMapRegionToCache(_ regionData: CachedMapRegion) async {
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(regionData)
            let fileURL = cacheDirectory.appendingPathComponent("region_\(regionData.identifier).json")
            try data.write(to: fileURL)
            
            await updateCacheStatistics()
            
        } catch {
            print("Failed to save map region to cache: \(error)")
        }
    }
    
    private func loadMapRegionFromCache(identifier: String) async -> CachedMapRegion? {
        do {
            let fileURL = cacheDirectory.appendingPathComponent("region_\(identifier).json")
            let data = try Data(contentsOf: fileURL)
            let decoder = JSONDecoder()
            let regionData = try decoder.decode(CachedMapRegion.self, from: data)
            
            // Check if cache is still valid
            if regionData.cachedAt.timeIntervalSinceNow > -configuration.maxCacheAge {
                return regionData
            } else {
                // Remove expired cache
                try? FileManager.default.removeItem(at: fileURL)
                return nil
            }
            
        } catch {
            print("Failed to load map region from cache: \(error)")
            return nil
        }
    }
    
    // MARK: - Destination Caching
    func cacheDestinations(_ destinations: [Destination], for tripId: UUID) async {
        do {
            try await persistenceController.performBackgroundTask { context in
                // Find the trip
                let tripRequest: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
                tripRequest.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
                
                guard let trip = try context.fetch(tripRequest).first else {
                    print("Trip not found for destination caching")
                    return
                }
                
                // Clear existing destinations
                if let existingDestinations = trip.destinations {
                    for destination in existingDestinations {
                        context.delete(destination as! NSManagedObject)
                    }
                }
                
                // Add new destinations
                for (index, destination) in destinations.enumerated() {
                    let cdDestination = CDDestination(context: context)
                    cdDestination.id = destination.id
                    cdDestination.name = destination.name
                    cdDestination.address = destination.address
                    cdDestination.latitude = destination.coordinate.latitude
                    cdDestination.longitude = destination.coordinate.longitude
                    cdDestination.plannedArrival = destination.plannedArrival
                    cdDestination.plannedDuration = destination.plannedDuration ?? 0
                    cdDestination.type = destination.type.rawValue
                    cdDestination.notes = destination.notes
                    cdDestination.trip = trip
                }
                
                try context.save()
            }
            
            await updateCacheStatistics()
            
        } catch {
            print("Failed to cache destinations: \(error)")
        }
    }
    
    func getCachedDestinations(for tripId: UUID) async -> [Destination] {
        do {
            return try await persistenceController.performBackgroundTask { context in
                let tripRequest: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
                tripRequest.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
                
                guard let trip = try context.fetch(tripRequest).first,
                      let cdDestinations = trip.destinations?.allObjects as? [CDDestination] else {
                    return []
                }
                
                return cdDestinations.compactMap { cdDestination in
                    guard let id = cdDestination.id,
                          let name = cdDestination.name,
                          let address = cdDestination.address,
                          let typeString = cdDestination.type,
                          let type = DestinationType(rawValue: typeString) else {
                        return nil
                    }
                    
                    return Destination(
                        id: id,
                        name: name,
                        address: address,
                        coordinate: CLLocationCoordinate2D(
                            latitude: cdDestination.latitude,
                            longitude: cdDestination.longitude
                        ),
                        plannedArrival: cdDestination.plannedArrival,
                        plannedDuration: cdDestination.plannedDuration > 0 ? cdDestination.plannedDuration : nil,
                        type: type,
                        notes: cdDestination.notes
                    )
                }.sorted { $0.name < $1.name }
            }
        } catch {
            print("Failed to get cached destinations: \(error)")
            return []
        }
    }
    
    // MARK: - POI Caching
    func cachePOIs(_ pois: [PointOfInterest], for region: MKCoordinateRegion) async {
        let regionIdentifier = "\(region.center.latitude)_\(region.center.longitude)_\(region.span.latitudeDelta)_\(region.span.longitudeDelta)"
        
        do {
            let encoder = JSONEncoder()
            let poisData = CachedPOIData(
                regionIdentifier: regionIdentifier,
                pois: pois,
                cachedAt: Date()
            )
            let data = try encoder.encode(poisData)
            let fileURL = cacheDirectory.appendingPathComponent("pois_\(regionIdentifier).json")
            try data.write(to: fileURL)
            
            await updateCacheStatistics()
            
        } catch {
            print("Failed to cache POIs: \(error)")
        }
    }
    
    func getCachedPOIs(for region: MKCoordinateRegion) async -> [PointOfInterest]? {
        let regionIdentifier = "\(region.center.latitude)_\(region.center.longitude)_\(region.span.latitudeDelta)_\(region.span.longitudeDelta)"
        
        do {
            let fileURL = cacheDirectory.appendingPathComponent("pois_\(regionIdentifier).json")
            let data = try Data(contentsOf: fileURL)
            let decoder = JSONDecoder()
            let poisData = try decoder.decode(CachedPOIData.self, from: data)
            
            // Check if cache is still valid
            if poisData.cachedAt.timeIntervalSinceNow > -configuration.maxCacheAge {
                return poisData.pois
            } else {
                // Remove expired cache
                try? FileManager.default.removeItem(at: fileURL)
                return nil
            }
            
        } catch {
            print("Failed to load cached POIs: \(error)")
            return nil
        }
    }
    
    // MARK: - Cache Management
    func clearExpiredCache() async {
        let fileManager = FileManager.default
        let cutoffDate = Date().addingTimeInterval(-configuration.maxCacheAge)
        
        do {
            let files = try fileManager.contentsOfDirectory(at: cacheDirectory, includingPropertiesForKeys: [.contentModificationDateKey])
            
            for fileURL in files {
                let attributes = try fileManager.attributesOfItem(atPath: fileURL.path)
                if let modificationDate = attributes[.modificationDate] as? Date,
                   modificationDate < cutoffDate {
                    try fileManager.removeItem(at: fileURL)
                }
            }
            
            await updateCacheStatistics()
            
        } catch {
            print("Failed to clear expired cache: \(error)")
        }
    }
    
    func clearAllCache() async {
        do {
            let files = try FileManager.default.contentsOfDirectory(at: cacheDirectory, includingPropertiesForKeys: nil)
            for fileURL in files {
                try FileManager.default.removeItem(at: fileURL)
            }
            
            await updateCacheStatistics()
            
        } catch {
            print("Failed to clear all cache: \(error)")
        }
    }
    
    func getCacheSize() async -> Int64 {
        do {
            let files = try FileManager.default.contentsOfDirectory(at: cacheDirectory, includingPropertiesForKeys: [.fileSizeKey])
            var totalSize: Int64 = 0
            
            for fileURL in files {
                let attributes = try FileManager.default.attributesOfItem(atPath: fileURL.path)
                if let fileSize = attributes[.size] as? Int64 {
                    totalSize += fileSize
                }
            }
            
            return totalSize
            
        } catch {
            print("Failed to calculate cache size: \(error)")
            return 0
        }
    }
    
    private func updateCacheStatistics() async {
        do {
            let files = try FileManager.default.contentsOfDirectory(at: cacheDirectory, includingPropertiesForKeys: [.fileSizeKey])
            cachedRegionsCount = files.count
            totalCacheSize = await getCacheSize()
            
        } catch {
            print("Failed to update cache statistics: \(error)")
        }
    }
}

// MARK: - Cached Data Models

struct CachedRouteData: Codable {
    let tripId: UUID
    let polylineData: Data
    let distance: CLLocationDistance
    let expectedTravelTime: TimeInterval
    let name: String
    let advisoryNotices: [String]
    let cachedAt: Date
    
    init(tripId: UUID, polyline: MKPolyline, distance: CLLocationDistance, expectedTravelTime: TimeInterval, name: String, advisoryNotices: [String], cachedAt: Date) {
        self.tripId = tripId
        self.polylineData = NSKeyedArchiver.archivedData(withRootObject: polyline)
        self.distance = distance
        self.expectedTravelTime = expectedTravelTime
        self.name = name
        self.advisoryNotices = advisoryNotices
        self.cachedAt = cachedAt
    }
    
    var polyline: MKPolyline? {
        return NSKeyedUnarchiver.unarchiveObject(with: polylineData) as? MKPolyline
    }
}

struct CachedMapRegion: Codable {
    let identifier: String
    let center: CLLocationCoordinate2D
    let span: MKCoordinateSpan
    let cachedAt: Date
}

struct CachedPOIData: Codable {
    let regionIdentifier: String
    let pois: [PointOfInterest]
    let cachedAt: Date
}

// MARK: - CLLocationCoordinate2D Codable Extension
extension CLLocationCoordinate2D: Codable {
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(latitude, forKey: .latitude)
        try container.encode(longitude, forKey: .longitude)
    }
    
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let latitude = try container.decode(Double.self, forKey: .latitude)
        let longitude = try container.decode(Double.self, forKey: .longitude)
        self.init(latitude: latitude, longitude: longitude)
    }
    
    private enum CodingKeys: String, CodingKey {
        case latitude, longitude
    }
}

// MARK: - MKCoordinateSpan Codable Extension
extension MKCoordinateSpan: Codable {
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(latitudeDelta, forKey: .latitudeDelta)
        try container.encode(longitudeDelta, forKey: .longitudeDelta)
    }
    
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let latitudeDelta = try container.decode(Double.self, forKey: .latitudeDelta)
        let longitudeDelta = try container.decode(Double.self, forKey: .longitudeDelta)
        self.init(latitudeDelta: latitudeDelta, longitudeDelta: longitudeDelta)
    }
    
    private enum CodingKeys: String, CodingKey {
        case latitudeDelta, longitudeDelta
    }
}