import Foundation
import UserNotifications
import Combine
import CoreLocation

// MARK: - Notification Service
class NotificationService: NSObject, NotificationServiceProtocol {
    
    // MARK: - Properties
    private let notificationCenter = UNUserNotificationCenter.current()
    private let notificationPermissionSubject = CurrentValueSubject<UNAuthorizationStatus, Never>(.notDetermined)
    
    // MARK: - Publishers
    var notificationPermissionStatus: AnyPublisher<UNAuthorizationStatus, Never> {
        notificationPermissionSubject.eraseToAnyPublisher()
    }
    
    // MARK: - Initialization
    override init() {
        super.init()
        notificationCenter.delegate = self
        checkNotificationPermissionStatus()
    }
    
    // MARK: - Permission Management
    func requestNotificationPermission() async throws -> Bool {
        let options: UNAuthorizationOptions = [.alert, .sound, .badge, .provisional]
        
        do {
            let granted = try await notificationCenter.requestAuthorization(options: options)
            await updatePermissionStatus()
            return granted
        } catch {
            throw AppError.notificationPermissionDenied
        }
    }
    
    private func checkNotificationPermissionStatus() {
        Task {
            await updatePermissionStatus()
        }
    }
    
    @MainActor
    private func updatePermissionStatus() async {
        let settings = await notificationCenter.notificationSettings()
        notificationPermissionSubject.send(settings.authorizationStatus)
    }
    
    // MARK: - Local Notifications
    func scheduleLocalNotification(_ notification: LocalNotification) async throws {
        let content = UNMutableNotificationContent()
        content.title = notification.title
        content.body = notification.body
        content.sound = notification.sound
        content.badge = notification.badge
        
        if let userInfo = notification.userInfo {
            content.userInfo = userInfo
        }
        
        let request = UNNotificationRequest(
            identifier: notification.identifier,
            content: content,
            trigger: notification.trigger
        )
        
        try await notificationCenter.add(request)
    }
    
    func cancelNotification(withIdentifier identifier: String) async throws {
        notificationCenter.removePendingNotificationRequests(withIdentifiers: [identifier])
        notificationCenter.removeDeliveredNotifications(withIdentifiers: [identifier])
    }
    
    func cancelAllNotifications() async throws {
        notificationCenter.removeAllPendingNotificationRequests()
        notificationCenter.removeAllDeliveredNotifications()
    }
    
    // MARK: - Push Notifications
    func sendPushNotification(_ notification: PushNotification) async throws {
        // In a real implementation, this would send to a backend service
        // For now, we'll simulate by creating local notifications for testing
        
        for recipientId in notification.recipientIds {
            let localNotification = LocalNotification(
                identifier: "push_\(UUID().uuidString)",
                title: notification.title,
                body: notification.body,
                sound: notification.priority == .emergency ? .defaultCritical : .default,
                badge: nil,
                userInfo: [
                    "recipientId": recipientId.uuidString,
                    "priority": notification.priority.rawValue,
                    "data": notification.data ?? [:]
                ],
                trigger: UNTimeIntervalNotificationTrigger(timeInterval: 0.1, repeats: false)
            )
            
            try await scheduleLocalNotification(localNotification)
        }
    }
    
    func registerForRemoteNotifications() async throws -> Data {
        // This would typically register with APNs
        // For now, return mock data
        return Data()
    }
    
    func handleRemoteNotification(_ userInfo: [AnyHashable: Any]) async {
        // Handle incoming push notifications
        // Parse notification data and take appropriate actions
        
        if let notificationType = userInfo["type"] as? String {
            switch notificationType {
            case "participant_joined":
                await handleParticipantJoinedNotification(userInfo)
            case "participant_left":
                await handleParticipantLeftNotification(userInfo)
            case "approaching_destination":
                await handleApproachingDestinationNotification(userInfo)
            case "emergency":
                await handleEmergencyNotification(userInfo)
            case "trip_update":
                await handleTripUpdateNotification(userInfo)
            default:
                break
            }
        }
    }
    
    // MARK: - Trip Event Notifications
    func sendParticipantJoinedNotification(participant: Participant, trip: Trip) async throws {
        let notification = PushNotification(
            recipientIds: trip.participants.map { $0.userId },
            title: "New Participant Joined",
            body: "\(participant.user.username) has joined \(trip.name)",
            data: [
                "type": "participant_joined",
                "tripId": trip.id.uuidString,
                "participantId": participant.id.uuidString
            ],
            priority: .normal
        )
        
        try await sendPushNotification(notification)
    }
    
    func sendParticipantLeftNotification(participant: Participant, trip: Trip) async throws {
        let notification = PushNotification(
            recipientIds: trip.participants.map { $0.userId },
            title: "Participant Left",
            body: "\(participant.user.username) has left \(trip.name)",
            data: [
                "type": "participant_left",
                "tripId": trip.id.uuidString,
                "participantId": participant.id.uuidString
            ],
            priority: .normal
        )
        
        try await sendPushNotification(notification)
    }
    
    func sendApproachingDestinationNotification(destination: Destination, participant: Participant, trip: Trip, distance: CLLocationDistance) async throws {
        let distanceText = distance < 1000 ? 
            String(format: "%.0f meters", distance) : 
            String(format: "%.1f km", distance / 1000)
        
        let notification = PushNotification(
            recipientIds: trip.participants.map { $0.userId },
            title: "Approaching Destination",
            body: "\(participant.user.username) is \(distanceText) from \(destination.name)",
            data: [
                "type": "approaching_destination",
                "tripId": trip.id.uuidString,
                "participantId": participant.id.uuidString,
                "destinationId": destination.id.uuidString,
                "distance": distance
            ],
            priority: .high
        )
        
        try await sendPushNotification(notification)
    }
    
    func sendEmergencyNotification(participant: Participant, trip: Trip, message: String, location: CLLocationCoordinate2D) async throws {
        let notification = PushNotification(
            recipientIds: trip.participants.map { $0.userId },
            title: "🚨 EMERGENCY ALERT",
            body: "\(participant.user.username): \(message)",
            data: [
                "type": "emergency",
                "tripId": trip.id.uuidString,
                "participantId": participant.id.uuidString,
                "message": message,
                "latitude": location.latitude,
                "longitude": location.longitude
            ],
            priority: .emergency
        )
        
        try await sendPushNotification(notification)
    }
    
    func sendTripUpdateNotification(trip: Trip, updateType: TripUpdateType, message: String) async throws {
        let notification = PushNotification(
            recipientIds: trip.participants.map { $0.userId },
            title: "Trip Update",
            body: message,
            data: [
                "type": "trip_update",
                "tripId": trip.id.uuidString,
                "updateType": updateType.rawValue
            ],
            priority: .normal
        )
        
        try await sendPushNotification(notification)
    }
    
    // MARK: - Location-Based Notifications
    func scheduleLocationBasedNotification(
        identifier: String,
        title: String,
        body: String,
        coordinate: CLLocationCoordinate2D,
        radius: CLLocationDistance,
        notifyOnEntry: Bool = true,
        notifyOnExit: Bool = false
    ) async throws {
        let region = CLCircularRegion(
            center: coordinate,
            radius: radius,
            identifier: identifier
        )
        region.notifyOnEntry = notifyOnEntry
        region.notifyOnExit = notifyOnExit
        
        let trigger = UNLocationNotificationTrigger(region: region, repeats: false)
        
        let notification = LocalNotification(
            identifier: identifier,
            title: title,
            body: body,
            trigger: trigger
        )
        
        try await scheduleLocalNotification(notification)
    }
    
    // MARK: - Notification Preferences
    func updateNotificationPreferences(_ preferences: NotificationPreferences) async throws {
        // Store preferences locally or sync with backend
        UserDefaults.standard.set(try PropertyListEncoder().encode(preferences), forKey: "notification_preferences")
    }
    
    func getNotificationPreferences() -> NotificationPreferences {
        guard let data = UserDefaults.standard.data(forKey: "notification_preferences"),
              let preferences = try? PropertyListDecoder().decode(NotificationPreferences.self, from: data) else {
            return NotificationPreferences()
        }
        return preferences
    }
    
    // MARK: - Do Not Disturb Handling
    private func shouldSendNotification(priority: NotificationPriority) -> Bool {
        let preferences = getNotificationPreferences()
        
        // Always send emergency notifications
        if priority == .emergency {
            return true
        }
        
        // Check if Do Not Disturb is enabled
        if preferences.respectDoNotDisturb {
            let hour = Calendar.current.component(.hour, from: Date())
            if hour >= preferences.quietHoursStart || hour < preferences.quietHoursEnd {
                return priority == .high || priority == .emergency
            }
        }
        
        return true
    }
    
    // MARK: - Private Notification Handlers
    private func handleParticipantJoinedNotification(_ userInfo: [AnyHashable: Any]) async {
        // Handle participant joined notification
        // Update local state, refresh UI, etc.
    }
    
    private func handleParticipantLeftNotification(_ userInfo: [AnyHashable: Any]) async {
        // Handle participant left notification
        // Update local state, refresh UI, etc.
    }
    
    private func handleApproachingDestinationNotification(_ userInfo: [AnyHashable: Any]) async {
        // Handle approaching destination notification
        // Show location on map, prepare navigation, etc.
    }
    
    private func handleEmergencyNotification(_ userInfo: [AnyHashable: Any]) async {
        // Handle emergency notification
        // Show emergency alert, provide assistance options, etc.
    }
    
    private func handleTripUpdateNotification(_ userInfo: [AnyHashable: Any]) async {
        // Handle trip update notification
        // Refresh trip data, update UI, etc.
    }
}

// MARK: - UNUserNotificationCenterDelegate
extension NotificationService: UNUserNotificationCenterDelegate {
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        // Handle notification when app is in foreground
        let userInfo = notification.request.content.userInfo
        
        if let priorityString = userInfo["priority"] as? String,
           let priority = NotificationPriority(rawValue: priorityString) {
            
            switch priority {
            case .emergency:
                completionHandler([.banner, .sound, .badge])
            case .high:
                completionHandler([.banner, .sound])
            case .normal, .low:
                completionHandler([.banner])
            }
        } else {
            completionHandler([.banner])
        }
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        // Handle notification tap
        let userInfo = response.notification.request.content.userInfo
        
        Task {
            await handleRemoteNotification(userInfo)
            completionHandler()
        }
    }
}

// MARK: - Supporting Types
enum TripUpdateType: String, Codable {
    case destinationAdded = "destination_added"
    case destinationRemoved = "destination_removed"
    case routeChanged = "route_changed"
    case statusChanged = "status_changed"
    case budgetUpdated = "budget_updated"
}

struct NotificationPreferences: Codable {
    var tripEvents: Bool = true
    var participantUpdates: Bool = true
    var locationAlerts: Bool = true
    var emergencyAlerts: Bool = true
    var budgetAlerts: Bool = true
    var weatherAlerts: Bool = true
    var respectDoNotDisturb: Bool = true
    var quietHoursStart: Int = 22 // 10 PM
    var quietHoursEnd: Int = 7   // 7 AM
    
    init() {}
}

// MARK: - NotificationPriority Extension
extension NotificationPriority {
    init?(rawValue: String) {
        switch rawValue {
        case "low": self = .low
        case "normal": self = .normal
        case "high": self = .high
        case "emergency": self = .emergency
        default: return nil
        }
    }
    
    var rawValue: String {
        switch self {
        case .low: return "low"
        case .normal: return "normal"
        case .high: return "high"
        case .emergency: return "emergency"
        }
    }
}