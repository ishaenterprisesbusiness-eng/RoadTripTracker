import Foundation
import CoreData
import CoreLocation
import Combine

// MARK: - Location Cache Service
@MainActor
class LocationCacheService: ObservableObject {
    
    // MARK: - Properties
    private let persistenceController = PersistenceController.shared
    private let offlineManager = OfflineManager.shared
    private let configuration = OfflineConfiguration()
    
    @Published var cachedLocationsCount: Int = 0
    @Published var lastCacheUpdate: Date?
    
    // MARK: - Location Caching
    func cacheLocation(_ location: CLLocation, for participantId: UUID, in tripId: UUID) async {
        // Cache locally in Core Data
        await cacheLocationLocally(location, participantId: participantId, tripId: tripId)
        
        // Queue for sync if offline
        if !offlineManager.isOnline {
            let cachedData = CachedLocationData(
                tripId: tripId,
                participantId: participantId,
                latitude: location.coordinate.latitude,
                longitude: location.coordinate.longitude,
                timestamp: location.timestamp,
                speed: location.speed >= 0 ? location.speed : nil,
                heading: location.course >= 0 ? location.course : nil,
                accuracy: location.horizontalAccuracy
            )
            
            if let data = try? JSONEncoder().encode(cachedData) {
                let operation = OfflineOperation(type: .locationUpdate, data: data)
                offlineManager.queueOperation(operation)
            }
        }
    }
    
    private func cacheLocationLocally(_ location: CLLocation, participantId: UUID, tripId: UUID) async {
        do {
            try await persistenceController.performBackgroundTask { context in
                // Find or create participant
                let participantRequest: NSFetchRequest<CDParticipant> = CDParticipant.fetchRequest()
                participantRequest.predicate = NSPredicate(format: "id == %@ AND trip.id == %@", participantId as CVarArg, tripId as CVarArg)
                
                let participants = try context.fetch(participantRequest)
                guard let participant = participants.first else {
                    print("Participant not found for location caching")
                    return
                }
                
                // Update participant location
                participant.currentLatitude = location.coordinate.latitude
                participant.currentLongitude = location.coordinate.longitude
                participant.lastLocationUpdate = location.timestamp
                
                try context.save()
            }
            
            await updateCacheStatistics()
            
        } catch {
            print("Failed to cache location locally: \(error)")
        }
    }
    
    // MARK: - Location Retrieval
    func getCachedLocations(for tripId: UUID) async -> [UUID: CLLocation] {
        do {
            return try await persistenceController.performBackgroundTask { context in
                let participantRequest: NSFetchRequest<CDParticipant> = CDParticipant.fetchRequest()
                participantRequest.predicate = NSPredicate(format: "trip.id == %@ AND lastLocationUpdate != nil", tripId as CVarArg)
                
                let participants = try context.fetch(participantRequest)
                var locations: [UUID: CLLocation] = [:]
                
                for participant in participants {
                    guard let participantId = participant.id,
                          let lastUpdate = participant.lastLocationUpdate,
                          participant.currentLatitude != 0 || participant.currentLongitude != 0 else {
                        continue
                    }
                    
                    let location = CLLocation(
                        coordinate: CLLocationCoordinate2D(
                            latitude: participant.currentLatitude,
                            longitude: participant.currentLongitude
                        ),
                        altitude: 0,
                        horizontalAccuracy: 10,
                        verticalAccuracy: -1,
                        timestamp: lastUpdate
                    )
                    
                    locations[participantId] = location
                }
                
                return locations
            }
        } catch {
            print("Failed to retrieve cached locations: \(error)")
            return [:]
        }
    }
    
    func getLastKnownLocation(for participantId: UUID, in tripId: UUID) async -> CLLocation? {
        do {
            return try await persistenceController.performBackgroundTask { context in
                let participantRequest: NSFetchRequest<CDParticipant> = CDParticipant.fetchRequest()
                participantRequest.predicate = NSPredicate(format: "id == %@ AND trip.id == %@", participantId as CVarArg, tripId as CVarArg)
                
                let participants = try context.fetch(participantRequest)
                guard let participant = participants.first,
                      let lastUpdate = participant.lastLocationUpdate,
                      participant.currentLatitude != 0 || participant.currentLongitude != 0 else {
                    return nil
                }
                
                return CLLocation(
                    coordinate: CLLocationCoordinate2D(
                        latitude: participant.currentLatitude,
                        longitude: participant.currentLongitude
                    ),
                    altitude: 0,
                    horizontalAccuracy: 10,
                    verticalAccuracy: -1,
                    timestamp: lastUpdate
                )
            }
        } catch {
            print("Failed to retrieve last known location: \(error)")
            return nil
        }
    }
    
    // MARK: - Location History
    func getLocationHistory(for participantId: UUID, in tripId: UUID, limit: Int = 50) async -> [CLLocation] {
        // For now, we only store the latest location per participant
        // In a full implementation, you might want to store location history
        if let location = await getLastKnownLocation(for: participantId, in: tripId) {
            return [location]
        }
        return []
    }
    
    // MARK: - Cache Management
    func clearExpiredLocations() async {
        let cutoffDate = Date().addingTimeInterval(-configuration.maxCacheAge)
        
        do {
            try await persistenceController.performBackgroundTask { context in
                let participantRequest: NSFetchRequest<CDParticipant> = CDParticipant.fetchRequest()
                participantRequest.predicate = NSPredicate(format: "lastLocationUpdate < %@", cutoffDate as NSDate)
                
                let expiredParticipants = try context.fetch(participantRequest)
                for participant in expiredParticipants {
                    participant.currentLatitude = 0
                    participant.currentLongitude = 0
                    participant.lastLocationUpdate = nil
                }
                
                try context.save()
            }
            
            await updateCacheStatistics()
            
        } catch {
            print("Failed to clear expired locations: \(error)")
        }
    }
    
    func clearAllCachedLocations() async {
        do {
            try await persistenceController.performBackgroundTask { context in
                let participantRequest: NSFetchRequest<CDParticipant> = CDParticipant.fetchRequest()
                let participants = try context.fetch(participantRequest)
                
                for participant in participants {
                    participant.currentLatitude = 0
                    participant.currentLongitude = 0
                    participant.lastLocationUpdate = nil
                }
                
                try context.save()
            }
            
            await updateCacheStatistics()
            
        } catch {
            print("Failed to clear all cached locations: \(error)")
        }
    }
    
    // MARK: - Statistics
    private func updateCacheStatistics() async {
        do {
            let count = try await persistenceController.performBackgroundTask { context in
                let participantRequest: NSFetchRequest<CDParticipant> = CDParticipant.fetchRequest()
                participantRequest.predicate = NSPredicate(format: "lastLocationUpdate != nil")
                return try context.count(for: participantRequest)
            }
            
            cachedLocationsCount = count
            lastCacheUpdate = Date()
            
        } catch {
            print("Failed to update cache statistics: \(error)")
        }
    }
    
    func getCacheStatistics() async -> CacheStatistics {
        do {
            let (count, oldestDate, size) = try await persistenceController.performBackgroundTask { context in
                let participantRequest: NSFetchRequest<CDParticipant> = CDParticipant.fetchRequest()
                participantRequest.predicate = NSPredicate(format: "lastLocationUpdate != nil")
                participantRequest.sortDescriptors = [NSSortDescriptor(keyPath: \CDParticipant.lastLocationUpdate, ascending: true)]
                
                let count = try context.count(for: participantRequest)
                let participants = try context.fetch(participantRequest)
                let oldestDate = participants.first?.lastLocationUpdate
                
                // Estimate cache size (rough calculation)
                let estimatedSize = Int64(count * 64) // ~64 bytes per location entry
                
                return (count, oldestDate, estimatedSize)
            }
            
            return CacheStatistics(
                totalCachedItems: count,
                pendingOperations: offlineManager.pendingOperationsCount,
                lastSyncDate: lastCacheUpdate,
                cacheSize: size,
                oldestCachedItem: oldestDate
            )
            
        } catch {
            print("Failed to get cache statistics: \(error)")
            return CacheStatistics(
                totalCachedItems: 0,
                pendingOperations: 0,
                lastSyncDate: nil,
                cacheSize: 0,
                oldestCachedItem: nil
            )
        }
    }
    
    // MARK: - Sync Support
    func syncCachedLocations() async {
        await offlineManager.syncPendingOperations()
    }
    
    // MARK: - Location Validation
    func isLocationValid(_ location: CLLocation) -> Bool {
        // Check if location is recent enough
        guard location.timestamp.timeIntervalSinceNow > -configuration.maxCacheAge else {
            return false
        }
        
        // Check accuracy
        guard location.horizontalAccuracy > 0 && location.horizontalAccuracy < 100 else {
            return false
        }
        
        // Check if coordinates are valid
        guard CLLocationCoordinate2DIsValid(location.coordinate) else {
            return false
        }
        
        return true
    }
    
    func shouldUpdateLocation(_ newLocation: CLLocation, previous: CLLocation?) -> Bool {
        guard let previous = previous else { return true }
        
        // Update if significant distance change
        let distance = newLocation.distance(from: previous)
        if distance > 10 { // 10 meters
            return true
        }
        
        // Update if significant time has passed
        let timeDifference = newLocation.timestamp.timeIntervalSince(previous.timestamp)
        if timeDifference > configuration.locationUpdateThreshold {
            return true
        }
        
        // Update if accuracy improved significantly
        if newLocation.horizontalAccuracy < previous.horizontalAccuracy * 0.8 {
            return true
        }
        
        return false
    }
}