import SwiftUI
import UIKit
import AVFoundation
import Combine

// MARK: - Accessibility Manager
class AccessibilityManager: ObservableObject {
    @Published var isVoiceOverEnabled = false
    @Published var isReduceMotionEnabled = false
    @Published var isReduceTransparencyEnabled = false
    @Published var isHighContrastEnabled = false
    @Published var isDynamicTypeEnabled = false
    @Published var preferredContentSizeCategory: ContentSizeCategory = .medium
    @Published var isAssistiveTouchEnabled = false
    @Published var isSwitchControlEnabled = false
    
    private var cancellables = Set<AnyCancellable>()
    private let speechSynthesizer = AVSpeechSynthesizer()
    
    static let shared = AccessibilityManager()
    
    init() {
        setupAccessibilityObservers()
        updateAccessibilitySettings()
    }
    
    private func setupAccessibilityObservers() {
        // VoiceOver
        NotificationCenter.default.publisher(for: UIAccessibility.voiceOverStatusDidChangeNotification)
            .sink { [weak self] _ in
                self?.updateAccessibilitySettings()
            }
            .store(in: &cancellables)
        
        // Reduce Motion
        NotificationCenter.default.publisher(for: UIAccessibility.reduceMotionStatusDidChangeNotification)
            .sink { [weak self] _ in
                self?.updateAccessibilitySettings()
            }
            .store(in: &cancellables)
        
        // Reduce Transparency
        NotificationCenter.default.publisher(for: UIAccessibility.reduceTransparencyStatusDidChangeNotification)
            .sink { [weak self] _ in
                self?.updateAccessibilitySettings()
            }
            .store(in: &cancellables)
        
        // High Contrast
        NotificationCenter.default.publisher(for: UIAccessibility.darkerSystemColorsStatusDidChangeNotification)
            .sink { [weak self] _ in
                self?.updateAccessibilitySettings()
            }
            .store(in: &cancellables)
        
        // Dynamic Type
        NotificationCenter.default.publisher(for: UIContentSizeCategory.didChangeNotification)
            .sink { [weak self] _ in
                self?.updateAccessibilitySettings()
            }
            .store(in: &cancellables)
        
        // Assistive Touch
        NotificationCenter.default.publisher(for: UIAccessibility.assistiveTouchStatusDidChangeNotification)
            .sink { [weak self] _ in
                self?.updateAccessibilitySettings()
            }
            .store(in: &cancellables)
        
        // Switch Control
        NotificationCenter.default.publisher(for: UIAccessibility.switchControlStatusDidChangeNotification)
            .sink { [weak self] _ in
                self?.updateAccessibilitySettings()
            }
            .store(in: &cancellables)
    }
    
    private func updateAccessibilitySettings() {
        DispatchQueue.main.async {
            self.isVoiceOverEnabled = UIAccessibility.isVoiceOverRunning
            self.isReduceMotionEnabled = UIAccessibility.isReduceMotionEnabled
            self.isReduceTransparencyEnabled = UIAccessibility.isReduceTransparencyEnabled
            self.isHighContrastEnabled = UIAccessibility.isDarkerSystemColorsEnabled
            self.isDynamicTypeEnabled = UIApplication.shared.preferredContentSizeCategory.isAccessibilityCategory
            self.preferredContentSizeCategory = ContentSizeCategory(UIApplication.shared.preferredContentSizeCategory)
            self.isAssistiveTouchEnabled = UIAccessibility.isAssistiveTouchRunning
            self.isSwitchControlEnabled = UIAccessibility.isSwitchControlRunning
        }
    }
    
    // MARK: - Accessibility Helpers
    
    func announceForAccessibility(_ message: String, priority: UIAccessibility.Notification = .announcement) {
        guard isVoiceOverEnabled else { return }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            UIAccessibility.post(notification: priority, argument: message)
        }
    }
    
    func speakText(_ text: String, rate: Float = 0.5, pitch: Float = 1.0, volume: Float = 1.0) {
        guard !isVoiceOverEnabled else { return } // Don't interfere with VoiceOver
        
        let utterance = AVSpeechUtterance(string: text)
        utterance.rate = rate
        utterance.pitchMultiplier = pitch
        utterance.volume = volume
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        
        speechSynthesizer.speak(utterance)
    }
    
    func stopSpeaking() {
        speechSynthesizer.stopSpeaking(at: .immediate)
    }
    
    func getAccessibilityLabel(for element: AccessibilityElement) -> String {
        switch element {
        case .tripDashboard:
            return "Trip Dashboard. Shows current trip progress, time to destination, and participant status."
        case .mapView:
            return "Map View. Displays real-time locations of all trip participants and planned route."
        case .chatView:
            return "Group Chat. Send messages and share photos with trip participants."
        case .profileView:
            return "Profile. Manage your account, vehicle details, and trip history."
        case .createTrip:
            return "Create New Trip. Start planning a new road trip with multiple destinations."
        case .joinTrip:
            return "Join Trip. Enter a trip code to join an existing road trip group."
        case .emergencyButton:
            return "Emergency Button. Tap to send emergency alert to all participants and emergency contacts."
        case .locationSharing:
            return "Location Sharing Toggle. Enable or disable sharing your location with trip participants."
        case .fuelStop:
            return "Plan Fuel Stop. Find and coordinate fuel stops with your group."
        case .foodStop:
            return "Plan Food Stop. Find restaurants and coordinate meal stops with your group."
        }
    }
    
    func getAccessibilityHint(for element: AccessibilityElement) -> String {
        switch element {
        case .tripDashboard:
            return "Double tap to view detailed trip information and metrics."
        case .mapView:
            return "Double tap to center map on your location. Use gestures to zoom and pan."
        case .chatView:
            return "Double tap to open keyboard and send a message to your group."
        case .profileView:
            return "Double tap to edit your profile information and settings."
        case .createTrip:
            return "Double tap to start creating a new trip with destinations and settings."
        case .joinTrip:
            return "Double tap to enter a trip code and join an existing group."
        case .emergencyButton:
            return "Double tap to send emergency alert. This will notify all participants and emergency services."
        case .locationSharing:
            return "Double tap to toggle location sharing on or off."
        case .fuelStop:
            return "Double tap to search for nearby gas stations and propose a fuel stop."
        case .foodStop:
            return "Double tap to search for nearby restaurants and propose a food stop."
        }
    }
    
    func shouldReduceAnimations() -> Bool {
        return isReduceMotionEnabled
    }
    
    func shouldReduceTransparency() -> Bool {
        return isReduceTransparencyEnabled
    }
    
    func shouldUseHighContrast() -> Bool {
        return isHighContrastEnabled
    }
    
    func getAdaptiveAnimationDuration() -> Double {
        return isReduceMotionEnabled ? 0.1 : 0.3
    }
    
    func getAdaptiveSpringAnimation() -> Animation {
        if isReduceMotionEnabled {
            return .linear(duration: 0.1)
        } else {
            return .spring(response: 0.4, dampingFraction: 0.8)
        }
    }
}

// MARK: - Accessibility Element Types
enum AccessibilityElement {
    case tripDashboard
    case mapView
    case chatView
    case profileView
    case createTrip
    case joinTrip
    case emergencyButton
    case locationSharing
    case fuelStop
    case foodStop
}

// MARK: - Accessibility Modifiers
extension View {
    func accessibilityElement(_ element: AccessibilityElement) -> some View {
        let manager = AccessibilityManager.shared
        return self
            .accessibilityLabel(manager.getAccessibilityLabel(for: element))
            .accessibilityHint(manager.getAccessibilityHint(for: element))
    }
    
    func accessibilityAnnouncement(_ message: String, priority: UIAccessibility.Notification = .announcement) -> some View {
        self.onAppear {
            AccessibilityManager.shared.announceForAccessibility(message, priority: priority)
        }
    }
    
    func adaptiveAnimation() -> some View {
        let manager = AccessibilityManager.shared
        return self.animation(manager.getAdaptiveSpringAnimation(), value: UUID())
    }
    
    func adaptiveTransparency() -> some View {
        let manager = AccessibilityManager.shared
        return self.opacity(manager.shouldReduceTransparency() ? 1.0 : 0.9)
    }
    
    func adaptiveBlur(radius: CGFloat) -> some View {
        let manager = AccessibilityManager.shared
        return self.blur(radius: manager.shouldReduceTransparency() ? 0 : radius)
    }
    
    func highContrastColors(normal: Color, highContrast: Color) -> some View {
        let manager = AccessibilityManager.shared
        return self.foregroundColor(manager.shouldUseHighContrast() ? highContrast : normal)
    }
}

// MARK: - Content Size Category Extension
extension ContentSizeCategory {
    init(_ uiContentSizeCategory: UIContentSizeCategory) {
        switch uiContentSizeCategory {
        case .extraSmall: self = .extraSmall
        case .small: self = .small
        case .medium: self = .medium
        case .large: self = .large
        case .extraLarge: self = .extraLarge
        case .extraExtraLarge: self = .extraExtraLarge
        case .extraExtraExtraLarge: self = .extraExtraExtraLarge
        case .accessibilityMedium: self = .accessibilityMedium
        case .accessibilityLarge: self = .accessibilityLarge
        case .accessibilityExtraLarge: self = .accessibilityExtraLarge
        case .accessibilityExtraExtraLarge: self = .accessibilityExtraExtraLarge
        case .accessibilityExtraExtraExtraLarge: self = .accessibilityExtraExtraExtraLarge
        default: self = .medium
        }
    }
}