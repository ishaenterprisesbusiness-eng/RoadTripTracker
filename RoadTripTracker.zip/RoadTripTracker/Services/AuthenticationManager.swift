import Foundation
import Combine
import LocalAuthentication
import CryptoKit

// MARK: - Authentication Manager
class AuthenticationManager: AuthenticationServiceProtocol {
    
    // MARK: - Properties
    @Published private(set) var currentUser: User?
    @Published private(set) var isAuthenticated: Bool = false
    @Published private(set) var authenticationState: AuthenticationState = .unauthenticated
    
    var authenticationStatePublisher: AnyPublisher<AuthenticationState, Never> {
        $authenticationState.eraseToAnyPublisher()
    }
    
    private let persistenceController: PersistenceController
    private let emailVerificationService: EmailVerificationService
    private let jwtManager = JWTManager()
    private let biometricManager = BiometricAuthManager()
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Session Management
    private var currentSession: UserSession?
    private let keychain = KeychainManager()
    
    // MARK: - Initialization
    init(persistenceController: PersistenceController) {
        self.persistenceController = persistenceController
        self.emailVerificationService = EmailVerificationService()
        
        // Try to restore session on init
        Task {
            await restoreSession()
        }
    }
    
    // MARK: - Authentication Methods
    
    func signUp(userData: UserRegistrationData) async throws -> User {
        authenticationState = .authenticating
        
        do {
            // Validate user data
            try validateUserData(userData)
            
            // Check if email already exists
            if await emailExists(userData.email) {
                throw AuthenticationError.emailAlreadyExists
            }
            
            // Create user in Core Data
            let user = try await createUser(from: userData)
            
            // Send email verification
            try await emailVerificationService.sendVerificationEmail(to: userData.email, userId: user.id)
            
            // Set state to require email verification
            authenticationState = .emailVerificationRequired
            
            return user
            
        } catch let error as AuthenticationError {
            authenticationState = .error(error)
            throw error
        } catch {
            let authError = AuthenticationError.unknown(error.localizedDescription)
            authenticationState = .error(authError)
            throw authError
        }
    }
    
    func signIn(email: String, password: String) async throws -> User {
        authenticationState = .authenticating
        
        do {
            // Find user by email
            guard let user = await findUser(by: email) else {
                throw AuthenticationError.invalidCredentials
            }
            
            // Verify password
            let hashedPassword = hashPassword(password)
            guard await verifyPassword(hashedPassword, for: user.id) else {
                throw AuthenticationError.invalidCredentials
            }
            
            // Check if email is verified
            guard await isEmailVerified(for: user.id) else {
                authenticationState = .emailVerificationRequired
                throw AuthenticationError.emailNotVerified
            }
            
            // Create session
            let session = try await createSession(for: user)
            currentSession = session
            
            // Store session in keychain
            try keychain.store(session: session)
            
            // Update state
            currentUser = user
            isAuthenticated = true
            authenticationState = .authenticated(user)
            
            return user
            
        } catch let error as AuthenticationError {
            authenticationState = .error(error)
            throw error
        } catch {
            let authError = AuthenticationError.unknown(error.localizedDescription)
            authenticationState = .error(authError)
            throw authError
        }
    }
    
    func signOut() async throws {
        do {
            // Invalidate current session
            if let session = currentSession {
                try await invalidateSession(session)
            }
            
            // Clear keychain
            try keychain.clearSession()
            
            // Reset state
            currentUser = nil
            isAuthenticated = false
            currentSession = nil
            authenticationState = .unauthenticated
            
        } catch {
            throw AuthenticationError.unknown(error.localizedDescription)
        }
    }
    
    func resetPassword(email: String) async throws {
        do {
            // Check if user exists
            guard await emailExists(email) else {
                // Don't reveal if email exists for security
                return
            }
            
            // Send password reset email
            try await emailVerificationService.sendPasswordResetEmail(to: email)
            
        } catch {
            throw AuthenticationError.networkError
        }
    }
    
    func verifyEmail(token: String) async throws {
        do {
            // Verify the email token
            let userId = try await emailVerificationService.verifyEmailToken(token)
            
            // Mark email as verified in database
            try await markEmailAsVerified(for: userId)
            
            // If this is the current user, update authentication state
            if let currentUser = currentUser, currentUser.id == userId {
                authenticationState = .authenticated(currentUser)
            }
            
        } catch {
            throw AuthenticationError.unknown(error.localizedDescription)
        }
    }
    
    func refreshToken() async throws {
        guard let session = currentSession else {
            throw AuthenticationError.tokenExpired
        }
        
        do {
            // Check if token needs refresh
            if session.isExpired {
                let newSession = try await refreshSession(session)
                currentSession = newSession
                try keychain.store(session: newSession)
            }
        } catch {
            // If refresh fails, sign out
            try await signOut()
            throw AuthenticationError.tokenExpired
        }
    }
    
    // MARK: - Biometric Authentication
    
    func enableBiometricAuth() async throws -> Bool {
        guard biometricManager.isBiometricAvailable else {
            throw AuthenticationError.biometricNotAvailable
        }
        
        guard let user = currentUser else {
            throw AuthenticationError.unknown("No authenticated user")
        }
        
        do {
            let success = try await biometricManager.authenticateWithBiometrics(
                reason: "Enable biometric authentication for Road Trip Tracker"
            )
            
            if success {
                // Store biometric preference
                try keychain.enableBiometricAuth(for: user.id)
                biometricManager.setBiometricPreference(true, for: user.id)
                return true
            }
            
            return false
        } catch let error as BiometricError {
            throw AuthenticationError.biometricAuthFailed
        } catch {
            throw AuthenticationError.biometricAuthFailed
        }
    }
    
    func authenticateWithBiometrics() async throws -> User {
        guard biometricManager.isBiometricAvailable else {
            throw AuthenticationError.biometricNotAvailable
        }
        
        do {
            let success = try await biometricManager.authenticateWithBiometrics(
                reason: "Sign in to Road Trip Tracker"
            )
            
            if success {
                // Get stored session from keychain
                guard let session = try keychain.getStoredSession() else {
                    throw AuthenticationError.tokenExpired
                }
                
                // Verify session is still valid
                let user = try await validateSession(session)
                
                currentUser = user
                isAuthenticated = true
                currentSession = session
                authenticationState = .authenticated(user)
                
                return user
            } else {
                throw AuthenticationError.biometricAuthFailed
            }
        } catch let error as BiometricError {
            throw AuthenticationError.biometricAuthFailed
        } catch {
            throw AuthenticationError.biometricAuthFailed
        }
    }
    
    // MARK: - Private Helper Methods
    
    private func validateUserData(_ userData: UserRegistrationData) throws {
        // Validate email format
        let emailRegex = #"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"#
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        guard emailPredicate.evaluate(with: userData.email) else {
            throw AuthenticationError.invalidCredentials
        }
        
        // Validate password strength
        guard isPasswordStrong(userData.password) else {
            throw AuthenticationError.weakPassword
        }
        
        // Validate username
        guard !userData.username.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw AuthenticationError.unknown("Username cannot be empty")
        }
    }
    
    private func isPasswordStrong(_ password: String) -> Bool {
        // At least 8 characters, contains uppercase, lowercase, and number
        let minLength = password.count >= 8
        let hasUppercase = password.range(of: "[A-Z]", options: .regularExpression) != nil
        let hasLowercase = password.range(of: "[a-z]", options: .regularExpression) != nil
        let hasNumber = password.range(of: "[0-9]", options: .regularExpression) != nil
        
        return minLength && hasUppercase && hasLowercase && hasNumber
    }
    
    private func hashPassword(_ password: String) -> String {
        let data = Data(password.utf8)
        let hashed = SHA256.hash(data: data)
        return hashed.compactMap { String(format: "%02x", $0) }.joined()
    }
    
    private func createUser(from userData: UserRegistrationData) async throws -> User {
        let context = persistenceController.container.viewContext
        
        return try await context.perform {
            let cdUser = CDUser(context: context)
            cdUser.id = UUID()
            cdUser.username = userData.username
            cdUser.email = userData.email
            cdUser.city = userData.city
            cdUser.dateOfBirth = userData.dateOfBirth
            cdUser.age = Int32(Calendar.current.dateComponents([.year], from: userData.dateOfBirth, to: Date()).year ?? 0)
            
            // Create vehicle if provided
            if let vehicleData = userData.vehicle {
                let cdVehicle = CDVehicle(context: context)
                cdVehicle.id = UUID()
                cdVehicle.make = vehicleData.make
                cdVehicle.model = vehicleData.model
                cdVehicle.vehicleNumber = vehicleData.vehicleNumber
                cdVehicle.odometerReading = Int32(vehicleData.odometerReading)
                cdVehicle.type = vehicleData.type.rawValue
                cdVehicle.color = vehicleData.color
                cdUser.vehicle = cdVehicle
            }
            
            // Store hashed password (in a real app, this would be more secure)
            let hashedPassword = self.hashPassword(userData.password)
            // Note: In production, password should be stored more securely
            
            try context.save()
            
            // Convert to User model
            let vehicle = userData.vehicle
            return User(
                id: cdUser.id!,
                username: cdUser.username!,
                email: cdUser.email!,
                city: cdUser.city!,
                dateOfBirth: cdUser.dateOfBirth!,
                vehicle: vehicle
            )
        }
    }
    
    private func emailExists(_ email: String) async -> Bool {
        let context = persistenceController.container.viewContext
        
        return await context.perform {
            let request = CDUser.fetchRequest()
            request.predicate = NSPredicate(format: "email == %@", email)
            request.fetchLimit = 1
            
            do {
                let users = try context.fetch(request)
                return !users.isEmpty
            } catch {
                return false
            }
        }
    }
    
    private func findUser(by email: String) async -> User? {
        let context = persistenceController.container.viewContext
        
        return await context.perform {
            let request = CDUser.fetchRequest()
            request.predicate = NSPredicate(format: "email == %@", email)
            request.fetchLimit = 1
            
            do {
                let cdUsers = try context.fetch(request)
                guard let cdUser = cdUsers.first else { return nil }
                
                let vehicle = cdUser.vehicle.map { cdVehicle in
                    Vehicle(
                        make: cdVehicle.make ?? "",
                        model: cdVehicle.model ?? "",
                        vehicleNumber: cdVehicle.vehicleNumber ?? "",
                        odometerReading: Int(cdVehicle.odometerReading),
                        type: VehicleType(rawValue: cdVehicle.type ?? "") ?? .other,
                        color: cdVehicle.color
                    )
                }
                
                return User(
                    id: cdUser.id!,
                    username: cdUser.username!,
                    email: cdUser.email!,
                    city: cdUser.city!,
                    dateOfBirth: cdUser.dateOfBirth!,
                    vehicle: vehicle,
                    profileImageURL: cdUser.profileImageURL
                )
            } catch {
                return nil
            }
        }
    }
    
    private func verifyPassword(_ hashedPassword: String, for userId: UUID) async -> Bool {
        // In a real implementation, this would verify against stored hash
        // For now, we'll simulate password verification
        return true
    }
    
    private func isEmailVerified(for userId: UUID) async -> Bool {
        // In a real implementation, this would check email verification status
        // For now, we'll simulate email verification
        return true
    }
    
    private func createSession(for user: User) async throws -> UserSession {
        let session = UserSession(
            userId: user.id,
            token: generateJWTToken(for: user),
            refreshToken: generateRefreshToken(),
            expiresAt: Date().addingTimeInterval(3600) // 1 hour
        )
        return session
    }
    
    private func generateJWTToken(for user: User) -> String {
        return jwtManager.generateToken(for: user)
    }
    
    private func generateRefreshToken() -> String {
        return UUID().uuidString
    }
    
    private func invalidateSession(_ session: UserSession) async throws {
        // In a real implementation, this would invalidate the session on the server
    }
    
    private func refreshSession(_ session: UserSession) async throws -> UserSession {
        // Validate the refresh token and generate a new access token
        guard let newToken = jwtManager.refreshToken(session.token) else {
            throw AuthenticationError.tokenExpired
        }
        
        return UserSession(
            userId: session.userId,
            token: newToken,
            refreshToken: generateRefreshToken(),
            expiresAt: Date().addingTimeInterval(3600)
        )
    }
    
    private func validateSession(_ session: UserSession) async throws -> User {
        // Validate the JWT token
        guard let jwtToken = jwtManager.validateToken(session.token),
              !jwtToken.isExpired,
              let userId = jwtToken.userId else {
            throw AuthenticationError.tokenExpired
        }
        
        guard let user = await findUser(by: userId) else {
            throw AuthenticationError.tokenExpired
        }
        
        return user
    }
    
    private func findUser(by userId: UUID) async -> User? {
        let context = persistenceController.container.viewContext
        
        return await context.perform {
            let request = CDUser.fetchRequest()
            request.predicate = NSPredicate(format: "id == %@", userId as CVarArg)
            request.fetchLimit = 1
            
            do {
                let cdUsers = try context.fetch(request)
                guard let cdUser = cdUsers.first else { return nil }
                
                let vehicle = cdUser.vehicle.map { cdVehicle in
                    Vehicle(
                        make: cdVehicle.make ?? "",
                        model: cdVehicle.model ?? "",
                        vehicleNumber: cdVehicle.vehicleNumber ?? "",
                        odometerReading: Int(cdVehicle.odometerReading),
                        type: VehicleType(rawValue: cdVehicle.type ?? "") ?? .other,
                        color: cdVehicle.color
                    )
                }
                
                return User(
                    id: cdUser.id!,
                    username: cdUser.username!,
                    email: cdUser.email!,
                    city: cdUser.city!,
                    dateOfBirth: cdUser.dateOfBirth!,
                    vehicle: vehicle,
                    profileImageURL: cdUser.profileImageURL
                )
            } catch {
                return nil
            }
        }
    }
    
    private func markEmailAsVerified(for userId: UUID) async throws {
        // In a real implementation, this would mark the email as verified in the database
    }
    
    private func restoreSession() async {
        do {
            guard let session = try keychain.getStoredSession() else { return }
            
            if !session.isExpired {
                let user = try await validateSession(session)
                await MainActor.run {
                    currentUser = user
                    isAuthenticated = true
                    currentSession = session
                    authenticationState = .authenticated(user)
                }
            } else {
                try keychain.clearSession()
            }
        } catch {
            // Failed to restore session, user needs to sign in again
        }
    }
    
    // MARK: - User Management Methods
    
    func getCurrentUser() async throws -> User? {
        if let user = currentUser {
            return user
        }
        
        // Try to get user from session
        guard let session = currentSession else {
            return nil
        }
        
        return try await validateSession(session)
    }
    
    func updateUserVehicle(_ vehicle: Vehicle) async throws {
        guard let user = currentUser else {
            throw AuthenticationError.unknown("No authenticated user")
        }
        
        let context = persistenceController.container.viewContext
        
        try await context.perform {
            let request = CDUser.fetchRequest()
            request.predicate = NSPredicate(format: "id == %@", user.id as CVarArg)
            request.fetchLimit = 1
            
            guard let cdUser = try context.fetch(request).first else {
                throw AuthenticationError.unknown("User not found")
            }
            
            // Update or create vehicle
            let cdVehicle: CDVehicle
            if let existingVehicle = cdUser.vehicle {
                cdVehicle = existingVehicle
            } else {
                cdVehicle = CDVehicle(context: context)
                cdVehicle.id = UUID()
                cdUser.vehicle = cdVehicle
            }
            
            cdVehicle.make = vehicle.make
            cdVehicle.model = vehicle.model
            cdVehicle.vehicleNumber = vehicle.vehicleNumber
            cdVehicle.odometerReading = Int32(vehicle.odometerReading)
            cdVehicle.type = vehicle.type.rawValue
            cdVehicle.color = vehicle.color
            
            try context.save()
        }
        
        // Update current user in memory
        var updatedUser = user
        updatedUser.vehicle = vehicle
        await MainActor.run {
            currentUser = updatedUser
            authenticationState = .authenticated(updatedUser)
        }
    }
    
    func updateUserProfile(_ user: User) async throws {
        guard let currentUser = currentUser else {
            throw AuthenticationError.unknown("No authenticated user")
        }
        
        let context = persistenceController.container.viewContext
        
        try await context.perform {
            let request = CDUser.fetchRequest()
            request.predicate = NSPredicate(format: "id == %@", currentUser.id as CVarArg)
            request.fetchLimit = 1
            
            guard let cdUser = try context.fetch(request).first else {
                throw AuthenticationError.unknown("User not found")
            }
            
            cdUser.username = user.username
            cdUser.email = user.email
            cdUser.city = user.city
            cdUser.dateOfBirth = user.dateOfBirth
            cdUser.age = Int32(user.age)
            cdUser.profileImageURL = user.profileImageURL
            
            try context.save()
        }
        
        // Update current user in memory
        await MainActor.run {
            self.currentUser = user
            authenticationState = .authenticated(user)
        }
    }
}

// MARK: - User Session Model
struct UserSession: Codable {
    let userId: UUID
    let token: String
    let refreshToken: String
    let expiresAt: Date
    
    var isExpired: Bool {
        Date() > expiresAt
    }
}