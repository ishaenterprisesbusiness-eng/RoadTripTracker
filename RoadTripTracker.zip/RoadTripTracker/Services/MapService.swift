import Foundation
import Combine
import MapKit
import CoreLocation

// MARK: - Map Service Implementation
class MapService: MapServiceProtocol {
    
    func displayRoute(_ route: Route) async throws {
        // Create polyline overlays for route visualization with different colors
        let routeOverlays = createRouteOverlays(for: route)
        
        // Create destination annotations with numbered markers
        let destinationAnnotations = createDestinationAnnotations(for: route.destinations)
        
        // Create route progress overlay if navigation is active
        let progressOverlay = createRouteProgressOverlay(for: route)
        
        // Notify observers about route display update
        await MainActor.run {
            NotificationCenter.default.post(
                name: .routeDisplayUpdate,
                object: RouteDisplayData(
                    route: route,
                    overlays: routeOverlays,
                    annotations: destinationAnnotations,
                    progressOverlay: progressOverlay
                )
            )
        }
    }
    
    private func createRouteOverlays(for route: Route) -> [RouteSegmentOverlay] {
        var overlays: [RouteSegmentOverlay] = []
        
        // Create polyline for each segment between destinations with different colors
        for i in 0..<(route.destinations.count - 1) {
            let startDestination = route.destinations[i]
            let endDestination = route.destinations[i + 1]
            
            // Get waypoints for this segment from route steps
            let segmentWaypoints = getWaypointsForSegment(route: route, segmentIndex: i)
            
            let overlay = RouteSegmentOverlay(
                startDestination: startDestination,
                endDestination: endDestination,
                waypoints: segmentWaypoints,
                segmentIndex: i,
                segmentType: determineSegmentType(from: startDestination, to: endDestination)
            )
            
            overlays.append(overlay)
        }
        
        return overlays
    }
    
    private func getWaypointsForSegment(route: Route, segmentIndex: Int) -> [CLLocationCoordinate2D] {
        // Extract waypoints for specific segment from route steps
        let segmentSteps = route.steps.filter { step in
            // This is a simplified approach - in production you'd have better segment tracking
            return true
        }
        
        return segmentSteps.map { $0.coordinate }
    }
    
    private func determineSegmentType(from start: Destination, to end: Destination) -> RouteSegmentType {
        // Determine segment type based on destination types
        if start.type == .fuel || end.type == .fuel {
            return .fuelStop
        } else if start.type == .food || end.type == .food {
            return .foodStop
        } else if start.type == .accommodation || end.type == .accommodation {
            return .accommodation
        } else if start.type == .attraction || end.type == .attraction {
            return .scenic
        } else {
            return .normal
        }
    }
    
    private func createRouteProgressOverlay(for route: Route) -> RouteProgressOverlay? {
        // Create progress overlay for active navigation
        return RouteProgressOverlay(route: route)
    }
    
    private func createDestinationAnnotations(for destinations: [Destination]) -> [DestinationAnnotation] {
        return destinations.enumerated().map { index, destination in
            let annotation = DestinationAnnotation()
            annotation.coordinate = destination.coordinate
            annotation.title = destination.name
            annotation.subtitle = destination.address
            annotation.destinationIndex = index
            annotation.destinationType = destination.type
            annotation.isStart = index == 0
            annotation.isEnd = index == destinations.count - 1
            annotation.estimatedArrival = destination.plannedArrival
            annotation.plannedDuration = destination.plannedDuration
            return annotation
        }
    }
    
    func showParticipants(_ participants: [Participant]) async throws {
        // Implementation for showing participants on map
        // This would typically add participant annotations to map
    }
    
    func findNearbyPOIs(category: POICategory, near location: CLLocationCoordinate2D, radius: CLLocationDistance) async throws -> [PointOfInterest] {
        // Implementation for finding nearby points of interest
        // This would typically use MapKit or external API
        return []
    }
    
    func calculateRoute(from origin: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D, waypoints: [CLLocationCoordinate2D]) async throws -> Route {
        // Create MKDirections request
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: origin))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: destination))
        request.transportType = .automobile
        
        let directions = MKDirections(request: request)
        
        do {
            let response = try await directions.calculate()
            guard let mkRoute = response.routes.first else {
                throw MapServiceError.routeCalculationFailed
            }
            
            // Convert MKRoute to our Route model
            let route = Route(
                name: "Route",
                destinations: [],
                waypoints: waypoints,
                distance: mkRoute.distance,
                estimatedTravelTime: mkRoute.expectedTravelTime,
                polyline: encodePolyline(mkRoute.polyline),
                steps: convertSteps(mkRoute.steps)
            )
            
            return route
        } catch {
            throw MapServiceError.routeCalculationFailed
        }
    }
    
    func calculateMultiDestinationRoute(destinations: [Destination]) async throws -> Route {
        guard destinations.count >= 2 else {
            throw MapServiceError.routeCalculationFailed
        }
        
        var allSteps: [RouteStep] = []
        var totalDistance: CLLocationDistance = 0
        var totalTime: TimeInterval = 0
        var allWaypoints: [CLLocationCoordinate2D] = []
        
        // Calculate route segments between consecutive destinations
        for i in 0..<(destinations.count - 1) {
            let origin = destinations[i].coordinate
            let destination = destinations[i + 1].coordinate
            
            let segmentRoute = try await calculateRoute(from: origin, to: destination, waypoints: [])
            
            allSteps.append(contentsOf: segmentRoute.steps)
            totalDistance += segmentRoute.distance
            totalTime += segmentRoute.estimatedTravelTime
            allWaypoints.append(contentsOf: segmentRoute.waypoints)
        }
        
        // Create comprehensive route
        let route = Route(
            name: "Multi-Destination Route",
            destinations: destinations,
            waypoints: allWaypoints,
            distance: totalDistance,
            estimatedTravelTime: totalTime,
            polyline: nil, // Will be generated when displaying
            steps: allSteps
        )
        
        return route
    }
    
    func getDirections(for route: Route) async throws -> [RouteStep] {
        return route.steps
    }
    
    func searchPlaces(query: String, near location: CLLocationCoordinate2D) async throws -> [Place] {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        request.region = MKCoordinateRegion(
            center: location,
            latitudinalMeters: 10000,
            longitudinalMeters: 10000
        )
        
        let search = MKLocalSearch(request: request)
        
        do {
            let response = try await search.start()
            
            return response.mapItems.map { mapItem in
                Place(
                    name: mapItem.name ?? "Unknown",
                    address: mapItem.placemark.title ?? "",
                    coordinate: mapItem.placemark.coordinate,
                    category: mapItem.pointOfInterestCategory?.rawValue
                )
            }
        } catch {
            throw MapServiceError.placeSearchFailed
        }
    }
    
    // MARK: - Private Helper Methods
    
    private func encodePolyline(_ polyline: MKPolyline) -> String {
        // Simple polyline encoding - in production you'd use a proper encoding algorithm
        let coordinates = polyline.coordinates()
        return coordinates.map { "\($0.latitude),\($0.longitude)" }.joined(separator: ";")
    }
    
    private func convertSteps(_ mkSteps: [MKRoute.Step]) -> [RouteStep] {
        return mkSteps.map { mkStep in
            RouteStep(
                instruction: mkStep.instructions,
                distance: mkStep.distance,
                estimatedTime: mkStep.transportType == .automobile ? mkStep.distance / 15 : 0, // Rough estimate
                coordinate: mkStep.polyline.coordinate,
                maneuver: convertManeuver(mkStep.instructions)
            )
        }
    }
    
    private func convertManeuver(_ instruction: String) -> ManeuverType {
        let lowercased = instruction.lowercased()
        
        if lowercased.contains("left") {
            return .turnLeft
        } else if lowercased.contains("right") {
            return .turnRight
        } else if lowercased.contains("straight") {
            return .straight
        } else if lowercased.contains("u-turn") || lowercased.contains("uturn") {
            return .uturn
        } else if lowercased.contains("merge") {
            return .merge
        } else if lowercased.contains("roundabout") {
            return .roundabout
        } else if lowercased.contains("arrive") {
            return .arrive
        } else {
            return .straight
        }
    }
}

// MARK: - Supporting Classes

class DestinationAnnotation: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D = CLLocationCoordinate2D()
    var title: String?
    var subtitle: String?
    var destinationIndex: Int = 0
    var destinationType: DestinationType = .waypoint
    var isStart: Bool = false
    var isEnd: Bool = false
    var estimatedArrival: Date?
    var plannedDuration: TimeInterval?
}

class RouteSegmentOverlay: MKPolyline {
    let startDestination: Destination
    let endDestination: Destination
    let segmentIndex: Int
    let segmentType: RouteSegmentType
    
    init(startDestination: Destination, endDestination: Destination, waypoints: [CLLocationCoordinate2D], segmentIndex: Int, segmentType: RouteSegmentType) {
        self.startDestination = startDestination
        self.endDestination = endDestination
        self.segmentIndex = segmentIndex
        self.segmentType = segmentType
        
        // Create coordinates array including start, waypoints, and end
        var coordinates = [startDestination.coordinate]
        coordinates.append(contentsOf: waypoints)
        coordinates.append(endDestination.coordinate)
        
        super.init(coordinates: coordinates, count: coordinates.count)
    }
}

class RouteProgressOverlay: MKPolyline {
    let route: Route
    var progressPercentage: Double = 0.0
    
    init(route: Route) {
        self.route = route
        
        // Create polyline from route waypoints
        let coordinates = route.waypoints
        super.init(coordinates: coordinates, count: coordinates.count)
    }
    
    func updateProgress(_ percentage: Double) {
        progressPercentage = min(100.0, max(0.0, percentage))
    }
}

enum RouteSegmentType {
    case normal
    case fuelStop
    case foodStop
    case accommodation
    case scenic
    case emergency
    
    var color: UIColor {
        switch self {
        case .normal:
            return .systemBlue
        case .fuelStop:
            return .systemOrange
        case .foodStop:
            return .systemGreen
        case .accommodation:
            return .systemPurple
        case .scenic:
            return .systemTeal
        case .emergency:
            return .systemRed
        }
    }
    
    var lineWidth: CGFloat {
        switch self {
        case .normal:
            return 4.0
        case .fuelStop, .foodStop:
            return 5.0
        case .accommodation:
            return 6.0
        case .scenic:
            return 4.0
        case .emergency:
            return 8.0
        }
    }
}

struct RouteDisplayData {
    let route: Route
    let overlays: [RouteSegmentOverlay]
    let annotations: [DestinationAnnotation]
    let progressOverlay: RouteProgressOverlay?
}

// MARK: - Notification Names
extension Notification.Name {
    static let routeDisplayUpdate = Notification.Name("routeDisplayUpdate")
    static let routeRecalculated = Notification.Name("routeRecalculated")
    static let routeDeviationDetected = Notification.Name("routeDeviationDetected")
}

// MARK: - MKPolyline Extension
// MARK: - Map Service Error
enum MapServiceError: LocalizedError {
    case routeCalculationFailed
    case placeSearchFailed
    case invalidCoordinates
    case noRouteFound
    case mapDisplayError
    
    var errorDescription: String? {
        switch self {
        case .routeCalculationFailed:
            return "Failed to calculate route"
        case .placeSearchFailed:
            return "Failed to search for places"
        case .invalidCoordinates:
            return "Invalid coordinates provided"
        case .noRouteFound:
            return "No route found between destinations"
        case .mapDisplayError:
            return "Failed to display map information"
        }
    }
}

// MARK: - MKPolyline Extension
extension MKPolyline {
    func coordinates() -> [CLLocationCoordinate2D] {
        var coordinates: [CLLocationCoordinate2D] = []
        let coordsPointer = UnsafeMutablePointer<CLLocationCoordinate2D>.allocate(capacity: pointCount)
        getCoordinates(coordsPointer, range: NSRange(location: 0, length: pointCount))
        
        for i in 0..<pointCount {
            coordinates.append(coordsPointer[i])
        }
        
        coordsPointer.deallocate()
        return coordinates
    }
}