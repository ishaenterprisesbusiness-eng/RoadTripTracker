import Foundation
import CoreLocation
import Combine

// MARK: - Geofencing Service
@MainActor
class GeofencingService: NSObject, ObservableObject, GeofencingServiceProtocol {
    
    // MARK: - Properties
    private let locationManager = CLLocationManager()
    
    // Publishers
    private let geofenceEventsSubject = PassthroughSubject<GeofenceEvent, Never>()
    
    // State
    private var monitoredDestinations: [UUID: Destination] = [:]
    private var subscriptions: Set<AnyCancellable> = []
    
    // MARK: - Computed Properties
    var geofenceEvents: AnyPublisher<GeofenceEvent, Never> {
        geofenceEventsSubject.eraseToAnyPublisher()
    }
    
    // MARK: - Initialization
    override init() {
        super.init()
        setupGeofencing()
    }
    
    // MARK: - Setup
    private func setupGeofencing() {
        locationManager.delegate = self
    }
    
    // MARK: - GeofencingServiceProtocol Implementation
    
    func addGeofence(for destination: Destination, radius: CLLocationDistance = 100.0) async throws {
        guard locationManager.authorizationStatus == .authorizedAlways ||
              locationManager.authorizationStatus == .authorizedWhenInUse else {
            throw LocationServiceError.permissionDenied
        }
        
        // Check if we're already monitoring this destination
        if monitoredDestinations[destination.id] != nil {
            return
        }
        
        // Create geofence region
        let region = CLCircularRegion(
            center: destination.coordinate,
            radius: radius,
            identifier: destination.id.uuidString
        )
        
        region.notifyOnEntry = true
        region.notifyOnExit = true
        
        // Start monitoring
        locationManager.startMonitoring(for: region)
        
        // Store destination for reference
        monitoredDestinations[destination.id] = destination
        
        print("Started monitoring geofence for destination: \(destination.name)")
    }
    
    func removeGeofence(for destinationId: UUID) async throws {
        guard let destination = monitoredDestinations[destinationId] else {
            return
        }
        
        // Find and stop monitoring the region
        for region in locationManager.monitoredRegions {
            if region.identifier == destinationId.uuidString {
                locationManager.stopMonitoring(for: region)
                break
            }
        }
        
        // Remove from tracked destinations
        monitoredDestinations.removeValue(forKey: destinationId)
        
        print("Stopped monitoring geofence for destination: \(destination.name)")
    }
    
    func removeAllGeofences() async throws {
        // Stop monitoring all regions
        for region in locationManager.monitoredRegions {
            locationManager.stopMonitoring(for: region)
        }
        
        // Clear tracked destinations
        monitoredDestinations.removeAll()
        
        print("Stopped monitoring all geofences")
    }
    
    // MARK: - Geofence Management
    func getMonitoredDestinations() -> [Destination] {
        return Array(monitoredDestinations.values)
    }
    
    func isMonitoring(destinationId: UUID) -> Bool {
        return monitoredDestinations[destinationId] != nil
    }
    
    func getGeofenceStatus(for destinationId: UUID) async -> GeofenceStatus? {
        guard let destination = monitoredDestinations[destinationId] else {
            return nil
        }
        
        // Find the corresponding region
        guard let region = locationManager.monitoredRegions.first(where: { 
            $0.identifier == destinationId.uuidString 
        }) as? CLCircularRegion else {
            return nil
        }
        
        return await withCheckedContinuation { continuation in
            locationManager.requestState(for: region)
            
            // Set up a temporary observer for the state
            let cancellable = NotificationCenter.default
                .publisher(for: .geofenceStateReceived)
                .compactMap { notification in
                    notification.userInfo?["region"] as? CLRegion
                }
                .filter { $0.identifier == destinationId.uuidString }
                .compactMap { region in
                    notification.userInfo?["state"] as? CLRegionState
                }
                .first()
                .sink { state in
                    let status = GeofenceStatus(
                        destinationId: destinationId,
                        destination: destination,
                        region: region,
                        state: state
                    )
                    continuation.resume(returning: status)
                }
            
            // Timeout after 5 seconds
            DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                cancellable.cancel()
                continuation.resume(returning: nil)
            }
        }
    }
}

// MARK: - CLLocationManagerDelegate
extension GeofencingService: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        guard let destinationId = UUID(uuidString: region.identifier),
              let destination = monitoredDestinations[destinationId] else {
            return
        }
        
        let event = GeofenceEvent(
            destinationId: destinationId,
            eventType: .entered,
            location: CLLocation(
                latitude: destination.coordinate.latitude,
                longitude: destination.coordinate.longitude
            )
        )
        
        geofenceEventsSubject.send(event)
        
        print("Entered geofence for destination: \(destination.name)")
    }
    
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        guard let destinationId = UUID(uuidString: region.identifier),
              let destination = monitoredDestinations[destinationId] else {
            return
        }
        
        let event = GeofenceEvent(
            destinationId: destinationId,
            eventType: .exited,
            location: CLLocation(
                latitude: destination.coordinate.latitude,
                longitude: destination.coordinate.longitude
            )
        )
        
        geofenceEventsSubject.send(event)
        
        print("Exited geofence for destination: \(destination.name)")
    }
    
    func locationManager(_ manager: CLLocationManager, didDetermineState state: CLRegionState, for region: CLRegion) {
        // Post notification for geofence status requests
        NotificationCenter.default.post(
            name: .geofenceStateReceived,
            object: nil,
            userInfo: [
                "region": region,
                "state": state
            ]
        )
    }
    
    func locationManager(_ manager: CLLocationManager, monitoringDidFailFor region: CLRegion?, withError error: Error) {
        if let region = region,
           let destinationId = UUID(uuidString: region.identifier) {
            print("Geofencing failed for destination \(destinationId): \(error)")
            
            // Remove failed geofence from tracking
            monitoredDestinations.removeValue(forKey: destinationId)
        }
    }
}

// MARK: - Geofence Status
struct GeofenceStatus {
    let destinationId: UUID
    let destination: Destination
    let region: CLCircularRegion
    let state: CLRegionState
    
    var isInside: Bool {
        return state == .inside
    }
    
    var isOutside: Bool {
        return state == .outside
    }
    
    var isUnknown: Bool {
        return state == .unknown
    }
}

// MARK: - Notification Names
extension Notification.Name {
    static let geofenceStateReceived = Notification.Name("geofenceStateReceived")
}