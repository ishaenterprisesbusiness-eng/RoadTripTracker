import Foundation
import CoreLocation
import Combine

// MARK: - Weather Service Implementation
class WeatherService: WeatherServiceProtocol {
    
    // MARK: - Properties
    private let apiKey: String
    private let baseURL = "https://api.openweathermap.org/data/2.5"
    private let session = URLSession.shared
    private let decoder: JSONDecoder
    
    // MARK: - Initialization
    init(apiKey: String = "YOUR_API_KEY_HERE") {
        self.apiKey = apiKey
        self.decoder = JSONDecoder()
        self.decoder.dateDecodingStrategy = .secondsSince1970
    }
    
    // MARK: - WeatherServiceProtocol Implementation
    
    func getCurrentWeather(for coordinate: CLLocationCoordinate2D) async throws -> WeatherData {
        let urlString = "\(baseURL)/weather?lat=\(coordinate.latitude)&lon=\(coordinate.longitude)&appid=\(apiKey)&units=metric"
        
        guard let url = URL(string: urlString) else {
            throw WeatherServiceError.networkError
        }
        
        do {
            let (data, response) = try await session.data(from: url)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw WeatherServiceError.networkError
            }
            
            switch httpResponse.statusCode {
            case 200:
                let openWeatherResponse = try decoder.decode(OpenWeatherCurrentResponse.self, from: data)
                return convertToWeatherData(from: openWeatherResponse, coordinate: coordinate)
            case 401:
                throw WeatherServiceError.apiKeyInvalid
            case 404:
                throw WeatherServiceError.locationNotFound
            default:
                throw WeatherServiceError.networkError
            }
        } catch let error as WeatherServiceError {
            throw error
        } catch {
            throw WeatherServiceError.dataParsingError
        }
    }
    
    func getWeatherForecast(for coordinate: CLLocationCoordinate2D, days: Int) async throws -> [WeatherData] {
        let urlString = "\(baseURL)/forecast?lat=\(coordinate.latitude)&lon=\(coordinate.longitude)&appid=\(apiKey)&units=metric&cnt=\(min(days * 8, 40))"
        
        guard let url = URL(string: urlString) else {
            throw WeatherServiceError.networkError
        }
        
        do {
            let (data, response) = try await session.data(from: url)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw WeatherServiceError.networkError
            }
            
            switch httpResponse.statusCode {
            case 200:
                let openWeatherResponse = try decoder.decode(OpenWeatherForecastResponse.self, from: data)
                return openWeatherResponse.list.map { forecast in
                    convertToWeatherData(from: forecast, coordinate: coordinate)
                }
            case 401:
                throw WeatherServiceError.apiKeyInvalid
            case 404:
                throw WeatherServiceError.locationNotFound
            default:
                throw WeatherServiceError.networkError
            }
        } catch let error as WeatherServiceError {
            throw error
        } catch {
            throw WeatherServiceError.dataParsingError
        }
    }
    
    func getWeatherAlerts(for coordinate: CLLocationCoordinate2D) async throws -> [WeatherAlert] {
        // OpenWeatherMap One Call API provides alerts, but requires a different endpoint
        let urlString = "\(baseURL.replacingOccurrences(of: "2.5", with: "3.0"))/onecall?lat=\(coordinate.latitude)&lon=\(coordinate.longitude)&appid=\(apiKey)&exclude=minutely,hourly,daily"
        
        guard let url = URL(string: urlString) else {
            throw WeatherServiceError.networkError
        }
        
        do {
            let (data, response) = try await session.data(from: url)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw WeatherServiceError.networkError
            }
            
            switch httpResponse.statusCode {
            case 200:
                let oneCallResponse = try decoder.decode(OpenWeatherOneCallResponse.self, from: data)
                return oneCallResponse.alerts?.map { alert in
                    convertToWeatherAlert(from: alert)
                } ?? []
            case 401:
                throw WeatherServiceError.apiKeyInvalid
            case 404:
                throw WeatherServiceError.locationNotFound
            default:
                throw WeatherServiceError.networkError
            }
        } catch let error as WeatherServiceError {
            throw error
        } catch {
            // If One Call API fails, return empty alerts array
            return []
        }
    }
    
    func getWeatherBasedStopRecommendations(for coordinate: CLLocationCoordinate2D, currentWeather: WeatherData) async throws -> [WeatherStopRecommendation] {
        var recommendations: [WeatherStopRecommendation] = []
        
        // Check for severe weather conditions that require immediate stops
        if currentWeather.condition == .thunderstorm {
            recommendations.append(WeatherStopRecommendation(
                type: .shelter,
                priority: .high,
                title: "Seek Shelter",
                description: "Thunderstorm conditions detected. Find safe indoor shelter immediately.",
                recommendedStopTypes: [.accommodation, .food, .shelter],
                estimatedWaitTime: 3600 // 1 hour
            ))
        }
        
        if currentWeather.condition == .snow || (currentWeather.temperature < 0 && currentWeather.condition == .rain) {
            recommendations.append(WeatherStopRecommendation(
                type: .winterConditions,
                priority: .high,
                title: "Winter Driving Conditions",
                description: "Snow or freezing rain detected. Consider stopping for tire chains or winter supplies.",
                recommendedStopTypes: [.fuel, .other],
                estimatedWaitTime: 1800 // 30 minutes
            ))
        }
        
        if currentWeather.windSpeed > 60 { // km/h - dangerous wind speeds
            recommendations.append(WeatherStopRecommendation(
                type: .highWinds,
                priority: .high,
                title: "High Wind Warning",
                description: "Dangerous wind speeds detected. Consider waiting for conditions to improve.",
                recommendedStopTypes: [.accommodation, .food, .shelter],
                estimatedWaitTime: 7200 // 2 hours
            ))
        }
        
        if currentWeather.visibility < 0.5 { // km - very low visibility
            recommendations.append(WeatherStopRecommendation(
                type: .lowVisibility,
                priority: .high,
                title: "Low Visibility",
                description: "Very low visibility conditions. Consider stopping until visibility improves.",
                recommendedStopTypes: [.fuel, .food, .shelter],
                estimatedWaitTime: 3600 // 1 hour
            ))
        }
        
        // Moderate weather recommendations
        if currentWeather.temperature > 35 {
            recommendations.append(WeatherStopRecommendation(
                type: .heatWarning,
                priority: .medium,
                title: "Extreme Heat",
                description: "Very hot conditions. Consider stopping for hydration and vehicle cooling check.",
                recommendedStopTypes: [.fuel, .food],
                estimatedWaitTime: 900 // 15 minutes
            ))
        }
        
        if currentWeather.condition == .rain && currentWeather.windSpeed > 30 {
            recommendations.append(WeatherStopRecommendation(
                type: .heavyRain,
                priority: .medium,
                title: "Heavy Rain and Wind",
                description: "Challenging driving conditions. Consider taking a break until conditions improve.",
                recommendedStopTypes: [.food, .fuel],
                estimatedWaitTime: 1800 // 30 minutes
            ))
        }
        
        return recommendations
    }
}

// MARK: - Private Helper Methods
private extension WeatherService {
    
    func convertToWeatherData(from response: OpenWeatherCurrentResponse, coordinate: CLLocationCoordinate2D) -> WeatherData {
        WeatherData(
            location: coordinate,
            timestamp: Date(timeIntervalSince1970: TimeInterval(response.dt)),
            temperature: response.main.temp,
            feelsLike: response.main.feelsLike,
            humidity: response.main.humidity,
            windSpeed: response.wind?.speed ?? 0.0,
            windDirection: response.wind?.deg ?? 0.0,
            visibility: Double(response.visibility ?? 10000) / 1000.0, // Convert to km
            uvIndex: 0.0, // Not available in current weather API
            condition: mapWeatherCondition(from: response.weather.first?.main ?? "unknown"),
            description: response.weather.first?.description ?? "Unknown weather"
        )
    }
    
    func convertToWeatherData(from forecast: OpenWeatherForecastItem, coordinate: CLLocationCoordinate2D) -> WeatherData {
        WeatherData(
            location: coordinate,
            timestamp: Date(timeIntervalSince1970: TimeInterval(forecast.dt)),
            temperature: forecast.main.temp,
            feelsLike: forecast.main.feelsLike,
            humidity: forecast.main.humidity,
            windSpeed: forecast.wind?.speed ?? 0.0,
            windDirection: forecast.wind?.deg ?? 0.0,
            visibility: Double(forecast.visibility ?? 10000) / 1000.0,
            uvIndex: 0.0,
            condition: mapWeatherCondition(from: forecast.weather.first?.main ?? "unknown"),
            description: forecast.weather.first?.description ?? "Unknown weather"
        )
    }
    
    func convertToWeatherAlert(from alert: OpenWeatherAlert) -> WeatherAlert {
        WeatherAlert(
            title: alert.event,
            description: alert.description,
            severity: mapAlertSeverity(from: alert.tags),
            startTime: Date(timeIntervalSince1970: TimeInterval(alert.start)),
            endTime: Date(timeIntervalSince1970: TimeInterval(alert.end)),
            affectedArea: alert.senderName
        )
    }
    
    func mapWeatherCondition(from openWeatherCondition: String) -> WeatherCondition {
        switch openWeatherCondition.lowercased() {
        case "clear":
            return .clear
        case "clouds":
            return .cloudy
        case "rain", "drizzle":
            return .rain
        case "snow":
            return .snow
        case "thunderstorm":
            return .thunderstorm
        case "mist", "fog", "haze":
            return .fog
        default:
            return .unknown
        }
    }
    
    func mapAlertSeverity(from tags: [String]?) -> WeatherAlertSeverity {
        guard let tags = tags else { return .minor }
        
        if tags.contains("Extreme") {
            return .extreme
        } else if tags.contains("Severe") {
            return .severe
        } else if tags.contains("Moderate") {
            return .moderate
        } else {
            return .minor
        }
    }
}

// MARK: - OpenWeatherMap API Response Models
private struct OpenWeatherCurrentResponse: Codable {
    let dt: Int
    let main: OpenWeatherMain
    let weather: [OpenWeatherWeather]
    let wind: OpenWeatherWind?
    let visibility: Int?
}

private struct OpenWeatherForecastResponse: Codable {
    let list: [OpenWeatherForecastItem]
}

private struct OpenWeatherForecastItem: Codable {
    let dt: Int
    let main: OpenWeatherMain
    let weather: [OpenWeatherWeather]
    let wind: OpenWeatherWind?
    let visibility: Int?
}

private struct OpenWeatherOneCallResponse: Codable {
    let alerts: [OpenWeatherAlert]?
}

private struct OpenWeatherMain: Codable {
    let temp: Double
    let feelsLike: Double
    let humidity: Double
    
    enum CodingKeys: String, CodingKey {
        case temp
        case feelsLike = "feels_like"
        case humidity
    }
}

private struct OpenWeatherWeather: Codable {
    let main: String
    let description: String
}

private struct OpenWeatherWind: Codable {
    let speed: Double
    let deg: Double
}

private struct OpenWeatherAlert: Codable {
    let senderName: String
    let event: String
    let start: Int
    let end: Int
    let description: String
    let tags: [String]?
    
    enum CodingKeys: String, CodingKey {
        case senderName = "sender_name"
        case event
        case start
        case end
        case description
        case tags
    }
}