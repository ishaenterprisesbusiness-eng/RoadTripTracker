# Emergency Response System

The Emergency Response System provides comprehensive safety features for road trip participants, including panic alerts, breakdown assistance, emergency service location, and offline emergency information caching.

## Features

### 1. Panic Button with Emergency Service Alerts (Requirement 23.1)
- **Immediate Alert**: Triggers instant notifications to all trip participants
- **Emergency Contact Notification**: Automatically contacts user's emergency contacts via SMS, email, or phone
- **Location Sharing**: Shares exact GPS coordinates with emergency services and contacts
- **Critical Notifications**: Uses iOS critical alerts to bypass Do Not Disturb settings
- **Haptic Feedback**: Provides strong haptic feedback when panic button is pressed

### 2. Exact Location Sharing to Emergency Contacts (Requirement 23.2)
- **Real-time Location**: Shares precise GPS coordinates when emergency is triggered
- **Multiple Contact Methods**: Supports SMS, email, and phone call notifications
- **Apple Maps Integration**: Provides direct links to Apple Maps for navigation to emergency location
- **Contact Prioritization**: Primary contacts are notified first, followed by secondary contacts
- **Message Templates**: Pre-formatted emergency messages with location and trip details

### 3. Check-in Notifications for Inactive Participants (Requirement 23.3)
- **Automatic Monitoring**: Tracks participant activity and location updates
- **Configurable Intervals**: Default 30-minute check-in intervals (configurable 15-60 minutes)
- **Smart Detection**: Distinguishes between intentional stops and potential emergencies
- **Escalation Process**: Sends increasingly urgent notifications if no response
- **Group Notifications**: Alerts other participants when someone hasn't checked in

### 4. Breakdown Assistance Finder (Requirement 23.4)
- **Service Location**: Finds nearby mechanics, towing services, and auto repair shops
- **Real-time Availability**: Shows current operating hours and 24/7 services
- **Distance Calculation**: Sorts services by proximity to breakdown location
- **Direct Contact**: One-tap calling and messaging to service providers
- **Service Details**: Displays ratings, contact information, and specializations

### 5. Offline Emergency Information Caching (Requirement 23.5)
- **Service Caching**: Pre-downloads emergency service locations along planned route
- **Contact Backup**: Stores emergency contacts locally for offline access
- **Emergency Numbers**: Caches local emergency numbers for different regions
- **Map Data**: Downloads relevant map tiles for emergency navigation
- **Sync Management**: Automatically syncs cached data when connection is restored

## Architecture

### Core Components

#### EmergencyService
- **Protocol**: `EmergencyServiceProtocol`
- **Implementation**: `EmergencyService`
- **Dependencies**: LocationManager, NotificationService, PersistenceController

#### EmergencyViewModel
- **Purpose**: Manages emergency UI state and user interactions
- **Features**: Panic button handling, service discovery, alert management
- **Reactive**: Uses Combine for real-time updates

#### Emergency Views
- **EmergencyView**: Main emergency interface with quick actions
- **EmergencyAlertSheet**: Panic button confirmation and message input
- **EmergencyContactsView**: Emergency contact management
- **EmergencyServicesSheet**: Nearby emergency service browser

### Data Models

#### EmergencyAlert
```swift
struct EmergencyAlert {
    let id: UUID
    let tripId: UUID
    let userId: UUID
    let alertType: EmergencyAlertType
    let location: CLLocationCoordinate2D
    let message: String?
    let timestamp: Date
    let status: EmergencyAlertStatus
}
```

#### EmergencyContact
```swift
struct EmergencyContact {
    let id: UUID
    var name: String
    var relationship: String
    var phoneNumber: String
    var email: String?
    var contactMethod: EmergencyContactMethod
    var isPrimary: Bool
}
```

#### EmergencyService
```swift
struct EmergencyService {
    let id: UUID
    let name: String
    let type: EmergencyServiceType
    let phoneNumber: String
    let address: String
    let coordinate: CLLocationCoordinate2D
    let distance: CLLocationDistance
    let isOpen24Hours: Bool
}
```

## Usage Examples

### Triggering Emergency Alert
```swift
let emergencyService = ServiceContainer.shared.emergencyService
let location = CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631)

try await emergencyService.triggerEmergencyAlert(
    location: location,
    message: "Car accident, need immediate assistance"
)
```

### Finding Emergency Services
```swift
let services = try await emergencyService.findNearbyEmergencyServices(
    location: currentLocation
)

let hospitals = services.filter { $0.type == .hospital }
let towingServices = services.filter { $0.type == .towingService }
```

### Listening for Emergency Alerts
```swift
emergencyService.emergencyAlerts
    .sink { alert in
        switch alert.alertType {
        case .panic:
            handlePanicAlert(alert)
        case .breakdown:
            handleBreakdownAlert(alert)
        // ... handle other alert types
        }
    }
    .store(in: &cancellables)
```

## Integration Points

### Service Container
The EmergencyService is registered in the ServiceContainer and can be accessed throughout the app:

```swift
let emergencyService = ServiceContainer.shared.emergencyService
```

### Location Integration
- Uses LocationManager for current position
- Integrates with GeofencingService for proximity alerts
- Leverages MapService for directions and navigation

### Notification Integration
- Uses NotificationService for push notifications
- Supports critical alerts for emergency situations
- Integrates with iOS notification categories

### Data Persistence
- Uses Core Data for offline emergency contact storage
- Caches emergency service data for offline access
- Syncs with CloudKit for cross-device availability

## Security and Privacy

### Data Protection
- Emergency contacts are encrypted in local storage
- Location data is only shared during active emergencies
- User consent is required before sharing location with contacts

### Privacy Controls
- Users can configure which contacts receive notifications
- Location sharing can be disabled for non-critical emergencies
- Emergency data is automatically purged after trip completion

### Offline Security
- Cached emergency data is encrypted
- Local authentication required for emergency contact access
- Secure key management for offline operations

## Testing

### Unit Tests
- EmergencyServiceTests: Core emergency functionality
- EmergencyContactTests: Contact management and validation
- EmergencyAlertTests: Alert creation and status management

### Integration Tests
- Location service integration
- Notification delivery testing
- Offline/online sync scenarios

### UI Tests
- Emergency button accessibility
- Alert flow testing
- Contact management workflows

## Configuration

### Emergency Settings
Users can configure:
- Check-in notification intervals (15-60 minutes)
- Emergency contact notification methods
- Location sharing preferences
- Offline data caching options

### Developer Configuration
```swift
// Configure check-in monitoring
let checkInInterval: TimeInterval = 1800 // 30 minutes

// Configure emergency service search radius
let searchRadius: CLLocationDistance = 10000 // 10km

// Configure notification priorities
let emergencyNotificationPriority: UNNotificationRequest.Priority = .critical
```

## Error Handling

### Network Errors
- Graceful fallback to cached emergency services
- Offline queue for emergency alerts
- Retry mechanisms with exponential backoff

### Location Errors
- Manual location entry when GPS unavailable
- Last known location fallback
- Clear error messages for permission issues

### Service Errors
- Alternative emergency service suggestions
- Manual contact entry for emergency services
- Comprehensive error logging for debugging

## Performance Considerations

### Battery Optimization
- Efficient location monitoring during emergencies
- Background processing limits for check-in monitoring
- Smart caching to minimize network usage

### Memory Management
- Lazy loading of emergency service data
- Automatic cleanup of old emergency alerts
- Efficient image handling for service listings

### Network Optimization
- Compressed data transmission for emergency alerts
- Batch updates for non-critical emergency data
- Smart sync strategies for offline/online transitions

## Accessibility

### VoiceOver Support
- Comprehensive screen reader support for all emergency features
- Audio descriptions for emergency service locations
- Voice-guided emergency procedures

### Visual Accessibility
- High contrast emergency button design
- Large touch targets for emergency actions
- Color-blind friendly alert indicators

### Motor Accessibility
- Voice control compatibility for emergency activation
- Switch control support for all emergency features
- Reduced motion options for emergency animations

## Future Enhancements

### Planned Features
- Integration with vehicle telematics systems
- Automatic crash detection using device sensors
- Integration with roadside assistance providers
- Multi-language emergency message support

### API Integrations
- Integration with local emergency service APIs
- Real-time traffic data for emergency routing
- Weather service integration for emergency planning
- Insurance provider integration for claims

## Support and Documentation

### User Documentation
- In-app emergency procedure guides
- Video tutorials for emergency features
- FAQ for common emergency scenarios

### Developer Documentation
- API reference for emergency service integration
- Code examples for custom emergency handlers
- Testing guidelines for emergency features

### Support Channels
- 24/7 emergency support hotline
- In-app emergency assistance chat
- Community forums for emergency preparedness tips