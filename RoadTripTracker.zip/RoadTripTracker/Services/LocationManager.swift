import Foundation
import CoreLocation
import Combine
import CloudKit

// MARK: - Location Manager
@MainActor
class LocationManager: NSObject, ObservableObject, LocationServiceProtocol {
    
    // MARK: - Properties
    private let locationManager = CLLocationManager()
    private let cloudKitContainer = CKContainer.default()
    
    // Publishers
    private let locationSubject = PassthroughSubject<CLLocation, Never>()
    private let authorizationSubject = PassthroughSubject<CLAuthorizationStatus, Never>()
    
    // State
    @Published var currentLocation: CLLocation?
    @Published var authorizationStatus: CLAuthorizationStatus = .notDetermined
    @Published var isLocationSharingEnabled: Bool = false
    
    // Configuration
    private var locationUpdateFrequency: TimeInterval = 30.0 // Default 30 seconds
    private var lastLocationUpdate: Date?
    private var currentTripId: UUID?
    private var currentParticipantId: UUID?
    
    // MARK: - Computed Properties
    var locationUpdates: AnyPublisher<CLLocation, Never> {
        locationSubject.eraseToAnyPublisher()
    }
    
    var authorizationUpdates: AnyPublisher<CLAuthorizationStatus, Never> {
        authorizationSubject.eraseToAnyPublisher()
    }
    
    // MARK: - Initialization
    override init() {
        super.init()
        setupLocationManager()
    }
    
    // MARK: - Setup
    private func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 10.0 // Update every 10 meters
        
        // Set initial authorization status
        authorizationStatus = locationManager.authorizationStatus
    }
    
    // MARK: - LocationServiceProtocol Implementation
    
    func requestLocationPermission() async throws {
        guard authorizationStatus == .notDetermined else {
            if authorizationStatus == .denied || authorizationStatus == .restricted {
                throw LocationServiceError.permissionDenied
            }
            return
        }
        
        return await withCheckedContinuation { continuation in
            // Store continuation to resume when authorization changes
            let cancellable = authorizationUpdates
                .first()
                .sink { status in
                    if status == .authorizedWhenInUse || status == .authorizedAlways {
                        continuation.resume()
                    } else {
                        continuation.resume(throwing: LocationServiceError.permissionDenied)
                    }
                }
            
            locationManager.requestWhenInUseAuthorization()
            
            // Clean up cancellable after a timeout
            DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
                cancellable.cancel()
            }
        }
    }
    
    func startLocationSharing() async throws {
        guard authorizationStatus == .authorizedWhenInUse || authorizationStatus == .authorizedAlways else {
            throw LocationServiceError.permissionDenied
        }
        
        isLocationSharingEnabled = true
        locationManager.startUpdatingLocation()
        
        // Also start significant location changes for battery optimization
        locationManager.startMonitoringSignificantLocationChanges()
    }
    
    func stopLocationSharing() {
        isLocationSharingEnabled = false
        locationManager.stopUpdatingLocation()
        locationManager.stopMonitoringSignificantLocationChanges()
    }
    
    func getCurrentLocation() async throws -> CLLocation {
        guard authorizationStatus == .authorizedWhenInUse || authorizationStatus == .authorizedAlways else {
            throw LocationServiceError.permissionDenied
        }
        
        // If we have a recent location (within 30 seconds), return it
        if let current = currentLocation,
           current.timestamp.timeIntervalSinceNow > -30 {
            return current
        }
        
        // Otherwise, request a new location
        return await withCheckedContinuation { continuation in
            let cancellable = locationUpdates
                .first()
                .sink { location in
                    continuation.resume(returning: location)
                }
            
            locationManager.requestLocation()
            
            // Timeout after 10 seconds
            DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
                cancellable.cancel()
                continuation.resume(throwing: LocationServiceError.timeout)
            }
        }
    }
    
    func startMonitoringSignificantLocationChanges() {
        guard authorizationStatus == .authorizedWhenInUse || authorizationStatus == .authorizedAlways else {
            return
        }
        locationManager.startMonitoringSignificantLocationChanges()
    }
    
    func stopMonitoringSignificantLocationChanges() {
        locationManager.stopMonitoringSignificantLocationChanges()
    }
    
    func calculateDistance(from: CLLocation, to: CLLocation) -> CLLocationDistance {
        return from.distance(from: to)
    }
    
    func calculateDrivingDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) async throws -> CLLocationDistance {
        // This would integrate with MapKit for driving directions
        // For now, return straight-line distance as placeholder
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        return calculateDistance(from: fromLocation, to: toLocation)
    }
    
    func isLocationStale(_ location: CLLocation, threshold: TimeInterval = 300) -> Bool {
        return location.timestamp.timeIntervalSinceNow < -threshold
    }
    
    // MARK: - Trip Context Management
    func setTripContext(tripId: UUID, participantId: UUID) {
        currentTripId = tripId
        currentParticipantId = participantId
    }
    
    func clearTripContext() {
        currentTripId = nil
        currentParticipantId = nil
    }
    
    // MARK: - Location Update Optimization
    func optimizeLocationUpdates(for speed: CLLocationSpeed) {
        // Adjust update frequency based on speed
        if speed < 1.0 { // Stationary
            locationUpdateFrequency = 60.0 // 1 minute
            locationManager.distanceFilter = 50.0 // 50 meters
        } else if speed < 10.0 { // Walking/slow driving
            locationUpdateFrequency = 30.0 // 30 seconds
            locationManager.distanceFilter = 25.0 // 25 meters
        } else { // Driving
            locationUpdateFrequency = 15.0 // 15 seconds
            locationManager.distanceFilter = 10.0 // 10 meters
        }
    }
    
    // MARK: - CloudKit Integration
    private func broadcastLocationToCloudKit(_ location: CLLocation) async {
        guard let tripId = currentTripId,
              let participantId = currentParticipantId,
              isLocationSharingEnabled else {
            return
        }
        
        // Throttle updates based on frequency
        if let lastUpdate = lastLocationUpdate,
           Date().timeIntervalSince(lastUpdate) < locationUpdateFrequency {
            return
        }
        
        do {
            let participantLocation = ParticipantLocation(
                participantId: participantId,
                location: location.coordinate,
                timestamp: location.timestamp,
                speed: location.speed >= 0 ? location.speed : nil,
                heading: location.course >= 0 ? location.course : nil,
                accuracy: location.horizontalAccuracy
            )
            
            // Create CloudKit record
            let record = CKRecord(recordType: "ParticipantLocation")
            record["tripId"] = tripId.uuidString
            record["participantId"] = participantId.uuidString
            record["latitude"] = location.coordinate.latitude
            record["longitude"] = location.coordinate.longitude
            record["timestamp"] = location.timestamp
            record["speed"] = participantLocation.speed
            record["heading"] = participantLocation.heading
            record["accuracy"] = location.horizontalAccuracy
            
            // Save to CloudKit
            let database = cloudKitContainer.publicCloudDatabase
            _ = try await database.save(record)
            
            lastLocationUpdate = Date()
            
        } catch {
            print("Failed to broadcast location to CloudKit: \(error)")
        }
    }
}

// MARK: - CLLocationManagerDelegate
extension LocationManager: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        
        // Filter out inaccurate locations
        guard location.horizontalAccuracy < 100 else { return }
        
        // Update current location
        currentLocation = location
        
        // Optimize updates based on speed
        if location.speed >= 0 {
            optimizeLocationUpdates(for: location.speed)
        }
        
        // Publish location update
        locationSubject.send(location)
        
        // Broadcast to CloudKit if sharing is enabled
        Task {
            await broadcastLocationToCloudKit(location)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location manager failed with error: \(error)")
        
        if let clError = error as? CLError {
            switch clError.code {
            case .denied:
                authorizationStatus = .denied
            case .locationUnknown:
                // Continue trying to get location
                break
            case .network:
                // Handle network error
                break
            default:
                break
            }
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        authorizationStatus = status
        authorizationSubject.send(status)
        
        switch status {
        case .notDetermined:
            break
        case .restricted, .denied:
            stopLocationSharing()
        case .authorizedWhenInUse, .authorizedAlways:
            // Location permission granted
            break
        @unknown default:
            break
        }
    }
}