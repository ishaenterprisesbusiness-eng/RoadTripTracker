import Foundation
import CoreLocation
import Combine
import CoreData

// MARK: - Driving Statistics Service Implementation
@MainActor
class DrivingStatisticsService: ObservableObject, DrivingStatisticsServiceProtocol {
    
    // MARK: - Published Properties
    @Published private(set) var currentStatistics: DrivingStatistics?
    @Published private(set) var isTracking: Bool = false
    @Published private(set) var currentSpeed: Double = 0.0
    @Published private(set) var speedLimit: Double = 50.0 // Default 50 km/h in m/s
    @Published private(set) var isSpeedingDetected: Bool = false
    @Published private(set) var currentRestPeriod: RestPeriod?
    @Published private(set) var shouldSuggestBreak: Bool = false
    
    // MARK: - Private Properties
    private let persistenceController: PersistenceController
    private let locationManager: LocationServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    
    // Publishers
    private let statisticsSubject = PassthroughSubject<DrivingStatistics?, Never>()
    private let speedingAlertsSubject = PassthroughSubject<SpeedingIncident, Never>()
    private let breakSuggestionsSubject = PassthroughSubject<BreakSuggestion, Never>()
    
    // Tracking state
    private var trackingStartTime: Date?
    private var lastLocationUpdate: Date?
    private var lastBreakSuggestion: Date?
    private var locationHistory: [LocationDataPoint] = []
    private var currentSpeedingIncident: SpeedingIncident?
    private var speedingStartTime: Date?
    
    // Configuration
    private let speedingThreshold: Double = 2.0 // 2 m/s (7.2 km/h) over limit
    private let restDetectionThreshold: Double = 1.0 // 1 m/s (3.6 km/h)
    private let restDetectionDuration: TimeInterval = 300 // 5 minutes
    private let breakSuggestionInterval: TimeInterval = 7200 // 2 hours
    private let maxContinuousDriving: TimeInterval = 14400 // 4 hours
    
    // MARK: - Computed Properties
    var statisticsUpdates: AnyPublisher<DrivingStatistics?, Never> {
        statisticsSubject.eraseToAnyPublisher()
    }
    
    var speedingAlerts: AnyPublisher<SpeedingIncident, Never> {
        speedingAlertsSubject.eraseToAnyPublisher()
    }
    
    var breakSuggestions: AnyPublisher<BreakSuggestion, Never> {
        breakSuggestionsSubject.eraseToAnyPublisher()
    }
    
    // MARK: - Initialization
    init(persistenceController: PersistenceController, locationManager: LocationServiceProtocol) {
        self.persistenceController = persistenceController
        self.locationManager = locationManager
        setupLocationSubscription()
    }
    
    // MARK: - Setup
    private func setupLocationSubscription() {
        locationManager.locationUpdates
            .sink { [weak self] location in
                Task { @MainActor in
                    await self?.processLocationUpdate(location)
                }
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Tracking Management
    func startTracking(for tripId: UUID, participantId: UUID) async throws {
        guard !isTracking else {
            throw DrivingStatisticsServiceError.trackingAlreadyActive
        }
        
        // Create new statistics record
        let statistics = DrivingStatistics(
            tripId: tripId,
            participantId: participantId,
            startTime: Date()
        )
        
        currentStatistics = statistics
        isTracking = true
        trackingStartTime = Date()
        locationHistory.removeAll()
        
        // Save initial statistics
        try await saveStatistics(statistics)
        
        // Publish update
        statisticsSubject.send(statistics)
    }
    
    func stopTracking() async throws {
        guard isTracking, var statistics = currentStatistics else {
            throw DrivingStatisticsServiceError.trackingNotStarted
        }
        
        // End current rest period if active
        if currentRestPeriod != nil {
            try await endCurrentRestPeriod()
        }
        
        // Update final statistics
        statistics.endTime = Date()
        statistics.lastUpdated = Date()
        
        // Calculate final metrics
        statistics = await calculateFinalMetrics(for: statistics)
        
        // Save final statistics
        try await saveStatistics(statistics)
        
        // Reset state
        currentStatistics = nil
        isTracking = false
        trackingStartTime = nil
        locationHistory.removeAll()
        currentRestPeriod = nil
        shouldSuggestBreak = false
        
        // Publish final update
        statisticsSubject.send(nil)
    }
    
    func pauseTracking() async throws {
        guard isTracking else {
            throw DrivingStatisticsServiceError.trackingNotStarted
        }
        
        // Start automatic rest period
        if let lastLocation = locationHistory.last {
            await detectAutomaticRestPeriod(CLLocation(
                latitude: lastLocation.coordinate.latitude,
                longitude: lastLocation.coordinate.longitude
            ))
        }
    }
    
    func resumeTracking() async throws {
        guard isTracking else {
            throw DrivingStatisticsServiceError.trackingNotStarted
        }
        
        // End current rest period
        if currentRestPeriod != nil {
            try await endCurrentRestPeriod()
        }
    }
    
    // MARK: - Location Updates
    func processLocationUpdate(_ location: CLLocation) async {
        guard isTracking, var statistics = currentStatistics else { return }
        
        let now = Date()
        let speed = max(0, location.speed) // Ensure non-negative speed
        currentSpeed = speed
        
        // Create location data point
        let dataPoint = LocationDataPoint(
            timestamp: now,
            coordinate: location.coordinate,
            speed: speed,
            heading: location.course >= 0 ? location.course : 0,
            accuracy: location.horizontalAccuracy
        )
        
        // Add to history (keep last 1000 points)
        locationHistory.append(dataPoint)
        if locationHistory.count > 1000 {
            locationHistory.removeFirst()
        }
        
        // Update statistics
        if let lastUpdate = lastLocationUpdate,
           let lastLocation = locationHistory.dropLast().last {
            
            let timeDelta = now.timeIntervalSince(lastUpdate)
            let distance = CLLocation(
                latitude: lastLocation.coordinate.latitude,
                longitude: lastLocation.coordinate.longitude
            ).distance(from: location)
            
            // Update driving metrics (only if moving)
            if speed > restDetectionThreshold {
                statistics.totalDistance += distance
                statistics.totalDrivingTime += timeDelta
                statistics.maxSpeed = max(statistics.maxSpeed, speed)
                
                // Calculate average speed
                if statistics.totalDrivingTime > 0 {
                    statistics.averageSpeed = statistics.totalDistance / statistics.totalDrivingTime
                }
                
                // Check for speeding
                await checkSpeedLimit(currentSpeed: speed, speedLimit: speedLimit)
                
                // End rest period if active
                if currentRestPeriod != nil {
                    try? await endCurrentRestPeriod()
                }
            } else {
                // Detect potential rest period
                await detectAutomaticRestPeriod(location)
            }
        }
        
        lastLocationUpdate = now
        statistics.lastUpdated = now
        currentStatistics = statistics
        
        // Evaluate break need
        if let suggestion = await evaluateBreakNeed() {
            breakSuggestionsSubject.send(suggestion)
        }
        
        // Save updated statistics periodically
        if Int(now.timeIntervalSince1970) % 60 == 0 { // Every minute
            try? await saveStatistics(statistics)
            statisticsSubject.send(statistics)
        }
    }
    
    func updateSpeedLimit(_ speedLimit: Double) async {
        self.speedLimit = speedLimit / 3.6 // Convert km/h to m/s
    }
    
    // MARK: - Rest Period Management
    func startManualRestPeriod(type: RestType, location: CLLocationCoordinate2D) async throws {
        guard isTracking else {
            throw DrivingStatisticsServiceError.trackingNotStarted
        }
        
        // End current rest period if active
        if currentRestPeriod != nil {
            try await endCurrentRestPeriod()
        }
        
        let restPeriod = RestPeriod(
            startTime: Date(),
            location: location,
            type: type
        )
        
        currentRestPeriod = restPeriod
        
        // Add to statistics
        if var statistics = currentStatistics {
            statistics.restPeriods.append(restPeriod)
            statistics.lastUpdated = Date()
            currentStatistics = statistics
            try await saveStatistics(statistics)
        }
    }
    
    func endCurrentRestPeriod() async throws {
        guard let restPeriod = currentRestPeriod else { return }
        
        let endedRestPeriod = RestPeriod(
            id: restPeriod.id,
            startTime: restPeriod.startTime,
            endTime: Date(),
            location: restPeriod.location,
            type: restPeriod.type
        )
        
        // Update statistics
        if var statistics = currentStatistics {
            if let index = statistics.restPeriods.firstIndex(where: { $0.id == restPeriod.id }) {
                statistics.restPeriods[index] = endedRestPeriod
            }
            statistics.lastUpdated = Date()
            currentStatistics = statistics
            try await saveStatistics(statistics)
        }
        
        currentRestPeriod = nil
        shouldSuggestBreak = false
        lastBreakSuggestion = Date()
    }
    
    func detectAutomaticRestPeriod(location: CLLocation) async {
        guard currentRestPeriod == nil else { return }
        
        let now = Date()
        let recentLocations = locationHistory.suffix(10) // Last 10 locations
        
        // Check if stationary for minimum duration
        let stationaryDuration = recentLocations.allSatisfy { $0.speed <= restDetectionThreshold }
        
        if stationaryDuration,
           let firstStationaryTime = recentLocations.first?.timestamp,
           now.timeIntervalSince(firstStationaryTime) >= restDetectionDuration {
            
            let restPeriod = RestPeriod(
                startTime: firstStationaryTime,
                location: location.coordinate,
                type: .automatic
            )
            
            currentRestPeriod = restPeriod
            
            // Add to statistics
            if var statistics = currentStatistics {
                statistics.restPeriods.append(restPeriod)
                statistics.lastUpdated = Date()
                currentStatistics = statistics
                try? await saveStatistics(statistics)
            }
        }
    }
    
    // MARK: - Statistics Retrieval
    func getStatistics(for tripId: UUID, participantId: UUID) async throws -> DrivingStatistics? {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDDrivingStatistics> = CDDrivingStatistics.fetchRequest()
        request.predicate = NSPredicate(format: "tripId == %@ AND participantId == %@", tripId as CVarArg, participantId as CVarArg)
        
        do {
            let results = try context.fetch(request)
            return results.first.flatMap { try? convertToStatistics(from: $0) }
        } catch {
            throw DrivingStatisticsServiceError.unknown(error.localizedDescription)
        }
    }
    
    func getTripStatistics(for tripId: UUID) async throws -> [DrivingStatistics] {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDDrivingStatistics> = CDDrivingStatistics.fetchRequest()
        request.predicate = NSPredicate(format: "tripId == %@", tripId as CVarArg)
        
        do {
            let results = try context.fetch(request)
            return results.compactMap { try? convertToStatistics(from: $0) }
        } catch {
            throw DrivingStatisticsServiceError.unknown(error.localizedDescription)
        }
    }
    
    func getPerformanceSummary(for participantId: UUID) async throws -> DrivingPerformanceSummary {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDDrivingStatistics> = CDDrivingStatistics.fetchRequest()
        request.predicate = NSPredicate(format: "participantId == %@ AND endTime != nil", participantId as CVarArg)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CDDrivingStatistics.startTime, ascending: false)]
        
        do {
            let results = try context.fetch(request)
            let statistics = results.compactMap { try? convertToStatistics(from: $0) }
            
            return calculatePerformanceSummary(from: statistics, participantId: participantId)
        } catch {
            throw DrivingStatisticsServiceError.unknown(error.localizedDescription)
        }
    }
    
    func getTripComparisons(for participantId: UUID, limit: Int = 10) async throws -> [TripComparisonData] {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDDrivingStatistics> = CDDrivingStatistics.fetchRequest()
        request.predicate = NSPredicate(format: "participantId == %@ AND endTime != nil", participantId as CVarArg)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CDDrivingStatistics.startTime, ascending: false)]
        request.fetchLimit = limit
        
        do {
            let results = try context.fetch(request)
            return results.compactMap { cdStats in
                guard let statistics = try? convertToStatistics(from: cdStats) else { return nil }
                
                return TripComparisonData(
                    tripId: statistics.tripId,
                    tripName: "Trip \(statistics.tripId.uuidString.prefix(8))", // Simplified name
                    date: statistics.startTime,
                    totalDistance: statistics.totalDistance,
                    totalTime: statistics.totalDrivingTime,
                    averageSpeed: statistics.averageSpeed,
                    maxSpeed: statistics.maxSpeed,
                    speedingIncidents: statistics.speedingIncidents.count,
                    restPeriods: statistics.restPeriods.count,
                    safetyScore: calculateSafetyScore(for: statistics)
                )
            }
        } catch {
            throw DrivingStatisticsServiceError.unknown(error.localizedDescription)
        }
    }
    
    // MARK: - Speed Monitoring
    func checkSpeedLimit(currentSpeed: Double, speedLimit: Double) async -> Bool {
        let isCurrentlySpeeding = currentSpeed > (speedLimit + speedingThreshold)
        
        if isCurrentlySpeeding && !isSpeedingDetected {
            // Start speeding incident
            isSpeedingDetected = true
            speedingStartTime = Date()
            
        } else if !isCurrentlySpeeding && isSpeedingDetected {
            // End speeding incident
            isSpeedingDetected = false
            
            if let startTime = speedingStartTime,
               let lastLocation = locationHistory.last {
                
                let incident = SpeedingIncident(
                    timestamp: startTime,
                    location: lastLocation.coordinate,
                    actualSpeed: currentSpeed,
                    speedLimit: speedLimit,
                    duration: Date().timeIntervalSince(startTime),
                    severity: SpeedingSeverity.severity(for: (currentSpeed - speedLimit) * 3.6)
                )
                
                try? await recordSpeedingIncident(incident)
                speedingAlertsSubject.send(incident)
            }
            
            speedingStartTime = nil
        }
        
        return isCurrentlySpeeding
    }
    
    func recordSpeedingIncident(_ incident: SpeedingIncident) async throws {
        guard var statistics = currentStatistics else { return }
        
        statistics.speedingIncidents.append(incident)
        statistics.lastUpdated = Date()
        currentStatistics = statistics
        
        try await saveStatistics(statistics)
    }
    
    func getSpeedingHistory(for participantId: UUID) async throws -> [SpeedingIncident] {
        let statistics = try await getPerformanceSummary(for: participantId)
        // This would need to be implemented to fetch all speeding incidents
        // For now, return empty array
        return []
    }
    
    // MARK: - Break Suggestions
    func evaluateBreakNeed() async -> BreakSuggestion? {
        guard let statistics = currentStatistics,
              let startTime = trackingStartTime else { return nil }
        
        let now = Date()
        let drivingTime = now.timeIntervalSince(startTime) - statistics.totalRestTime
        
        // Check if we should suggest a break
        var shouldSuggest = false
        var reason: BreakReason = .continuousDriving
        var urgency: BreakUrgency = .low
        var message = ""
        
        // Continuous driving check
        if drivingTime > maxContinuousDriving {
            shouldSuggest = true
            reason = .continuousDriving
            urgency = .critical
            message = "You've been driving for over 4 hours. Take a break for safety."
        } else if drivingTime > breakSuggestionInterval {
            shouldSuggest = true
            reason = .continuousDriving
            urgency = .medium
            message = "Consider taking a break after 2 hours of driving."
        }
        
        // Speeding pattern check
        let recentSpeedingIncidents = statistics.speedingIncidents.filter {
            $0.timestamp.timeIntervalSinceNow > -1800 // Last 30 minutes
        }
        
        if recentSpeedingIncidents.count >= 3 {
            shouldSuggest = true
            reason = .speedingPattern
            urgency = .high
            message = "Multiple speeding incidents detected. Take a break to refocus."
        }
        
        // Time of day check (late night/early morning)
        let hour = Calendar.current.component(.hour, from: now)
        if (hour >= 22 || hour <= 6) && drivingTime > 3600 { // After 10 PM or before 6 AM, after 1 hour
            shouldSuggest = true
            reason = .timeOfDay
            urgency = .high
            message = "Driving late at night increases fatigue risk. Consider resting."
        }
        
        // Check if we recently suggested a break
        if let lastSuggestion = lastBreakSuggestion,
           now.timeIntervalSince(lastSuggestion) < 1800 { // 30 minutes
            shouldSuggest = false
        }
        
        if shouldSuggest {
            self.shouldSuggestBreak = true
            return BreakSuggestion(
                reason: reason,
                urgency: urgency,
                recommendedDuration: urgency == .critical ? 1800 : 900, // 30 or 15 minutes
                message: message
            )
        }
        
        return nil
    }
    
    func dismissBreakSuggestion() async {
        shouldSuggestBreak = false
        lastBreakSuggestion = Date()
    }
    
    func getBreakRecommendations() async -> [BreakRecommendation] {
        return [
            BreakRecommendation(
                type: .automatic,
                duration: 900, // 15 minutes
                description: "Short break to rest and stretch",
                benefits: ["Reduces fatigue", "Improves concentration", "Prevents muscle stiffness"]
            ),
            BreakRecommendation(
                type: .food,
                duration: 1800, // 30 minutes
                description: "Meal break with light refreshments",
                benefits: ["Maintains energy levels", "Provides hydration", "Social interaction"]
            ),
            BreakRecommendation(
                type: .fuel,
                duration: 600, // 10 minutes
                description: "Quick fuel stop and vehicle check",
                benefits: ["Ensures vehicle readiness", "Brief movement", "Route planning"]
            )
        ]
    }
    
    // MARK: - Performance Analysis
    func calculateSafetyScore(for statistics: DrivingStatistics) -> Double {
        var score: Double = 100.0
        
        // Deduct points for speeding incidents
        let speedingPenalty = Double(statistics.speedingIncidents.count) * 5.0
        score -= speedingPenalty
        
        // Deduct points for excessive speed
        if statistics.maxSpeed > 0 {
            let maxSpeedKmh = statistics.maxSpeed * 3.6
            if maxSpeedKmh > 120 { // Above 120 km/h
                score -= (maxSpeedKmh - 120) * 0.5
            }
        }
        
        // Bonus points for regular breaks
        let drivingHours = statistics.totalDrivingTime / 3600.0
        let expectedBreaks = max(1, Int(drivingHours / 2)) // Every 2 hours
        let actualBreaks = statistics.restPeriods.count
        
        if actualBreaks >= expectedBreaks {
            score += 5.0
        } else {
            score -= Double(expectedBreaks - actualBreaks) * 3.0
        }
        
        return max(0, min(100, score))
    }
    
    func compareWithPreviousTrips(current: DrivingStatistics, participantId: UUID) async throws -> TripPerformanceComparison {
        let comparisons = try await getTripComparisons(for: participantId, limit: 10)
        let previousTrips = comparisons.filter { $0.tripId != current.tripId }
        
        guard !previousTrips.isEmpty else {
            return TripPerformanceComparison(
                currentTrip: current,
                averageFromPreviousTrips: nil,
                bestTrip: nil,
                improvements: [],
                regressions: []
            )
        }
        
        // Calculate averages
        let avgDistance = previousTrips.map { $0.totalDistance }.reduce(0, +) / Double(previousTrips.count)
        let avgTime = previousTrips.map { $0.totalTime }.reduce(0, +) / Double(previousTrips.count)
        let avgSpeed = previousTrips.map { $0.averageSpeed }.reduce(0, +) / Double(previousTrips.count)
        let avgSafetyScore = previousTrips.map { $0.safetyScore }.reduce(0, +) / Double(previousTrips.count)
        
        let averageStats = DrivingStatistics(
            tripId: UUID(),
            participantId: participantId,
            totalDistance: avgDistance,
            totalDrivingTime: avgTime,
            averageSpeed: avgSpeed
        )
        
        // Find best trip
        let bestTrip = previousTrips.max { $0.safetyScore < $1.safetyScore }
        
        // Calculate improvements and regressions
        var improvements: [PerformanceImprovement] = []
        var regressions: [PerformanceRegression] = []
        
        let currentSafetyScore = calculateSafetyScore(for: current)
        
        if currentSafetyScore > avgSafetyScore {
            improvements.append(PerformanceImprovement(
                metric: .safetyScore,
                improvement: currentSafetyScore - avgSafetyScore,
                description: "Safety score improved by \(String(format: "%.1f", currentSafetyScore - avgSafetyScore)) points"
            ))
        } else if currentSafetyScore < avgSafetyScore {
            regressions.append(PerformanceRegression(
                metric: .safetyScore,
                regression: avgSafetyScore - currentSafetyScore,
                description: "Safety score decreased by \(String(format: "%.1f", avgSafetyScore - currentSafetyScore)) points"
            ))
        }
        
        return TripPerformanceComparison(
            currentTrip: current,
            averageFromPreviousTrips: averageStats,
            bestTrip: nil, // Would need to convert TripComparisonData to DrivingStatistics
            improvements: improvements,
            regressions: regressions
        )
    }
    
    func generatePerformanceReport(for tripId: UUID, participantId: UUID) async throws -> PerformanceReport {
        guard let statistics = try await getStatistics(for: tripId, participantId: participantId) else {
            throw DrivingStatisticsServiceError.dataNotFound
        }
        
        let safetyScore = calculateSafetyScore(for: statistics)
        let safetyRating = DrivingPerformanceSummary(
            participantId: participantId,
            safetyScore: safetyScore
        ).safetyRating
        
        let summary = PerformanceSummary(
            overallRating: safetyRating,
            strengths: generateStrengths(for: statistics),
            areasForImprovement: generateImprovementAreas(for: statistics),
            keyMetrics: generateKeyMetrics(for: statistics)
        )
        
        let recommendations = generateRecommendations(for: statistics)
        let charts = generateChartData(for: statistics)
        
        return PerformanceReport(
            tripId: tripId,
            participantId: participantId,
            statistics: statistics,
            summary: summary,
            recommendations: recommendations,
            charts: charts
        )
    }
    
    // MARK: - Data Management
    func saveStatistics(_ statistics: DrivingStatistics) async throws {
        let context = persistenceController.container.viewContext
        
        // Find existing record or create new one
        let request: NSFetchRequest<CDDrivingStatistics> = CDDrivingStatistics.fetchRequest()
        request.predicate = NSPredicate(format: "tripId == %@ AND participantId == %@", statistics.tripId as CVarArg, statistics.participantId as CVarArg)
        
        do {
            let results = try context.fetch(request)
            let cdStatistics = results.first ?? CDDrivingStatistics(context: context)
            
            // Update Core Data entity
            cdStatistics.id = statistics.id
            cdStatistics.tripId = statistics.tripId
            cdStatistics.participantId = statistics.participantId
            cdStatistics.totalDistance = statistics.totalDistance
            cdStatistics.totalDrivingTime = statistics.totalDrivingTime
            cdStatistics.averageSpeed = statistics.averageSpeed
            cdStatistics.maxSpeed = statistics.maxSpeed
            cdStatistics.startTime = statistics.startTime
            cdStatistics.endTime = statistics.endTime
            cdStatistics.lastUpdated = statistics.lastUpdated
            
            // Encode complex data as JSON
            let encoder = JSONEncoder()
            cdStatistics.speedingIncidentsData = try encoder.encode(statistics.speedingIncidents)
            cdStatistics.restPeriodsData = try encoder.encode(statistics.restPeriods)
            
            try context.save()
            
        } catch {
            throw DrivingStatisticsServiceError.saveFailed(error.localizedDescription)
        }
    }
    
    func deleteStatistics(for tripId: UUID) async throws {
        let context = persistenceController.container.viewContext
        
        let request: NSFetchRequest<CDDrivingStatistics> = CDDrivingStatistics.fetchRequest()
        request.predicate = NSPredicate(format: "tripId == %@", tripId as CVarArg)
        
        do {
            let results = try context.fetch(request)
            for cdStatistics in results {
                context.delete(cdStatistics)
            }
            try context.save()
        } catch {
            throw DrivingStatisticsServiceError.unknown(error.localizedDescription)
        }
    }
    
    func exportStatistics(for participantId: UUID, format: ExportFormat) async throws -> Data {
        let summary = try await getPerformanceSummary(for: participantId)
        let comparisons = try await getTripComparisons(for: participantId, limit: 50)
        
        switch format {
        case .json:
            let exportData = [
                "summary": summary,
                "trips": comparisons
            ]
            return try JSONEncoder().encode(exportData)
            
        case .csv:
            var csvContent = "Trip ID,Date,Distance (km),Time (hours),Average Speed (km/h),Max Speed (km/h),Speeding Incidents,Rest Periods,Safety Score\n"
            
            for trip in comparisons {
                csvContent += "\(trip.tripId),\(trip.date),\(trip.totalDistanceKm),\(trip.totalTimeHours),\(trip.averageSpeedKmh),\(trip.maxSpeedKmh),\(trip.speedingIncidents),\(trip.restPeriods),\(trip.safetyScore)\n"
            }
            
            return csvContent.data(using: .utf8) ?? Data()
            
        case .pdf:
            // PDF generation would require additional implementation
            throw DrivingStatisticsServiceError.exportFailed("PDF export not yet implemented")
        }
    }
    
    // MARK: - Private Helper Methods
    
    private func calculateFinalMetrics(for statistics: DrivingStatistics) async -> DrivingStatistics {
        var finalStats = statistics
        
        // Recalculate average speed
        if finalStats.totalDrivingTime > 0 {
            finalStats.averageSpeed = finalStats.totalDistance / finalStats.totalDrivingTime
        }
        
        return finalStats
    }
    
    private func calculatePerformanceSummary(from statistics: [DrivingStatistics], participantId: UUID) -> DrivingPerformanceSummary {
        guard !statistics.isEmpty else {
            return DrivingPerformanceSummary(participantId: participantId)
        }
        
        let totalDistance = statistics.map { $0.totalDistance }.reduce(0, +)
        let totalTime = statistics.map { $0.totalDrivingTime }.reduce(0, +)
        let avgSpeed = statistics.map { $0.averageSpeed }.reduce(0, +) / Double(statistics.count)
        let bestSpeed = statistics.map { $0.averageSpeed }.max() ?? 0
        let totalSpeeding = statistics.map { $0.speedingIncidents.count }.reduce(0, +)
        let avgSafetyScore = statistics.map { calculateSafetyScore(for: $0) }.reduce(0, +) / Double(statistics.count)
        let lastTrip = statistics.max { $0.startTime < $1.startTime }
        
        return DrivingPerformanceSummary(
            participantId: participantId,
            totalTrips: statistics.count,
            totalDistance: totalDistance,
            totalDrivingTime: totalTime,
            averageSpeed: avgSpeed,
            bestAverageSpeed: bestSpeed,
            totalSpeedingIncidents: totalSpeeding,
            safetyScore: avgSafetyScore,
            lastTripDate: lastTrip?.startTime
        )
    }
    
    private func convertToStatistics(from cdStatistics: CDDrivingStatistics) throws -> DrivingStatistics {
        guard let id = cdStatistics.id,
              let tripId = cdStatistics.tripId,
              let participantId = cdStatistics.participantId,
              let startTime = cdStatistics.startTime,
              let lastUpdated = cdStatistics.lastUpdated else {
            throw DrivingStatisticsServiceError.unknown("Invalid Core Data statistics")
        }
        
        let decoder = JSONDecoder()
        
        let speedingIncidents: [SpeedingIncident]
        if let speedingData = cdStatistics.speedingIncidentsData {
            speedingIncidents = (try? decoder.decode([SpeedingIncident].self, from: speedingData)) ?? []
        } else {
            speedingIncidents = []
        }
        
        let restPeriods: [RestPeriod]
        if let restData = cdStatistics.restPeriodsData {
            restPeriods = (try? decoder.decode([RestPeriod].self, from: restData)) ?? []
        } else {
            restPeriods = []
        }
        
        return DrivingStatistics(
            id: id,
            tripId: tripId,
            participantId: participantId,
            totalDistance: cdStatistics.totalDistance,
            totalDrivingTime: cdStatistics.totalDrivingTime,
            averageSpeed: cdStatistics.averageSpeed,
            maxSpeed: cdStatistics.maxSpeed,
            speedingIncidents: speedingIncidents,
            restPeriods: restPeriods,
            startTime: startTime,
            endTime: cdStatistics.endTime,
            lastUpdated: lastUpdated
        )
    }
    
    private func generateStrengths(for statistics: DrivingStatistics) -> [String] {
        var strengths: [String] = []
        
        let safetyScore = calculateSafetyScore(for: statistics)
        if safetyScore >= 90 {
            strengths.append("Excellent safety record")
        }
        
        if statistics.speedingIncidents.isEmpty {
            strengths.append("No speeding incidents")
        }
        
        if statistics.restPeriods.count >= Int(statistics.totalDrivingTime / 7200) { // Break every 2 hours
            strengths.append("Good break frequency")
        }
        
        if statistics.averageSpeedKmh > 0 && statistics.averageSpeedKmh <= 100 {
            strengths.append("Maintained reasonable speeds")
        }
        
        return strengths
    }
    
    private func generateImprovementAreas(for statistics: DrivingStatistics) -> [String] {
        var areas: [String] = []
        
        if statistics.speedingIncidents.count > 3 {
            areas.append("Reduce speeding incidents")
        }
        
        if statistics.restPeriods.count < Int(statistics.totalDrivingTime / 7200) {
            areas.append("Take more frequent breaks")
        }
        
        if statistics.maxSpeedKmh > 130 {
            areas.append("Avoid excessive speeds")
        }
        
        return areas
    }
    
    private func generateKeyMetrics(for statistics: DrivingStatistics) -> [KeyMetric] {
        return [
            KeyMetric(
                name: "Safety Score",
                value: String(format: "%.0f", calculateSafetyScore(for: statistics)),
                trend: .stable,
                description: "Overall driving safety rating"
            ),
            KeyMetric(
                name: "Average Speed",
                value: String(format: "%.0f km/h", statistics.averageSpeedKmh),
                trend: .stable,
                description: "Average driving speed"
            ),
            KeyMetric(
                name: "Total Distance",
                value: String(format: "%.0f km", statistics.totalDistanceKm),
                trend: .stable,
                description: "Total distance traveled"
            )
        ]
    }
    
    private func generateRecommendations(for statistics: DrivingStatistics) -> [PerformanceRecommendation] {
        var recommendations: [PerformanceRecommendation] = []
        
        if statistics.speedingIncidents.count > 0 {
            recommendations.append(PerformanceRecommendation(
                title: "Improve Speed Management",
                description: "Focus on maintaining speeds within legal limits",
                priority: .high,
                category: .safety,
                actionItems: [
                    "Use cruise control on highways",
                    "Check speed limits regularly",
                    "Allow extra time for trips"
                ]
            ))
        }
        
        if statistics.restPeriods.count < 2 {
            recommendations.append(PerformanceRecommendation(
                title: "Take Regular Breaks",
                description: "Increase break frequency for better safety",
                priority: .medium,
                category: .safety,
                actionItems: [
                    "Stop every 2 hours",
                    "Take 15-minute breaks",
                    "Stretch and hydrate"
                ]
            ))
        }
        
        return recommendations
    }
    
    private func generateChartData(for statistics: DrivingStatistics) -> [ChartData] {
        var charts: [ChartData] = []
        
        // Speed over time chart
        let speedData = locationHistory.enumerated().map { index, location in
            DataPoint(x: Double(index), y: location.speedKmh, label: nil)
        }
        
        if !speedData.isEmpty {
            charts.append(ChartData(
                type: .line,
                title: "Speed Over Time",
                data: speedData,
                xAxisLabel: "Time",
                yAxisLabel: "Speed (km/h)"
            ))
        }
        
        return charts
    }
}