import Foundation
import CryptoKit

// MARK: - JWT Manager
class JWTManager {
    
    // MARK: - JWT Token Structure
    struct JWTToken {
        let header: [String: Any]
        let payload: [String: Any]
        let signature: String
        
        var isExpired: Bool {
            guard let exp = payload["exp"] as? TimeInterval else { return true }
            return Date().timeIntervalSince1970 > exp
        }
        
        var userId: UUID? {
            guard let userIdString = payload["sub"] as? String else { return nil }
            return UUID(uuidString: userIdString)
        }
    }
    
    // MARK: - Properties
    private let secretKey = "your-secret-key-here" // In production, this should be securely managed
    
    // MARK: - Token Generation
    func generateToken(for user: User, expirationTime: TimeInterval = 3600) -> String {
        let header = [
            "alg": "HS256",
            "typ": "JWT"
        ]
        
        let payload = [
            "sub": user.id.uuidString,
            "email": user.email,
            "username": user.username,
            "iat": Date().timeIntervalSince1970,
            "exp": Date().timeIntervalSince1970 + expirationTime
        ] as [String: Any]
        
        guard let headerData = try? JSONSerialization.data(withJSONObject: header),
              let payloadData = try? JSONSerialization.data(withJSONObject: payload) else {
            return ""
        }
        
        let headerBase64 = headerData.base64URLEncodedString()
        let payloadBase64 = payloadData.base64URLEncodedString()
        
        let signatureInput = "\(headerBase64).\(payloadBase64)"
        let signature = generateSignature(for: signatureInput)
        
        return "\(headerBase64).\(payloadBase64).\(signature)"
    }
    
    // MARK: - Token Validation
    func validateToken(_ tokenString: String) -> JWTToken? {
        let components = tokenString.components(separatedBy: ".")
        guard components.count == 3 else { return nil }
        
        let headerBase64 = components[0]
        let payloadBase64 = components[1]
        let signature = components[2]
        
        // Verify signature
        let signatureInput = "\(headerBase64).\(payloadBase64)"
        let expectedSignature = generateSignature(for: signatureInput)
        
        guard signature == expectedSignature else { return nil }
        
        // Decode header and payload
        guard let headerData = Data(base64URLEncoded: headerBase64),
              let payloadData = Data(base64URLEncoded: payloadBase64),
              let header = try? JSONSerialization.jsonObject(with: headerData) as? [String: Any],
              let payload = try? JSONSerialization.jsonObject(with: payloadData) as? [String: Any] else {
            return nil
        }
        
        return JWTToken(header: header, payload: payload, signature: signature)
    }
    
    // MARK: - Token Refresh
    func refreshToken(_ tokenString: String) -> String? {
        guard let token = validateToken(tokenString),
              let userId = token.userId else { return nil }
        
        // In a real implementation, you would fetch the user from the database
        // For now, we'll create a mock user
        let user = User(
            id: userId,
            username: "User",
            email: "user@example.com",
            city: "City",
            dateOfBirth: Date()
        )
        
        return generateToken(for: user)
    }
    
    // MARK: - Private Methods
    private func generateSignature(for input: String) -> String {
        let key = SymmetricKey(data: secretKey.data(using: .utf8)!)
        let signature = HMAC<SHA256>.authenticationCode(for: input.data(using: .utf8)!, using: key)
        return Data(signature).base64URLEncodedString()
    }
}

// MARK: - Data Extension for Base64URL Encoding
extension Data {
    func base64URLEncodedString() -> String {
        return base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
    
    init?(base64URLEncoded string: String) {
        var base64 = string
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        
        // Add padding if needed
        let remainder = base64.count % 4
        if remainder > 0 {
            base64 += String(repeating: "=", count: 4 - remainder)
        }
        
        self.init(base64Encoded: base64)
    }
}