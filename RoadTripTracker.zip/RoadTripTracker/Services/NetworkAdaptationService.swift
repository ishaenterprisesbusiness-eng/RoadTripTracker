import Foundation
import Network
import Combine
import CoreData

// MARK: - Network Adaptation Service
@MainActor
class NetworkAdaptationService: ObservableObject {
    
    // MARK: - Properties
    static let shared = NetworkAdaptationService()
    
    private let networkMonitor = NWPathMonitor()
    private let monitorQueue = DispatchQueue(label: "NetworkAdaptationMonitor")
    private let offlineManager = OfflineManager.shared
    
    @Published var currentNetworkType: NetworkType = .unknown
    @Published var connectionQuality: ConnectionQuality = .unknown
    @Published var dataUsageMode: DataUsageMode = .normal
    @Published var isLowDataMode: Bool = false
    
    // Network metrics
    @Published var estimatedBandwidth: Double = 0 // Mbps
    @Published var latency: TimeInterval = 0 // seconds
    @Published var packetLoss: Double = 0 // percentage
    
    private var networkCancellables = Set<AnyCancellable>()
    private var bandwidthTestTimer: Timer?
    
    // MARK: - Initialization
    private init() {
        setupNetworkMonitoring()
        observeSystemSettings()
    }
    
    // MARK: - Network Monitoring
    private func setupNetworkMonitoring() {
        networkMonitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                self?.handleNetworkPathUpdate(path)
            }
        }
        networkMonitor.start(queue: monitorQueue)
    }
    
    private func handleNetworkPathUpdate(_ path: NWPath) {
        // Update network type
        if path.usesInterfaceType(.wifi) {
            currentNetworkType = .wifi
        } else if path.usesInterfaceType(.cellular) {
            currentNetworkType = .cellular
        } else if path.usesInterfaceType(.wiredEthernet) {
            currentNetworkType = .ethernet
        } else if path.status == .satisfied {
            currentNetworkType = .other
        } else {
            currentNetworkType = .offline
        }
        
        // Update connection quality based on network type
        updateConnectionQuality()
        
        // Adapt data usage based on network conditions
        adaptDataUsage()
        
        // Start bandwidth testing for active connections
        if path.status == .satisfied {
            startBandwidthTesting()
        } else {
            stopBandwidthTesting()
        }
    }
    
    private func observeSystemSettings() {
        // Monitor low data mode changes
        NotificationCenter.default.publisher(for: .NSProcessInfoPowerStateDidChange)
            .sink { [weak self] _ in
                self?.checkLowDataMode()
            }
            .store(in: &networkCancellables)
        
        checkLowDataMode()
    }
    
    private func checkLowDataMode() {
        // Check if low data mode is enabled (iOS 13+)
        if #available(iOS 13.0, *) {
            isLowDataMode = ProcessInfo.processInfo.isLowPowerModeEnabled
        }
        
        if isLowDataMode {
            dataUsageMode = .minimal
        }
    }
    
    // MARK: - Connection Quality Assessment
    private func updateConnectionQuality() {
        switch currentNetworkType {
        case .wifi:
            connectionQuality = .excellent
        case .cellular:
            // Cellular quality depends on signal strength and type
            connectionQuality = .good
        case .ethernet:
            connectionQuality = .excellent
        case .other:
            connectionQuality = .fair
        case .offline:
            connectionQuality = .none
        case .unknown:
            connectionQuality = .unknown
        }
    }
    
    // MARK: - Data Usage Adaptation
    private func adaptDataUsage() {
        switch currentNetworkType {
        case .wifi:
            if !isLowDataMode {
                dataUsageMode = .normal
            }
        case .cellular:
            dataUsageMode = isLowDataMode ? .minimal : .conservative
        case .ethernet:
            dataUsageMode = .normal
        case .other, .offline, .unknown:
            dataUsageMode = .minimal
        }
        
        // Apply data usage settings
        applyDataUsageSettings()
    }
    
    private func applyDataUsageSettings() {
        switch dataUsageMode {
        case .minimal:
            // Reduce location update frequency
            // Compress images heavily
            // Batch operations more aggressively
            // Disable automatic photo uploads
            break
        case .conservative:
            // Moderate location updates
            // Standard image compression
            // Regular operation batching
            break
        case .normal:
            // Full functionality
            // Standard compression
            // Real-time updates
            break
        }
    }
    
    // MARK: - Bandwidth Testing
    private func startBandwidthTesting() {
        stopBandwidthTesting()
        
        bandwidthTestTimer = Timer.scheduledTimer(withTimeInterval: 30.0, repeats: true) { [weak self] _ in
            Task {
                await self?.performBandwidthTest()
            }
        }
    }
    
    private func stopBandwidthTesting() {
        bandwidthTestTimer?.invalidate()
        bandwidthTestTimer = nil
    }
    
    private func performBandwidthTest() async {
        guard currentNetworkType != .offline else { return }
        
        let testStartTime = Date()
        
        do {
            // Perform a small network request to estimate bandwidth
            let url = URL(string: "https://httpbin.org/bytes/1024")! // 1KB test
            let (data, response) = try await URLSession.shared.data(from: url)
            
            let testDuration = Date().timeIntervalSince(testStartTime)
            let dataSize = Double(data.count) / 1024.0 // KB
            let bandwidth = (dataSize * 8) / (testDuration * 1000) // Mbps
            
            estimatedBandwidth = bandwidth
            
            // Estimate latency from response time
            if let httpResponse = response as? HTTPURLResponse {
                latency = testDuration
            }
            
            // Update connection quality based on bandwidth
            updateConnectionQualityFromBandwidth(bandwidth)
            
        } catch {
            // Handle test failure
            estimatedBandwidth = 0
            latency = 0
            connectionQuality = .poor
        }
    }
    
    private func updateConnectionQualityFromBandwidth(_ bandwidth: Double) {
        switch bandwidth {
        case 10...:
            connectionQuality = .excellent
        case 5..<10:
            connectionQuality = .good
        case 1..<5:
            connectionQuality = .fair
        case 0.1..<1:
            connectionQuality = .poor
        default:
            connectionQuality = .none
        }
    }
    
    // MARK: - Adaptive Configurations
    func getLocationUpdateInterval() -> TimeInterval {
        switch dataUsageMode {
        case .minimal:
            return 60.0 // 1 minute
        case .conservative:
            return 30.0 // 30 seconds
        case .normal:
            return 15.0 // 15 seconds
        }
    }
    
    func getImageCompressionQuality() -> Double {
        switch dataUsageMode {
        case .minimal:
            return 0.3
        case .conservative:
            return 0.6
        case .normal:
            return 0.8
        }
    }
    
    func getSyncBatchSize() -> Int {
        switch dataUsageMode {
        case .minimal:
            return 20
        case .conservative:
            return 10
        case .normal:
            return 5
        }
    }
    
    func shouldAutoUploadPhotos() -> Bool {
        switch dataUsageMode {
        case .minimal:
            return false
        case .conservative:
            return currentNetworkType == .wifi
        case .normal:
            return true
        }
    }
    
    func shouldPreloadMapData() -> Bool {
        switch dataUsageMode {
        case .minimal:
            return false
        case .conservative:
            return currentNetworkType == .wifi
        case .normal:
            return true
        }
    }
    
    // MARK: - Network Quality Metrics
    func getNetworkQualityScore() -> Double {
        var score: Double = 0
        
        // Base score from connection type
        switch currentNetworkType {
        case .wifi, .ethernet:
            score += 40
        case .cellular:
            score += 25
        case .other:
            score += 15
        case .offline, .unknown:
            score += 0
        }
        
        // Bandwidth contribution
        switch estimatedBandwidth {
        case 10...:
            score += 30
        case 5..<10:
            score += 25
        case 1..<5:
            score += 15
        case 0.1..<1:
            score += 5
        default:
            score += 0
        }
        
        // Latency contribution (lower is better)
        switch latency {
        case 0..<0.1:
            score += 20
        case 0.1..<0.3:
            score += 15
        case 0.3..<0.5:
            score += 10
        case 0.5..<1.0:
            score += 5
        default:
            score += 0
        }
        
        // Low data mode penalty
        if isLowDataMode {
            score *= 0.7
        }
        
        return min(score, 100.0)
    }
    
    // MARK: - Recommendations
    func getNetworkRecommendations() -> [NetworkRecommendation] {
        var recommendations: [NetworkRecommendation] = []
        
        if currentNetworkType == .cellular && !isLowDataMode {
            recommendations.append(.enableLowDataMode)
        }
        
        if connectionQuality == .poor {
            recommendations.append(.findBetterConnection)
        }
        
        if estimatedBandwidth < 1.0 {
            recommendations.append(.limitBackgroundSync)
        }
        
        if latency > 1.0 {
            recommendations.append(.enableOfflineMode)
        }
        
        return recommendations
    }
    
    // MARK: - Manual Override
    func setDataUsageMode(_ mode: DataUsageMode) {
        dataUsageMode = mode
        applyDataUsageSettings()
    }
    
    func forceNetworkTest() async {
        await performBandwidthTest()
    }
}

// MARK: - Supporting Enums

enum NetworkType {
    case wifi
    case cellular
    case ethernet
    case other
    case offline
    case unknown
}

enum ConnectionQuality {
    case excellent
    case good
    case fair
    case poor
    case none
    case unknown
}

enum DataUsageMode {
    case minimal
    case conservative
    case normal
}

enum NetworkRecommendation {
    case enableLowDataMode
    case findBetterConnection
    case limitBackgroundSync
    case enableOfflineMode
    
    var description: String {
        switch self {
        case .enableLowDataMode:
            return "Enable Low Data Mode to reduce cellular usage"
        case .findBetterConnection:
            return "Find a better network connection for optimal performance"
        case .limitBackgroundSync:
            return "Limit background synchronization due to slow connection"
        case .enableOfflineMode:
            return "Consider using offline mode due to high latency"
        }
    }
}