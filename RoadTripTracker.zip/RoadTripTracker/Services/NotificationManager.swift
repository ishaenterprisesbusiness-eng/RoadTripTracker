import Foundation
import Combine
import CoreLocation
import UserNotifications

// MARK: - Notification Manager
class NotificationManager: ObservableObject {
    
    // MARK: - Properties
    private let notificationService: NotificationServiceProtocol
    private let locationManager: LocationManager
    private var cancellables = Set<AnyCancellable>()
    
    @Published var notificationHistory = NotificationHistory()
    @Published var unreadCount: Int = 0
    @Published var hasEmergencyAlert: Bool = false
    
    // MARK: - Initialization
    init(notificationService: NotificationServiceProtocol, locationManager: LocationManager) {
        self.notificationService = notificationService
        self.locationManager = locationManager
        
        setupLocationBasedNotifications()
        loadNotificationHistory()
        updateUnreadCount()
    }
    
    // MARK: - Trip Event Notifications
    func notifyParticipantJoined(_ participant: Participant, in trip: Trip) async {
        guard let template = NotificationTemplate.templates[.participantJoined] else { return }
        
        let parameters = [
            "username": participant.user.username,
            "tripName": trip.name
        ]
        
        let (title, body) = template.generateNotification(with: parameters)
        
        let tripNotification = TripNotification(
            tripId: trip.id,
            type: .participantJoined,
            title: title,
            message: body,
            priority: template.priority,
            data: [
                "participantId": participant.id.uuidString,
                "userId": participant.userId.uuidString
            ]
        )
        
        await addNotificationToHistory(tripNotification)
        
        do {
            try await notificationService.sendParticipantJoinedNotification(
                participant: participant,
                trip: trip
            )
        } catch {
            print("Failed to send participant joined notification: \(error)")
        }
    }
    
    func notifyParticipantLeft(_ participant: Participant, from trip: Trip) async {
        guard let template = NotificationTemplate.templates[.participantLeft] else { return }
        
        let parameters = [
            "username": participant.user.username,
            "tripName": trip.name
        ]
        
        let (title, body) = template.generateNotification(with: parameters)
        
        let tripNotification = TripNotification(
            tripId: trip.id,
            type: .participantLeft,
            title: title,
            message: body,
            priority: template.priority,
            data: [
                "participantId": participant.id.uuidString,
                "userId": participant.userId.uuidString
            ]
        )
        
        await addNotificationToHistory(tripNotification)
        
        do {
            try await notificationService.sendParticipantLeftNotification(
                participant: participant,
                trip: trip
            )
        } catch {
            print("Failed to send participant left notification: \(error)")
        }
    }
    
    func notifyApproachingDestination(_ destination: Destination, participant: Participant, trip: Trip, distance: CLLocationDistance) async {
        guard let template = NotificationTemplate.templates[.approachingDestination] else { return }
        
        let distanceText = distance < 1000 ? 
            String(format: "%.0f meters", distance) : 
            String(format: "%.1f km", distance / 1000)
        
        let parameters = [
            "username": participant.user.username,
            "distance": distanceText,
            "destinationName": destination.name
        ]
        
        let (title, body) = template.generateNotification(with: parameters)
        
        let tripNotification = TripNotification(
            tripId: trip.id,
            type: .approachingDestination,
            title: title,
            message: body,
            priority: template.priority,
            data: [
                "participantId": participant.id.uuidString,
                "destinationId": destination.id.uuidString,
                "distance": String(distance)
            ]
        )
        
        await addNotificationToHistory(tripNotification)
        
        do {
            try await notificationService.sendApproachingDestinationNotification(
                destination: destination,
                participant: participant,
                trip: trip,
                distance: distance
            )
        } catch {
            print("Failed to send approaching destination notification: \(error)")
        }
    }
    
    func notifyEmergency(_ emergency: EmergencyNotification, participant: Participant, trip: Trip) async {
        guard let template = NotificationTemplate.templates[.emergencyAlert] else { return }
        
        let parameters = [
            "username": participant.user.username,
            "message": emergency.message
        ]
        
        let (title, body) = template.generateNotification(with: parameters)
        
        let tripNotification = TripNotification(
            tripId: trip.id,
            type: .emergencyAlert,
            title: title,
            message: body,
            priority: .emergency,
            data: [
                "emergencyId": emergency.id.uuidString,
                "participantId": participant.id.uuidString,
                "emergencyType": emergency.type.rawValue,
                "latitude": String(emergency.location.latitude),
                "longitude": String(emergency.location.longitude)
            ]
        )
        
        await addNotificationToHistory(tripNotification)
        await addEmergencyNotificationToHistory(emergency)
        
        await MainActor.run {
            hasEmergencyAlert = true
        }
        
        do {
            try await notificationService.sendEmergencyNotification(
                participant: participant,
                trip: trip,
                message: emergency.message,
                location: emergency.location
            )
        } catch {
            print("Failed to send emergency notification: \(error)")
        }
    }
    
    func notifyTripStarted(_ trip: Trip) async {
        guard let template = NotificationTemplate.templates[.tripStarted] else { return }
        
        let parameters = [
            "tripName": trip.name
        ]
        
        let (title, body) = template.generateNotification(with: parameters)
        
        let tripNotification = TripNotification(
            tripId: trip.id,
            type: .tripStarted,
            title: title,
            message: body,
            priority: template.priority
        )
        
        await addNotificationToHistory(tripNotification)
        
        do {
            try await notificationService.sendTripUpdateNotification(
                trip: trip,
                updateType: .statusChanged,
                message: body
            )
        } catch {
            print("Failed to send trip started notification: \(error)")
        }
    }
    
    func notifyTripCompleted(_ trip: Trip) async {
        guard let template = NotificationTemplate.templates[.tripCompleted] else { return }
        
        let parameters = [
            "tripName": trip.name
        ]
        
        let (title, body) = template.generateNotification(with: parameters)
        
        let tripNotification = TripNotification(
            tripId: trip.id,
            type: .tripCompleted,
            title: title,
            message: body,
            priority: template.priority
        )
        
        await addNotificationToHistory(tripNotification)
        
        do {
            try await notificationService.sendTripUpdateNotification(
                trip: trip,
                updateType: .statusChanged,
                message: body
            )
        } catch {
            print("Failed to send trip completed notification: \(error)")
        }
    }
    
    // MARK: - Budget Notifications
    func notifyBudgetAlert(_ budgetAlert: BudgetAlert, trip: Trip) async {
        guard let template = NotificationTemplate.templates[.budgetAlert] else { return }
        
        let percentage = Int((budgetAlert.currentAmount / budgetAlert.threshold) * 100)
        
        let parameters = [
            "percentage": String(percentage),
            "spent": String(format: "%.2f", budgetAlert.currentAmount),
            "total": String(format: "%.2f", budgetAlert.threshold)
        ]
        
        let (title, body) = template.generateNotification(with: parameters)
        
        let tripNotification = TripNotification(
            tripId: trip.id,
            type: .budgetAlert,
            title: title,
            message: body,
            priority: template.priority,
            data: [
                "alertType": budgetAlert.type.rawValue,
                "category": budgetAlert.category?.rawValue ?? "total"
            ]
        )
        
        await addNotificationToHistory(tripNotification)
        
        // Send local notification for budget alerts
        let localNotification = LocalNotification(
            identifier: "budget_alert_\(budgetAlert.id.uuidString)",
            title: title,
            body: body,
            sound: .default
        )
        
        do {
            try await notificationService.scheduleLocalNotification(localNotification)
        } catch {
            print("Failed to send budget alert notification: \(error)")
        }
    }
    
    // MARK: - Weather Notifications
    func notifyWeatherAlert(_ weatherAlert: WeatherAlert, location: String) async {
        guard let template = NotificationTemplate.templates[.weatherAlert] else { return }
        
        let parameters = [
            "alertType": weatherAlert.severity.rawValue.capitalized,
            "location": location,
            "description": weatherAlert.description
        ]
        
        let (title, body) = template.generateNotification(with: parameters)
        
        // Weather alerts are not trip-specific, so we use a generic trip ID
        let tripNotification = TripNotification(
            tripId: UUID(), // Generic ID for weather alerts
            type: .weatherAlert,
            title: title,
            message: body,
            priority: template.priority,
            data: [
                "weatherAlertId": weatherAlert.id.uuidString,
                "severity": weatherAlert.severity.rawValue,
                "location": location
            ]
        )
        
        await addNotificationToHistory(tripNotification)
        
        // Send local notification for weather alerts
        let localNotification = LocalNotification(
            identifier: "weather_alert_\(weatherAlert.id.uuidString)",
            title: title,
            body: body,
            sound: weatherAlert.severity == .extreme ? .defaultCritical : .default
        )
        
        do {
            try await notificationService.scheduleLocalNotification(localNotification)
        } catch {
            print("Failed to send weather alert notification: \(error)")
        }
    }
    
    // MARK: - Check-in Reminders
    func scheduleCheckInReminder(for participant: Participant, trip: Trip, after interval: TimeInterval) async {
        guard let template = NotificationTemplate.templates[.checkInReminder] else { return }
        
        let (title, body) = template.generateNotification(with: [:])
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: interval, repeats: false)
        
        let localNotification = LocalNotification(
            identifier: "checkin_reminder_\(participant.id.uuidString)",
            title: title,
            body: body,
            trigger: trigger
        )
        
        do {
            try await notificationService.scheduleLocalNotification(localNotification)
        } catch {
            print("Failed to schedule check-in reminder: \(error)")
        }
    }
    
    func cancelCheckInReminder(for participant: Participant) async {
        do {
            try await notificationService.cancelNotification(
                withIdentifier: "checkin_reminder_\(participant.id.uuidString)"
            )
        } catch {
            print("Failed to cancel check-in reminder: \(error)")
        }
    }
    
    // MARK: - Location-Based Notifications
    private func setupLocationBasedNotifications() {
        locationManager.locationUpdates
            .sink { [weak self] location in
                Task {
                    await self?.checkLocationBasedAlerts(location)
                }
            }
            .store(in: &cancellables)
    }
    
    private func checkLocationBasedAlerts(_ location: CLLocation) async {
        // This would check against active trips and destinations
        // For now, this is a placeholder for the location-based notification logic
    }
    
    func setupDestinationAlerts(for trip: Trip) async {
        for destination in trip.destinations {
            let alertTypes: [LocationAlertType] = [.approaching, .nearby, .arrived]
            
            for alertType in alertTypes {
                let identifier = "destination_\(destination.id.uuidString)_\(alertType.rawValue)"
                
                do {
                    try await notificationService.scheduleLocationBasedNotification(
                        identifier: identifier,
                        title: "Destination \(alertType.displayName)",
                        body: "You are \(alertType.displayName.lowercased()) \(destination.name)",
                        coordinate: destination.coordinate,
                        radius: alertType.distance
                    )
                } catch {
                    print("Failed to setup destination alert: \(error)")
                }
            }
        }
    }
    
    // MARK: - Notification History Management
    @MainActor
    private func addNotificationToHistory(_ notification: TripNotification) async {
        notificationHistory.addNotification(notification)
        updateUnreadCount()
        saveNotificationHistory()
    }
    
    @MainActor
    private func addEmergencyNotificationToHistory(_ notification: EmergencyNotification) async {
        notificationHistory.addEmergencyNotification(notification)
        saveNotificationHistory()
    }
    
    func markNotificationAsRead(_ notificationId: UUID) {
        notificationHistory.markAsRead(notificationId)
        updateUnreadCount()
        saveNotificationHistory()
    }
    
    func clearEmergencyAlert() {
        hasEmergencyAlert = false
    }
    
    private func updateUnreadCount() {
        unreadCount = notificationHistory.notifications.filter { !$0.isRead }.count
    }
    
    // MARK: - Persistence
    private func loadNotificationHistory() {
        guard let data = UserDefaults.standard.data(forKey: "notification_history"),
              let history = try? JSONDecoder().decode(NotificationHistory.self, from: data) else {
            return
        }
        
        DispatchQueue.main.async {
            self.notificationHistory = history
            self.updateUnreadCount()
            self.hasEmergencyAlert = !history.emergencyNotifications.filter { !$0.isResolved }.isEmpty
        }
    }
    
    private func saveNotificationHistory() {
        guard let data = try? JSONEncoder().encode(notificationHistory) else { return }
        UserDefaults.standard.set(data, forKey: "notification_history")
    }
    
    // MARK: - Notification Preferences
    func updateNotificationPreferences(_ preferences: NotificationPreferences) async {
        do {
            try await notificationService.updateNotificationPreferences(preferences)
        } catch {
            print("Failed to update notification preferences: \(error)")
        }
    }
    
    func getNotificationPreferences() -> NotificationPreferences {
        return notificationService.getNotificationPreferences()
    }
    
    // MARK: - Permission Management
    func requestNotificationPermission() async -> Bool {
        do {
            return try await notificationService.requestNotificationPermission()
        } catch {
            print("Failed to request notification permission: \(error)")
            return false
        }
    }
    
    var notificationPermissionStatus: AnyPublisher<UNAuthorizationStatus, Never> {
        notificationService.notificationPermissionStatus
    }
}