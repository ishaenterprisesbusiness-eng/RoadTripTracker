import Foundation
import CoreLocation
import MapKit
import Combine

// MARK: - POI Service Implementation
class POIService: POIServiceProtocol {
    private let placesService: PlacesServiceProtocol
    private let notificationService: NotificationServiceProtocol
    private let tripService: TripServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    
    // Cache for POI data
    private var poiCache: [String: PointOfInterest] = [:]
    private var proposalsCache: [UUID: [POIProposal]] = [:]
    
    init(placesService: PlacesServiceProtocol, notificationService: NotificationServiceProtocol, tripService: TripServiceProtocol) {
        self.placesService = placesService
        self.notificationService = notificationService
        self.tripService = tripService
    }
    
    // MARK: - POI Discovery
    
    func discoverPOIsNearRoute(route: [CLLocationCoordinate2D], radius: CLLocationDistance, filter: POISearchFilter) async throws -> [PointOfInterest] {
        guard !route.isEmpty else {
            throw POIServiceError.invalidLocation
        }
        
        var allPOIs: [PointOfInterest] = []
        
        // Sample points along the route
        let samplePoints = sampleRoutePoints(route: route, maxPoints: 10)
        
        for point in samplePoints {
            do {
                let nearbyPOIs = try await discoverPOIsNearLocation(coordinate: point, radius: radius, filter: filter)
                allPOIs.append(contentsOf: nearbyPOIs)
            } catch {
                // Continue with other points if one fails
                continue
            }
        }
        
        // Remove duplicates and sort
        let uniquePOIs = removeDuplicatePOIs(allPOIs)
        return sortPOIs(uniquePOIs, by: filter.sortBy, referencePoint: route.first)
    }
    
    func discoverPOIsNearLocation(coordinate: CLLocationCoordinate2D, radius: CLLocationDistance, filter: POISearchFilter) async throws -> [PointOfInterest] {
        var allPOIs: [PointOfInterest] = []
        
        // Search for each category in the filter
        for category in filter.categories {
            do {
                let categoryPOIs = try await searchPOIsForCategory(category: category, coordinate: coordinate, radius: radius)
                allPOIs.append(contentsOf: categoryPOIs)
            } catch {
                // Continue with other categories if one fails
                continue
            }
        }
        
        // Apply filters
        let filteredPOIs = applyFilters(allPOIs, filter: filter, referencePoint: coordinate)
        
        // Sort results
        return sortPOIs(filteredPOIs, by: filter.sortBy, referencePoint: coordinate)
    }
    
    func searchPOIs(query: String, near coordinate: CLLocationCoordinate2D, filter: POISearchFilter) async throws -> [PointOfInterest] {
        let region = MKCoordinateRegion(
            center: coordinate,
            latitudinalMeters: filter.maxDistance ?? 10000,
            longitudinalMeters: filter.maxDistance ?? 10000
        )
        
        do {
            let searchResults = try await placesService.searchPlaces(query: query, region: region)
            let pois = searchResults.compactMap { result in
                convertSearchResultToPOI(result)
            }
            
            // Apply filters
            let filteredPOIs = applyFilters(pois, filter: filter, referencePoint: coordinate)
            
            // Sort results
            return sortPOIs(filteredPOIs, by: filter.sortBy, referencePoint: coordinate)
        } catch {
            throw POIServiceError.discoveryFailed(error.localizedDescription)
        }
    }
    
    // MARK: - POI Details
    
    func getPOIDetails(placeId: String) async throws -> PointOfInterest {
        // Check cache first
        if let cachedPOI = poiCache[placeId] {
            return cachedPOI
        }
        
        do {
            let placeDetails = try await placesService.getPlaceDetails(for: placeId)
            let poi = convertPlaceDetailsToPOI(placeDetails)
            
            // Cache the result
            poiCache[placeId] = poi
            
            return poi
        } catch {
            throw POIServiceError.detailsFailed(error.localizedDescription)
        }
    }
    
    func getPOIPhotos(placeId: String) async throws -> [URL] {
        let poi = try await getPOIDetails(placeId: placeId)
        return poi.photos ?? []
    }
    
    func getPOIReviews(placeId: String) async throws -> [POIReview] {
        let poi = try await getPOIDetails(placeId: placeId)
        return poi.reviews ?? []
    }
    
    // MARK: - POI Proposals
    
    func proposePOI(poi: PointOfInterest, for trip: Trip, insertionIndex: Int, message: String?) async throws -> POIProposal {
        guard insertionIndex >= 0 && insertionIndex <= trip.destinations.count else {
            throw POIServiceError.proposalFailed("Invalid insertion index")
        }
        
        let proposal = POIProposal(
            tripId: trip.id,
            proposedBy: trip.participants.first?.userId ?? UUID(), // Should be current user
            poi: poi,
            proposalMessage: message,
            proposedInsertionIndex: insertionIndex
        )
        
        // Add to cache
        if proposalsCache[trip.id] == nil {
            proposalsCache[trip.id] = []
        }
        proposalsCache[trip.id]?.append(proposal)
        
        // Send notification to all participants
        try await notifyParticipantsOfProposal(proposal: proposal, trip: trip)
        
        return proposal
    }
    
    func votePOIProposal(proposalId: UUID, participantId: UUID, vote: VoteType, comment: String?) async throws {
        // Find the proposal
        guard let tripProposals = proposalsCache.values.first(where: { proposals in
            proposals.contains { $0.id == proposalId }
        }),
              let proposalIndex = tripProposals.firstIndex(where: { $0.id == proposalId }) else {
            throw POIServiceError.votingFailed("Proposal not found")
        }
        
        let tripId = tripProposals[proposalIndex].tripId
        
        // Create vote
        let newVote = POIVote(participantId: participantId, vote: vote, comment: comment)
        
        // Update proposal with vote
        if var proposals = proposalsCache[tripId] {
            let proposalIndex = proposals.firstIndex { $0.id == proposalId }!
            
            // Remove existing vote from this participant if any
            proposals[proposalIndex].votes.removeAll { $0.participantId == participantId }
            
            // Add new vote
            proposals[proposalIndex].votes.append(newVote)
            
            proposalsCache[tripId] = proposals
            
            // Check if voting is complete
            _ = try await processPOIProposal(proposalId: proposalId)
        }
    }
    
    func getPOIProposals(for tripId: UUID) async throws -> [POIProposal] {
        return proposalsCache[tripId] ?? []
    }
    
    func processPOIProposal(proposalId: UUID) async throws -> POIProposalStatus {
        // Find the proposal
        guard let tripProposals = proposalsCache.values.first(where: { proposals in
            proposals.contains { $0.id == proposalId }
        }),
              let proposal = tripProposals.first(where: { $0.id == proposalId }) else {
            throw POIServiceError.proposalFailed("Proposal not found")
        }
        
        let trip = try await tripService.getTrip(id: proposal.tripId)
        let totalParticipants = trip.participants.count
        let totalVotes = proposal.votes.count
        
        // Check if all participants have voted or if majority reached
        let approveVotes = proposal.votes.filter { $0.vote == .approve }.count
        let rejectVotes = proposal.votes.filter { $0.vote == .reject }.count
        
        var newStatus: POIProposalStatus = .pending
        
        if totalVotes == totalParticipants {
            // All voted
            newStatus = approveVotes > rejectVotes ? .approved : .rejected
        } else if approveVotes > totalParticipants / 2 {
            // Majority approved
            newStatus = .approved
        } else if rejectVotes > totalParticipants / 2 {
            // Majority rejected
            newStatus = .rejected
        }
        
        // Update proposal status
        if var proposals = proposalsCache[proposal.tripId] {
            if let index = proposals.firstIndex(where: { $0.id == proposalId }) {
                proposals[index].status = newStatus
                proposals[index].decidedAt = Date()
                proposalsCache[proposal.tripId] = proposals
                
                // If approved, add POI to trip
                if newStatus == .approved {
                    let destination = Destination(
                        name: proposal.poi.name,
                        address: proposal.poi.address,
                        coordinate: proposal.poi.coordinate,
                        type: .attraction
                    )
                    
                    _ = try await tripService.addDestination(destination, to: trip, at: proposal.proposedInsertionIndex)
                }
                
                // Notify participants of decision
                try await notifyParticipantsOfDecision(proposal: proposals[index], trip: trip)
            }
        }
        
        return newStatus
    }
    
    // MARK: - POI Notifications
    
    func enablePOINotifications(for tripId: UUID, categories: Set<POICategory>) async throws {
        // Implementation would store notification preferences
        // For now, we'll just mark it as enabled
    }
    
    func disablePOINotifications(for tripId: UUID) async throws {
        // Implementation would disable notification preferences
    }
    
    func checkForNearbyPOIs(location: CLLocationCoordinate2D, tripId: UUID) async throws -> [PointOfInterest] {
        let filter = POISearchFilter(
            categories: [.nature, .history, .entertainment, .culture],
            maxDistance: 5000 // 5km radius
        )
        
        return try await discoverPOIsNearLocation(coordinate: location, radius: 5000, filter: filter)
    }
    
    // MARK: - POI Management
    
    func addPOIToTrip(poi: PointOfInterest, trip: Trip, insertionIndex: Int) async throws -> Trip {
        let destination = Destination(
            name: poi.name,
            address: poi.address,
            coordinate: poi.coordinate,
            plannedDuration: poi.estimatedVisitDuration,
            type: .attraction,
            notes: poi.description
        )
        
        return try await tripService.addDestination(destination, to: trip, at: insertionIndex)
    }
    
    func removePOIFromTrip(poiId: UUID, trip: Trip) async throws -> Trip {
        // Find destination that matches POI
        guard let destinationIndex = trip.destinations.firstIndex(where: { destination in
            destination.type == .attraction && destination.id.uuidString == poiId.uuidString
        }) else {
            throw POIServiceError.proposalFailed("POI not found in trip")
        }
        
        return try await tripService.removeDestination(at: destinationIndex, from: trip)
    }
    
    func updatePOIInTrip(poi: PointOfInterest, trip: Trip) async throws -> Trip {
        // Find and update the corresponding destination
        guard let destinationIndex = trip.destinations.firstIndex(where: { destination in
            destination.type == .attraction && destination.name == poi.name
        }) else {
            throw POIServiceError.proposalFailed("POI not found in trip")
        }
        
        var updatedTrip = trip
        updatedTrip.destinations[destinationIndex].name = poi.name
        updatedTrip.destinations[destinationIndex].address = poi.address
        updatedTrip.destinations[destinationIndex].coordinate = poi.coordinate
        updatedTrip.destinations[destinationIndex].plannedDuration = poi.estimatedVisitDuration
        updatedTrip.destinations[destinationIndex].notes = poi.description
        
        return try await tripService.updateTrip(updatedTrip)
    }
    
    // MARK: - Private Helper Methods
    
    private func sampleRoutePoints(route: [CLLocationCoordinate2D], maxPoints: Int) -> [CLLocationCoordinate2D] {
        guard route.count > maxPoints else { return route }
        
        let step = route.count / maxPoints
        var sampledPoints: [CLLocationCoordinate2D] = []
        
        for i in stride(from: 0, to: route.count, by: step) {
            sampledPoints.append(route[i])
        }
        
        return sampledPoints
    }
    
    private func searchPOIsForCategory(category: POICategory, coordinate: CLLocationCoordinate2D, radius: CLLocationDistance) async throws -> [PointOfInterest] {
        let placeCategory = mapPOICategoryToPlaceCategory(category)
        let searchResults = try await placesService.getNearbyPlaces(coordinate: coordinate, radius: radius, category: placeCategory)
        
        return searchResults.compactMap { result in
            convertSearchResultToPOI(result, preferredCategory: category)
        }
    }
    
    private func mapPOICategoryToPlaceCategory(_ poiCategory: POICategory) -> PlaceCategory {
        switch poiCategory {
        case .nature, .sports:
            return .attraction
        case .history, .culture, .entertainment:
            return .attraction
        case .shopping:
            return .shopping
        case .food:
            return .restaurant
        case .accommodation:
            return .hotel
        case .services:
            return .general
        case .other:
            return .general
        }
    }
    
    private func convertSearchResultToPOI(_ result: PlaceSearchResult, preferredCategory: POICategory? = nil) -> PointOfInterest {
        let category = preferredCategory ?? mapPlaceCategoryToPOICategory(result.category)
        
        return PointOfInterest(
            placeId: result.id,
            name: result.name,
            address: result.address,
            coordinate: result.coordinate,
            category: category,
            rating: result.rating,
            priceLevel: result.priceLevel,
            isOpen: result.isOpen
        )
    }
    
    private func mapPlaceCategoryToPOICategory(_ placeCategory: PlaceCategory) -> POICategory {
        switch placeCategory {
        case .restaurant:
            return .food
        case .gasStation:
            return .services
        case .hotel:
            return .accommodation
        case .attraction:
            return .entertainment
        case .shopping:
            return .shopping
        case .hospital, .bank, .pharmacy:
            return .services
        case .general:
            return .other
        }
    }
    
    private func convertPlaceDetailsToPOI(_ details: PlaceDetails) -> PointOfInterest {
        let category = mapPlaceCategoryToPOICategory(.general) // Would need more sophisticated mapping
        
        return PointOfInterest(
            placeId: details.id,
            name: details.name,
            address: details.address,
            coordinate: details.coordinate,
            category: category,
            rating: details.rating,
            priceLevel: details.priceLevel,
            phoneNumber: details.phoneNumber,
            website: details.website,
            openingHours: details.openingHours,
            photos: details.photos,
            reviews: details.reviews?.map { review in
                POIReview(
                    author: review.author,
                    rating: review.rating,
                    text: review.text,
                    timestamp: review.timestamp
                )
            }
        )
    }
    
    private func applyFilters(_ pois: [PointOfInterest], filter: POISearchFilter, referencePoint: CLLocationCoordinate2D) -> [PointOfInterest] {
        return pois.filter { poi in
            // Category filter
            if !filter.categories.contains(poi.category) {
                return false
            }
            
            // Rating filter
            if let minRating = filter.minRating,
               let rating = poi.rating,
               rating < minRating {
                return false
            }
            
            // Distance filter
            if let maxDistance = filter.maxDistance {
                let distance = CLLocation(latitude: referencePoint.latitude, longitude: referencePoint.longitude)
                    .distance(from: CLLocation(latitude: poi.coordinate.latitude, longitude: poi.coordinate.longitude))
                if distance > maxDistance {
                    return false
                }
            }
            
            // Price level filter
            if let priceLevel = filter.priceLevel,
               let poiPriceLevel = poi.priceLevel,
               poiPriceLevel > priceLevel {
                return false
            }
            
            // Open now filter
            if let isOpenNow = filter.isOpenNow,
               let poiIsOpen = poi.isOpen,
               isOpenNow && !poiIsOpen {
                return false
            }
            
            // Has photos filter
            if let hasPhotos = filter.hasPhotos,
               hasPhotos && (poi.photos?.isEmpty ?? true) {
                return false
            }
            
            return true
        }
    }
    
    private func sortPOIs(_ pois: [PointOfInterest], by sortOption: POISortOption, referencePoint: CLLocationCoordinate2D?) -> [PointOfInterest] {
        switch sortOption {
        case .distance:
            guard let referencePoint = referencePoint else { return pois }
            return pois.sorted { poi1, poi2 in
                let distance1 = CLLocation(latitude: referencePoint.latitude, longitude: referencePoint.longitude)
                    .distance(from: CLLocation(latitude: poi1.coordinate.latitude, longitude: poi1.coordinate.longitude))
                let distance2 = CLLocation(latitude: referencePoint.latitude, longitude: referencePoint.longitude)
                    .distance(from: CLLocation(latitude: poi2.coordinate.latitude, longitude: poi2.coordinate.longitude))
                return distance1 < distance2
            }
        case .rating:
            return pois.sorted { poi1, poi2 in
                let rating1 = poi1.rating ?? 0
                let rating2 = poi2.rating ?? 0
                return rating1 > rating2
            }
        case .name:
            return pois.sorted { $0.name < $1.name }
        case .popularity:
            // For now, use rating as popularity indicator
            return pois.sorted { poi1, poi2 in
                let rating1 = poi1.rating ?? 0
                let rating2 = poi2.rating ?? 0
                return rating1 > rating2
            }
        }
    }
    
    private func removeDuplicatePOIs(_ pois: [PointOfInterest]) -> [PointOfInterest] {
        var uniquePOIs: [PointOfInterest] = []
        var seenPlaceIds: Set<String> = []
        
        for poi in pois {
            if !seenPlaceIds.contains(poi.placeId) {
                uniquePOIs.append(poi)
                seenPlaceIds.insert(poi.placeId)
            }
        }
        
        return uniquePOIs
    }
    
    private func notifyParticipantsOfProposal(proposal: POIProposal, trip: Trip) async throws {
        let notification = Notification(
            id: UUID(),
            type: .poiProposal,
            title: "New POI Proposal",
            message: "\(proposal.poi.name) has been proposed as a stop",
            tripId: trip.id,
            senderId: proposal.proposedBy,
            timestamp: Date()
        )
        
        for participant in trip.participants {
            if participant.userId != proposal.proposedBy {
                try await notificationService.sendNotification(notification, to: participant.userId)
            }
        }
    }
    
    private func notifyParticipantsOfDecision(proposal: POIProposal, trip: Trip) async throws {
        let title = proposal.status == .approved ? "POI Approved" : "POI Rejected"
        let message = "\(proposal.poi.name) has been \(proposal.status.rawValue)"
        
        let notification = Notification(
            id: UUID(),
            type: .poiDecision,
            title: title,
            message: message,
            tripId: trip.id,
            senderId: nil,
            timestamp: Date()
        )
        
        for participant in trip.participants {
            try await notificationService.sendNotification(notification, to: participant.userId)
        }
    }
}