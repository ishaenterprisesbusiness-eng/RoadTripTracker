import Foundation
import CoreLocation
import Combine
import MapKit

// MARK: - Food Stop Service Implementation
class FoodStopService: FoodStopServiceProtocol {
    private let placesService: PlacesServiceProtocol
    private let notificationService: NotificationServiceProtocol
    private let routeManager: RouteManager
    
    private let foodStopSubject = PassthroughSubject<FoodStop, Never>()
    private let orderSubject = PassthroughSubject<FoodOrder, Never>()
    private let approachingNotificationSubject = PassthroughSubject<FoodStopApproachNotification, Never>()
    
    private var foodStops: [UUID: FoodStop] = [:]
    private var orders: [UUID: FoodOrder] = [:]
    private var monitoringTasks: [UUID: Task<Void, Never>] = [:]
    
    var foodStopUpdates: AnyPublisher<FoodStop, Never> {
        foodStopSubject.eraseToAnyPublisher()
    }
    
    var orderUpdates: AnyPublisher<FoodOrder, Never> {
        orderSubject.eraseToAnyPublisher()
    }
    
    var approachingFoodStopNotifications: AnyPublisher<FoodStopApproachNotification, Never> {
        approachingNotificationSubject.eraseToAnyPublisher()
    }
    
    init(placesService: PlacesServiceProtocol, notificationService: NotificationServiceProtocol, routeManager: RouteManager) {
        self.placesService = placesService
        self.notificationService = notificationService
        self.routeManager = routeManager
    }
    
    // MARK: - Restaurant Discovery
    
    func findNearbyRestaurants(coordinate: CLLocationCoordinate2D, radius: Double, cuisineFilter: CuisineType?) async throws -> [Restaurant] {
        let places = try await placesService.getNearbyPlaces(
            coordinate: coordinate,
            radius: radius,
            category: .restaurant
        )
        
        return places.compactMap { place in
            let restaurant = Restaurant(
                id: place.id,
                name: place.name,
                address: place.address,
                coordinate: place.coordinate,
                priceLevel: place.priceLevel,
                rating: place.rating,
                isOpenNow: place.isOpen
            )
            
            // Apply cuisine filter if specified
            if let filter = cuisineFilter {
                // In a real implementation, you'd determine cuisine from place data
                // For now, we'll include all restaurants
                return restaurant
            }
            
            return restaurant
        }
    }
    
    func findRestaurantsAlongRoute(route: [CLLocationCoordinate2D], searchRadius: Double, cuisineFilter: CuisineType?) async throws -> [Restaurant] {
        var allRestaurants: [Restaurant] = []
        
        // Search for restaurants along route points
        for coordinate in route {
            let restaurants = try await findNearbyRestaurants(
                coordinate: coordinate,
                radius: searchRadius,
                cuisineFilter: cuisineFilter
            )
            allRestaurants.append(contentsOf: restaurants)
        }
        
        // Remove duplicates and sort by distance from route
        let uniqueRestaurants = Dictionary(grouping: allRestaurants, by: { $0.id })
            .compactMapValues { $0.first }
            .values
            .map { restaurant in
                var updatedRestaurant = restaurant
                updatedRestaurant.distanceFromRoute = calculateMinDistanceFromRoute(restaurant.coordinate, route: route)
                return updatedRestaurant
            }
            .sorted { $0.distanceFromRoute ?? Double.infinity < $1.distanceFromRoute ?? Double.infinity }
        
        return Array(uniqueRestaurants)
    }
    
    func getRestaurantDetails(restaurantId: String) async throws -> Restaurant {
        // In a real implementation, this would fetch detailed restaurant information
        // For now, we'll return a basic restaurant object
        throw FoodStopServiceError.notImplemented
    }
    
    // MARK: - Food Stop Proposal and Approval
    
    func proposeFoodStop(restaurant: Restaurant, tripId: UUID, proposedBy: UUID, notes: String?) async throws -> FoodStop {
        let foodStop = FoodStop(
            tripId: tripId,
            proposedBy: proposedBy,
            restaurant: restaurant,
            notes: notes
        )
        
        foodStops[foodStop.id] = foodStop
        
        // Send notification to all trip participants
        let notification = PushNotification(
            recipientIds: [], // Will be populated with trip participant IDs
            title: "Food Stop Proposed",
            body: "\(restaurant.name) has been proposed as a food stop",
            data: [
                "type": "food_stop_proposal",
                "foodStopId": foodStop.id.uuidString,
                "tripId": tripId.uuidString
            ]
        )
        
        try await notificationService.sendPushNotification(notification)
        foodStopSubject.send(foodStop)
        
        return foodStop
    }
    
    func approveFoodStop(foodStopId: UUID, participantId: UUID) async throws {
        guard var foodStop = foodStops[foodStopId] else {
            throw FoodStopServiceError.foodStopNotFound
        }
        
        // Add approval if not already approved
        if !foodStop.approvals.contains(participantId) {
            foodStop.approvals.append(participantId)
            
            // Remove from rejections if previously rejected
            foodStop.rejections.removeAll { $0 == participantId }
            
            // Check if majority approved (simple majority for now)
            if foodStop.approvals.count >= 2 { // Simplified threshold
                foodStop.proposalStatus = .approved
                
                // Add to route as waypoint
                try await addFoodStopToRoute(foodStop)
                
                // Send approval notification
                let notification = PushNotification(
                    recipientIds: [],
                    title: "Food Stop Approved",
                    body: "The group has approved the food stop at \(foodStop.restaurant.name)",
                    data: [
                        "type": "food_stop_approved",
                        "foodStopId": foodStopId.uuidString
                    ]
                )
                
                try await notificationService.sendPushNotification(notification)
            }
            
            foodStops[foodStopId] = foodStop
            foodStopSubject.send(foodStop)
        }
    }
    
    func rejectFoodStop(foodStopId: UUID, participantId: UUID, reason: String?) async throws {
        guard var foodStop = foodStops[foodStopId] else {
            throw FoodStopServiceError.foodStopNotFound
        }
        
        // Add rejection if not already rejected
        if !foodStop.rejections.contains(participantId) {
            foodStop.rejections.append(participantId)
            
            // Remove from approvals if previously approved
            foodStop.approvals.removeAll { $0 == participantId }
            
            // Check if majority rejected
            if foodStop.rejections.count >= 2 { // Simplified threshold
                foodStop.proposalStatus = .rejected
                
                let notification = PushNotification(
                    recipientIds: [],
                    title: "Food Stop Rejected",
                    body: "The group has rejected the food stop at \(foodStop.restaurant.name)",
                    data: [
                        "type": "food_stop_rejected",
                        "foodStopId": foodStopId.uuidString
                    ]
                )
                
                try await notificationService.sendPushNotification(notification)
            }
            
            foodStops[foodStopId] = foodStop
            foodStopSubject.send(foodStop)
        }
    }
    
    // MARK: - Order Management
    
    func placeOrder(foodStopId: UUID, participantId: UUID, items: [OrderItem], specialInstructions: String?) async throws -> FoodOrder {
        guard var foodStop = foodStops[foodStopId] else {
            throw FoodStopServiceError.foodStopNotFound
        }
        
        // Remove existing order for this participant if any
        foodStop.orders.removeAll { $0.participantId == participantId }
        
        // Create new order
        let order = FoodOrder(
            participantId: participantId,
            orderStatus: .placed,
            items: items,
            totalCost: items.reduce(0) { $0 + ($1.price ?? 0) * Double($1.quantity) },
            specialInstructions: specialInstructions,
            estimatedReadyTime: Date().addingTimeInterval(foodStop.estimatedWaitTime ?? 1800) // Default 30 minutes
        )
        
        foodStop.orders.append(order)
        orders[order.id] = order
        
        // Update food stop status to active if first order
        if foodStop.proposalStatus == .approved && foodStop.actualArrivalTime == nil {
            foodStop.proposalStatus = .active
            foodStop.actualArrivalTime = Date()
        }
        
        foodStops[foodStopId] = foodStop
        foodStopSubject.send(foodStop)
        orderSubject.send(order)
        
        // Send order confirmation notification
        let notification = PushNotification(
            recipientIds: [participantId],
            title: "Order Placed",
            body: "Your order at \(foodStop.restaurant.name) has been placed",
            data: [
                "type": "order_placed",
                "orderId": order.id.uuidString,
                "foodStopId": foodStopId.uuidString
            ]
        )
        
        try await notificationService.sendPushNotification(notification)
        
        return order
    }
    
    func updateOrderStatus(orderId: UUID, status: OrderStatus, estimatedReadyTime: Date?) async throws {
        guard var order = orders[orderId] else {
            throw FoodStopServiceError.orderNotFound
        }
        
        order.orderStatus = status
        if let readyTime = estimatedReadyTime {
            order.estimatedReadyTime = readyTime
        }
        
        if status == .ready {
            order.actualReadyTime = Date()
        }
        
        orders[orderId] = order
        orderSubject.send(order)
        
        // Update the order in the food stop as well
        if let foodStopId = foodStops.first(where: { $0.value.orders.contains { $0.id == orderId } })?.key {
            var foodStop = foodStops[foodStopId]!
            if let orderIndex = foodStop.orders.firstIndex(where: { $0.id == orderId }) {
                foodStop.orders[orderIndex] = order
                foodStops[foodStopId] = foodStop
                foodStopSubject.send(foodStop)
            }
        }
        
        // Send status update notification
        if status == .ready {
            let notification = PushNotification(
                recipientIds: [order.participantId],
                title: "Order Ready",
                body: "Your order is ready for pickup!",
                data: [
                    "type": "order_ready",
                    "orderId": orderId.uuidString
                ]
            )
            
            try await notificationService.sendPushNotification(notification)
        }
    }
    
    func markOrderReady(orderId: UUID) async throws {
        try await updateOrderStatus(orderId: orderId, status: .ready, estimatedReadyTime: nil)
    }
    
    func markReadyToContinue(foodStopId: UUID, participantId: UUID) async throws {
        guard var foodStop = foodStops[foodStopId] else {
            throw FoodStopServiceError.foodStopNotFound
        }
        
        // Find and update the participant's order
        if let orderIndex = foodStop.orders.firstIndex(where: { $0.participantId == participantId }) {
            foodStop.orders[orderIndex].isReadyToContinue = true
            
            // Update the order in the orders dictionary as well
            let orderId = foodStop.orders[orderIndex].id
            orders[orderId]?.isReadyToContinue = true
            
            // Check if all participants are ready
            let allReady = foodStop.orders.allSatisfy { $0.isReadyToContinue }
            
            if allReady && !foodStop.orders.isEmpty {
                foodStop.proposalStatus = .completed
                
                let notification = PushNotification(
                    recipientIds: [],
                    title: "Ready to Continue",
                    body: "All participants are ready to continue from \(foodStop.restaurant.name)",
                    data: [
                        "type": "food_stop_ready",
                        "foodStopId": foodStopId.uuidString
                    ]
                )
                
                try await notificationService.sendPushNotification(notification)
            }
            
            foodStops[foodStopId] = foodStop
            foodStopSubject.send(foodStop)
        }
    }
    
    func cancelFoodStop(foodStopId: UUID, cancelledBy: UUID, reason: String?) async throws {
        guard var foodStop = foodStops[foodStopId] else {
            throw FoodStopServiceError.foodStopNotFound
        }
        
        foodStop.proposalStatus = .cancelled
        foodStop.notes = reason
        
        // Cancel all orders
        for order in foodStop.orders {
            var cancelledOrder = order
            cancelledOrder.orderStatus = .cancelled
            orders[order.id] = cancelledOrder
            orderSubject.send(cancelledOrder)
        }
        
        foodStops[foodStopId] = foodStop
        foodStopSubject.send(foodStop)
        
        let notification = PushNotification(
            recipientIds: [],
            title: "Food Stop Cancelled",
            body: "The food stop at \(foodStop.restaurant.name) has been cancelled",
            data: [
                "type": "food_stop_cancelled",
                "foodStopId": foodStopId.uuidString
            ]
        )
        
        try await notificationService.sendPushNotification(notification)
    }
    
    // MARK: - Data Retrieval
    
    func getFoodStopsForTrip(tripId: UUID) async throws -> [FoodStop] {
        return foodStops.values.filter { $0.tripId == tripId }
    }
    
    func getActiveFoodStop(tripId: UUID) async throws -> FoodStop? {
        return foodStops.values.first { $0.tripId == tripId && $0.proposalStatus == .active }
    }
    
    // MARK: - Route Integration
    
    func addFoodStopToRoute(foodStop: FoodStop) async throws {
        // Create a destination for the food stop
        let destination = Destination(
            name: foodStop.restaurant.name,
            address: foodStop.restaurant.address,
            coordinate: foodStop.restaurant.coordinate,
            type: .food,
            notes: foodStop.notes
        )
        
        // Add to route via RouteManager
        try await routeManager.addWaypoint(destination)
    }
    
    // MARK: - Additional Services
    
    func getEstimatedWaitTime(restaurantId: String) async throws -> TimeInterval? {
        // In a real implementation, this would query restaurant APIs or historical data
        // For now, return a default estimate based on restaurant type
        return 1800 // 30 minutes default
    }
    
    func getParkingInformation(restaurantId: String) async throws -> ParkingInfo? {
        // In a real implementation, this would fetch parking data from various sources
        // For now, return default parking info
        return ParkingInfo(
            hasParking: true,
            parkingType: .lot,
            parkingCost: .free,
            maxVehicleSize: .large,
            notes: "Large parking lot available"
        )
    }
    
    // MARK: - Approach Monitoring
    
    func monitorApproachingFoodStops(tripId: UUID, participantLocation: CLLocationCoordinate2D) async throws {
        // Cancel existing monitoring for this trip
        monitoringTasks[tripId]?.cancel()
        
        // Start new monitoring task
        monitoringTasks[tripId] = Task {
            while !Task.isCancelled {
                let activeFoodStops = foodStops.values.filter { 
                    $0.tripId == tripId && ($0.proposalStatus == .approved || $0.proposalStatus == .active)
                }
                
                for foodStop in activeFoodStops {
                    let distance = CLLocation(latitude: participantLocation.latitude, longitude: participantLocation.longitude)
                        .distance(from: CLLocation(latitude: foodStop.restaurant.coordinate.latitude, longitude: foodStop.restaurant.coordinate.longitude))
                    
                    // Check if approaching (within 5km)
                    if distance <= 5000 {
                        let parkingInfo = try? await getParkingInformation(restaurantId: foodStop.restaurant.id)
                        
                        let notification = FoodStopApproachNotification(
                            foodStopId: foodStop.id,
                            participantId: UUID(), // Would be actual participant ID
                            restaurant: foodStop.restaurant,
                            distanceToStop: distance,
                            estimatedArrivalTime: distance / 60 * 1000, // Rough estimate
                            notificationType: distance <= 500 ? .arrived : .approaching,
                            parkingInfo: parkingInfo
                        )
                        
                        approachingNotificationSubject.send(notification)
                        
                        // Send local notification with parking info
                        var notificationBody = "You are \(Int(distance))m from \(foodStop.restaurant.name)"
                        if let parking = parkingInfo, parking.hasParking {
                            notificationBody += ". \(parking.parkingType.displayName) available"
                        }
                        
                        let localNotification = LocalNotification(
                            identifier: "food_stop_approach_\(foodStop.id)",
                            title: notification.notificationType.displayMessage,
                            body: notificationBody
                        )
                        
                        try? await notificationService.scheduleLocalNotification(localNotification)
                    }
                }
                
                // Wait 30 seconds before next check
                try? await Task.sleep(nanoseconds: 30_000_000_000)
            }
        }
    }
    
    // MARK: - Private Helper Methods
    
    private func calculateMinDistanceFromRoute(_ point: CLLocationCoordinate2D, route: [CLLocationCoordinate2D]) -> CLLocationDistance {
        let pointLocation = CLLocation(latitude: point.latitude, longitude: point.longitude)
        
        return route.map { routePoint in
            let routeLocation = CLLocation(latitude: routePoint.latitude, longitude: routePoint.longitude)
            return pointLocation.distance(from: routeLocation)
        }.min() ?? Double.infinity
    }
}

// MARK: - Food Stop Service Error
enum FoodStopServiceError: LocalizedError {
    case foodStopNotFound
    case orderNotFound
    case invalidProposal
    case alreadyApproved
    case alreadyRejected
    case notAuthorized
    case routeUpdateFailed
    case notImplemented
    
    var errorDescription: String? {
        switch self {
        case .foodStopNotFound:
            return "Food stop not found"
        case .orderNotFound:
            return "Order not found"
        case .invalidProposal:
            return "Invalid food stop proposal"
        case .alreadyApproved:
            return "Food stop already approved"
        case .alreadyRejected:
            return "Food stop already rejected"
        case .notAuthorized:
            return "Not authorized to perform this action"
        case .routeUpdateFailed:
            return "Failed to update route with food stop"
        case .notImplemented:
            return "Feature not implemented"
        }
    }
}