import Foundation
import CoreLocation
import Combine
import MapKit

// MARK: - Fuel Stop Service Implementation
class FuelStopService: FuelStopServiceProtocol {
    private let placesService: PlacesServiceProtocol
    private let notificationService: NotificationServiceProtocol
    private let routeManager: RouteManager
    
    private let fuelStopSubject = PassthroughSubject<FuelStop, Never>()
    private let approachingNotificationSubject = PassthroughSubject<FuelStopApproachNotification, Never>()
    
    private var fuelStops: [UUID: FuelStop] = [:]
    private var monitoringTasks: [UUID: Task<Void, Never>] = [:]
    
    var fuelStopUpdates: AnyPublisher<FuelStop, Never> {
        fuelStopSubject.eraseToAnyPublisher()
    }
    
    var approachingFuelStopNotifications: AnyPublisher<FuelStopApproachNotification, Never> {
        approachingNotificationSubject.eraseToAnyPublisher()
    }
    
    init(placesService: PlacesServiceProtocol, notificationService: NotificationServiceProtocol, routeManager: RouteManager) {
        self.placesService = placesService
        self.notificationService = notificationService
        self.routeManager = routeManager
    }
    
    // MARK: - Gas Station Discovery
    
    func findNearbyGasStations(coordinate: CLLocationCoordinate2D, radius: Double) async throws -> [GasStation] {
        let places = try await placesService.getNearbyPlaces(
            coordinate: coordinate,
            radius: radius,
            category: .gasStation
        )
        
        return places.map { place in
            GasStation(
                id: place.id,
                name: place.name,
                address: place.address,
                coordinate: place.coordinate,
                isOpen24Hours: place.isOpen ?? false,
                rating: place.rating
            )
        }
    }
    
    func findGasStationsAlongRoute(route: [CLLocationCoordinate2D], searchRadius: Double) async throws -> [GasStation] {
        var allGasStations: [GasStation] = []
        
        // Search for gas stations along route points
        for coordinate in route {
            let gasStations = try await findNearbyGasStations(coordinate: coordinate, radius: searchRadius)
            allGasStations.append(contentsOf: gasStations)
        }
        
        // Remove duplicates and sort by distance from route
        let uniqueStations = Dictionary(grouping: allGasStations, by: { $0.id })
            .compactMapValues { $0.first }
            .values
            .map { station in
                var updatedStation = station
                updatedStation.distanceFromRoute = calculateMinDistanceFromRoute(station.coordinate, route: route)
                return updatedStation
            }
            .sorted { $0.distanceFromRoute ?? Double.infinity < $1.distanceFromRoute ?? Double.infinity }
        
        return Array(uniqueStations)
    }
    
    // MARK: - Fuel Stop Proposal and Approval
    
    func proposeFuelStop(gasStation: GasStation, tripId: UUID, proposedBy: UUID, notes: String?) async throws -> FuelStop {
        let fuelStop = FuelStop(
            tripId: tripId,
            proposedBy: proposedBy,
            gasStation: gasStation,
            notes: notes
        )
        
        fuelStops[fuelStop.id] = fuelStop
        
        // Send notification to all trip participants
        let notification = PushNotification(
            recipientIds: [], // Will be populated with trip participant IDs
            title: "Fuel Stop Proposed",
            body: "\(gasStation.name) has been proposed as a fuel stop",
            data: [
                "type": "fuel_stop_proposal",
                "fuelStopId": fuelStop.id.uuidString,
                "tripId": tripId.uuidString
            ]
        )
        
        try await notificationService.sendPushNotification(notification)
        fuelStopSubject.send(fuelStop)
        
        return fuelStop
    }
    
    func approveFuelStop(fuelStopId: UUID, participantId: UUID) async throws {
        guard var fuelStop = fuelStops[fuelStopId] else {
            throw FuelStopServiceError.fuelStopNotFound
        }
        
        // Add approval if not already approved
        if !fuelStop.approvals.contains(participantId) {
            fuelStop.approvals.append(participantId)
            
            // Remove from rejections if previously rejected
            fuelStop.rejections.removeAll { $0 == participantId }
            
            // Check if majority approved (simple majority for now)
            // In a real implementation, you'd get the actual participant count
            if fuelStop.approvals.count >= 2 { // Simplified threshold
                fuelStop.proposalStatus = .approved
                
                // Add to route as waypoint
                try await addFuelStopToRoute(fuelStop)
                
                // Send approval notification
                let notification = PushNotification(
                    recipientIds: [],
                    title: "Fuel Stop Approved",
                    body: "The group has approved the fuel stop at \(fuelStop.gasStation.name)",
                    data: [
                        "type": "fuel_stop_approved",
                        "fuelStopId": fuelStopId.uuidString
                    ]
                )
                
                try await notificationService.sendPushNotification(notification)
            }
            
            fuelStops[fuelStopId] = fuelStop
            fuelStopSubject.send(fuelStop)
        }
    }
    
    func rejectFuelStop(fuelStopId: UUID, participantId: UUID, reason: String?) async throws {
        guard var fuelStop = fuelStops[fuelStopId] else {
            throw FuelStopServiceError.fuelStopNotFound
        }
        
        // Add rejection if not already rejected
        if !fuelStop.rejections.contains(participantId) {
            fuelStop.rejections.append(participantId)
            
            // Remove from approvals if previously approved
            fuelStop.approvals.removeAll { $0 == participantId }
            
            // Check if majority rejected
            if fuelStop.rejections.count >= 2 { // Simplified threshold
                fuelStop.proposalStatus = .rejected
                
                let notification = PushNotification(
                    recipientIds: [],
                    title: "Fuel Stop Rejected",
                    body: "The group has rejected the fuel stop at \(fuelStop.gasStation.name)",
                    data: [
                        "type": "fuel_stop_rejected",
                        "fuelStopId": fuelStopId.uuidString
                    ]
                )
                
                try await notificationService.sendPushNotification(notification)
            }
            
            fuelStops[fuelStopId] = fuelStop
            fuelStopSubject.send(fuelStop)
        }
    }
    
    // MARK: - Check-in System
    
    func checkInAtFuelStop(fuelStopId: UUID, participantId: UUID, fuelAmount: Double?, fuelCost: Double?, notes: String?) async throws {
        guard var fuelStop = fuelStops[fuelStopId] else {
            throw FuelStopServiceError.fuelStopNotFound
        }
        
        // Remove existing check-in for this participant if any
        fuelStop.checkIns.removeAll { $0.participantId == participantId }
        
        // Add new check-in
        let checkIn = FuelStopCheckIn(
            participantId: participantId,
            fuelAmount: fuelAmount,
            fuelCost: fuelCost,
            notes: notes
        )
        
        fuelStop.checkIns.append(checkIn)
        
        // Update status to active if first check-in
        if fuelStop.proposalStatus == .approved && fuelStop.actualArrivalTime == nil {
            fuelStop.proposalStatus = .active
            fuelStop.actualArrivalTime = Date()
        }
        
        fuelStops[fuelStopId] = fuelStop
        fuelStopSubject.send(fuelStop)
        
        // Send check-in notification
        let notification = PushNotification(
            recipientIds: [],
            title: "Participant Checked In",
            body: "A participant has checked in at \(fuelStop.gasStation.name)",
            data: [
                "type": "fuel_stop_checkin",
                "fuelStopId": fuelStopId.uuidString
            ]
        )
        
        try await notificationService.sendPushNotification(notification)
    }
    
    func markReadyToContinue(fuelStopId: UUID, participantId: UUID) async throws {
        guard var fuelStop = fuelStops[fuelStopId] else {
            throw FuelStopServiceError.fuelStopNotFound
        }
        
        // Find and update the participant's check-in
        if let index = fuelStop.checkIns.firstIndex(where: { $0.participantId == participantId }) {
            fuelStop.checkIns[index].isReadyToContinue = true
            
            // Check if all participants are ready
            let allReady = fuelStop.checkIns.allSatisfy { $0.isReadyToContinue }
            
            if allReady && !fuelStop.checkIns.isEmpty {
                fuelStop.proposalStatus = .completed
                
                let notification = PushNotification(
                    recipientIds: [],
                    title: "Ready to Continue",
                    body: "All participants are ready to continue from \(fuelStop.gasStation.name)",
                    data: [
                        "type": "fuel_stop_ready",
                        "fuelStopId": fuelStopId.uuidString
                    ]
                )
                
                try await notificationService.sendPushNotification(notification)
            }
            
            fuelStops[fuelStopId] = fuelStop
            fuelStopSubject.send(fuelStop)
        }
    }
    
    func cancelFuelStop(fuelStopId: UUID, cancelledBy: UUID, reason: String?) async throws {
        guard var fuelStop = fuelStops[fuelStopId] else {
            throw FuelStopServiceError.fuelStopNotFound
        }
        
        fuelStop.proposalStatus = .cancelled
        fuelStop.notes = reason
        
        fuelStops[fuelStopId] = fuelStop
        fuelStopSubject.send(fuelStop)
        
        let notification = PushNotification(
            recipientIds: [],
            title: "Fuel Stop Cancelled",
            body: "The fuel stop at \(fuelStop.gasStation.name) has been cancelled",
            data: [
                "type": "fuel_stop_cancelled",
                "fuelStopId": fuelStopId.uuidString
            ]
        )
        
        try await notificationService.sendPushNotification(notification)
    }
    
    // MARK: - Data Retrieval
    
    func getFuelStopsForTrip(tripId: UUID) async throws -> [FuelStop] {
        return fuelStops.values.filter { $0.tripId == tripId }
    }
    
    func getActiveFuelStop(tripId: UUID) async throws -> FuelStop? {
        return fuelStops.values.first { $0.tripId == tripId && $0.proposalStatus == .active }
    }
    
    // MARK: - Route Integration
    
    func addFuelStopToRoute(fuelStop: FuelStop) async throws {
        // Create a destination for the fuel stop
        let destination = Destination(
            name: fuelStop.gasStation.name,
            address: fuelStop.gasStation.address,
            coordinate: fuelStop.gasStation.coordinate,
            type: .fuel,
            notes: fuelStop.notes
        )
        
        // Add to route via RouteManager
        try await routeManager.addWaypoint(destination)
    }
    
    // MARK: - Approach Monitoring
    
    func monitorApproachingFuelStops(tripId: UUID, participantLocation: CLLocationCoordinate2D) async throws {
        // Cancel existing monitoring for this trip
        monitoringTasks[tripId]?.cancel()
        
        // Start new monitoring task
        monitoringTasks[tripId] = Task {
            while !Task.isCancelled {
                let activeFuelStops = fuelStops.values.filter { 
                    $0.tripId == tripId && ($0.proposalStatus == .approved || $0.proposalStatus == .active)
                }
                
                for fuelStop in activeFuelStops {
                    let distance = CLLocation(latitude: participantLocation.latitude, longitude: participantLocation.longitude)
                        .distance(from: CLLocation(latitude: fuelStop.gasStation.coordinate.latitude, longitude: fuelStop.gasStation.coordinate.longitude))
                    
                    // Check if approaching (within 5km)
                    if distance <= 5000 {
                        let notification = FuelStopApproachNotification(
                            fuelStopId: fuelStop.id,
                            participantId: UUID(), // Would be actual participant ID
                            gasStation: fuelStop.gasStation,
                            distanceToStop: distance,
                            estimatedArrivalTime: distance / 60 * 1000, // Rough estimate
                            notificationType: distance <= 500 ? .arrived : .approaching
                        )
                        
                        approachingNotificationSubject.send(notification)
                        
                        // Send local notification
                        let localNotification = LocalNotification(
                            identifier: "fuel_stop_approach_\(fuelStop.id)",
                            title: notification.notificationType.displayMessage,
                            body: "You are \(Int(distance))m from \(fuelStop.gasStation.name)"
                        )
                        
                        try? await notificationService.scheduleLocalNotification(localNotification)
                    }
                }
                
                // Wait 30 seconds before next check
                try? await Task.sleep(nanoseconds: 30_000_000_000)
            }
        }
    }
    
    // MARK: - Private Helper Methods
    
    private func calculateMinDistanceFromRoute(_ point: CLLocationCoordinate2D, route: [CLLocationCoordinate2D]) -> CLLocationDistance {
        let pointLocation = CLLocation(latitude: point.latitude, longitude: point.longitude)
        
        return route.map { routePoint in
            let routeLocation = CLLocation(latitude: routePoint.latitude, longitude: routePoint.longitude)
            return pointLocation.distance(from: routeLocation)
        }.min() ?? Double.infinity
    }
}

// MARK: - Fuel Stop Service Error
enum FuelStopServiceError: LocalizedError {
    case fuelStopNotFound
    case invalidProposal
    case alreadyApproved
    case alreadyRejected
    case notAuthorized
    case routeUpdateFailed
    
    var errorDescription: String? {
        switch self {
        case .fuelStopNotFound:
            return "Fuel stop not found"
        case .invalidProposal:
            return "Invalid fuel stop proposal"
        case .alreadyApproved:
            return "Fuel stop already approved"
        case .alreadyRejected:
            return "Fuel stop already rejected"
        case .notAuthorized:
            return "Not authorized to perform this action"
        case .routeUpdateFailed:
            return "Failed to update route with fuel stop"
        }
    }
}