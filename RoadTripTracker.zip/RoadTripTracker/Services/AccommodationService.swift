import Foundation
import CoreLocation
import MapKit

// MARK: - Accommodation Service Implementation
class AccommodationService: AccommodationServiceProtocol {
    private let placesService: PlacesServiceProtocol
    private let distanceCalculationService: DistanceCalculationService
    
    init(placesService: PlacesServiceProtocol = PlacesService(), distanceCalculationService: DistanceCalculationService = DistanceCalculationService()) {
        self.placesService = placesService
        self.distanceCalculationService = distanceCalculationService
    }
    
    // MARK: - Public Methods
    
    func searchAccommodations(near coordinate: CLLocationCoordinate2D, radius: Double, filters: AccommodationSearchFilters) async throws -> [Accommodation] {
        var allAccommodations: [Accommodation] = []
        
        // Search for different accommodation types
        for accommodationType in filters.types {
            do {
                let places = try await searchAccommodationType(accommodationType, near: coordinate, radius: radius)
                let accommodations = places.compactMap { place in
                    createAccommodation(from: place, type: accommodationType, referenceLocation: coordinate)
                }
                allAccommodations.append(contentsOf: accommodations)
            } catch {
                // Continue searching other types even if one fails
                print("Failed to search for \(accommodationType.displayName): \(error)")
            }
        }
        
        // Apply filters
        let filteredAccommodations = applyFilters(accommodations: allAccommodations, filters: filters)
        
        // Sort by distance
        return filteredAccommodations.sorted { accommodation1, accommodation2 in
            guard let distance1 = accommodation1.distance,
                  let distance2 = accommodation2.distance else {
                return false
            }
            return distance1 < distance2
        }
    }
    
    func searchAccommodationsAlongRoute(route: [CLLocationCoordinate2D], filters: AccommodationSearchFilters) async throws -> [Accommodation] {
        guard !route.isEmpty else {
            throw AccommodationServiceError.invalidLocation
        }
        
        var allAccommodations: [Accommodation] = []
        let searchRadius = filters.maxDistance ?? 10.0 // Default 10km radius
        
        // Search along route points (sample every 50km or so)
        let sampleDistance: Double = 50000 // 50km in meters
        var searchPoints: [CLLocationCoordinate2D] = []
        
        if route.count <= 5 {
            // For short routes, search at all points
            searchPoints = route
        } else {
            // For longer routes, sample points
            searchPoints.append(route.first!)
            
            var currentDistance: Double = 0
            var lastSampleIndex = 0
            
            for i in 1..<route.count {
                let distance = CLLocation(latitude: route[i-1].latitude, longitude: route[i-1].longitude)
                    .distance(from: CLLocation(latitude: route[i].latitude, longitude: route[i].longitude))
                currentDistance += distance
                
                if currentDistance >= sampleDistance {
                    searchPoints.append(route[i])
                    currentDistance = 0
                    lastSampleIndex = i
                }
            }
            
            // Always include the last point
            if lastSampleIndex < route.count - 1 {
                searchPoints.append(route.last!)
            }
        }
        
        // Search accommodations near each sample point
        for point in searchPoints {
            do {
                let accommodations = try await searchAccommodations(near: point, radius: searchRadius * 1000, filters: filters)
                allAccommodations.append(contentsOf: accommodations)
            } catch {
                print("Failed to search accommodations near \(point): \(error)")
            }
        }
        
        // Remove duplicates based on ID
        let uniqueAccommodations = Array(Set(allAccommodations.map { $0.id }))
            .compactMap { id in allAccommodations.first { $0.id == id } }
        
        return uniqueAccommodations
    }
    
    func getAccommodationDetails(accommodationId: String) async throws -> Accommodation {
        // In a real implementation, this would fetch detailed information from an API
        // For now, we'll throw an error indicating this needs external API integration
        throw AccommodationServiceError.accommodationNotFound
    }
    
    func checkAvailability(accommodationId: String, checkIn: Date, checkOut: Date, guests: Int) async throws -> AccommodationAvailability {
        // Validate date range
        guard checkIn < checkOut else {
            throw AccommodationServiceError.invalidDateRange
        }
        
        // In a real implementation, this would check with booking APIs
        // For now, return mock availability
        return AccommodationAvailability(
            isAvailable: Bool.random(),
            availableRooms: Int.random(in: 1...10),
            pricePerNight: Double.random(in: 50...300),
            currency: "USD",
            checkInDate: checkIn,
            checkOutDate: checkOut
        )
    }
    
    func getBookingInfo(accommodationId: String) async throws -> AccommodationBookingInfo {
        // In a real implementation, this would fetch booking information from APIs
        // For now, return mock booking info
        let mockPlatforms = [
            BookingPlatform(id: "booking", name: "Booking.com", url: URL(string: "https://booking.com")!, price: 120.0),
            BookingPlatform(id: "expedia", name: "Expedia", url: URL(string: "https://expedia.com")!, price: 125.0),
            BookingPlatform(id: "hotels", name: "Hotels.com", url: URL(string: "https://hotels.com")!, price: 118.0)
        ]
        
        return AccommodationBookingInfo(
            accommodationId: accommodationId,
            bookingURL: URL(string: "https://booking.com"),
            phoneNumber: "+1-555-0123",
            bookingPlatforms: mockPlatforms,
            directBookingAvailable: true,
            cancellationPolicy: "Free cancellation up to 24 hours before check-in",
            paymentMethods: [.creditCard, .debitCard, .paypal, .applePay]
        )
    }
    
    func addAccommodationToTrip(accommodation: Accommodation, trip: Trip) async throws -> Trip {
        var updatedTrip = trip
        
        // Create destination from accommodation
        let destination = Destination(
            name: accommodation.name,
            address: accommodation.address,
            coordinate: accommodation.coordinate,
            type: .accommodation,
            notes: "Accommodation: \(accommodation.type.displayName)"
        )
        
        // Add to destinations
        updatedTrip.destinations.append(destination)
        
        return updatedTrip
    }
    
    // MARK: - Private Methods
    
    private func searchAccommodationType(_ type: AccommodationType, near coordinate: CLLocationCoordinate2D, radius: Double) async throws -> [PlaceSearchResult] {
        let searchQuery = getSearchQuery(for: type)
        
        // Use MapKit local search
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = searchQuery
        request.region = MKCoordinateRegion(
            center: coordinate,
            latitudinalMeters: radius * 2,
            longitudinalMeters: radius * 2
        )
        
        let search = MKLocalSearch(request: request)
        
        do {
            let response = try await search.start()
            
            return response.mapItems.compactMap { mapItem in
                guard let name = mapItem.name,
                      let placemark = mapItem.placemark.location?.coordinate else {
                    return nil
                }
                
                let address = formatAddress(from: mapItem.placemark)
                
                return PlaceSearchResult(
                    id: mapItem.placemark.description,
                    name: name,
                    address: address,
                    coordinate: placemark,
                    category: .hotel // We'll determine the specific type later
                )
            }
        } catch {
            throw AccommodationServiceError.searchFailed(error.localizedDescription)
        }
    }
    
    private func getSearchQuery(for type: AccommodationType) -> String {
        switch type {
        case .hotel:
            return "hotel"
        case .motel:
            return "motel"
        case .resort:
            return "resort"
        case .bedAndBreakfast:
            return "bed and breakfast"
        case .hostel:
            return "hostel"
        case .campground:
            return "campground camping"
        case .rvPark:
            return "RV park"
        case .vacation_rental:
            return "vacation rental"
        case .cabin:
            return "cabin lodge"
        case .lodge:
            return "lodge"
        }
    }
    
    private func createAccommodation(from place: PlaceSearchResult, type: AccommodationType, referenceLocation: CLLocationCoordinate2D) -> Accommodation {
        let distance = CLLocation(latitude: referenceLocation.latitude, longitude: referenceLocation.longitude)
            .distance(from: CLLocation(latitude: place.coordinate.latitude, longitude: place.coordinate.longitude)) / 1000.0 // Convert to km
        
        // Generate mock data for demonstration
        let amenities = generateMockAmenities(for: type)
        let priceRange = generateMockPriceRange()
        let rating = Double.random(in: 3.0...5.0)
        
        return Accommodation(
            id: place.id,
            name: place.name,
            address: place.address,
            coordinate: place.coordinate,
            type: type,
            rating: rating,
            priceRange: priceRange,
            amenities: amenities,
            phoneNumber: generateMockPhoneNumber(),
            website: generateMockWebsite(),
            bookingURL: generateMockBookingURL(),
            checkInTime: type == .campground || type == .rvPark ? "12:00 PM" : "3:00 PM",
            checkOutTime: type == .campground || type == .rvPark ? "11:00 AM" : "11:00 AM",
            photos: [],
            distance: distance
        )
    }
    
    private func applyFilters(accommodations: [Accommodation], filters: AccommodationSearchFilters) -> [Accommodation] {
        return accommodations.filter { accommodation in
            // Filter by type
            if !filters.types.contains(accommodation.type) {
                return false
            }
            
            // Filter by price range
            if let priceRange = filters.priceRange,
               let accommodationPriceRange = accommodation.priceRange {
                if accommodationPriceRange.rawValue < priceRange.lowerBound.rawValue ||
                   accommodationPriceRange.rawValue > priceRange.upperBound.rawValue {
                    return false
                }
            }
            
            // Filter by minimum rating
            if let minRating = filters.minRating,
               let accommodationRating = accommodation.rating {
                if accommodationRating < minRating {
                    return false
                }
            }
            
            // Filter by required amenities
            if !filters.requiredAmenities.isEmpty {
                let accommodationAmenities = Set(accommodation.amenities)
                if !filters.requiredAmenities.isSubset(of: accommodationAmenities) {
                    return false
                }
            }
            
            // Filter by maximum distance
            if let maxDistance = filters.maxDistance,
               let accommodationDistance = accommodation.distance {
                if accommodationDistance > maxDistance {
                    return false
                }
            }
            
            return true
        }
    }
    
    private func formatAddress(from placemark: CLPlacemark) -> String {
        var addressComponents: [String] = []
        
        if let subThoroughfare = placemark.subThoroughfare {
            addressComponents.append(subThoroughfare)
        }
        
        if let thoroughfare = placemark.thoroughfare {
            addressComponents.append(thoroughfare)
        }
        
        if let locality = placemark.locality {
            addressComponents.append(locality)
        }
        
        if let administrativeArea = placemark.administrativeArea {
            addressComponents.append(administrativeArea)
        }
        
        if let postalCode = placemark.postalCode {
            addressComponents.append(postalCode)
        }
        
        return addressComponents.joined(separator: ", ")
    }
    
    // MARK: - Mock Data Generation (for demonstration)
    
    private func generateMockAmenities(for type: AccommodationType) -> [Amenity] {
        switch type {
        case .hotel, .resort:
            return [.wifi, .parking, .airConditioning, .restaurant, .gym].shuffled().prefix(Int.random(in: 3...5)).map { $0 }
        case .motel:
            return [.wifi, .parking, .airConditioning].shuffled().prefix(Int.random(in: 2...3)).map { $0 }
        case .bedAndBreakfast:
            return [.wifi, .parking, .breakfast, .petFriendly].shuffled().prefix(Int.random(in: 2...4)).map { $0 }
        case .hostel:
            return [.wifi, .laundry, .sharedKitchen].compactMap { amenity in
                // Note: sharedKitchen is not in our enum, so we'll use available ones
                return [.wifi, .laundry].randomElement()
            }
        case .campground:
            return [.restrooms, .showers, .firepit, .picnicTable].shuffled().prefix(Int.random(in: 2...4)).map { $0 }
        case .rvPark:
            return [.electricHookup, .waterHookup, .sewerHookup, .wifi, .restrooms, .showers].shuffled().prefix(Int.random(in: 3...6)).map { $0 }
        case .vacation_rental, .cabin, .lodge:
            return [.wifi, .parking, .petFriendly].shuffled().prefix(Int.random(in: 2...3)).map { $0 }
        }
    }
    
    private func generateMockPriceRange() -> PriceRange {
        return PriceRange.allCases.randomElement() ?? .moderate
    }
    
    private func generateMockPhoneNumber() -> String? {
        return Bool.random() ? "+1-555-\(String(format: "%04d", Int.random(in: 0...9999)))" : nil
    }
    
    private func generateMockWebsite() -> URL? {
        return Bool.random() ? URL(string: "https://example-hotel.com") : nil
    }
    
    private func generateMockBookingURL() -> URL? {
        return Bool.random() ? URL(string: "https://booking.com/hotel/example") : nil
    }
}

// MARK: - Accommodation Extension for Hashable
extension Accommodation: Hashable {
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: Accommodation, rhs: Accommodation) -> Bool {
        return lhs.id == rhs.id
    }
}