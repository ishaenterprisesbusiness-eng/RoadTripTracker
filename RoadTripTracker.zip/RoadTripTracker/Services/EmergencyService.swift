import Foundation
import CoreLocation
import Combine
import UserNotifications
import MessageUI

// MARK: - Emergency Service Implementation
class EmergencyService: NSObject, EmergencyServiceProtocol {
    
    // MARK: - Properties
    private let locationManager: LocationManager
    private let notificationService: NotificationServiceProtocol
    private let persistenceController: PersistenceController
    private let emergencyAlertsSubject = PassthroughSubject<EmergencyAlert, Never>()
    private var cancellables = Set<AnyCancellable>()
    
    // Emergency contacts cache for offline access
    private var cachedEmergencyContacts: [EmergencyContact] = []
    private var cachedEmergencyServices: [EmergencyService] = []
    
    // Check-in timer for inactive participant monitoring
    private var checkInTimer: Timer?
    private let checkInInterval: TimeInterval = 1800 // 30 minutes
    
    // MARK: - Initialization
    init(locationManager: LocationManager, 
         notificationService: NotificationServiceProtocol,
         persistenceController: PersistenceController) {
        self.locationManager = locationManager
        self.notificationService = notificationService
        self.persistenceController = persistenceController
        super.init()
        
        setupCheckInMonitoring()
        loadCachedEmergencyData()
    }
    
    // MARK: - Emergency Service Protocol Implementation
    
    var emergencyAlerts: AnyPublisher<EmergencyAlert, Never> {
        emergencyAlertsSubject.eraseToAnyPublisher()
    }
    
    func triggerEmergencyAlert(location: CLLocationCoordinate2D, message: String?) async throws {
        let alert = EmergencyAlert(
            tripId: getCurrentTripId(),
            userId: getCurrentUserId(),
            alertType: .panic,
            location: location,
            message: message
        )
        
        // Send to all trip participants
        try await broadcastEmergencyAlert(alert)
        
        // Send to emergency contacts
        try await notifyEmergencyContacts(alert)
        
        // Send local notification
        await sendLocalEmergencyNotification(alert)
        
        // Cache for offline access
        await cacheEmergencyAlert(alert)
        
        emergencyAlertsSubject.send(alert)
    }
    
    func sendBreakdownAssistance(location: CLLocationCoordinate2D, vehicleInfo: Vehicle) async throws {
        let alert = EmergencyAlert(
            tripId: getCurrentTripId(),
            userId: getCurrentUserId(),
            alertType: .breakdown,
            location: location,
            message: "Vehicle breakdown: \(vehicleInfo.make) \(vehicleInfo.model) - \(vehicleInfo.vehicleNumber)"
        )
        
        // Find nearby breakdown services
        let nearbyServices = try await findNearbyBreakdownServices(location: location)
        
        // Send alert to trip participants
        try await broadcastEmergencyAlert(alert)
        
        // Cache breakdown services for offline access
        await cacheBreakdownServices(nearbyServices, location: location)
        
        emergencyAlertsSubject.send(alert)
    }
    
    func findNearbyEmergencyServices(location: CLLocationCoordinate2D) async throws -> [EmergencyService] {
        // Try to fetch from network first
        do {
            let services = try await fetchEmergencyServicesFromNetwork(location: location)
            await cacheEmergencyServices(services, location: location)
            return services
        } catch {
            // Fall back to cached data if network fails
            return getCachedEmergencyServices(near: location)
        }
    }
    
    func cancelEmergencyAlert() async throws {
        // Send cancellation to all participants
        let cancellationAlert = EmergencyAlert(
            tripId: getCurrentTripId(),
            userId: getCurrentUserId(),
            alertType: .other,
            location: CLLocationCoordinate2D(latitude: 0, longitude: 0),
            message: "Emergency alert cancelled",
            status: .cancelled
        )
        
        try await broadcastEmergencyAlert(cancellationAlert)
        emergencyAlertsSubject.send(cancellationAlert)
    }
    
    // MARK: - Private Methods
    
    private func setupCheckInMonitoring() {
        checkInTimer = Timer.scheduledTimer(withTimeInterval: checkInInterval, repeats: true) { [weak self] _ in
            Task {
                await self?.checkInactiveParticipants()
            }
        }
    }
    
    private func checkInactiveParticipants() async {
        guard let currentTrip = getCurrentTrip() else { return }
        
        let inactiveThreshold = Date().addingTimeInterval(-checkInInterval)
        
        for participant in currentTrip.participants {
            if let lastUpdate = participant.lastLocationUpdate,
               lastUpdate < inactiveThreshold,
               participant.isLocationSharingEnabled {
                
                await sendCheckInNotification(for: participant)
            }
        }
    }
    
    private func sendCheckInNotification(for participant: Participant) async {
        let notification = UNMutableNotificationContent()
        notification.title = "Check-in Required"
        notification.body = "\(participant.user.username) hasn't been active for 30 minutes. Please check in."
        notification.sound = .default
        notification.categoryIdentifier = "CHECK_IN_REQUIRED"
        
        let request = UNNotificationRequest(
            identifier: "checkin_\(participant.id.uuidString)",
            content: notification,
            trigger: nil
        )
        
        try? await UNUserNotificationCenter.current().add(request)
    }
    
    private func broadcastEmergencyAlert(_ alert: EmergencyAlert) async throws {
        // This would typically send to CloudKit or your backend
        // For now, we'll simulate the broadcast
        print("Broadcasting emergency alert: \(alert)")
        
        // Send push notifications to all trip participants
        guard let currentTrip = getCurrentTrip() else { return }
        
        for participant in currentTrip.participants {
            if participant.userId != alert.userId {
                await sendEmergencyNotificationToParticipant(alert, participant: participant)
            }
        }
    }
    
    private func sendEmergencyNotificationToParticipant(_ alert: EmergencyAlert, participant: Participant) async {
        let notification = UNMutableNotificationContent()
        notification.title = "🚨 Emergency Alert"
        notification.body = getEmergencyAlertMessage(alert, from: participant.user.username)
        notification.sound = .critical
        notification.categoryIdentifier = "EMERGENCY_ALERT"
        notification.userInfo = [
            "alertId": alert.id.uuidString,
            "alertType": alert.alertType.rawValue,
            "latitude": alert.location.latitude,
            "longitude": alert.location.longitude
        ]
        
        let request = UNNotificationRequest(
            identifier: "emergency_\(alert.id.uuidString)",
            content: notification,
            trigger: nil
        )
        
        try? await UNUserNotificationCenter.current().add(request)
    }
    
    private func notifyEmergencyContacts(_ alert: EmergencyAlert) async throws {
        let emergencyContacts = await getEmergencyContacts()
        
        for contact in emergencyContacts {
            switch contact.contactMethod {
            case .sms:
                await sendEmergencySMS(to: contact, alert: alert)
            case .email:
                await sendEmergencyEmail(to: contact, alert: alert)
            case .call:
                // For calls, we'll just prepare the contact info
                await cacheEmergencyCallInfo(contact: contact, alert: alert)
            }
        }
    }
    
    private func sendEmergencySMS(to contact: EmergencyContact, alert: EmergencyAlert) async {
        guard MFMessageComposeViewController.canSendText() else { return }
        
        let message = """
        🚨 EMERGENCY ALERT 🚨
        
        \(contact.name), this is an automated emergency message from Road Trip Tracker.
        
        Alert Type: \(alert.alertType.rawValue.capitalized)
        Time: \(alert.timestamp.formatted())
        Location: https://maps.apple.com/?ll=\(alert.location.latitude),\(alert.location.longitude)
        
        \(alert.message ?? "No additional message")
        
        Please contact emergency services if needed: 000
        """
        
        // In a real implementation, you would use MFMessageComposeViewController
        // or integrate with a SMS service API
        print("Would send SMS to \(contact.phoneNumber): \(message)")
    }
    
    private func sendEmergencyEmail(to contact: EmergencyContact, alert: EmergencyAlert) async {
        let subject = "🚨 Emergency Alert - Road Trip Tracker"
        let body = """
        <html>
        <body>
        <h2 style="color: red;">🚨 EMERGENCY ALERT 🚨</h2>
        
        <p>Dear \(contact.name),</p>
        
        <p>This is an automated emergency message from Road Trip Tracker.</p>
        
        <h3>Alert Details:</h3>
        <ul>
        <li><strong>Alert Type:</strong> \(alert.alertType.rawValue.capitalized)</li>
        <li><strong>Time:</strong> \(alert.timestamp.formatted())</li>
        <li><strong>Location:</strong> <a href="https://maps.apple.com/?ll=\(alert.location.latitude),\(alert.location.longitude)">View on Map</a></li>
        </ul>
        
        \(alert.message.map { "<p><strong>Message:</strong> \($0)</p>" } ?? "")
        
        <p style="color: red;"><strong>If this is a life-threatening emergency, please contact emergency services immediately: 000</strong></p>
        
        <p>This message was sent automatically by Road Trip Tracker.</p>
        </body>
        </html>
        """
        
        // In a real implementation, you would use MFMailComposeViewController
        // or integrate with an email service API
        print("Would send email to \(contact.email): \(subject)")
    }
    
    private func sendLocalEmergencyNotification(_ alert: EmergencyAlert) async {
        let notification = UNMutableNotificationContent()
        notification.title = "Emergency Alert Sent"
        notification.body = "Your emergency alert has been sent to trip participants and emergency contacts."
        notification.sound = .default
        
        let request = UNNotificationRequest(
            identifier: "emergency_sent_\(alert.id.uuidString)",
            content: notification,
            trigger: nil
        )
        
        try? await UNUserNotificationCenter.current().add(request)
    }
    
    private func fetchEmergencyServicesFromNetwork(location: CLLocationCoordinate2D) async throws -> [EmergencyService] {
        // This would typically call a Places API or similar service
        // For now, we'll return mock data
        return [
            EmergencyService(
                name: "City Hospital Emergency",
                type: .hospital,
                phoneNumber: "000",
                address: "123 Hospital St",
                coordinate: CLLocationCoordinate2D(
                    latitude: location.latitude + 0.01,
                    longitude: location.longitude + 0.01
                ),
                distance: 1200,
                isOpen24Hours: true
            ),
            EmergencyService(
                name: "Police Station",
                type: .police,
                phoneNumber: "000",
                address: "456 Police Ave",
                coordinate: CLLocationCoordinate2D(
                    latitude: location.latitude - 0.005,
                    longitude: location.longitude + 0.005
                ),
                distance: 800,
                isOpen24Hours: true
            ),
            EmergencyService(
                name: "24/7 Towing Service",
                type: .towingService,
                phoneNumber: "1800-TOW-NOW",
                address: "789 Service Rd",
                coordinate: CLLocationCoordinate2D(
                    latitude: location.latitude + 0.005,
                    longitude: location.longitude - 0.005
                ),
                distance: 600,
                isOpen24Hours: true
            )
        ]
    }
    
    private func findNearbyBreakdownServices(location: CLLocationCoordinate2D) async throws -> [EmergencyService] {
        let allServices = try await findNearbyEmergencyServices(location: location)
        return allServices.filter { $0.type == .mechanic || $0.type == .towingService }
    }
    
    // MARK: - Caching Methods
    
    private func loadCachedEmergencyData() {
        // Load cached emergency contacts and services from Core Data
        // This would be implemented with actual Core Data queries
    }
    
    private func cacheEmergencyAlert(_ alert: EmergencyAlert) async {
        // Cache the alert in Core Data for offline access
    }
    
    private func cacheEmergencyServices(_ services: [EmergencyService], location: CLLocationCoordinate2D) async {
        cachedEmergencyServices = services
    }
    
    private func cacheBreakdownServices(_ services: [EmergencyService], location: CLLocationCoordinate2D) async {
        // Cache breakdown services for offline access
    }
    
    private func cacheEmergencyCallInfo(contact: EmergencyContact, alert: EmergencyAlert) async {
        // Cache call information for quick access
    }
    
    private func getCachedEmergencyServices(near location: CLLocationCoordinate2D) -> [EmergencyService] {
        return cachedEmergencyServices.filter { service in
            let distance = CLLocation(latitude: location.latitude, longitude: location.longitude)
                .distance(from: CLLocation(latitude: service.coordinate.latitude, longitude: service.coordinate.longitude))
            return distance < 10000 // Within 10km
        }
    }
    
    // MARK: - Helper Methods
    
    private func getEmergencyAlertMessage(_ alert: EmergencyAlert, from username: String) -> String {
        switch alert.alertType {
        case .panic:
            return "\(username) has triggered a panic alert. Location shared."
        case .breakdown:
            return "\(username) has a vehicle breakdown and needs assistance."
        case .accident:
            return "\(username) has been in an accident. Emergency services may be needed."
        case .medical:
            return "\(username) has a medical emergency. Immediate assistance required."
        case .other:
            return "\(username) needs assistance: \(alert.message ?? "No details provided")"
        }
    }
    
    private func getEmergencyContacts() async -> [EmergencyContact] {
        // This would fetch from user's profile
        return cachedEmergencyContacts
    }
    
    private func getCurrentTripId() -> UUID {
        // This would get the current active trip ID
        return UUID()
    }
    
    private func getCurrentUserId() -> UUID {
        // This would get the current user ID
        return UUID()
    }
    
    private func getCurrentTrip() -> Trip? {
        // This would get the current active trip
        return nil
    }
    
    deinit {
        checkInTimer?.invalidate()
    }
}

