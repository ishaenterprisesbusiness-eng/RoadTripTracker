import Foundation
import Combine
import MapKit
import CoreLocation

// MARK: - Navigation Service Implementation
class NavigationService: NavigationServiceProtocol {
    
    // MARK: - Properties
    @Published private(set) var currentRoute: Route?
    @Published private(set) var isNavigating: Bool = false
    @Published private(set) var currentStepIndex: Int = 0
    
    private let navigationUpdateSubject = PassthroughSubject<NavigationUpdate, Never>()
    private let routeProgressSubject = PassthroughSubject<RouteProgress, Never>()
    
    private var cancellables = Set<AnyCancellable>()
    private var navigationStartTime: Date?
    private var totalDistanceTraveled: CLLocationDistance = 0
    
    // Dependencies
    private let mapService: MapServiceProtocol
    private let locationManager: LocationServiceProtocol
    
    // MARK: - Published Properties
    var navigationUpdates: AnyPublisher<NavigationUpdate, Never> {
        navigationUpdateSubject.eraseToAnyPublisher()
    }
    
    var routeProgress: AnyPublisher<RouteProgress, Never> {
        routeProgressSubject.eraseToAnyPublisher()
    }
    
    // MARK: - Initialization
    init(mapService: MapServiceProtocol, locationManager: LocationServiceProtocol) {
        self.mapService = mapService
        self.locationManager = locationManager
        setupLocationUpdates()
    }
    
    // MARK: - NavigationServiceProtocol Implementation
    
    func startNavigation(route: Route) async throws {
        guard !route.destinations.isEmpty else {
            throw NavigationServiceError.invalidRoute
        }
        
        currentRoute = route
        isNavigating = true
        currentStepIndex = 0
        navigationStartTime = Date()
        totalDistanceTraveled = 0
        
        // Start location updates
        try await locationManager.startLocationUpdates()
        
        // Display route on map
        try await mapService.displayRoute(route)
        
        // Send initial navigation update
        if let currentLocation = locationManager.currentLocation {
            await sendNavigationUpdate(currentLocation: currentLocation.coordinate)
        }
    }
    
    func stopNavigation() async throws {
        isNavigating = false
        currentRoute = nil
        currentStepIndex = 0
        navigationStartTime = nil
        totalDistanceTraveled = 0
        
        // Stop location updates
        await locationManager.stopLocationUpdates()
    }
    
    func recalculateRoute(from currentLocation: CLLocationCoordinate2D) async throws -> Route {
        guard let route = currentRoute else {
            throw NavigationServiceError.navigationNotStarted
        }
        
        // Get remaining destinations from current position
        let remainingDestinations = Array(route.destinations.dropFirst(currentStepIndex))
        
        guard !remainingDestinations.isEmpty else {
            throw NavigationServiceError.noRemainingDestinations
        }
        
        // Calculate new route from current location
        let newRoute = try await mapService.calculateMultiDestinationRoute(destinations: remainingDestinations)
        
        // Update current route
        currentRoute = newRoute
        currentStepIndex = 0
        
        // Display updated route
        try await mapService.displayRoute(newRoute)
        
        return newRoute
    }
    
    func getNextInstruction() -> RouteStep? {
        guard let route = currentRoute,
              currentStepIndex < route.steps.count else {
            return nil
        }
        
        return route.steps[currentStepIndex]
    }
    
    func isOffRoute(currentLocation: CLLocationCoordinate2D, threshold: CLLocationDistance = 100) -> Bool {
        guard let route = currentRoute else { return false }
        
        // Check if current location is within threshold of route path
        let currentCLLocation = CLLocation(latitude: currentLocation.latitude, longitude: currentLocation.longitude)
        
        // Find closest point on route
        var minDistance = CLLocationDistance.greatestFiniteMagnitude
        
        for waypoint in route.waypoints {
            let waypointLocation = CLLocation(latitude: waypoint.latitude, longitude: waypoint.longitude)
            let distance = currentCLLocation.distance(from: waypointLocation)
            minDistance = min(minDistance, distance)
        }
        
        return minDistance > threshold
    }
    
    // MARK: - Private Methods
    
    private func setupLocationUpdates() {
        locationManager.locationUpdates
            .sink { [weak self] location in
                guard let self = self, self.isNavigating else { return }
                
                Task {
                    await self.handleLocationUpdate(location)
                }
            }
            .store(in: &cancellables)
    }
    
    private func handleLocationUpdate(_ location: CLLocation) async {
        let coordinate = location.coordinate
        
        // Check if off route
        let offRoute = isOffRoute(currentLocation: coordinate)
        
        if offRoute {
            // Attempt to recalculate route
            do {
                _ = try await recalculateRoute(from: coordinate)
            } catch {
                print("Failed to recalculate route: \(error)")
            }
        }
        
        // Update progress
        await updateRouteProgress(currentLocation: location)
        
        // Send navigation update
        await sendNavigationUpdate(currentLocation: coordinate, isOffRoute: offRoute)
        
        // Check if we've reached the next step
        await checkStepCompletion(currentLocation: location)
    }
    
    private func sendNavigationUpdate(currentLocation: CLLocationCoordinate2D, isOffRoute: Bool = false) async {
        let nextStep = getNextInstruction()
        
        var distanceToNextStep: CLLocationDistance = 0
        var timeToNextStep: TimeInterval = 0
        
        if let step = nextStep {
            let currentCLLocation = CLLocation(latitude: currentLocation.latitude, longitude: currentLocation.longitude)
            let stepLocation = CLLocation(latitude: step.coordinate.latitude, longitude: step.coordinate.longitude)
            distanceToNextStep = currentCLLocation.distance(from: stepLocation)
            
            // Estimate time based on average speed (assuming 50 km/h in city, 80 km/h on highway)
            let averageSpeed: CLLocationDistance = 60 * 1000 / 3600 // 60 km/h in m/s
            timeToNextStep = distanceToNextStep / averageSpeed
        }
        
        let update = NavigationUpdate(
            currentLocation: currentLocation,
            nextStep: nextStep,
            distanceToNextStep: distanceToNextStep,
            timeToNextStep: timeToNextStep,
            isOffRoute: isOffRoute
        )
        
        navigationUpdateSubject.send(update)
    }
    
    private func updateRouteProgress(currentLocation: CLLocation) async {
        guard let route = currentRoute,
              let startTime = navigationStartTime else { return }
        
        let timeElapsed = Date().timeIntervalSince(startTime)
        
        // Calculate distance traveled (simplified - in production you'd track actual path)
        if let firstDestination = route.destinations.first {
            let startLocation = CLLocation(latitude: firstDestination.coordinate.latitude, longitude: firstDestination.coordinate.longitude)
            let distanceTraveled = startLocation.distance(from: currentLocation)
            totalDistanceTraveled = max(totalDistanceTraveled, distanceTraveled)
        }
        
        let distanceRemaining = max(0, route.distance - totalDistanceTraveled)
        let progressPercentage = route.distance > 0 ? (totalDistanceTraveled / route.distance) * 100 : 0
        
        // Estimate remaining time based on current progress
        let estimatedTimeRemaining = timeElapsed > 0 && progressPercentage > 0 
            ? (timeElapsed / (progressPercentage / 100)) - timeElapsed 
            : route.estimatedTravelTime
        
        let progress = RouteProgress(
            distanceTraveled: totalDistanceTraveled,
            distanceRemaining: distanceRemaining,
            timeElapsed: timeElapsed,
            estimatedTimeRemaining: max(0, estimatedTimeRemaining),
            currentDestinationIndex: currentStepIndex,
            progressPercentage: min(100, progressPercentage)
        )
        
        routeProgressSubject.send(progress)
    }
    
    private func checkStepCompletion(currentLocation: CLLocation) async {
        guard let route = currentRoute,
              currentStepIndex < route.steps.count else { return }
        
        let currentStep = route.steps[currentStepIndex]
        let stepLocation = CLLocation(latitude: currentStep.coordinate.latitude, longitude: currentStep.coordinate.longitude)
        let distanceToStep = currentLocation.distance(from: stepLocation)
        
        // If within 50 meters of step, consider it completed
        if distanceToStep < 50 {
            currentStepIndex += 1
            
            // Check if we've completed all steps
            if currentStepIndex >= route.steps.count {
                await completeNavigation()
            }
        }
    }
    
    private func completeNavigation() async {
        isNavigating = false
        
        // Send final progress update
        if let route = currentRoute {
            let finalProgress = RouteProgress(
                distanceTraveled: route.distance,
                distanceRemaining: 0,
                timeElapsed: navigationStartTime.map { Date().timeIntervalSince($0) } ?? 0,
                estimatedTimeRemaining: 0,
                currentDestinationIndex: route.destinations.count,
                progressPercentage: 100
            )
            
            routeProgressSubject.send(finalProgress)
        }
        
        // Send completion update
        if let currentLocation = locationManager.currentLocation {
            let completionUpdate = NavigationUpdate(
                currentLocation: currentLocation.coordinate,
                nextStep: nil,
                distanceToNextStep: 0,
                timeToNextStep: 0,
                isOffRoute: false
            )
            
            navigationUpdateSubject.send(completionUpdate)
        }
    }
}

// MARK: - Navigation Service Error
enum NavigationServiceError: LocalizedError {
    case invalidRoute
    case navigationNotStarted
    case noRemainingDestinations
    case locationUnavailable
    case routeRecalculationFailed
    
    var errorDescription: String? {
        switch self {
        case .invalidRoute:
            return "Invalid route provided"
        case .navigationNotStarted:
            return "Navigation has not been started"
        case .noRemainingDestinations:
            return "No remaining destinations in route"
        case .locationUnavailable:
            return "Current location unavailable"
        case .routeRecalculationFailed:
            return "Failed to recalculate route"
        }
    }
}