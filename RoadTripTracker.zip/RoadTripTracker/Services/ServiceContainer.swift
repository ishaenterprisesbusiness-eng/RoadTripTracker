import Foundation
import Combine

// MARK: - Service Container
@MainActor
class ServiceContainer: ObservableObject {
    static let shared = ServiceContainer()
    
    // MARK: - Service Properties
    private var _authenticationService: AuthenticationServiceProtocol?
    private var _tripService: TripServiceProtocol?
    private var _placesService: PlacesServiceProtocol?
    private var _locationService: LocationServiceProtocol?
    private var _locationSharingService: LocationSharingServiceProtocol?
    private var _chatService: ChatServiceProtocol?
    private var _photoSharingService: PhotoSharingServiceProtocol?
    private var _mapService: MapServiceProtocol?
    private var _navigationService: NavigationServiceProtocol?
    private var _geofencingService: GeofencingServiceProtocol?
    private var _notificationService: NotificationServiceProtocol?
    private var _weatherService: WeatherServiceProtocol?
    private var _emergencyService: EmergencyServiceProtocol?
    private var _budgetService: BudgetServiceProtocol?
    private var _distanceCalculationService: DistanceCalculationService?
    
    private init() {
        setupServices()
    }
    
    // MARK: - Service Accessors
    var authenticationService: AuthenticationServiceProtocol {
        guard let service = _authenticationService else {
            fatalError("AuthenticationService not registered")
        }
        return service
    }
    
    var tripService: TripServiceProtocol {
        guard let service = _tripService else {
            fatalError("TripService not registered")
        }
        return service
    }
    
    var placesService: PlacesServiceProtocol {
        guard let service = _placesService else {
            fatalError("PlacesService not registered")
        }
        return service
    }
    
    var locationService: LocationServiceProtocol {
        guard let service = _locationService else {
            fatalError("LocationService not registered")
        }
        return service
    }
    
    var locationSharingService: LocationSharingServiceProtocol {
        guard let service = _locationSharingService else {
            fatalError("LocationSharingService not registered")
        }
        return service
    }
    
    var chatService: ChatServiceProtocol {
        guard let service = _chatService else {
            fatalError("ChatService not registered")
        }
        return service
    }
    
    var photoSharingService: PhotoSharingServiceProtocol {
        guard let service = _photoSharingService else {
            fatalError("PhotoSharingService not registered")
        }
        return service
    }
    
    var mapService: MapServiceProtocol {
        guard let service = _mapService else {
            fatalError("MapService not registered")
        }
        return service
    }
    
    var navigationService: NavigationServiceProtocol {
        guard let service = _navigationService else {
            fatalError("NavigationService not registered")
        }
        return service
    }
    
    var geofencingService: GeofencingServiceProtocol {
        guard let service = _geofencingService else {
            fatalError("GeofencingService not registered")
        }
        return service
    }
    
    var notificationService: NotificationServiceProtocol {
        guard let service = _notificationService else {
            fatalError("NotificationService not registered")
        }
        return service
    }
    
    var weatherService: WeatherServiceProtocol {
        guard let service = _weatherService else {
            fatalError("WeatherService not registered")
        }
        return service
    }
    
    var emergencyService: EmergencyServiceProtocol {
        guard let service = _emergencyService else {
            fatalError("EmergencyService not registered")
        }
        return service
    }
    
    var budgetService: BudgetServiceProtocol {
        guard let service = _budgetService else {
            fatalError("BudgetService not registered")
        }
        return service
    }
    
    var distanceCalculationService: DistanceCalculationService {
        guard let service = _distanceCalculationService else {
            fatalError("DistanceCalculationService not registered")
        }
        return service
    }
    
    // MARK: - Service Registration
    func register<T>(service: T, for type: T.Type) {
        switch type {
        case is AuthenticationServiceProtocol.Type:
            _authenticationService = service as? AuthenticationServiceProtocol
        case is TripServiceProtocol.Type:
            _tripService = service as? TripServiceProtocol
        case is PlacesServiceProtocol.Type:
            _placesService = service as? PlacesServiceProtocol
        case is LocationServiceProtocol.Type:
            _locationService = service as? LocationServiceProtocol
        case is LocationSharingServiceProtocol.Type:
            _locationSharingService = service as? LocationSharingServiceProtocol
        case is ChatServiceProtocol.Type:
            _chatService = service as? ChatServiceProtocol
        case is PhotoSharingServiceProtocol.Type:
            _photoSharingService = service as? PhotoSharingServiceProtocol
        case is MapServiceProtocol.Type:
            _mapService = service as? MapServiceProtocol
        case is NavigationServiceProtocol.Type:
            _navigationService = service as? NavigationServiceProtocol
        case is GeofencingServiceProtocol.Type:
            _geofencingService = service as? GeofencingServiceProtocol
        case is NotificationServiceProtocol.Type:
            _notificationService = service as? NotificationServiceProtocol
        case is WeatherServiceProtocol.Type:
            _weatherService = service as? WeatherServiceProtocol
        case is EmergencyServiceProtocol.Type:
            _emergencyService = service as? EmergencyServiceProtocol
        case is BudgetServiceProtocol.Type:
            _budgetService = service as? BudgetServiceProtocol
        case is DistanceCalculationService.Type:
            _distanceCalculationService = service as? DistanceCalculationService
        default:
            fatalError("Unknown service type: \(type)")
        }
    }
    
    // MARK: - Private Methods
    private func setupServices() {
        // Register authentication service
        let authManager = AuthenticationManager(persistenceController: PersistenceController.shared)
        register(service: authManager, for: AuthenticationServiceProtocol.self)
        
        // Register places service
        let placesService = PlacesService()
        register(service: placesService, for: PlacesServiceProtocol.self)
        
        // Register location services
        let locationManager = LocationManager()
        register(service: locationManager, for: LocationServiceProtocol.self)
        
        let locationSharingService = LocationSharingService()
        register(service: locationSharingService, for: LocationSharingServiceProtocol.self)
        
        let geofencingService = GeofencingService()
        register(service: geofencingService, for: GeofencingServiceProtocol.self)
        
        // Register trip service
        let tripService = TripService(
            persistenceController: PersistenceController.shared,
            placesService: placesService,
            authenticationManager: authManager
        )
        register(service: tripService, for: TripServiceProtocol.self)
        
        // Register map service
        let mapService = MapService()
        register(service: mapService, for: MapServiceProtocol.self)
        
        // Register notification service
        let notificationService = NotificationService()
        register(service: notificationService, for: NotificationServiceProtocol.self)
        
        // Register distance calculation service
        let distanceCalculationService = DistanceCalculationService(
            locationManager: locationManager,
            mapService: mapService
        )
        register(service: distanceCalculationService, for: DistanceCalculationService.self)
        
        // Register budget service
        let budgetService = BudgetService(
            persistenceController: PersistenceController.shared,
            notificationService: notificationService
        )
        register(service: budgetService, for: BudgetServiceProtocol.self)
        
        // Register weather service
        let weatherService = WeatherService()
        register(service: weatherService, for: WeatherServiceProtocol.self)
        
        // Register emergency service
        let emergencyService = EmergencyService(
            locationManager: locationManager,
            notificationService: notificationService,
            persistenceController: PersistenceController.shared
        )
        register(service: emergencyService, for: EmergencyServiceProtocol.self)
        
        // Note: Other services will be implemented in subsequent tasks
    }
}

// MARK: - Service Registration Helper
extension ServiceContainer {
    func registerMockServices() {
        // This method will be used to register mock services during development
        // Real service implementations will be registered in production
    }
}