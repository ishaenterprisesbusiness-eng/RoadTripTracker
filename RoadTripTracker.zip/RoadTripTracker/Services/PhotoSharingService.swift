import Foundation
import Combine
import UIKit
import CoreLocation
import CloudKit
import Photos

// MARK: - Photo Sharing Service Implementation
class PhotoSharingService: PhotoSharingServiceProtocol, ObservableObject {
    
    // MARK: - Properties
    private let container = CKContainer.default()
    private let database: CKDatabase
    private let persistenceController: PersistenceController
    private var subscriptions = Set<AnyCancellable>()
    
    // Publishers
    private let photoSubject = PassthroughSubject<PhotoShare, Never>()
    
    // Cache for downloaded photos
    private let photoCache = NSCache<NSString, UIImage>()
    
    // MARK: - Published Properties
    var photoUpdates: AnyPublisher<PhotoShare, Never> {
        photoSubject.eraseToAnyPublisher()
    }
    
    // MARK: - Initialization
    init(persistenceController: PersistenceController = PersistenceController.shared) {
        self.database = container.publicCloudDatabase
        self.persistenceController = persistenceController
        
        setupPhotoCache()
    }
    
    // MARK: - Public Methods
    
    func sharePhoto(_ photo: UIImage, caption: String?, location: CLLocationCoordinate2D?, to tripId: UUID) async throws -> PhotoShare {
        // Compress and prepare photo
        guard let imageData = photo.jpegData(compressionQuality: 0.8) else {
            throw ChatServiceError.photoUploadFailed
        }
        
        // Create thumbnail
        let thumbnail = createThumbnail(from: photo)
        
        // Upload main photo
        let photoURL = try await uploadPhotoData(imageData, filename: "\(UUID().uuidString).jpg")
        
        // Upload thumbnail
        var thumbnailURL: URL?
        if let thumbnailData = thumbnail.jpegData(compressionQuality: 0.6) {
            thumbnailURL = try await uploadPhotoData(thumbnailData, filename: "thumb_\(UUID().uuidString).jpg")
        }
        
        // Create PhotoShare object
        let photoShare = PhotoShare(
            tripId: tripId,
            sharedBy: getCurrentUserId(),
            photoURL: photoURL,
            thumbnailURL: thumbnailURL,
            caption: caption,
            location: location,
            tags: generateTags(for: photo, location: location)
        )
        
        // Save to CloudKit
        let record = recordFromPhotoShare(photoShare)
        do {
            _ = try await database.save(record)
            
            // Save locally
            savePhotoShareLocally(photoShare)
            
            // Notify subscribers
            photoSubject.send(photoShare)
            
            return photoShare
        } catch {
            throw ChatServiceError.photoUploadFailed
        }
    }
    
    func getTripPhotos(for tripId: UUID) async throws -> [PhotoShare] {
        let predicate = NSPredicate(format: "tripId == %@", tripId.uuidString)
        let query = CKQuery(recordType: "PhotoShare", predicate: predicate)
        query.sortDescriptors = [NSSortDescriptor(key: "timestamp", ascending: false)]
        
        do {
            let (records, _) = try await database.records(matching: query)
            let photoShares = records.compactMap { _, result in
                switch result {
                case .success(let record):
                    return photoShareFromRecord(record)
                case .failure:
                    return nil
                }
            }
            
            // Also get local cached photos
            let localPhotos = getLocalPhotoShares(for: tripId)
            
            // Merge and deduplicate
            return mergePhotoShares(cloudPhotos: photoShares, localPhotos: localPhotos)
        } catch {
            // Fallback to local photos only
            return getLocalPhotoShares(for: tripId)
        }
    }
    
    func downloadPhoto(from url: URL) async throws -> UIImage {
        // Check cache first
        let cacheKey = url.absoluteString as NSString
        if let cachedImage = photoCache.object(forKey: cacheKey) {
            return cachedImage
        }
        
        // Download from CloudKit or URL
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            guard let image = UIImage(data: data) else {
                throw ChatServiceError.photoDownloadFailed
            }
            
            // Cache the image
            photoCache.setObject(image, forKey: cacheKey)
            
            return image
        } catch {
            throw ChatServiceError.photoDownloadFailed
        }
    }
    
    func deletePhoto(_ photoId: UUID) async throws {
        let recordID = CKRecord.ID(recordName: photoId.uuidString)
        
        do {
            // Get the record first to delete associated assets
            let record = try await database.record(for: recordID)
            
            // Delete the record
            try await database.deleteRecord(withID: recordID)
            
            // Delete locally
            deleteLocalPhotoShare(photoId)
            
            // Remove from cache
            if let photoURL = record["photoURL"] as? String {
                photoCache.removeObject(forKey: photoURL as NSString)
            }
        } catch {
            throw ChatServiceError.photoDownloadFailed
        }
    }
    
    func createTripAlbum(for tripId: UUID) async throws -> TripAlbum {
        // Get all photos for the trip
        let photos = try await getTripPhotos(for: tripId)
        
        // Get trip name (this would come from TripService)
        let tripName = await getTripName(for: tripId)
        
        // Create album
        let album = TripAlbum(
            tripId: tripId,
            name: "\(tripName) Album",
            photos: photos,
            coverPhotoURL: photos.first?.photoURL
        )
        
        // Save album to CloudKit
        let record = recordFromTripAlbum(album)
        do {
            _ = try await database.save(record)
            return album
        } catch {
            throw ChatServiceError.unknown("Failed to create trip album")
        }
    }
    
    func downloadAllPhotos(for tripId: UUID) async throws -> [UIImage] {
        let photoShares = try await getTripPhotos(for: tripId)
        var images: [UIImage] = []
        
        for photoShare in photoShares {
            do {
                let image = try await downloadPhoto(from: photoShare.photoURL)
                images.append(image)
            } catch {
                // Continue with other photos if one fails
                continue
            }
        }
        
        return images
    }
}

// MARK: - Private Methods
private extension PhotoSharingService {
    
    func setupPhotoCache() {
        photoCache.countLimit = 100 // Limit cache to 100 images
        photoCache.totalCostLimit = 50 * 1024 * 1024 // 50MB limit
    }
    
    func uploadPhotoData(_ data: Data, filename: String) async throws -> URL {
        // Create temporary file
        let tempURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(filename)
        
        try data.write(to: tempURL)
        
        // Create CKAsset
        let asset = CKAsset(fileURL: tempURL)
        let record = CKRecord(recordType: "PhotoAsset")
        record["photo"] = asset
        record["filename"] = filename
        
        do {
            let savedRecord = try await database.save(record)
            
            // Clean up temp file
            try? FileManager.default.removeItem(at: tempURL)
            
            // Return CloudKit URL (this would be the actual asset URL in production)
            return URL(string: "cloudkit://photo/\(savedRecord.recordID.recordName)")!
        } catch {
            try? FileManager.default.removeItem(at: tempURL)
            throw ChatServiceError.photoUploadFailed
        }
    }
    
    func createThumbnail(from image: UIImage, size: CGSize = CGSize(width: 200, height: 200)) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { _ in
            image.draw(in: CGRect(origin: .zero, size: size))
        }
    }
    
    func generateTags(for photo: UIImage, location: CLLocationCoordinate2D?) -> [String] {
        var tags: [String] = []
        
        // Add location-based tags if available
        if let location = location {
            // This would use reverse geocoding to get location names
            tags.append("location")
        }
        
        // Add time-based tags
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 6..<12:
            tags.append("morning")
        case 12..<17:
            tags.append("afternoon")
        case 17..<21:
            tags.append("evening")
        default:
            tags.append("night")
        }
        
        return tags
    }
    
    func recordFromPhotoShare(_ photoShare: PhotoShare) -> CKRecord {
        let record = CKRecord(recordType: "PhotoShare", recordID: CKRecord.ID(recordName: photoShare.id.uuidString))
        record["tripId"] = photoShare.tripId.uuidString
        record["sharedBy"] = photoShare.sharedBy.uuidString
        record["photoURL"] = photoShare.photoURL.absoluteString
        record["caption"] = photoShare.caption
        record["timestamp"] = photoShare.timestamp
        record["tags"] = photoShare.tags
        
        if let thumbnailURL = photoShare.thumbnailURL {
            record["thumbnailURL"] = thumbnailURL.absoluteString
        }
        
        if let location = photoShare.location {
            record["location"] = CLLocation(latitude: location.latitude, longitude: location.longitude)
        }
        
        return record
    }
    
    func photoShareFromRecord(_ record: CKRecord) -> PhotoShare? {
        guard
            let tripIdString = record["tripId"] as? String,
            let tripId = UUID(uuidString: tripIdString),
            let sharedByString = record["sharedBy"] as? String,
            let sharedBy = UUID(uuidString: sharedByString),
            let photoURLString = record["photoURL"] as? String,
            let photoURL = URL(string: photoURLString),
            let timestamp = record["timestamp"] as? Date
        else {
            return nil
        }
        
        let photoId = UUID(uuidString: record.recordID.recordName) ?? UUID()
        let caption = record["caption"] as? String
        let tags = record["tags"] as? [String] ?? []
        
        var thumbnailURL: URL?
        if let thumbnailURLString = record["thumbnailURL"] as? String {
            thumbnailURL = URL(string: thumbnailURLString)
        }
        
        var location: CLLocationCoordinate2D?
        if let clLocation = record["location"] as? CLLocation {
            location = clLocation.coordinate
        }
        
        return PhotoShare(
            id: photoId,
            tripId: tripId,
            sharedBy: sharedBy,
            photoURL: photoURL,
            thumbnailURL: thumbnailURL,
            caption: caption,
            location: location,
            timestamp: timestamp,
            tags: tags
        )
    }
    
    func recordFromTripAlbum(_ album: TripAlbum) -> CKRecord {
        let record = CKRecord(recordType: "TripAlbum", recordID: CKRecord.ID(recordName: album.id.uuidString))
        record["tripId"] = album.tripId.uuidString
        record["name"] = album.name
        record["createdAt"] = album.createdAt
        
        if let coverPhotoURL = album.coverPhotoURL {
            record["coverPhotoURL"] = coverPhotoURL.absoluteString
        }
        
        // Store photo IDs as references
        let photoReferences = album.photos.map { CKRecord.Reference(recordID: CKRecord.ID(recordName: $0.id.uuidString), action: .none) }
        record["photos"] = photoReferences
        
        return record
    }
    
    func getCurrentUserId() -> UUID {
        // This should get the current user ID from authentication service
        // For now, return a placeholder
        return UUID()
    }
    
    func getTripName(for tripId: UUID) async -> String {
        // This would get the trip name from TripService
        return "Road Trip"
    }
    
    // MARK: - Local Storage Methods
    
    func savePhotoShareLocally(_ photoShare: PhotoShare) {
        // Save to Core Data for offline access
        let context = persistenceController.container.viewContext
        // Implementation would save to Core Data
    }
    
    func getLocalPhotoShares(for tripId: UUID) -> [PhotoShare] {
        // Get photo shares from Core Data
        // This is a placeholder implementation
        return []
    }
    
    func deleteLocalPhotoShare(_ photoId: UUID) {
        // Delete from Core Data
    }
    
    func mergePhotoShares(cloudPhotos: [PhotoShare], localPhotos: [PhotoShare]) -> [PhotoShare] {
        var photoDict: [UUID: PhotoShare] = [:]
        
        // Add local photos first
        for photo in localPhotos {
            photoDict[photo.id] = photo
        }
        
        // Override with cloud photos (they're more up-to-date)
        for photo in cloudPhotos {
            photoDict[photo.id] = photo
        }
        
        return Array(photoDict.values).sorted { $0.timestamp > $1.timestamp }
    }
}