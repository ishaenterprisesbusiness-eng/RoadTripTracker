import Foundation
import Combine
import UIKit
import CoreLocation
import CloudKit

// MARK: - Chat Service Implementation
class ChatService: ChatServiceProtocol, ObservableObject {
    
    // MARK: - Properties
    private let container = CKContainer.default()
    private let database: CKDatabase
    private let persistenceController: PersistenceController
    private var subscriptions = Set<AnyCancellable>()
    private var messageSubscription: CKQuerySubscription?
    
    // Publishers
    private let messageSubject = PassthroughSubject<Message, Never>()
    private let connectionSubject = CurrentValueSubject<ConnectionStatus, Never>(.disconnected)
    
    // Offline message queue
    private var offlineMessageQueue: [Message] = []
    private let offlineQueueKey = "OfflineMessageQueue"
    
    // MARK: - Published Properties
    var messageUpdates: AnyPublisher<Message, Never> {
        messageSubject.eraseToAnyPublisher()
    }
    
    var connectionStatus: AnyPublisher<ConnectionStatus, Never> {
        connectionSubject.eraseToAnyPublisher()
    }
    
    // MARK: - Initialization
    init(persistenceController: PersistenceController = PersistenceController.shared) {
        self.database = container.publicCloudDatabase
        self.persistenceController = persistenceController
        
        setupNetworkMonitoring()
        loadOfflineQueue()
    }
    
    // MARK: - Public Methods
    
    func sendMessage(_ content: String, to tripId: UUID) async throws -> Message {
        let message = Message(
            tripId: tripId,
            senderId: getCurrentUserId(),
            content: content,
            type: .text
        )
        
        return try await sendMessage(message)
    }
    
    func sendLocationMessage(_ location: CLLocationCoordinate2D, to tripId: UUID) async throws -> Message {
        let message = Message(
            tripId: tripId,
            senderId: getCurrentUserId(),
            content: "Shared location",
            type: .location,
            location: location
        )
        
        return try await sendMessage(message)
    }
    
    func sendPhotoMessage(_ photo: UIImage, caption: String?, to tripId: UUID) async throws -> Message {
        // Upload photo first
        let photoURL = try await uploadPhoto(photo)
        
        let message = Message(
            tripId: tripId,
            senderId: getCurrentUserId(),
            content: caption ?? "Shared a photo",
            type: .photo,
            photoURL: photoURL
        )
        
        return try await sendMessage(message)
    }
    
    func sendEmergencyMessage(_ content: String, location: CLLocationCoordinate2D, to tripId: UUID) async throws -> Message {
        let message = Message(
            tripId: tripId,
            senderId: getCurrentUserId(),
            content: content,
            type: .emergency,
            location: location
        )
        
        return try await sendMessage(message)
    }
    
    func getMessages(for tripId: UUID, limit: Int = 50, offset: Int = 0) async throws -> [Message] {
        let predicate = NSPredicate(format: "tripId == %@", tripId.uuidString)
        let query = CKQuery(recordType: "Message", predicate: predicate)
        query.sortDescriptors = [NSSortDescriptor(key: "timestamp", ascending: false)]
        
        do {
            let (records, _) = try await database.records(matching: query)
            let messages = records.compactMap { _, result in
                switch result {
                case .success(let record):
                    return messageFromRecord(record)
                case .failure:
                    return nil
                }
            }
            
            // Also get local cached messages
            let localMessages = getLocalMessages(for: tripId, limit: limit, offset: offset)
            
            // Merge and deduplicate
            let allMessages = mergeMessages(cloudMessages: messages, localMessages: localMessages)
            
            return Array(allMessages.prefix(limit))
        } catch {
            // Fallback to local messages only
            return getLocalMessages(for: tripId, limit: limit, offset: offset)
        }
    }
    
    func markMessageAsRead(_ messageId: UUID, by userId: UUID) async throws {
        // Update in CloudKit
        let recordID = CKRecord.ID(recordName: messageId.uuidString)
        
        do {
            let record = try await database.record(for: recordID)
            var readBy = record["readBy"] as? [String] ?? []
            if !readBy.contains(userId.uuidString) {
                readBy.append(userId.uuidString)
                record["readBy"] = readBy
                try await database.save(record)
            }
        } catch {
            // Store locally for later sync
            storeReadStatusLocally(messageId: messageId, userId: userId)
        }
    }
    
    func deleteMessage(_ messageId: UUID) async throws {
        let recordID = CKRecord.ID(recordName: messageId.uuidString)
        
        do {
            try await database.deleteRecord(withID: recordID)
            deleteLocalMessage(messageId)
        } catch {
            throw ChatServiceError.messageNotFound
        }
    }
    
    func subscribeToMessages(for tripId: UUID) async throws {
        let predicate = NSPredicate(format: "tripId == %@", tripId.uuidString)
        let subscription = CKQuerySubscription(
            recordType: "Message",
            predicate: predicate,
            subscriptionID: "messages-\(tripId.uuidString)",
            options: [.firesOnRecordCreation, .firesOnRecordUpdate]
        )
        
        let notificationInfo = CKSubscription.NotificationInfo()
        notificationInfo.shouldSendContentAvailable = true
        subscription.notificationInfo = notificationInfo
        
        do {
            messageSubscription = try await database.save(subscription)
            connectionSubject.send(.connected)
        } catch {
            connectionSubject.send(.error("Failed to subscribe to messages"))
            throw ChatServiceError.connectionFailed
        }
    }
    
    func unsubscribeFromMessages(for tripId: UUID) async throws {
        let subscriptionID = "messages-\(tripId.uuidString)"
        
        do {
            try await database.deleteSubscription(withID: subscriptionID)
            messageSubscription = nil
        } catch {
            // Subscription might not exist, which is fine
        }
    }
}

// MARK: - Private Methods
private extension ChatService {
    
    func sendMessage(_ message: Message) async throws -> Message {
        var updatedMessage = message
        
        // Try to send to CloudKit
        if connectionSubject.value == .connected {
            do {
                let record = recordFromMessage(updatedMessage)
                let savedRecord = try await database.save(record)
                updatedMessage.deliveryStatus = .sent
                
                // Update local storage
                saveMessageLocally(updatedMessage)
                
                // Notify subscribers
                messageSubject.send(updatedMessage)
                
                return updatedMessage
            } catch {
                updatedMessage.deliveryStatus = .failed
                // Add to offline queue
                addToOfflineQueue(updatedMessage)
                throw ChatServiceError.messageNotSent
            }
        } else {
            // Add to offline queue
            updatedMessage.deliveryStatus = .sending
            addToOfflineQueue(updatedMessage)
            saveMessageLocally(updatedMessage)
            
            // Notify subscribers
            messageSubject.send(updatedMessage)
            
            return updatedMessage
        }
    }
    
    func uploadPhoto(_ photo: UIImage) async throws -> URL {
        guard let imageData = photo.jpegData(compressionQuality: 0.8) else {
            throw ChatServiceError.photoUploadFailed
        }
        
        // Create temporary file
        let tempURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("jpg")
        
        try imageData.write(to: tempURL)
        
        // Create CKAsset
        let asset = CKAsset(fileURL: tempURL)
        let record = CKRecord(recordType: "PhotoAsset")
        record["photo"] = asset
        
        do {
            let savedRecord = try await database.save(record)
            
            // Clean up temp file
            try? FileManager.default.removeItem(at: tempURL)
            
            // Return CloudKit URL (this would be the actual asset URL in production)
            return URL(string: "cloudkit://photo/\(savedRecord.recordID.recordName)")!
        } catch {
            try? FileManager.default.removeItem(at: tempURL)
            throw ChatServiceError.photoUploadFailed
        }
    }
    
    func recordFromMessage(_ message: Message) -> CKRecord {
        let record = CKRecord(recordType: "Message", recordID: CKRecord.ID(recordName: message.id.uuidString))
        record["tripId"] = message.tripId.uuidString
        record["senderId"] = message.senderId.uuidString
        record["content"] = message.content
        record["type"] = message.type.rawValue
        record["timestamp"] = message.timestamp
        record["deliveryStatus"] = message.deliveryStatus.rawValue
        record["readBy"] = message.readBy.map { $0.uuidString }
        
        if let location = message.location {
            record["location"] = CLLocation(latitude: location.latitude, longitude: location.longitude)
        }
        
        if let photoURL = message.photoURL {
            record["photoURL"] = photoURL.absoluteString
        }
        
        return record
    }
    
    func messageFromRecord(_ record: CKRecord) -> Message? {
        guard
            let tripIdString = record["tripId"] as? String,
            let tripId = UUID(uuidString: tripIdString),
            let senderIdString = record["senderId"] as? String,
            let senderId = UUID(uuidString: senderIdString),
            let content = record["content"] as? String,
            let typeString = record["type"] as? String,
            let type = MessageType(rawValue: typeString),
            let timestamp = record["timestamp"] as? Date,
            let deliveryStatusString = record["deliveryStatus"] as? String,
            let deliveryStatus = MessageDeliveryStatus(rawValue: deliveryStatusString)
        else {
            return nil
        }
        
        let messageId = UUID(uuidString: record.recordID.recordName) ?? UUID()
        let readByStrings = record["readBy"] as? [String] ?? []
        let readBy = readByStrings.compactMap { UUID(uuidString: $0) }
        
        var location: CLLocationCoordinate2D?
        if let clLocation = record["location"] as? CLLocation {
            location = clLocation.coordinate
        }
        
        var photoURL: URL?
        if let photoURLString = record["photoURL"] as? String {
            photoURL = URL(string: photoURLString)
        }
        
        return Message(
            id: messageId,
            tripId: tripId,
            senderId: senderId,
            content: content,
            type: type,
            timestamp: timestamp,
            location: location,
            photoURL: photoURL,
            deliveryStatus: deliveryStatus,
            readBy: readBy
        )
    }
    
    func getCurrentUserId() -> UUID {
        // This should get the current user ID from authentication service
        // For now, return a placeholder
        return UUID()
    }
    
    func setupNetworkMonitoring() {
        // Monitor network connectivity and update connection status
        // This is a simplified implementation
        connectionSubject.send(.connected)
    }
    
    func loadOfflineQueue() {
        if let data = UserDefaults.standard.data(forKey: offlineQueueKey),
           let queue = try? JSONDecoder().decode([Message].self, from: data) {
            offlineMessageQueue = queue
        }
    }
    
    func saveOfflineQueue() {
        if let data = try? JSONEncoder().encode(offlineMessageQueue) {
            UserDefaults.standard.set(data, forKey: offlineQueueKey)
        }
    }
    
    func addToOfflineQueue(_ message: Message) {
        offlineMessageQueue.append(message)
        saveOfflineQueue()
    }
    
    func processOfflineQueue() async {
        guard !offlineMessageQueue.isEmpty else { return }
        
        var processedMessages: [Message] = []
        
        for message in offlineMessageQueue {
            do {
                _ = try await sendMessage(message)
                processedMessages.append(message)
            } catch {
                // Keep failed messages in queue
                break
            }
        }
        
        // Remove processed messages
        offlineMessageQueue.removeAll { message in
            processedMessages.contains { $0.id == message.id }
        }
        saveOfflineQueue()
    }
    
    // MARK: - Local Storage Methods
    
    func saveMessageLocally(_ message: Message) {
        // Save to Core Data for offline access
        let context = persistenceController.container.viewContext
        // Implementation would save to Core Data
    }
    
    func getLocalMessages(for tripId: UUID, limit: Int, offset: Int) -> [Message] {
        // Get messages from Core Data
        // This is a placeholder implementation
        return []
    }
    
    func deleteLocalMessage(_ messageId: UUID) {
        // Delete from Core Data
    }
    
    func storeReadStatusLocally(messageId: UUID, userId: UUID) {
        // Store read status locally for later sync
    }
    
    func mergeMessages(cloudMessages: [Message], localMessages: [Message]) -> [Message] {
        var messageDict: [UUID: Message] = [:]
        
        // Add local messages first
        for message in localMessages {
            messageDict[message.id] = message
        }
        
        // Override with cloud messages (they're more up-to-date)
        for message in cloudMessages {
            messageDict[message.id] = message
        }
        
        return Array(messageDict.values).sorted { $0.timestamp > $1.timestamp }
    }
}