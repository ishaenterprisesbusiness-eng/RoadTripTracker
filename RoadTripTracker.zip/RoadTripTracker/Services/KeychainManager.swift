import Foundation
import Security

// MARK: - Keychain Manager
class KeychainManager {
    
    // MARK: - Constants
    private let service = "com.roadtriptracker.app"
    private let sessionKey = "user_session"
    private let biometricKey = "biometric_enabled"
    
    // MARK: - Session Management
    
    func store(session: UserSession) throws {
        let data = try JSONEncoder().encode(session)
        
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: sessionKey,
            kSecValueData as String: data
        ]
        
        // Delete existing item first
        SecItemDelete(query as CFDictionary)
        
        // Add new item
        let status = SecItemAdd(query as CFDictionary, nil)
        
        guard status == errSecSuccess else {
            throw KeychainError.storeFailed
        }
    }
    
    func getStoredSession() throws -> UserSession? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: sessionKey,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        
        guard status == errSecSuccess else {
            if status == errSecItemNotFound {
                return nil
            }
            throw KeychainError.retrieveFailed
        }
        
        guard let data = result as? Data else {
            throw KeychainError.invalidData
        }
        
        do {
            let session = try JSONDecoder().decode(UserSession.self, from: data)
            return session
        } catch {
            throw KeychainError.decodeFailed
        }
    }
    
    func clearSession() throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: sessionKey
        ]
        
        let status = SecItemDelete(query as CFDictionary)
        
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw KeychainError.deleteFailed
        }
    }
    
    // MARK: - Biometric Authentication
    
    func enableBiometricAuth(for userId: UUID) throws {
        let data = userId.uuidString.data(using: .utf8)!
        
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: biometricKey,
            kSecValueData as String: data,
            kSecAttrAccessControl as String: createBiometricAccessControl()
        ]
        
        // Delete existing item first
        SecItemDelete(query as CFDictionary)
        
        // Add new item
        let status = SecItemAdd(query as CFDictionary, nil)
        
        guard status == errSecSuccess else {
            throw KeychainError.storeFailed
        }
    }
    
    func isBiometricAuthEnabled() -> Bool {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: biometricKey,
            kSecReturnData as String: false,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        
        let status = SecItemCopyMatching(query as CFDictionary, nil)
        return status == errSecSuccess
    }
    
    func disableBiometricAuth() throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: biometricKey
        ]
        
        let status = SecItemDelete(query as CFDictionary)
        
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw KeychainError.deleteFailed
        }
    }
    
    // MARK: - Private Helper Methods
    
    private func createBiometricAccessControl() -> SecAccessControl {
        var error: Unmanaged<CFError>?
        
        let accessControl = SecAccessControlCreateWithFlags(
            kCFAllocatorDefault,
            kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
            .biometryAny,
            &error
        )
        
        guard let accessControl = accessControl else {
            fatalError("Failed to create access control: \(error!.takeRetainedValue())")
        }
        
        return accessControl
    }
}

// MARK: - Keychain Error
enum KeychainError: LocalizedError {
    case storeFailed
    case retrieveFailed
    case deleteFailed
    case invalidData
    case decodeFailed
    
    var errorDescription: String? {
        switch self {
        case .storeFailed:
            return "Failed to store data in keychain"
        case .retrieveFailed:
            return "Failed to retrieve data from keychain"
        case .deleteFailed:
            return "Failed to delete data from keychain"
        case .invalidData:
            return "Invalid data format in keychain"
        case .decodeFailed:
            return "Failed to decode keychain data"
        }
    }
}