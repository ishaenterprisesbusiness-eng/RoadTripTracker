import Foundation
import Combine
import CloudKit
import CoreLocation

// MARK: - Location Sharing Service
@MainActor
class LocationSharingService: ObservableObject, LocationSharingServiceProtocol {
    
    // MARK: - Properties
    private let cloudKitContainer = CKContainer.default()
    private let database: CKDatabase
    
    // Publishers
    private let participantLocationsSubject = CurrentValueSubject<[UUID: ParticipantLocation], Never>([:])
    
    // State
    @Published private var _participantLocations: [UUID: ParticipantLocation] = [:]
    private var subscriptions: Set<AnyCancellable> = []
    private var activeSubscriptions: [UUID: CKQuerySubscription] = [:]
    
    // MARK: - Computed Properties
    var participantLocations: AnyPublisher<[UUID: ParticipantLocation], Never> {
        participantLocationsSubject.eraseToAnyPublisher()
    }
    
    // MARK: - Initialization
    init() {
        self.database = cloudKitContainer.publicCloudDatabase
        setupLocationUpdatesPublisher()
    }
    
    // MARK: - Setup
    private func setupLocationUpdatesPublisher() {
        // Sync internal state with published subject
        $_participantLocations
            .sink { [weak self] locations in
                self?.participantLocationsSubject.send(locations)
            }
            .store(in: &subscriptions)
    }
    
    // MARK: - LocationSharingServiceProtocol Implementation
    
    func shareLocation(_ location: CLLocation, for participantId: UUID, in tripId: UUID) async throws {
        let participantLocation = ParticipantLocation(
            participantId: participantId,
            location: location.coordinate,
            timestamp: location.timestamp,
            speed: location.speed >= 0 ? location.speed : nil,
            heading: location.course >= 0 ? location.course : nil,
            accuracy: location.horizontalAccuracy
        )
        
        // Create CloudKit record
        let recordID = CKRecord.ID(recordName: "location_\(tripId.uuidString)_\(participantId.uuidString)")
        let record = CKRecord(recordType: "ParticipantLocation", recordID: recordID)
        
        record["tripId"] = tripId.uuidString
        record["participantId"] = participantId.uuidString
        record["latitude"] = location.coordinate.latitude
        record["longitude"] = location.coordinate.longitude
        record["timestamp"] = location.timestamp
        record["speed"] = participantLocation.speed
        record["heading"] = participantLocation.heading
        record["accuracy"] = location.horizontalAccuracy
        
        do {
            _ = try await database.save(record)
            
            // Update local cache
            _participantLocations[participantId] = participantLocation
            
        } catch {
            throw LocationServiceError.networkError
        }
    }
    
    func stopSharingLocation(for participantId: UUID, in tripId: UUID) async throws {
        let recordID = CKRecord.ID(recordName: "location_\(tripId.uuidString)_\(participantId.uuidString)")
        
        do {
            _ = try await database.deleteRecord(withID: recordID)
            
            // Remove from local cache
            _participantLocations.removeValue(forKey: participantId)
            
        } catch {
            // If record doesn't exist, that's fine
            if let ckError = error as? CKError, ckError.code == .unknownItem {
                _participantLocations.removeValue(forKey: participantId)
                return
            }
            throw LocationServiceError.networkError
        }
    }
    
    func getParticipantLocations(for tripId: UUID) async throws -> [UUID: ParticipantLocation] {
        let predicate = NSPredicate(format: "tripId == %@", tripId.uuidString)
        let query = CKQuery(recordType: "ParticipantLocation", predicate: predicate)
        query.sortDescriptors = [NSSortDescriptor(key: "timestamp", ascending: false)]
        
        do {
            let result = try await database.records(matching: query)
            var locations: [UUID: ParticipantLocation] = [:]
            
            for (_, recordResult) in result.matchResults {
                switch recordResult {
                case .success(let record):
                    if let participantLocation = parseParticipantLocation(from: record) {
                        locations[participantLocation.participantId] = participantLocation
                    }
                case .failure(let error):
                    print("Failed to fetch participant location: \(error)")
                }
            }
            
            // Update local cache
            _participantLocations = locations
            
            return locations
            
        } catch {
            throw LocationServiceError.networkError
        }
    }
    
    func subscribeToLocationUpdates(for tripId: UUID) async throws {
        // Remove existing subscription if any
        if let existingSubscription = activeSubscriptions[tripId] {
            try? await database.deleteSubscription(withID: existingSubscription.subscriptionID)
        }
        
        // Create new subscription
        let predicate = NSPredicate(format: "tripId == %@", tripId.uuidString)
        let subscription = CKQuerySubscription(
            recordType: "ParticipantLocation",
            predicate: predicate,
            subscriptionID: "trip_locations_\(tripId.uuidString)",
            options: [.firesOnRecordCreation, .firesOnRecordUpdate]
        )
        
        // Configure notification info
        let notificationInfo = CKSubscription.NotificationInfo()
        notificationInfo.shouldSendContentAvailable = true
        subscription.notificationInfo = notificationInfo
        
        do {
            let savedSubscription = try await database.save(subscription)
            activeSubscriptions[tripId] = savedSubscription
            
        } catch {
            throw LocationServiceError.networkError
        }
    }
    
    func unsubscribeFromLocationUpdates(for tripId: UUID) async throws {
        guard let subscription = activeSubscriptions[tripId] else {
            return
        }
        
        do {
            _ = try await database.deleteSubscription(withID: subscription.subscriptionID)
            activeSubscriptions.removeValue(forKey: tripId)
            
        } catch {
            // If subscription doesn't exist, that's fine
            if let ckError = error as? CKError, ckError.code == .unknownItem {
                activeSubscriptions.removeValue(forKey: tripId)
                return
            }
            throw LocationServiceError.networkError
        }
    }
    
    // MARK: - CloudKit Record Parsing
    private func parseParticipantLocation(from record: CKRecord) -> ParticipantLocation? {
        guard let participantIdString = record["participantId"] as? String,
              let participantId = UUID(uuidString: participantIdString),
              let latitude = record["latitude"] as? Double,
              let longitude = record["longitude"] as? Double,
              let timestamp = record["timestamp"] as? Date else {
            return nil
        }
        
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let speed = record["speed"] as? CLLocationSpeed
        let heading = record["heading"] as? CLLocationDirection
        let accuracy = record["accuracy"] as? CLLocationAccuracy ?? 0
        
        return ParticipantLocation(
            participantId: participantId,
            location: coordinate,
            timestamp: timestamp,
            speed: speed,
            heading: heading,
            accuracy: accuracy
        )
    }
    
    // MARK: - Push Notification Handling
    func handleLocationUpdateNotification(_ userInfo: [AnyHashable: Any]) async {
        guard let notification = CKNotification(fromRemoteNotificationDictionary: userInfo),
              let queryNotification = notification as? CKQueryNotification,
              let recordID = queryNotification.recordID else {
            return
        }
        
        do {
            let record = try await database.record(for: recordID)
            if let participantLocation = parseParticipantLocation(from: record) {
                _participantLocations[participantLocation.participantId] = participantLocation
            }
        } catch {
            print("Failed to fetch updated location record: \(error)")
        }
    }
    
    // MARK: - Cleanup
    func cleanup() async {
        // Unsubscribe from all active subscriptions
        for (tripId, _) in activeSubscriptions {
            try? await unsubscribeFromLocationUpdates(for: tripId)
        }
        
        // Clear local state
        _participantLocations.removeAll()
        subscriptions.removeAll()
    }
}

// MARK: - Location Staleness Check
extension LocationSharingService {
    
    func removeStaleLocations(olderThan threshold: TimeInterval = 300) {
        let cutoffTime = Date().addingTimeInterval(-threshold)
        
        _participantLocations = _participantLocations.filter { _, location in
            location.timestamp > cutoffTime
        }
    }
    
    func getStaleParticipants(threshold: TimeInterval = 300) -> [UUID] {
        let cutoffTime = Date().addingTimeInterval(-threshold)
        
        return _participantLocations.compactMap { participantId, location in
            location.timestamp <= cutoffTime ? participantId : nil
        }
    }
}