import Foundation
import Combine
import CoreLocation
import MapKit

// MARK: - Distance Calculation Service
class DistanceCalculationService: ObservableObject {
    
    // MARK: - Published Properties
    @Published private(set) var distanceCalculations: [UUID: [DistanceCalculation]] = [:]
    @Published private(set) var participantDistances: [UUID: [UUID: CLLocationDistance]] = [:]
    @Published private(set) var destinationDistances: [UUID: [UUID: CLLocationDistance]] = [:]
    
    // MARK: - Private Properties
    private let locationManager: LocationServiceProtocol
    private let mapService: MapServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    private var updateTimer: Timer?
    
    // Distance calculation cache
    private var distanceCache: [String: DistanceCalculation] = [:]
    private let cacheExpirationTime: TimeInterval = 300 // 5 minutes
    
    // MARK: - Initialization
    init(locationManager: LocationServiceProtocol, mapService: MapServiceProtocol) {
        self.locationManager = locationManager
        self.mapService = mapService
        setupLocationUpdates()
        startPeriodicUpdates()
    }
    
    deinit {
        updateTimer?.invalidate()
    }
    
    // MARK: - Public Methods
    
    /// Calculate real-time distance between two participants
    func calculateDistanceBetweenParticipants(_ participant1: Participant, _ participant2: Participant) async -> DistanceCalculation? {
        guard let location1 = participant1.currentLocation,
              let location2 = participant2.currentLocation else {
            return nil
        }
        
        let cacheKey = "\(participant1.id.uuidString)-\(participant2.id.uuidString)"
        
        // Check cache first
        if let cachedCalculation = distanceCache[cacheKey],
           Date().timeIntervalSince(cachedCalculation.lastUpdated) < cacheExpirationTime {
            return cachedCalculation
        }
        
        // Calculate straight-line distance
        let straightLineDistance = calculateStraightLineDistance(from: location1, to: location2)
        
        // Calculate driving distance
        let drivingDistance = await calculateDrivingDistance(from: location1, to: location2)
        let estimatedTime = drivingDistance.map { $0 / (60 * 1000 / 3600) } // Assuming 60 km/h average
        
        let calculation = DistanceCalculation(
            fromParticipant: participant1.id,
            toParticipant: participant2.id,
            straightLineDistance: straightLineDistance,
            drivingDistance: drivingDistance,
            estimatedDrivingTime: estimatedTime
        )
        
        // Cache the result
        distanceCache[cacheKey] = calculation
        
        return calculation
    }
    
    /// Calculate distance from participant to destination
    func calculateDistanceToDestination(_ participant: Participant, _ destination: Destination) async -> DistanceCalculation? {
        guard let participantLocation = participant.currentLocation else {
            return nil
        }
        
        let cacheKey = "\(participant.id.uuidString)-\(destination.id.uuidString)"
        
        // Check cache first
        if let cachedCalculation = distanceCache[cacheKey],
           Date().timeIntervalSince(cachedCalculation.lastUpdated) < cacheExpirationTime {
            return cachedCalculation
        }
        
        // Calculate straight-line distance
        let straightLineDistance = calculateStraightLineDistance(from: participantLocation, to: destination.coordinate)
        
        // Calculate driving distance
        let drivingDistance = await calculateDrivingDistance(from: participantLocation, to: destination.coordinate)
        let estimatedTime = drivingDistance.map { $0 / (60 * 1000 / 3600) } // Assuming 60 km/h average
        
        let calculation = DistanceCalculation(
            fromParticipant: participant.id,
            toDestination: destination.id,
            straightLineDistance: straightLineDistance,
            drivingDistance: drivingDistance,
            estimatedDrivingTime: estimatedTime
        )
        
        // Cache the result
        distanceCache[cacheKey] = calculation
        
        return calculation
    }
    
    /// Calculate distances from participant to next and final destinations
    func calculateDistancesToDestinations(_ participant: Participant, destinations: [Destination], currentDestinationIndex: Int) async -> [DistanceCalculation] {
        guard let participantLocation = participant.currentLocation else {
            return []
        }
        
        var calculations: [DistanceCalculation] = []
        
        // Calculate distance to next destination
        if currentDestinationIndex < destinations.count {
            let nextDestination = destinations[currentDestinationIndex]
            if let calculation = await calculateDistanceToDestination(participant, nextDestination) {
                calculations.append(calculation)
            }
        }
        
        // Calculate distance to final destination (if different from next)
        if destinations.count > 1 && currentDestinationIndex < destinations.count - 1 {
            let finalDestination = destinations.last!
            if let calculation = await calculateDistanceToDestination(participant, finalDestination) {
                calculations.append(calculation)
            }
        }
        
        return calculations
    }
    
    /// Update all distance calculations for a trip
    func updateDistanceCalculations(for trip: Trip) async {
        var newCalculations: [UUID: [DistanceCalculation]] = [:]
        var newParticipantDistances: [UUID: [UUID: CLLocationDistance]] = [:]
        var newDestinationDistances: [UUID: [UUID: CLLocationDistance]] = [:]
        
        let activeParticipants = trip.participants.filter { $0.isLocationSharingEnabled && $0.currentLocation != nil }
        
        // Calculate distances between all participants
        for i in 0..<activeParticipants.count {
            let participant1 = activeParticipants[i]
            var participantCalculations: [DistanceCalculation] = []
            var participantToParticipantDistances: [UUID: CLLocationDistance] = [:]
            var participantToDestinationDistances: [UUID: CLLocationDistance] = [:]
            
            // Distance to other participants
            for j in 0..<activeParticipants.count {
                if i != j {
                    let participant2 = activeParticipants[j]
                    if let calculation = await calculateDistanceBetweenParticipants(participant1, participant2) {
                        participantCalculations.append(calculation)
                        participantToParticipantDistances[participant2.id] = calculation.straightLineDistance
                    }
                }
            }
            
            // Distance to destinations
            let destinationCalculations = await calculateDistancesToDestinations(
                participant1,
                destinations: trip.destinations,
                currentDestinationIndex: trip.currentDestinationIndex
            )
            participantCalculations.append(contentsOf: destinationCalculations)
            
            for calculation in destinationCalculations {
                if let destinationId = calculation.toDestination {
                    participantToDestinationDistances[destinationId] = calculation.straightLineDistance
                }
            }
            
            newCalculations[participant1.id] = participantCalculations
            newParticipantDistances[participant1.id] = participantToParticipantDistances
            newDestinationDistances[participant1.id] = participantToDestinationDistances
        }
        
        await MainActor.run {
            self.distanceCalculations = newCalculations
            self.participantDistances = newParticipantDistances
            self.destinationDistances = newDestinationDistances
        }
        
        // Notify observers of distance updates
        NotificationCenter.default.post(
            name: .distanceCalculationsUpdated,
            object: DistanceUpdateNotification(
                tripId: trip.id,
                calculations: newCalculations,
                timestamp: Date()
            )
        )
    }
    
    /// Get distance between two specific participants
    func getDistanceBetweenParticipants(_ participant1Id: UUID, _ participant2Id: UUID) -> CLLocationDistance? {
        return participantDistances[participant1Id]?[participant2Id]
    }
    
    /// Get distance from participant to destination
    func getDistanceToDestination(_ participantId: UUID, _ destinationId: UUID) -> CLLocationDistance? {
        return destinationDistances[participantId]?[destinationId]
    }
    
    /// Identify participants who are significantly behind
    func getParticipantsBehind(for trip: Trip, threshold: CLLocationDistance = 5000) -> [Participant] {
        guard let leadParticipant = findLeadParticipant(in: trip) else {
            return []
        }
        
        var behindParticipants: [Participant] = []
        
        for participant in trip.participants {
            if participant.id != leadParticipant.id,
               let distance = getDistanceBetweenParticipants(leadParticipant.id, participant.id),
               distance > threshold {
                behindParticipants.append(participant)
            }
        }
        
        return behindParticipants
    }
    
    /// Find the participant who is furthest along the route
    func findLeadParticipant(in trip: Trip) -> Participant? {
        guard !trip.destinations.isEmpty,
              trip.currentDestinationIndex < trip.destinations.count else {
            return nil
        }
        
        let currentDestination = trip.destinations[trip.currentDestinationIndex]
        var leadParticipant: Participant?
        var shortestDistance: CLLocationDistance = .greatestFiniteMagnitude
        
        for participant in trip.participants {
            if let distance = getDistanceToDestination(participant.id, currentDestination.id),
               distance < shortestDistance {
                shortestDistance = distance
                leadParticipant = participant
            }
        }
        
        return leadParticipant
    }
    
    // MARK: - Private Methods
    
    private func setupLocationUpdates() {
        locationManager.locationUpdates
            .debounce(for: .seconds(5), scheduler: DispatchQueue.main)
            .sink { [weak self] _ in
                // Location updates will trigger distance recalculations
                // This is handled by the periodic update timer
            }
            .store(in: &cancellables)
    }
    
    private func startPeriodicUpdates() {
        updateTimer = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { [weak self] _ in
            // Periodic updates are handled by the RouteManager or TripViewModel
            // This timer just cleans up the cache
            self?.cleanupCache()
        }
    }
    
    private func cleanupCache() {
        let now = Date()
        distanceCache = distanceCache.filter { _, calculation in
            now.timeIntervalSince(calculation.lastUpdated) < cacheExpirationTime
        }
    }
    
    private func calculateStraightLineDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDistance {
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        return fromLocation.distance(from: toLocation)
    }
    
    private func calculateDrivingDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) async -> CLLocationDistance? {
        do {
            let route = try await mapService.calculateRoute(from: from, to: to, waypoints: [])
            return route.distance
        } catch {
            print("Failed to calculate driving distance: \(error)")
            return nil
        }
    }
}

// MARK: - Distance Update Notification
struct DistanceUpdateNotification {
    let tripId: UUID
    let calculations: [UUID: [DistanceCalculation]]
    let timestamp: Date
}

// MARK: - Notification Names
extension Notification.Name {
    static let distanceCalculationsUpdated = Notification.Name("distanceCalculationsUpdated")
    static let participantBehindDetected = Notification.Name("participantBehindDetected")
}

// MARK: - Distance Calculation Error
enum DistanceCalculationError: LocalizedError {
    case locationUnavailable
    case routeCalculationFailed
    case invalidParticipants
    case cacheError
    
    var errorDescription: String? {
        switch self {
        case .locationUnavailable:
            return "Location information unavailable"
        case .routeCalculationFailed:
            return "Failed to calculate route distance"
        case .invalidParticipants:
            return "Invalid participant data"
        case .cacheError:
            return "Distance calculation cache error"
        }
    }
}