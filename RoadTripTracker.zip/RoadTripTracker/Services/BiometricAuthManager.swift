import Foundation
import LocalAuthentication

// MARK: - Biometric Authentication Manager
class BiometricAuthManager {
    
    // MARK: - Biometric Types
    enum BiometricType {
        case none
        case touchID
        case faceID
        case opticID
        
        var displayName: String {
            switch self {
            case .none:
                return "None"
            case .touchID:
                return "Touch ID"
            case .faceID:
                return "Face ID"
            case .opticID:
                return "Optic ID"
            }
        }
        
        var iconName: String {
            switch self {
            case .none:
                return "touchid"
            case .touchID:
                return "touchid"
            case .faceID:
                return "faceid"
            case .opticID:
                return "opticid"
            }
        }
    }
    
    // MARK: - Properties
    private let context = LAContext()
    
    // MARK: - Biometric Availability
    var biometricType: BiometricType {
        var error: NSError?
        
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            return .none
        }
        
        switch context.biometryType {
        case .none:
            return .none
        case .touchID:
            return .touchID
        case .faceID:
            return .faceID
        case .opticID:
            return .opticID
        @unknown default:
            return .none
        }
    }
    
    var isBiometricAvailable: Bool {
        return biometricType != .none
    }
    
    var biometricErrorDescription: String? {
        var error: NSError?
        context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)
        return error?.localizedDescription
    }
    
    // MARK: - Authentication Methods
    func authenticateWithBiometrics(reason: String) async throws -> Bool {
        let context = LAContext()
        
        // Check if biometrics are available
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            if let error = error {
                throw BiometricError.from(laError: error)
            }
            throw BiometricError.notAvailable
        }
        
        do {
            let result = try await context.evaluatePolicy(
                .deviceOwnerAuthenticationWithBiometrics,
                localizedReason: reason
            )
            return result
        } catch let error as LAError {
            throw BiometricError.from(laError: error)
        } catch {
            throw BiometricError.unknown(error.localizedDescription)
        }
    }
    
    func authenticateWithDevicePasscode(reason: String) async throws -> Bool {
        let context = LAContext()
        
        do {
            let result = try await context.evaluatePolicy(
                .deviceOwnerAuthentication,
                localizedReason: reason
            )
            return result
        } catch let error as LAError {
            throw BiometricError.from(laError: error)
        } catch {
            throw BiometricError.unknown(error.localizedDescription)
        }
    }
    
    // MARK: - Settings Management
    func setBiometricPreference(_ enabled: Bool, for userId: UUID) {
        UserDefaults.standard.set(enabled, forKey: "biometric_enabled_\(userId.uuidString)")
    }
    
    func getBiometricPreference(for userId: UUID) -> Bool {
        return UserDefaults.standard.bool(forKey: "biometric_enabled_\(userId.uuidString)")
    }
    
    func clearBiometricPreference(for userId: UUID) {
        UserDefaults.standard.removeObject(forKey: "biometric_enabled_\(userId.uuidString)")
    }
    
    // MARK: - Biometric Change Detection
    func hasBiometricDataChanged() -> Bool {
        let context = LAContext()
        var error: NSError?
        
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            return true // Assume changed if we can't evaluate
        }
        
        // Check if biometric data has changed since last successful authentication
        // This is a simplified check - in production, you might want to store
        // and compare biometric domain state
        return false
    }
}

// MARK: - Biometric Error
enum BiometricError: LocalizedError {
    case notAvailable
    case notEnrolled
    case passcodeNotSet
    case cancelled
    case fallback
    case lockout
    case systemCancel
    case userCancel
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .notAvailable:
            return "Biometric authentication is not available on this device"
        case .notEnrolled:
            return "No biometric data is enrolled on this device"
        case .passcodeNotSet:
            return "Device passcode is not set"
        case .cancelled:
            return "Biometric authentication was cancelled"
        case .fallback:
            return "User chose to use fallback authentication"
        case .lockout:
            return "Biometric authentication is locked out"
        case .systemCancel:
            return "System cancelled biometric authentication"
        case .userCancel:
            return "User cancelled biometric authentication"
        case .unknown(let message):
            return "Biometric authentication failed: \(message)"
        }
    }
    
    static func from(laError: Error) -> BiometricError {
        guard let laError = laError as? LAError else {
            return .unknown(laError.localizedDescription)
        }
        
        switch laError.code {
        case .biometryNotAvailable:
            return .notAvailable
        case .biometryNotEnrolled:
            return .notEnrolled
        case .passcodeNotSet:
            return .passcodeNotSet
        case .authenticationFailed:
            return .cancelled
        case .userCancel:
            return .userCancel
        case .userFallback:
            return .fallback
        case .systemCancel:
            return .systemCancel
        case .biometryLockout:
            return .lockout
        default:
            return .unknown(laError.localizedDescription)
        }
    }
}

// MARK: - Biometric Error Equatable Extension
extension BiometricError: Equatable {
    static func == (lhs: BiometricError, rhs: BiometricError) -> Bool {
        switch (lhs, rhs) {
        case (.notAvailable, .notAvailable),
             (.notEnrolled, .notEnrolled),
             (.passcodeNotSet, .passcodeNotSet),
             (.cancelled, .cancelled),
             (.fallback, .fallback),
             (.lockout, .lockout),
             (.systemCancel, .systemCancel),
             (.userCancel, .userCancel):
            return true
        case (.unknown(let lhsMessage), .unknown(let rhsMessage)):
            return lhsMessage == rhsMessage
        default:
            return false
        }
    }
}