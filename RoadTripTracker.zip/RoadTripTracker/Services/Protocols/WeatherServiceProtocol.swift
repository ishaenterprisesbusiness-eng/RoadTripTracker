import Foundation
import CoreLocation

// MARK: - Weather Service Protocol
protocol WeatherServiceProtocol {
    func getCurrentWeather(for coordinate: CLLocationCoordinate2D) async throws -> WeatherData
    func getWeatherForecast(for coordinate: CLLocationCoordinate2D, days: Int) async throws -> [WeatherData]
    func getWeatherAlerts(for coordinate: CLLocationCoordinate2D) async throws -> [WeatherAlert]
    func getWeatherBasedStopRecommendations(for coordinate: CLLocationCoordinate2D, currentWeather: WeatherData) async throws -> [WeatherStopRecommendation]
}

// MARK: - Weather Data Model
struct WeatherData: Codable {
    let location: CLLocationCoordinate2D
    let timestamp: Date
    let temperature: Double
    let feelsLike: Double
    let humidity: Double
    let windSpeed: Double
    let windDirection: Double
    let visibility: Double
    let uvIndex: Double
    let condition: WeatherCondition
    let description: String
    
    init(location: CLLocationCoordinate2D, timestamp: Date = Date(), temperature: Double, feelsLike: Double, humidity: Double, windSpeed: Double, windDirection: Double, visibility: Double, uvIndex: Double, condition: WeatherCondition, description: String) {
        self.location = location
        self.timestamp = timestamp
        self.temperature = temperature
        self.feelsLike = feelsLike
        self.humidity = humidity
        self.windSpeed = windSpeed
        self.windDirection = windDirection
        self.visibility = visibility
        self.uvIndex = uvIndex
        self.condition = condition
        self.description = description
    }
}

// MARK: - Weather Condition Enum
enum WeatherCondition: String, Codable, CaseIterable {
    case clear = "clear"
    case partlyCloudy = "partly_cloudy"
    case cloudy = "cloudy"
    case rain = "rain"
    case snow = "snow"
    case thunderstorm = "thunderstorm"
    case fog = "fog"
    case unknown = "unknown"
}

// MARK: - Weather Alert Model
struct WeatherAlert: Codable, Identifiable {
    let id: UUID
    let title: String
    let description: String
    let severity: WeatherAlertSeverity
    let startTime: Date
    let endTime: Date
    let affectedArea: String
    
    init(id: UUID = UUID(), title: String, description: String, severity: WeatherAlertSeverity, startTime: Date, endTime: Date, affectedArea: String) {
        self.id = id
        self.title = title
        self.description = description
        self.severity = severity
        self.startTime = startTime
        self.endTime = endTime
        self.affectedArea = affectedArea
    }
}

// MARK: - Weather Alert Severity
enum WeatherAlertSeverity: String, Codable {
    case minor = "minor"
    case moderate = "moderate"
    case severe = "severe"
    case extreme = "extreme"
}

// MARK: - Weather Stop Recommendation Model
struct WeatherStopRecommendation: Codable, Identifiable {
    let id: UUID
    let type: WeatherStopType
    let priority: WeatherStopPriority
    let title: String
    let description: String
    let recommendedStopTypes: [WeatherRecommendedStopType]
    let estimatedWaitTime: TimeInterval
    
    init(id: UUID = UUID(), type: WeatherStopType, priority: WeatherStopPriority, title: String, description: String, recommendedStopTypes: [WeatherRecommendedStopType], estimatedWaitTime: TimeInterval) {
        self.id = id
        self.type = type
        self.priority = priority
        self.title = title
        self.description = description
        self.recommendedStopTypes = recommendedStopTypes
        self.estimatedWaitTime = estimatedWaitTime
    }
}

// MARK: - Weather Recommended Stop Type
enum WeatherRecommendedStopType: String, Codable {
    case fuel = "fuel"
    case food = "food"
    case accommodation = "accommodation"
    case shelter = "shelter"
    case other = "other"
}

// MARK: - Weather Stop Type
enum WeatherStopType: String, Codable {
    case shelter = "shelter"
    case winterConditions = "winter_conditions"
    case highWinds = "high_winds"
    case lowVisibility = "low_visibility"
    case heatWarning = "heat_warning"
    case heavyRain = "heavy_rain"
}

// MARK: - Weather Stop Priority
enum WeatherStopPriority: String, Codable {
    case low = "low"
    case medium = "medium"
    case high = "high"
    case critical = "critical"
}

// MARK: - Weather Service Error
enum WeatherServiceError: LocalizedError {
    case locationNotFound
    case apiKeyInvalid
    case networkError
    case dataParsingError
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .locationNotFound:
            return "Location not found"
        case .apiKeyInvalid:
            return "Invalid API key"
        case .networkError:
            return "Network connection error"
        case .dataParsingError:
            return "Failed to parse weather data"
        case .unknown(let message):
            return message
        }
    }
}