import Foundation
import CoreLocation
import Combine

// MARK: - Geofencing Service Protocol
protocol GeofencingServiceProtocol {
    func addGeofence(for destination: Destination, radius: CLLocationDistance) async throws
    func removeGeofence(for destinationId: UUID) async throws
    func removeAllGeofences() async throws
    var geofenceEvents: AnyPublisher<GeofenceEvent, Never> { get }
}

// MARK: - Geofence Event Model
struct GeofenceEvent: Codable {
    let id: UUID
    let destinationId: UUID
    let eventType: GeofenceEventType
    let timestamp: Date
    let location: CLLocationCoordinate2D
    
    init(id: UUID = UUID(), destinationId: UUID, eventType: GeofenceEventType, timestamp: Date = Date(), location: CLLocationCoordinate2D) {
        self.id = id
        self.destinationId = destinationId
        self.eventType = eventType
        self.timestamp = timestamp
        self.location = location
    }
}

// MARK: - Geofence Event Type
enum GeofenceEventType: String, Codable {
    case entered = "entered"
    case exited = "exited"
}

// MARK: - Geofencing Service Error
enum GeofencingServiceError: LocalizedError {
    case locationPermissionDenied
    case geofenceNotFound
    case maximumGeofencesReached
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .locationPermissionDenied:
            return "Location permission denied"
        case .geofenceNotFound:
            return "Geofence not found"
        case .maximumGeofencesReached:
            return "Maximum number of geofences reached"
        case .unknown(let message):
            return message
        }
    }
}