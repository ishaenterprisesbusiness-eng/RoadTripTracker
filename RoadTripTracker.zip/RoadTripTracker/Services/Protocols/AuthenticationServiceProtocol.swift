import Foundation
import Combine

// MARK: - Authentication Service Protocol
protocol AuthenticationServiceProtocol {
    var currentUser: User? { get }
    var isAuthenticated: Bool { get }
    var authenticationStatePublisher: AnyPublisher<AuthenticationState, Never> { get }
    
    func signUp(userData: UserRegistrationData) async throws -> User
    func signIn(email: String, password: String) async throws -> User
    func signOut() async throws
    func resetPassword(email: String) async throws
    func verifyEmail(token: String) async throws
    func refreshToken() async throws
    func enableBiometricAuth() async throws -> Bool
    func authenticateWithBiometrics() async throws -> User
    func getCurrentUser() async throws -> User?
    func updateUserVehicle(_ vehicle: Vehicle) async throws
    func updateUserProfile(_ user: User) async throws
}

// MARK: - User Registration Data
struct UserRegistrationData {
    let username: String
    let email: String
    let password: String
    let city: String
    let dateOfBirth: Date
    let vehicle: Vehicle?
    
    init(username: String, email: String, password: String, city: String, dateOfBirth: Date, vehicle: Vehicle? = nil) {
        self.username = username
        self.email = email
        self.password = password
        self.city = city
        self.dateOfBirth = dateOfBirth
        self.vehicle = vehicle
    }
}

// MARK: - Authentication State
enum AuthenticationState {
    case unauthenticated
    case authenticating
    case authenticated(User)
    case emailVerificationRequired
    case error(AuthenticationError)
}

// MARK: - Authentication Error
enum AuthenticationError: LocalizedError {
    case invalidCredentials
    case emailAlreadyExists
    case emailNotVerified
    case weakPassword
    case networkError
    case biometricNotAvailable
    case biometricAuthFailed
    case tokenExpired
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .invalidCredentials:
            return "Invalid email or password"
        case .emailAlreadyExists:
            return "An account with this email already exists"
        case .emailNotVerified:
            return "Please verify your email address before signing in"
        case .weakPassword:
            return "Password must be at least 8 characters with uppercase, lowercase, and numbers"
        case .networkError:
            return "Network connection error. Please try again."
        case .biometricNotAvailable:
            return "Biometric authentication is not available on this device"
        case .biometricAuthFailed:
            return "Biometric authentication failed"
        case .tokenExpired:
            return "Session expired. Please sign in again."
        case .unknown(let message):
            return message
        }
    }
}