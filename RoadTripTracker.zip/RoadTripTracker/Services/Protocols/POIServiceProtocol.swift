import Foundation
import CoreLocation
import MapKit

// MARK: - POI Service Protocol
protocol POIServiceProtocol {
    // MARK: - POI Discovery
    func discoverPOIsNearRoute(route: [CLLocationCoordinate2D], radius: CLLocationDistance, filter: POISearchFilter) async throws -> [PointOfInterest]
    func discoverPOIsNearLocation(coordinate: CLLocationCoordinate2D, radius: CLLocationDistance, filter: POISearchFilter) async throws -> [PointOfInterest]
    func searchPOIs(query: String, near coordinate: CLLocationCoordinate2D, filter: POISearchFilter) async throws -> [PointOfInterest]
    
    // MARK: - POI Details
    func getPOIDetails(placeId: String) async throws -> PointOfInterest
    func getPOIPhotos(placeId: String) async throws -> [URL]
    func getPOIReviews(placeId: String) async throws -> [POIReview]
    
    // MARK: - POI Proposals
    func proposePOI(poi: PointOfInterest, for trip: Trip, insertionIndex: Int, message: String?) async throws -> POIProposal
    func votePOIProposal(proposalId: UUID, participantId: UUID, vote: VoteType, comment: String?) async throws
    func getPOIProposals(for tripId: UUID) async throws -> [POIProposal]
    func processPOIProposal(proposalId: UUID) async throws -> POIProposalStatus
    
    // MARK: - POI Notifications
    func enablePOINotifications(for tripId: UUID, categories: Set<POICategory>) async throws
    func disablePOINotifications(for tripId: UUID) async throws
    func checkForNearbyPOIs(location: CLLocationCoordinate2D, tripId: UUID) async throws -> [PointOfInterest]
    
    // MARK: - POI Management
    func addPOIToTrip(poi: PointOfInterest, trip: Trip, insertionIndex: Int) async throws -> Trip
    func removePOIFromTrip(poiId: UUID, trip: Trip) async throws -> Trip
    func updatePOIInTrip(poi: PointOfInterest, trip: Trip) async throws -> Trip
}

// MARK: - POI Service Error
enum POIServiceError: LocalizedError {
    case discoveryFailed(String)
    case detailsFailed(String)
    case proposalFailed(String)
    case votingFailed(String)
    case notificationFailed(String)
    case networkError
    case invalidLocation
    case invalidFilter
    case unauthorized
    case rateLimitExceeded
    
    var errorDescription: String? {
        switch self {
        case .discoveryFailed(let message):
            return "POI discovery failed: \(message)"
        case .detailsFailed(let message):
            return "Failed to get POI details: \(message)"
        case .proposalFailed(let message):
            return "POI proposal failed: \(message)"
        case .votingFailed(let message):
            return "POI voting failed: \(message)"
        case .notificationFailed(let message):
            return "POI notification failed: \(message)"
        case .networkError:
            return "Network connection error"
        case .invalidLocation:
            return "Invalid location provided"
        case .invalidFilter:
            return "Invalid search filter"
        case .unauthorized:
            return "Unauthorized access"
        case .rateLimitExceeded:
            return "Rate limit exceeded, please try again later"
        }
    }
}