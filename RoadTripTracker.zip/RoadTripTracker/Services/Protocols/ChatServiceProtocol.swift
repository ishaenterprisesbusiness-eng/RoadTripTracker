import Foundation
import Combine
import UIKit
import CoreLocation

// MARK: - Chat Service Protocol
protocol ChatServiceProtocol {
    var messageUpdates: AnyPublisher<Message, Never> { get }
    var connectionStatus: AnyPublisher<ConnectionStatus, Never> { get }
    
    func sendMessage(_ content: String, to tripId: UUID) async throws -> Message
    func sendLocationMessage(_ location: CLLocationCoordinate2D, to tripId: UUID) async throws -> Message
    func sendPhotoMessage(_ photo: UIImage, caption: String?, to tripId: UUID) async throws -> Message
    func sendEmergencyMessage(_ content: String, location: CLLocationCoordinate2D, to tripId: UUID) async throws -> Message
    func getMessages(for tripId: UUID, limit: Int, offset: Int) async throws -> [Message]
    func markMessageAsRead(_ messageId: UUID, by userId: UUID) async throws
    func deleteMessage(_ messageId: UUID) async throws
    func subscribeToMessages(for tripId: UUID) async throws
    func unsubscribeFromMessages(for tripId: UUID) async throws
}

// MARK: - Photo Sharing Service Protocol
protocol PhotoSharingServiceProtocol {
    var photoUpdates: AnyPublisher<PhotoShare, Never> { get }
    
    func sharePhoto(_ photo: UIImage, caption: String?, location: CLLocationCoordinate2D?, to tripId: UUID) async throws -> PhotoShare
    func getTripPhotos(for tripId: UUID) async throws -> [PhotoShare]
    func downloadPhoto(from url: URL) async throws -> UIImage
    func deletePhoto(_ photoId: UUID) async throws
    func createTripAlbum(for tripId: UUID) async throws -> TripAlbum
    func downloadAllPhotos(for tripId: UUID) async throws -> [UIImage]
}

// MARK: - Trip Album
struct TripAlbum: Codable, Identifiable {
    let id: UUID
    let tripId: UUID
    var name: String
    var photos: [PhotoShare]
    var createdAt: Date
    var coverPhotoURL: URL?
    
    init(id: UUID = UUID(), tripId: UUID, name: String, photos: [PhotoShare] = [], createdAt: Date = Date(), coverPhotoURL: URL? = nil) {
        self.id = id
        self.tripId = tripId
        self.name = name
        self.photos = photos
        self.createdAt = createdAt
        self.coverPhotoURL = coverPhotoURL
    }
}

// MARK: - Connection Status
enum ConnectionStatus {
    case connected
    case connecting
    case disconnected
    case error(String)
}

// MARK: - Chat Service Error
enum ChatServiceError: LocalizedError {
    case messageNotSent
    case photoUploadFailed
    case photoDownloadFailed
    case connectionFailed
    case messageNotFound
    case insufficientPermissions
    case fileSizeTooLarge
    case unsupportedFileType
    case networkError
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .messageNotSent:
            return "Failed to send message"
        case .photoUploadFailed:
            return "Failed to upload photo"
        case .photoDownloadFailed:
            return "Failed to download photo"
        case .connectionFailed:
            return "Failed to connect to chat service"
        case .messageNotFound:
            return "Message not found"
        case .insufficientPermissions:
            return "Insufficient permissions"
        case .fileSizeTooLarge:
            return "File size too large"
        case .unsupportedFileType:
            return "Unsupported file type"
        case .networkError:
            return "Network connection error"
        case .unknown(let message):
            return message
        }
    }
}