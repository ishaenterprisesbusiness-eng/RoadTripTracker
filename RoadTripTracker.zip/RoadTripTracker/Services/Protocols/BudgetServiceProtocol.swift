import Foundation
import Combine

// MARK: - Budget Service Protocol
protocol BudgetServiceProtocol {
    func createBudget(for tripId: UUID, totalBudget: Double, perPersonBudget: Double?) async throws -> Budget
    func addExpense(_ expense: Expense, to tripId: UUID) async throws
    func updateExpense(_ expense: Expense) async throws
    func deleteExpense(_ expenseId: UUID, from tripId: UUID) async throws
    func getBudgetSummary(for tripId: UUID) async throws -> BudgetSummary
    var budgetUpdates: AnyPublisher<BudgetUpdate, Never> { get }
}

// MARK: - Budget Summary Model
struct BudgetSummary: Codable {
    let tripId: UUID
    let totalBudget: Double
    let totalSpent: Double
    let remainingBudget: Double
    let spendingByCategory: [ExpenseCategory: Double]
    let spendingByParticipant: [UUID: Double]
    let averageSpendingPerDay: Double
    let projectedTotalSpending: Double
    
    init(tripId: UUID, totalBudget: Double, totalSpent: Double, remainingBudget: Double, spendingByCategory: [ExpenseCategory: Double] = [:], spendingByParticipant: [UUID: Double] = [:], averageSpendingPerDay: Double = 0, projectedTotalSpending: Double = 0) {
        self.tripId = tripId
        self.totalBudget = totalBudget
        self.totalSpent = totalSpent
        self.remainingBudget = remainingBudget
        self.spendingByCategory = spendingByCategory
        self.spendingByParticipant = spendingByParticipant
        self.averageSpendingPerDay = averageSpendingPerDay
        self.projectedTotalSpending = projectedTotalSpending
    }
}

// MARK: - Budget Update Model
struct BudgetUpdate: Codable {
    let tripId: UUID
    let updateType: BudgetUpdateType
    let expense: Expense?
    let summary: BudgetSummary
    let timestamp: Date
    
    init(tripId: UUID, updateType: BudgetUpdateType, expense: Expense? = nil, summary: BudgetSummary, timestamp: Date = Date()) {
        self.tripId = tripId
        self.updateType = updateType
        self.expense = expense
        self.summary = summary
        self.timestamp = timestamp
    }
}

// MARK: - Budget Update Type
enum BudgetUpdateType: String, Codable {
    case expenseAdded = "expense_added"
    case expenseUpdated = "expense_updated"
    case expenseDeleted = "expense_deleted"
    case budgetUpdated = "budget_updated"
}

// MARK: - Budget Service Error
enum BudgetServiceError: LocalizedError {
    case budgetNotFound
    case expenseNotFound
    case insufficientBudget
    case invalidAmount
    case networkError
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .budgetNotFound:
            return "Budget not found"
        case .expenseNotFound:
            return "Expense not found"
        case .insufficientBudget:
            return "Insufficient budget"
        case .invalidAmount:
            return "Invalid amount"
        case .networkError:
            return "Network connection error"
        case .unknown(let message):
            return message
        }
    }
}