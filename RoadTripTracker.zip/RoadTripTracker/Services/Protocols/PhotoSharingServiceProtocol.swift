import Foundation
import CoreLocation
import UIKit
import Combine

// MARK: - Photo Sharing Service Protocol
protocol PhotoSharingServiceProtocol {
    func sharePhoto(_ photo: UIImage, caption: String?, tripId: UUID) async throws
    func getTripPhotos(for tripId: UUID) async throws -> [PhotoShare]
    func deletePhoto(_ photoId: UUID) async throws
    var photoUpdates: AnyPublisher<PhotoShare, Never> { get }
}



// MARK: - Photo Sharing Service Error
enum PhotoSharingServiceError: LocalizedError {
    case uploadFailed
    case photoNotFound
    case insufficientPermissions
    case networkError
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .uploadFailed:
            return "Failed to upload photo"
        case .photoNotFound:
            return "Photo not found"
        case .insufficientPermissions:
            return "Insufficient permissions"
        case .networkError:
            return "Network connection error"
        case .unknown(let message):
            return message
        }
    }
}