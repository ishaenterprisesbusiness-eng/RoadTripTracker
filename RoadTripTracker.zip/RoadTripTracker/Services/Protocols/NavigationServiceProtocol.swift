import Foundation
import CoreLocation
import MapKit
import Combine

// MARK: - Navigation Service Protocol
protocol NavigationServiceProtocol {
    var currentRoute: Route? { get }
    var navigationUpdates: AnyPublisher<NavigationUpdate, Never> { get }
    var routeProgress: AnyPublisher<RouteProgress, Never> { get }
    
    func startNavigation(route: Route) async throws
    func stopNavigation() async throws
    func recalculateRoute(from currentLocation: CLLocationCoordinate2D) async throws -> Route
    func getNextInstruction() -> RouteStep?
    func isOffRoute(currentLocation: CLLocationCoordinate2D, threshold: CLLocationDistance) -> Bool
}