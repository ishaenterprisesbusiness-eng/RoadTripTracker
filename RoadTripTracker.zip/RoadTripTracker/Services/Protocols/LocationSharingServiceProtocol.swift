import Foundation
import CoreLocation
import Combine

// MARK: - Location Sharing Service Protocol
protocol LocationSharingServiceProtocol {
    func startLocationSharing(for tripId: UUID) async throws
    func stopLocationSharing() async throws
    func updateLocation(_ location: CLLocation, for tripId: UUID) async throws
    var locationUpdates: AnyPublisher<CLLocation, Never> { get }
}

// MARK: - Location Sharing Service Error
enum LocationSharingServiceError: LocalizedError {
    case locationPermissionDenied
    case locationServicesDisabled
    case networkError
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .locationPermissionDenied:
            return "Location permission denied"
        case .locationServicesDisabled:
            return "Location services disabled"
        case .networkError:
            return "Network connection error"
        case .unknown(let message):
            return message
        }
    }
}