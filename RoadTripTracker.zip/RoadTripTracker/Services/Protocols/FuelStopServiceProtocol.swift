import Foundation
import CoreLocation
import Combine

// MARK: - Fuel Stop Service Protocol
protocol FuelStopServiceProtocol {
    var fuelStopUpdates: AnyPublisher<FuelStop, Never> { get }
    var approachingFuelStopNotifications: AnyPublisher<FuelStopApproachNotification, Never> { get }
    
    func findNearbyGasStations(coordinate: CLLocationCoordinate2D, radius: Double) async throws -> [GasStation]
    func findGasStationsAlongRoute(route: [CLLocationCoordinate2D], searchRadius: Double) async throws -> [GasStation]
    func proposeFuelStop(gasStation: GasStation, tripId: UUID, proposedBy: UUID, notes: String?) async throws -> FuelStop
    func approveFuelStop(fuelStopId: UUID, participantId: UUID) async throws
    func rejectFuelStop(fuelStopId: UUID, participantId: UUID, reason: String?) async throws
    func checkInAtFuelStop(fuelStopId: UUID, participantId: UUID, fuelAmount: Double?, fuelCost: Double?, notes: String?) async throws
    func markReadyToContinue(fuelStopId: UUID, participantId: UUID) async throws
    func cancelFuelStop(fuelStopId: UUID, cancelledBy: UUID, reason: String?) async throws
    func getFuelStopsForTrip(tripId: UUID) async throws -> [FuelStop]
    func getActiveFuelStop(tripId: UUID) async throws -> FuelStop?
    func addFuelStopToRoute(fuelStop: FuelStop) async throws
    func monitorApproachingFuelStops(tripId: UUID, participantLocation: CLLocationCoordinate2D) async throws
}

// MARK: - Fuel Stop Approach Notification
struct FuelStopApproachNotification: Codable {
    let fuelStopId: UUID
    let participantId: UUID
    let gasStation: GasStation
    let distanceToStop: CLLocationDistance
    let estimatedArrivalTime: TimeInterval
    let notificationType: FuelStopNotificationType
    
    init(fuelStopId: UUID, participantId: UUID, gasStation: GasStation, distanceToStop: CLLocationDistance, estimatedArrivalTime: TimeInterval, notificationType: FuelStopNotificationType) {
        self.fuelStopId = fuelStopId
        self.participantId = participantId
        self.gasStation = gasStation
        self.distanceToStop = distanceToStop
        self.estimatedArrivalTime = estimatedArrivalTime
        self.notificationType = notificationType
    }
}

// MARK: - Fuel Stop Notification Type
enum FuelStopNotificationType: String, Codable, CaseIterable {
    case approaching = "approaching"
    case arrived = "arrived"
    case waitingForGroup = "waiting_for_group"
    case readyToContinue = "ready_to_continue"
    
    var displayMessage: String {
        switch self {
        case .approaching: return "Approaching fuel stop"
        case .arrived: return "Arrived at fuel stop"
        case .waitingForGroup: return "Waiting for group at fuel stop"
        case .readyToContinue: return "Ready to continue from fuel stop"
        }
    }
}