import Foundation
import CoreLocation

// MARK: - Accommodation Service Protocol
protocol AccommodationServiceProtocol {
    /// Search for accommodations near a specific location
    func searchAccommodations(near coordinate: CLLocationCoordinate2D, radius: Double, filters: AccommodationSearchFilters) async throws -> [Accommodation]
    
    /// Search for accommodations along a route
    func searchAccommodationsAlongRoute(route: [CLLocationCoordinate2D], filters: AccommodationSearchFilters) async throws -> [Accommodation]
    
    /// Get detailed information for a specific accommodation
    func getAccommodationDetails(accommodationId: String) async throws -> Accommodation
    
    /// Check availability for specific dates
    func checkAvailability(accommodationId: String, checkIn: Date, checkOut: Date, guests: Int) async throws -> AccommodationAvailability
    
    /// Get booking information and links
    func getBookingInfo(accommodationId: String) async throws -> AccommodationBookingInfo
    
    /// Add accommodation as waypoint to trip
    func addAccommodationToTrip(accommodation: Accommodation, trip: Trip) async throws -> Trip
}

// MARK: - Accommodation Booking Info
struct AccommodationBookingInfo: Codable {
    let accommodationId: String
    let bookingURL: URL?
    let phoneNumber: String?
    let email: String?
    let bookingPlatforms: [BookingPlatform]
    let directBookingAvailable: Bool
    let cancellationPolicy: String?
    let paymentMethods: [PaymentMethod]
    
    init(accommodationId: String, bookingURL: URL? = nil, phoneNumber: String? = nil, email: String? = nil, bookingPlatforms: [BookingPlatform] = [], directBookingAvailable: Bool = false, cancellationPolicy: String? = nil, paymentMethods: [PaymentMethod] = []) {
        self.accommodationId = accommodationId
        self.bookingURL = bookingURL
        self.phoneNumber = phoneNumber
        self.email = email
        self.bookingPlatforms = bookingPlatforms
        self.directBookingAvailable = directBookingAvailable
        self.cancellationPolicy = cancellationPolicy
        self.paymentMethods = paymentMethods
    }
}

// MARK: - Booking Platform
struct BookingPlatform: Codable, Identifiable {
    let id: String
    let name: String
    let url: URL
    let price: Double?
    let currency: String
    let availability: Bool
    
    init(id: String, name: String, url: URL, price: Double? = nil, currency: String = "USD", availability: Bool = true) {
        self.id = id
        self.name = name
        self.url = url
        self.price = price
        self.currency = currency
        self.availability = availability
    }
}

// MARK: - Payment Method
enum PaymentMethod: String, CaseIterable, Codable {
    case creditCard = "credit_card"
    case debitCard = "debit_card"
    case paypal = "paypal"
    case applePay = "apple_pay"
    case googlePay = "google_pay"
    case bankTransfer = "bank_transfer"
    case cash = "cash"
    
    var displayName: String {
        switch self {
        case .creditCard: return "Credit Card"
        case .debitCard: return "Debit Card"
        case .paypal: return "PayPal"
        case .applePay: return "Apple Pay"
        case .googlePay: return "Google Pay"
        case .bankTransfer: return "Bank Transfer"
        case .cash: return "Cash"
        }
    }
}

// MARK: - Accommodation Service Error
enum AccommodationServiceError: LocalizedError {
    case searchFailed(String)
    case accommodationNotFound
    case availabilityCheckFailed
    case bookingInfoUnavailable
    case networkError
    case invalidLocation
    case invalidDateRange
    case noAccommodationsFound
    
    var errorDescription: String? {
        switch self {
        case .searchFailed(let message):
            return "Accommodation search failed: \(message)"
        case .accommodationNotFound:
            return "Accommodation not found"
        case .availabilityCheckFailed:
            return "Unable to check availability"
        case .bookingInfoUnavailable:
            return "Booking information unavailable"
        case .networkError:
            return "Network connection error"
        case .invalidLocation:
            return "Invalid location provided"
        case .invalidDateRange:
            return "Invalid date range"
        case .noAccommodationsFound:
            return "No accommodations found matching your criteria"
        }
    }
}