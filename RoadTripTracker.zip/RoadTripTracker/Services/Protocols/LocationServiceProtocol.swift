import Foundation
import Combine
import CoreLocation

// MARK: - Location Service Protocol
protocol LocationServiceProtocol {
    var currentLocation: CLLocation? { get }
    var authorizationStatus: CLAuthorizationStatus { get }
    var locationUpdates: AnyPublisher<CLLocation, Never> { get }
    var authorizationUpdates: AnyPublisher<CLAuthorizationStatus, Never> { get }
    var isLocationSharingEnabled: Bool { get }
    
    func requestLocationPermission() async throws
    func startLocationSharing() async throws
    func stopLocationSharing()
    func getCurrentLocation() async throws -> CLLocation
    func startMonitoringSignificantLocationChanges()
    func stopMonitoringSignificantLocationChanges()
    func calculateDistance(from: CLLocation, to: CLLocation) -> CLLocationDistance
    func calculateDrivingDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) async throws -> CLLocationDistance
    func isLocationStale(_ location: CLLocation, threshold: TimeInterval) -> Bool
}

// MARK: - Location Sharing Service Protocol
protocol LocationSharingServiceProtocol {
    var participantLocations: AnyPublisher<[UUID: ParticipantLocation], Never> { get }
    
    func shareLocation(_ location: CLLocation, for participantId: UUID, in tripId: UUID) async throws
    func stopSharingLocation(for participantId: UUID, in tripId: UUID) async throws
    func getParticipantLocations(for tripId: UUID) async throws -> [UUID: ParticipantLocation]
    func subscribeToLocationUpdates(for tripId: UUID) async throws
    func unsubscribeFromLocationUpdates(for tripId: UUID) async throws
}

// MARK: - Participant Location
struct ParticipantLocation: Codable {
    let participantId: UUID
    let location: CLLocationCoordinate2D
    let timestamp: Date
    let speed: CLLocationSpeed?
    let heading: CLLocationDirection?
    let accuracy: CLLocationAccuracy
    
    init(participantId: UUID, location: CLLocationCoordinate2D, timestamp: Date = Date(), speed: CLLocationSpeed? = nil, heading: CLLocationDirection? = nil, accuracy: CLLocationAccuracy = 0) {
        self.participantId = participantId
        self.location = location
        self.timestamp = timestamp
        self.speed = speed
        self.heading = heading
        self.accuracy = accuracy
    }
}

// MARK: - Geofencing Service Protocol
protocol GeofencingServiceProtocol {
    func addGeofence(for destination: Destination, radius: CLLocationDistance) async throws
    func removeGeofence(for destinationId: UUID) async throws
    func removeAllGeofences() async throws
    var geofenceEvents: AnyPublisher<GeofenceEvent, Never> { get }
}

// MARK: - Geofence Event
struct GeofenceEvent {
    let destinationId: UUID
    let eventType: GeofenceEventType
    let location: CLLocation
    let timestamp: Date
    
    init(destinationId: UUID, eventType: GeofenceEventType, location: CLLocation, timestamp: Date = Date()) {
        self.destinationId = destinationId
        self.eventType = eventType
        self.location = location
        self.timestamp = timestamp
    }
}

// MARK: - Geofence Event Type
enum GeofenceEventType {
    case entered
    case exited
}

// MARK: - Location Service Error
enum LocationServiceError: LocalizedError {
    case permissionDenied
    case locationUnavailable
    case networkError
    case accuracyTooLow
    case timeout
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .permissionDenied:
            return "Location permission denied"
        case .locationUnavailable:
            return "Location services unavailable"
        case .networkError:
            return "Network error while fetching location data"
        case .accuracyTooLow:
            return "Location accuracy too low"
        case .timeout:
            return "Location request timed out"
        case .unknown(let message):
            return message
        }
    }
}