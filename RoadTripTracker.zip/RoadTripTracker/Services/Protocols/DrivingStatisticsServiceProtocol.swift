import Foundation
import CoreLocation
import Combine

// MARK: - Driving Statistics Service Protocol
protocol DrivingStatisticsServiceProtocol: ObservableObject {
    
    // MARK: - Published Properties
    var currentStatistics: DrivingStatistics? { get }
    var isTracking: Bool { get }
    var currentSpeed: Double { get }
    var speedLimit: Double { get }
    var isSpeedingDetected: Bool { get }
    var currentRestPeriod: RestPeriod? { get }
    var shouldSuggestBreak: Bool { get }
    
    // MARK: - Publishers
    var statisticsUpdates: AnyPublisher<DrivingStatistics?, Never> { get }
    var speedingAlerts: AnyPublisher<SpeedingIncident, Never> { get }
    var breakSuggestions: AnyPublisher<BreakSuggestion, Never> { get }
    
    // MARK: - Tracking Management
    func startTracking(for tripId: UUID, participantId: UUID) async throws
    func stopTracking() async throws
    func pauseTracking() async throws
    func resumeTracking() async throws
    
    // MARK: - Location Updates
    func processLocationUpdate(_ location: CLLocation) async
    func updateSpeedLimit(_ speedLimit: Double) async
    
    // MARK: - Rest Period Management
    func startManualRestPeriod(type: RestType, location: CLLocationCoordinate2D) async throws
    func endCurrentRestPeriod() async throws
    func detectAutomaticRestPeriod(location: CLLocation) async
    
    // MARK: - Statistics Retrieval
    func getStatistics(for tripId: UUID, participantId: UUID) async throws -> DrivingStatistics?
    func getTripStatistics(for tripId: UUID) async throws -> [DrivingStatistics]
    func getPerformanceSummary(for participantId: UUID) async throws -> DrivingPerformanceSummary
    func getTripComparisons(for participantId: UUID, limit: Int) async throws -> [TripComparisonData]
    
    // MARK: - Speed Monitoring
    func checkSpeedLimit(currentSpeed: Double, speedLimit: Double) async -> Bool
    func recordSpeedingIncident(_ incident: SpeedingIncident) async throws
    func getSpeedingHistory(for participantId: UUID) async throws -> [SpeedingIncident]
    
    // MARK: - Break Suggestions
    func evaluateBreakNeed() async -> BreakSuggestion?
    func dismissBreakSuggestion() async
    func getBreakRecommendations() async -> [BreakRecommendation]
    
    // MARK: - Performance Analysis
    func calculateSafetyScore(for statistics: DrivingStatistics) -> Double
    func compareWithPreviousTrips(current: DrivingStatistics, participantId: UUID) async throws -> TripPerformanceComparison
    func generatePerformanceReport(for tripId: UUID, participantId: UUID) async throws -> PerformanceReport
    
    // MARK: - Data Management
    func saveStatistics(_ statistics: DrivingStatistics) async throws
    func deleteStatistics(for tripId: UUID) async throws
    func exportStatistics(for participantId: UUID, format: ExportFormat) async throws -> Data
}

// MARK: - Supporting Models

struct BreakSuggestion: Codable {
    let id: UUID
    let timestamp: Date
    let reason: BreakReason
    let urgency: BreakUrgency
    let recommendedDuration: TimeInterval
    let message: String
    
    init(id: UUID = UUID(), timestamp: Date = Date(), reason: BreakReason, urgency: BreakUrgency, recommendedDuration: TimeInterval, message: String) {
        self.id = id
        self.timestamp = timestamp
        self.reason = reason
        self.urgency = urgency
        self.recommendedDuration = recommendedDuration
        self.message = message
    }
}

enum BreakReason: String, Codable, CaseIterable {
    case continuousDriving = "continuous_driving"
    case fatigue = "fatigue"
    case speedingPattern = "speeding_pattern"
    case longDistance = "long_distance"
    case timeOfDay = "time_of_day"
    
    var displayName: String {
        switch self {
        case .continuousDriving: return "Continuous Driving"
        case .fatigue: return "Fatigue Detection"
        case .speedingPattern: return "Speeding Pattern"
        case .longDistance: return "Long Distance"
        case .timeOfDay: return "Time of Day"
        }
    }
}

enum BreakUrgency: String, Codable, CaseIterable {
    case low = "low"
    case medium = "medium"
    case high = "high"
    case critical = "critical"
    
    var displayName: String {
        switch self {
        case .low: return "Low"
        case .medium: return "Medium"
        case .high: return "High"
        case .critical: return "Critical"
        }
    }
    
    var color: String {
        switch self {
        case .low: return "blue"
        case .medium: return "yellow"
        case .high: return "orange"
        case .critical: return "red"
        }
    }
}

struct BreakRecommendation: Codable {
    let type: RestType
    let duration: TimeInterval
    let description: String
    let benefits: [String]
    
    init(type: RestType, duration: TimeInterval, description: String, benefits: [String]) {
        self.type = type
        self.duration = duration
        self.description = description
        self.benefits = benefits
    }
}

struct TripPerformanceComparison: Codable {
    let currentTrip: DrivingStatistics
    let averageFromPreviousTrips: DrivingStatistics?
    let bestTrip: DrivingStatistics?
    let improvements: [PerformanceImprovement]
    let regressions: [PerformanceRegression]
    
    init(currentTrip: DrivingStatistics, averageFromPreviousTrips: DrivingStatistics?, bestTrip: DrivingStatistics?, improvements: [PerformanceImprovement], regressions: [PerformanceRegression]) {
        self.currentTrip = currentTrip
        self.averageFromPreviousTrips = averageFromPreviousTrips
        self.bestTrip = bestTrip
        self.improvements = improvements
        self.regressions = regressions
    }
}

struct PerformanceImprovement: Codable {
    let metric: PerformanceMetric
    let improvement: Double
    let description: String
    
    init(metric: PerformanceMetric, improvement: Double, description: String) {
        self.metric = metric
        self.improvement = improvement
        self.description = description
    }
}

struct PerformanceRegression: Codable {
    let metric: PerformanceMetric
    let regression: Double
    let description: String
    
    init(metric: PerformanceMetric, regression: Double, description: String) {
        self.metric = metric
        self.regression = regression
        self.description = description
    }
}

enum PerformanceMetric: String, Codable, CaseIterable {
    case averageSpeed = "average_speed"
    case safetyScore = "safety_score"
    case speedingIncidents = "speeding_incidents"
    case restFrequency = "rest_frequency"
    case fuelEfficiency = "fuel_efficiency"
    
    var displayName: String {
        switch self {
        case .averageSpeed: return "Average Speed"
        case .safetyScore: return "Safety Score"
        case .speedingIncidents: return "Speeding Incidents"
        case .restFrequency: return "Rest Frequency"
        case .fuelEfficiency: return "Fuel Efficiency"
        }
    }
}

struct PerformanceReport: Codable {
    let tripId: UUID
    let participantId: UUID
    let generatedAt: Date
    let statistics: DrivingStatistics
    let summary: PerformanceSummary
    let recommendations: [PerformanceRecommendation]
    let charts: [ChartData]
    
    init(tripId: UUID, participantId: UUID, generatedAt: Date = Date(), statistics: DrivingStatistics, summary: PerformanceSummary, recommendations: [PerformanceRecommendation], charts: [ChartData]) {
        self.tripId = tripId
        self.participantId = participantId
        self.generatedAt = generatedAt
        self.statistics = statistics
        self.summary = summary
        self.recommendations = recommendations
        self.charts = charts
    }
}

struct PerformanceSummary: Codable {
    let overallRating: SafetyRating
    let strengths: [String]
    let areasForImprovement: [String]
    let keyMetrics: [KeyMetric]
    
    init(overallRating: SafetyRating, strengths: [String], areasForImprovement: [String], keyMetrics: [KeyMetric]) {
        self.overallRating = overallRating
        self.strengths = strengths
        self.areasForImprovement = areasForImprovement
        self.keyMetrics = keyMetrics
    }
}

struct KeyMetric: Codable {
    let name: String
    let value: String
    let trend: MetricTrend
    let description: String
    
    init(name: String, value: String, trend: MetricTrend, description: String) {
        self.name = name
        self.value = value
        self.trend = trend
        self.description = description
    }
}

enum MetricTrend: String, Codable, CaseIterable {
    case improving = "improving"
    case stable = "stable"
    case declining = "declining"
    
    var icon: String {
        switch self {
        case .improving: return "arrow.up.circle.fill"
        case .stable: return "minus.circle.fill"
        case .declining: return "arrow.down.circle.fill"
        }
    }
    
    var color: String {
        switch self {
        case .improving: return "green"
        case .stable: return "blue"
        case .declining: return "red"
        }
    }
}

struct PerformanceRecommendation: Codable {
    let title: String
    let description: String
    let priority: RecommendationPriority
    let category: RecommendationCategory
    let actionItems: [String]
    
    init(title: String, description: String, priority: RecommendationPriority, category: RecommendationCategory, actionItems: [String]) {
        self.title = title
        self.description = description
        self.priority = priority
        self.category = category
        self.actionItems = actionItems
    }
}

enum RecommendationPriority: String, Codable, CaseIterable {
    case low = "low"
    case medium = "medium"
    case high = "high"
    
    var displayName: String {
        switch self {
        case .low: return "Low"
        case .medium: return "Medium"
        case .high: return "High"
        }
    }
}

enum RecommendationCategory: String, Codable, CaseIterable {
    case safety = "safety"
    case efficiency = "efficiency"
    case comfort = "comfort"
    case planning = "planning"
    
    var displayName: String {
        switch self {
        case .safety: return "Safety"
        case .efficiency: return "Efficiency"
        case .comfort: return "Comfort"
        case .planning: return "Planning"
        }
    }
    
    var icon: String {
        switch self {
        case .safety: return "shield"
        case .efficiency: return "gauge"
        case .comfort: return "heart"
        case .planning: return "map"
        }
    }
}

struct ChartData: Codable {
    let type: ChartType
    let title: String
    let data: [DataPoint]
    let xAxisLabel: String
    let yAxisLabel: String
    
    init(type: ChartType, title: String, data: [DataPoint], xAxisLabel: String, yAxisLabel: String) {
        self.type = type
        self.title = title
        self.data = data
        self.xAxisLabel = xAxisLabel
        self.yAxisLabel = yAxisLabel
    }
}

enum ChartType: String, Codable, CaseIterable {
    case line = "line"
    case bar = "bar"
    case pie = "pie"
    case area = "area"
    
    var displayName: String {
        switch self {
        case .line: return "Line Chart"
        case .bar: return "Bar Chart"
        case .pie: return "Pie Chart"
        case .area: return "Area Chart"
        }
    }
}

struct DataPoint: Codable {
    let x: Double
    let y: Double
    let label: String?
    
    init(x: Double, y: Double, label: String? = nil) {
        self.x = x
        self.y = y
        self.label = label
    }
}

enum ExportFormat: String, Codable, CaseIterable {
    case json = "json"
    case csv = "csv"
    case pdf = "pdf"
    
    var displayName: String {
        switch self {
        case .json: return "JSON"
        case .csv: return "CSV"
        case .pdf: return "PDF"
        }
    }
    
    var fileExtension: String {
        return rawValue
    }
}

// MARK: - Service Errors
enum DrivingStatisticsServiceError: LocalizedError {
    case trackingNotStarted
    case trackingAlreadyActive
    case invalidTripId
    case invalidParticipantId
    case dataNotFound
    case saveFailed(String)
    case exportFailed(String)
    case permissionDenied
    case networkError
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .trackingNotStarted:
            return "Driving statistics tracking has not been started"
        case .trackingAlreadyActive:
            return "Driving statistics tracking is already active"
        case .invalidTripId:
            return "Invalid trip ID provided"
        case .invalidParticipantId:
            return "Invalid participant ID provided"
        case .dataNotFound:
            return "Driving statistics data not found"
        case .saveFailed(let message):
            return "Failed to save driving statistics: \(message)"
        case .exportFailed(let message):
            return "Failed to export driving statistics: \(message)"
        case .permissionDenied:
            return "Permission denied for driving statistics tracking"
        case .networkError:
            return "Network error occurred while processing driving statistics"
        case .unknown(let message):
            return "Unknown error: \(message)"
        }
    }
}