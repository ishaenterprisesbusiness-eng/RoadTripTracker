import Foundation
import Combine
import UserNotifications

// MARK: - Notification Service Protocol
protocol NotificationServiceProtocol {
    var notificationPermissionStatus: AnyPublisher<UNAuthorizationStatus, Never> { get }
    
    func requestNotificationPermission() async throws -> Bool
    func scheduleLocalNotification(_ notification: LocalNotification) async throws
    func cancelNotification(withIdentifier identifier: String) async throws
    func cancelAllNotifications() async throws
    func sendPushNotification(_ notification: PushNotification) async throws
    func registerForRemoteNotifications() async throws -> Data
    func handleRemoteNotification(_ userInfo: [AnyHashable: Any]) async
    func sendNotification(_ notification: Notification, to userId: UUID) async throws
}

// MARK: - Weather Service Protocol
protocol WeatherServiceProtocol {
    func getCurrentWeather(for coordinate: CLLocationCoordinate2D) async throws -> WeatherData
    func getWeatherForecast(for coordinate: CLLocationCoordinate2D, days: Int) async throws -> WeatherForecast
    func getWeatherAlerts(for coordinate: CLLocationCoordinate2D) async throws -> [WeatherAlert]
    func subscribeToWeatherUpdates(for coordinates: [CLLocationCoordinate2D]) async throws
    func unsubscribeFromWeatherUpdates() async throws
}

// MARK: - Emergency Service Protocol
protocol EmergencyServiceProtocol {
    func sendEmergencyAlert(location: CLLocationCoordinate2D, message: String, to tripId: UUID) async throws
    func findNearbyEmergencyServices(location: CLLocationCoordinate2D) async throws -> [EmergencyService]
    func callEmergencyServices(type: EmergencyServiceType) async throws
    func sendCheckInReminder(to participantId: UUID) async throws
    func reportBreakdown(location: CLLocationCoordinate2D, vehicleInfo: Vehicle, description: String) async throws
}

// MARK: - Budget Service Protocol
protocol BudgetServiceProtocol {
    func createBudget(totalAmount: Double, perPersonAmount: Double?, for tripId: UUID) async throws -> Budget
    func addExpense(_ expense: Expense, to tripId: UUID) async throws
    func updateExpense(_ expense: Expense) async throws
    func deleteExpense(_ expenseId: UUID, from tripId: UUID) async throws
    func getBudgetSummary(for tripId: UUID) async throws -> BudgetSummary
    func getExpensesByCategory(for tripId: UUID) async throws -> [ExpenseCategory: [Expense]]
    func checkBudgetLimits(for tripId: UUID) async throws -> [BudgetAlert]
}

// MARK: - Local Notification
struct LocalNotification {
    let identifier: String
    let title: String
    let body: String
    let sound: UNNotificationSound?
    let badge: NSNumber?
    let userInfo: [AnyHashable: Any]?
    let trigger: UNNotificationTrigger?
    
    init(identifier: String, title: String, body: String, sound: UNNotificationSound? = .default, badge: NSNumber? = nil, userInfo: [AnyHashable: Any]? = nil, trigger: UNNotificationTrigger? = nil) {
        self.identifier = identifier
        self.title = title
        self.body = body
        self.sound = sound
        self.badge = badge
        self.userInfo = userInfo
        self.trigger = trigger
    }
}

// MARK: - Push Notification
struct PushNotification {
    let recipientIds: [UUID]
    let title: String
    let body: String
    let data: [String: Any]?
    let priority: NotificationPriority
    
    init(recipientIds: [UUID], title: String, body: String, data: [String: Any]? = nil, priority: NotificationPriority = .normal) {
        self.recipientIds = recipientIds
        self.title = title
        self.body = body
        self.data = data
        self.priority = priority
    }
}

// MARK: - Notification Priority
enum NotificationPriority {
    case low
    case normal
    case high
    case emergency
}

// MARK: - Weather Data
struct WeatherData: Codable {
    let temperature: Double
    let feelsLike: Double
    let humidity: Double
    let windSpeed: Double
    let windDirection: Double
    let visibility: Double
    let uvIndex: Double
    let condition: WeatherCondition
    let timestamp: Date
    
    init(temperature: Double, feelsLike: Double, humidity: Double, windSpeed: Double, windDirection: Double, visibility: Double, uvIndex: Double, condition: WeatherCondition, timestamp: Date = Date()) {
        self.temperature = temperature
        self.feelsLike = feelsLike
        self.humidity = humidity
        self.windSpeed = windSpeed
        self.windDirection = windDirection
        self.visibility = visibility
        self.uvIndex = uvIndex
        self.condition = condition
        self.timestamp = timestamp
    }
}

// MARK: - Weather Forecast
struct WeatherForecast: Codable {
    let location: CLLocationCoordinate2D
    let dailyForecasts: [DailyWeatherForecast]
    let hourlyForecasts: [HourlyWeatherForecast]
    
    init(location: CLLocationCoordinate2D, dailyForecasts: [DailyWeatherForecast], hourlyForecasts: [HourlyWeatherForecast]) {
        self.location = location
        self.dailyForecasts = dailyForecasts
        self.hourlyForecasts = hourlyForecasts
    }
}

// MARK: - Daily Weather Forecast
struct DailyWeatherForecast: Codable, Identifiable {
    let id = UUID()
    let date: Date
    let highTemperature: Double
    let lowTemperature: Double
    let condition: WeatherCondition
    let precipitationChance: Double
    let windSpeed: Double
    
    init(date: Date, highTemperature: Double, lowTemperature: Double, condition: WeatherCondition, precipitationChance: Double, windSpeed: Double) {
        self.date = date
        self.highTemperature = highTemperature
        self.lowTemperature = lowTemperature
        self.condition = condition
        self.precipitationChance = precipitationChance
        self.windSpeed = windSpeed
    }
}

// MARK: - Hourly Weather Forecast
struct HourlyWeatherForecast: Codable, Identifiable {
    let id = UUID()
    let time: Date
    let temperature: Double
    let condition: WeatherCondition
    let precipitationChance: Double
    let windSpeed: Double
    
    init(time: Date, temperature: Double, condition: WeatherCondition, precipitationChance: Double, windSpeed: Double) {
        self.time = time
        self.temperature = temperature
        self.condition = condition
        self.precipitationChance = precipitationChance
        self.windSpeed = windSpeed
    }
}

// MARK: - Weather Condition
enum WeatherCondition: String, Codable, CaseIterable {
    case clear = "clear"
    case partlyCloudy = "partly_cloudy"
    case cloudy = "cloudy"
    case rain = "rain"
    case heavyRain = "heavy_rain"
    case snow = "snow"
    case heavySnow = "heavy_snow"
    case thunderstorm = "thunderstorm"
    case fog = "fog"
    case windy = "windy"
    
    var displayName: String {
        switch self {
        case .clear: return "Clear"
        case .partlyCloudy: return "Partly Cloudy"
        case .cloudy: return "Cloudy"
        case .rain: return "Rain"
        case .heavyRain: return "Heavy Rain"
        case .snow: return "Snow"
        case .heavySnow: return "Heavy Snow"
        case .thunderstorm: return "Thunderstorm"
        case .fog: return "Fog"
        case .windy: return "Windy"
        }
    }
}

// MARK: - Weather Alert
struct WeatherAlert: Codable, Identifiable {
    let id: UUID
    let title: String
    let description: String
    let severity: WeatherAlertSeverity
    let startTime: Date
    let endTime: Date
    let affectedAreas: [String]
    
    init(id: UUID = UUID(), title: String, description: String, severity: WeatherAlertSeverity, startTime: Date, endTime: Date, affectedAreas: [String]) {
        self.id = id
        self.title = title
        self.description = description
        self.severity = severity
        self.startTime = startTime
        self.endTime = endTime
        self.affectedAreas = affectedAreas
    }
}

// MARK: - Weather Alert Severity
enum WeatherAlertSeverity: String, Codable, CaseIterable {
    case minor = "minor"
    case moderate = "moderate"
    case severe = "severe"
    case extreme = "extreme"
}

// MARK: - Emergency Service
struct EmergencyService: Codable, Identifiable {
    let id: UUID
    let name: String
    let type: EmergencyServiceType
    let phoneNumber: String
    let address: String
    let coordinate: CLLocationCoordinate2D
    let distance: CLLocationDistance
    let isOpen24Hours: Bool
    
    init(id: UUID = UUID(), name: String, type: EmergencyServiceType, phoneNumber: String, address: String, coordinate: CLLocationCoordinate2D, distance: CLLocationDistance, isOpen24Hours: Bool) {
        self.id = id
        self.name = name
        self.type = type
        self.phoneNumber = phoneNumber
        self.address = address
        self.coordinate = coordinate
        self.distance = distance
        self.isOpen24Hours = isOpen24Hours
    }
}

// MARK: - Emergency Service Type
enum EmergencyServiceType: String, Codable, CaseIterable {
    case police = "police"
    case fire = "fire"
    case medical = "medical"
    case towing = "towing"
    case mechanic = "mechanic"
    case hospital = "hospital"
    
    var displayName: String {
        switch self {
        case .police: return "Police"
        case .fire: return "Fire Department"
        case .medical: return "Medical"
        case .towing: return "Towing Service"
        case .mechanic: return "Mechanic"
        case .hospital: return "Hospital"
        }
    }
}

// MARK: - Budget Summary
struct BudgetSummary: Codable {
    let totalBudget: Double
    let totalSpent: Double
    let remainingBudget: Double
    let spentByCategory: [ExpenseCategory: Double]
    let participantSpending: [UUID: Double]
    let averageSpendingPerDay: Double
    let projectedTotalSpending: Double
    
    init(totalBudget: Double, totalSpent: Double, remainingBudget: Double, spentByCategory: [ExpenseCategory: Double], participantSpending: [UUID: Double], averageSpendingPerDay: Double, projectedTotalSpending: Double) {
        self.totalBudget = totalBudget
        self.totalSpent = totalSpent
        self.remainingBudget = remainingBudget
        self.spentByCategory = spentByCategory
        self.participantSpending = participantSpending
        self.averageSpendingPerDay = averageSpendingPerDay
        self.projectedTotalSpending = projectedTotalSpending
    }
}

// MARK: - Budget Alert
struct BudgetAlert: Codable, Identifiable {
    let id: UUID
    let type: BudgetAlertType
    let message: String
    let threshold: Double
    let currentAmount: Double
    let category: ExpenseCategory?
    
    init(id: UUID = UUID(), type: BudgetAlertType, message: String, threshold: Double, currentAmount: Double, category: ExpenseCategory? = nil) {
        self.id = id
        self.type = type
        self.message = message
        self.threshold = threshold
        self.currentAmount = currentAmount
        self.category = category
    }
}

// MARK: - Budget Alert Type
enum BudgetAlertType: String, Codable, CaseIterable {
    case approaching = "approaching"
    case exceeded = "exceeded"
    case categoryLimit = "category_limit"
    case dailyLimit = "daily_limit"
}