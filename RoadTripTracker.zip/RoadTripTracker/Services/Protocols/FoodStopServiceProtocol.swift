import Foundation
import CoreLocation
import Combine

// MARK: - Food Stop Service Protocol
protocol FoodStopServiceProtocol {
    var foodStopUpdates: AnyPublisher<FoodStop, Never> { get }
    var orderUpdates: AnyPublisher<FoodOrder, Never> { get }
    var approachingFoodStopNotifications: AnyPublisher<FoodStopApproachNotification, Never> { get }
    
    func findNearbyRestaurants(coordinate: CLLocationCoordinate2D, radius: Double, cuisineFilter: CuisineType?) async throws -> [Restaurant]
    func findRestaurantsAlongRoute(route: [CLLocationCoordinate2D], searchRadius: Double, cuisineFilter: CuisineType?) async throws -> [Restaurant]
    func getRestaurantDetails(restaurantId: String) async throws -> Restaurant
    func proposeFoodStop(restaurant: Restaurant, tripId: UUID, proposedBy: UUID, notes: String?) async throws -> FoodStop
    func approveFoodStop(foodStopId: UUID, participantId: UUID) async throws
    func rejectFoodStop(foodStopId: UUID, participantId: UUID, reason: String?) async throws
    func placeOrder(foodStopId: UUID, participantId: UUID, items: [OrderItem], specialInstructions: String?) async throws -> FoodOrder
    func updateOrderStatus(orderId: UUID, status: OrderStatus, estimatedReadyTime: Date?) async throws
    func markOrderReady(orderId: UUID) async throws
    func markReadyToContinue(foodStopId: UUID, participantId: UUID) async throws
    func cancelFoodStop(foodStopId: UUID, cancelledBy: UUID, reason: String?) async throws
    func getFoodStopsForTrip(tripId: UUID) async throws -> [FoodStop]
    func getActiveFoodStop(tripId: UUID) async throws -> FoodStop?
    func addFoodStopToRoute(foodStop: FoodStop) async throws
    func monitorApproachingFoodStops(tripId: UUID, participantLocation: CLLocationCoordinate2D) async throws
    func getEstimatedWaitTime(restaurantId: String) async throws -> TimeInterval?
    func getParkingInformation(restaurantId: String) async throws -> ParkingInfo?
}

// MARK: - Food Stop Approach Notification
struct FoodStopApproachNotification: Codable {
    let foodStopId: UUID
    let participantId: UUID
    let restaurant: Restaurant
    let distanceToStop: CLLocationDistance
    let estimatedArrivalTime: TimeInterval
    let notificationType: FoodStopNotificationType
    let parkingInfo: ParkingInfo?
    
    init(foodStopId: UUID, participantId: UUID, restaurant: Restaurant, distanceToStop: CLLocationDistance, estimatedArrivalTime: TimeInterval, notificationType: FoodStopNotificationType, parkingInfo: ParkingInfo? = nil) {
        self.foodStopId = foodStopId
        self.participantId = participantId
        self.restaurant = restaurant
        self.distanceToStop = distanceToStop
        self.estimatedArrivalTime = estimatedArrivalTime
        self.notificationType = notificationType
        self.parkingInfo = parkingInfo
    }
}

// MARK: - Food Stop Notification Type
enum FoodStopNotificationType: String, Codable, CaseIterable {
    case approaching = "approaching"
    case arrived = "arrived"
    case orderReady = "order_ready"
    case waitingForGroup = "waiting_for_group"
    case readyToContinue = "ready_to_continue"
    case parkingInfo = "parking_info"
    
    var displayMessage: String {
        switch self {
        case .approaching: return "Approaching food stop"
        case .arrived: return "Arrived at food stop"
        case .orderReady: return "Your order is ready"
        case .waitingForGroup: return "Waiting for group at food stop"
        case .readyToContinue: return "Ready to continue from food stop"
        case .parkingInfo: return "Parking information available"
        }
    }
}