import Foundation
import Combine
import MapKit
import CoreLocation

// MARK: - Map Service Protocol
protocol MapServiceProtocol {
    func displayRoute(_ route: Route) async throws
    func showParticipants(_ participants: [Participant]) async throws
    func findNearbyPOIs(category: POICategory, near location: CLLocationCoordinate2D, radius: CLLocationDistance) async throws -> [PointOfInterest]
    func calculateRoute(from origin: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D, waypoints: [CLLocationCoordinate2D]) async throws -> Route
    func calculateMultiDestinationRoute(destinations: [Destination]) async throws -> Route
    func getDirections(for route: Route) async throws -> [RouteStep]
    func searchPlaces(query: String, near location: CLLocationCoordinate2D) async throws -> [Place]
}

// MARK: - Navigation Service Protocol
protocol NavigationServiceProtocol {
    var currentRoute: Route? { get }
    var navigationUpdates: AnyPublisher<NavigationUpdate, Never> { get }
    var routeProgress: AnyPublisher<RouteProgress, Never> { get }
    
    func startNavigation(route: Route) async throws
    func stopNavigation() async throws
    func recalculateRoute(from currentLocation: CLLocationCoordinate2D) async throws -> Route
    func getNextInstruction() -> RouteStep?
    func isOffRoute(currentLocation: CLLocationCoordinate2D, threshold: CLLocationDistance) -> Bool
}

// MARK: - Route Model
struct Route: Codable, Identifiable {
    let id: UUID
    var name: String
    var destinations: [Destination]
    var waypoints: [CLLocationCoordinate2D]
    var distance: CLLocationDistance
    var estimatedTravelTime: TimeInterval
    var polyline: String?
    var steps: [RouteStep]
    
    init(id: UUID = UUID(), name: String, destinations: [Destination], waypoints: [CLLocationCoordinate2D] = [], distance: CLLocationDistance = 0, estimatedTravelTime: TimeInterval = 0, polyline: String? = nil, steps: [RouteStep] = []) {
        self.id = id
        self.name = name
        self.destinations = destinations
        self.waypoints = waypoints
        self.distance = distance
        self.estimatedTravelTime = estimatedTravelTime
        self.polyline = polyline
        self.steps = steps
    }
}

// MARK: - Route Step
struct RouteStep: Codable, Identifiable {
    let id: UUID
    var instruction: String
    var distance: CLLocationDistance
    var estimatedTime: TimeInterval
    var coordinate: CLLocationCoordinate2D
    var maneuver: ManeuverType
    
    init(id: UUID = UUID(), instruction: String, distance: CLLocationDistance, estimatedTime: TimeInterval, coordinate: CLLocationCoordinate2D, maneuver: ManeuverType) {
        self.id = id
        self.instruction = instruction
        self.distance = distance
        self.estimatedTime = estimatedTime
        self.coordinate = coordinate
        self.maneuver = maneuver
    }
}

// MARK: - Maneuver Type
enum ManeuverType: String, Codable, CaseIterable {
    case straight = "straight"
    case turnLeft = "turn_left"
    case turnRight = "turn_right"
    case turnSlightLeft = "turn_slight_left"
    case turnSlightRight = "turn_slight_right"
    case turnSharpLeft = "turn_sharp_left"
    case turnSharpRight = "turn_sharp_right"
    case uturn = "uturn"
    case merge = "merge"
    case roundabout = "roundabout"
    case exitRoundabout = "exit_roundabout"
    case ferry = "ferry"
    case arrive = "arrive"
}

// MARK: - Point of Interest
struct PointOfInterest: Codable, Identifiable {
    let id: UUID
    var name: String
    var category: POICategory
    var coordinate: CLLocationCoordinate2D
    var address: String?
    var rating: Double?
    var priceLevel: Int?
    var openingHours: [String]?
    var phoneNumber: String?
    var website: URL?
    var photos: [URL]?
    
    init(id: UUID = UUID(), name: String, category: POICategory, coordinate: CLLocationCoordinate2D, address: String? = nil, rating: Double? = nil, priceLevel: Int? = nil, openingHours: [String]? = nil, phoneNumber: String? = nil, website: URL? = nil, photos: [URL]? = nil) {
        self.id = id
        self.name = name
        self.category = category
        self.coordinate = coordinate
        self.address = address
        self.rating = rating
        self.priceLevel = priceLevel
        self.openingHours = openingHours
        self.phoneNumber = phoneNumber
        self.website = website
        self.photos = photos
    }
}

// MARK: - POI Category
enum POICategory: String, Codable, CaseIterable {
    case gasStation = "gas_station"
    case restaurant = "restaurant"
    case hotel = "hotel"
    case attraction = "attraction"
    case hospital = "hospital"
    case mechanic = "mechanic"
    case shopping = "shopping"
    case nature = "nature"
    case history = "history"
    case entertainment = "entertainment"
    case camping = "camping"
    
    var displayName: String {
        switch self {
        case .gasStation: return "Gas Station"
        case .restaurant: return "Restaurant"
        case .hotel: return "Hotel"
        case .attraction: return "Attraction"
        case .hospital: return "Hospital"
        case .mechanic: return "Mechanic"
        case .shopping: return "Shopping"
        case .nature: return "Nature"
        case .history: return "History"
        case .entertainment: return "Entertainment"
        case .camping: return "Camping"
        }
    }
}

// MARK: - Place Search Result
struct Place: Codable, Identifiable {
    let id: UUID
    var name: String
    var address: String
    var coordinate: CLLocationCoordinate2D
    var category: String?
    var rating: Double?
    var priceLevel: Int?
    
    init(id: UUID = UUID(), name: String, address: String, coordinate: CLLocationCoordinate2D, category: String? = nil, rating: Double? = nil, priceLevel: Int? = nil) {
        self.id = id
        self.name = name
        self.address = address
        self.coordinate = coordinate
        self.category = category
        self.rating = rating
        self.priceLevel = priceLevel
    }
}

// MARK: - Navigation Update
struct NavigationUpdate {
    let currentLocation: CLLocationCoordinate2D
    let nextStep: RouteStep?
    let distanceToNextStep: CLLocationDistance
    let timeToNextStep: TimeInterval
    let isOffRoute: Bool
    
    init(currentLocation: CLLocationCoordinate2D, nextStep: RouteStep? = nil, distanceToNextStep: CLLocationDistance = 0, timeToNextStep: TimeInterval = 0, isOffRoute: Bool = false) {
        self.currentLocation = currentLocation
        self.nextStep = nextStep
        self.distanceToNextStep = distanceToNextStep
        self.timeToNextStep = timeToNextStep
        self.isOffRoute = isOffRoute
    }
}

// MARK: - Route Progress
struct RouteProgress {
    let distanceTraveled: CLLocationDistance
    let distanceRemaining: CLLocationDistance
    let timeElapsed: TimeInterval
    let estimatedTimeRemaining: TimeInterval
    let currentDestinationIndex: Int
    let progressPercentage: Double
    
    init(distanceTraveled: CLLocationDistance = 0, distanceRemaining: CLLocationDistance = 0, timeElapsed: TimeInterval = 0, estimatedTimeRemaining: TimeInterval = 0, currentDestinationIndex: Int = 0, progressPercentage: Double = 0) {
        self.distanceTraveled = distanceTraveled
        self.distanceRemaining = distanceRemaining
        self.timeElapsed = timeElapsed
        self.estimatedTimeRemaining = estimatedTimeRemaining
        self.currentDestinationIndex = currentDestinationIndex
        self.progressPercentage = progressPercentage
    }
}

// MARK: - Map Service Error
enum MapServiceError: LocalizedError {
    case routeCalculationFailed
    case directionsUnavailable
    case placeSearchFailed
    case poiSearchFailed
    case navigationNotStarted
    case invalidCoordinates
    case networkError
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .routeCalculationFailed:
            return "Failed to calculate route"
        case .directionsUnavailable:
            return "Directions unavailable"
        case .placeSearchFailed:
            return "Place search failed"
        case .poiSearchFailed:
            return "Points of interest search failed"
        case .navigationNotStarted:
            return "Navigation not started"
        case .invalidCoordinates:
            return "Invalid coordinates"
        case .networkError:
            return "Network connection error"
        case .unknown(let message):
            return message
        }
    }
}