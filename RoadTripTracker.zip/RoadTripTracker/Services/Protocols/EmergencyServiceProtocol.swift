import Foundation
import CoreLocation
import Combine

// MARK: - Emergency Service Protocol
protocol EmergencyServiceProtocol {
    func triggerEmergencyAlert(location: CLLocationCoordinate2D, message: String?) async throws
    func sendBreakdownAssistance(location: CLLocationCoordinate2D, vehicleInfo: Vehicle) async throws
    func findNearbyEmergencyServices(location: CLLocationCoordinate2D) async throws -> [EmergencyService]
    func cancelEmergencyAlert() async throws
    var emergencyAlerts: AnyPublisher<EmergencyAlert, Never> { get }
}

// MARK: - Emergency Alert Model
struct EmergencyAlert: Codable, Identifiable {
    let id: UUID
    let tripId: UUID
    let userId: UUID
    let alertType: EmergencyAlertType
    let location: CLLocationCoordinate2D
    let message: String?
    let timestamp: Date
    let status: EmergencyAlertStatus
    
    init(id: UUID = UUID(), tripId: UUID, userId: UUID, alertType: EmergencyAlertType, location: CLLocationCoordinate2D, message: String? = nil, timestamp: Date = Date(), status: EmergencyAlertStatus = .active) {
        self.id = id
        self.tripId = tripId
        self.userId = userId
        self.alertType = alertType
        self.location = location
        self.message = message
        self.timestamp = timestamp
        self.status = status
    }
}

// MARK: - Emergency Alert Type
enum EmergencyAlertType: String, Codable {
    case panic = "panic"
    case breakdown = "breakdown"
    case accident = "accident"
    case medical = "medical"
    case other = "other"
}

// MARK: - Emergency Alert Status
enum EmergencyAlertStatus: String, Codable {
    case active = "active"
    case acknowledged = "acknowledged"
    case resolved = "resolved"
    case cancelled = "cancelled"
}

// MARK: - Emergency Service Model
struct EmergencyService: Codable, Identifiable {
    let id: UUID
    let name: String
    let type: EmergencyServiceType
    let phoneNumber: String
    let address: String
    let coordinate: CLLocationCoordinate2D
    let distance: CLLocationDistance
    let isOpen24Hours: Bool
    
    init(id: UUID = UUID(), name: String, type: EmergencyServiceType, phoneNumber: String, address: String, coordinate: CLLocationCoordinate2D, distance: CLLocationDistance, isOpen24Hours: Bool = false) {
        self.id = id
        self.name = name
        self.type = type
        self.phoneNumber = phoneNumber
        self.address = address
        self.coordinate = coordinate
        self.distance = distance
        self.isOpen24Hours = isOpen24Hours
    }
}

// MARK: - Emergency Service Type
enum EmergencyServiceType: String, Codable {
    case hospital = "hospital"
    case police = "police"
    case fireStation = "fire_station"
    case mechanic = "mechanic"
    case towingService = "towing_service"
}

// MARK: - Emergency Service Error
enum EmergencyServiceError: LocalizedError {
    case locationNotAvailable
    case networkError
    case serviceUnavailable
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .locationNotAvailable:
            return "Location not available"
        case .networkError:
            return "Network connection error"
        case .serviceUnavailable:
            return "Emergency service unavailable"
        case .unknown(let message):
            return message
        }
    }
}