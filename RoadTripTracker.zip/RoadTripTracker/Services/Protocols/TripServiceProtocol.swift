import Foundation
import Combine
import CoreLocation

// MARK: - Trip Service Protocol
protocol TripServiceProtocol {
    var activeTrip: Trip? { get }
    var tripUpdates: AnyPublisher<Trip?, Never> { get }
    
    func createTrip(name: String, destinations: [Destination], settings: TripSettings) async throws -> Trip
    func joinTrip(code: String) async throws -> Trip
    func leaveTrip(_ tripId: UUID) async throws
    func updateTrip(_ trip: Trip) async throws
    func deleteTrip(_ tripId: UUID) async throws
    func generateTripCode() -> String
    func validateTripCode(_ code: String) async throws -> Bool
    func getTripHistory(for userId: UUID) async throws -> [Trip]
    func optimizeRoute(destinations: [Destination]) async throws -> [Destination]
    func addDestination(_ destination: Destination, to tripId: UUID) async throws
    func removeDestination(_ destinationId: UUID, from tripId: UUID) async throws
    func getTrip(id: UUID) async throws -> Trip
    func addDestination(_ destination: Destination, to trip: Trip, at index: Int) async throws -> Trip
    func removeDestination(at index: Int, from trip: Trip) async throws -> Trip
    func updateTrip(_ trip: Trip) async throws -> Trip
    func reorderDestinations(_ destinations: [Destination], in tripId: UUID) async throws
}

// MARK: - Trip Settings
struct TripSettings {
    var isPublic: Bool
    var allowParticipantInvites: Bool
    var maxParticipants: Int?
    var budget: Budget?
    var notificationPreferences: NotificationPreferences
    
    init(isPublic: Bool = false, allowParticipantInvites: Bool = true, maxParticipants: Int? = nil, budget: Budget? = nil, notificationPreferences: NotificationPreferences = NotificationPreferences()) {
        self.isPublic = isPublic
        self.allowParticipantInvites = allowParticipantInvites
        self.maxParticipants = maxParticipants
        self.budget = budget
        self.notificationPreferences = notificationPreferences
    }
}

// MARK: - Notification Preferences
struct NotificationPreferences: Codable {
    var participantJoined: Bool
    var participantLeft: Bool
    var approachingDestination: Bool
    var stopProposed: Bool
    var emergencyAlerts: Bool
    var chatMessages: Bool
    
    init(participantJoined: Bool = true, participantLeft: Bool = true, approachingDestination: Bool = true, stopProposed: Bool = true, emergencyAlerts: Bool = true, chatMessages: Bool = true) {
        self.participantJoined = participantJoined
        self.participantLeft = participantLeft
        self.approachingDestination = approachingDestination
        self.stopProposed = stopProposed
        self.emergencyAlerts = emergencyAlerts
        self.chatMessages = chatMessages
    }
}

// MARK: - Trip Service Error
enum TripServiceError: LocalizedError {
    case tripNotFound
    case invalidTripCode
    case tripFull
    case alreadyParticipant
    case notParticipant
    case insufficientPermissions
    case routeOptimizationFailed
    case networkError
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .tripNotFound:
            return "Trip not found"
        case .invalidTripCode:
            return "Invalid trip code"
        case .tripFull:
            return "Trip has reached maximum participants"
        case .alreadyParticipant:
            return "You are already a participant in this trip"
        case .notParticipant:
            return "You are not a participant in this trip"
        case .insufficientPermissions:
            return "You don't have permission to perform this action"
        case .routeOptimizationFailed:
            return "Failed to optimize route"
        case .networkError:
            return "Network connection error"
        case .unknown(let message):
            return message
        }
    }
}