import Foundation
import Combine
import CoreLocation
import MapKit
import UserNotifications

// MARK: - Route Manager
class RouteManager: ObservableObject {
    
    // MARK: - Published Properties
    @Published var currentRoute: Route?
    @Published var isNavigating: Bool = false
    @Published var routeProgress: RouteProgress?
    @Published var navigationUpdate: NavigationUpdate?
    @Published var routeDeviation: Bool = false
    
    // MARK: - Private Properties
    private let navigationService: NavigationServiceProtocol
    private let mapService: MapServiceProtocol
    private let locationManager: LocationServiceProtocol
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Initialization
    init(navigationService: NavigationServiceProtocol, mapService: MapServiceProtocol, locationManager: LocationServiceProtocol) {
        self.navigationService = navigationService
        self.mapService = mapService
        self.locationManager = locationManager
        
        setupBindings()
    }
    
    // MARK: - Public Methods
    
    /// Calculate and display a multi-destination route
    func calculateRoute(for destinations: [Destination]) async throws -> Route {
        guard !destinations.isEmpty else {
            throw RouteManagerError.noDestinations
        }
        
        let route = try await mapService.calculateMultiDestinationRoute(destinations: destinations)
        
        await MainActor.run {
            self.currentRoute = route
        }
        
        // Display the route on the map
        try await mapService.displayRoute(route)
        
        // Notify participants about route update
        await notifyRouteUpdate(route)
        
        return route
    }
    
    /// Start navigation for the current route
    func startNavigation() async throws {
        guard let route = currentRoute else {
            throw RouteManagerError.noRouteAvailable
        }
        
        try await navigationService.startNavigation(route: route)
        
        await MainActor.run {
            self.isNavigating = true
        }
    }
    
    /// Stop current navigation
    func stopNavigation() async throws {
        try await navigationService.stopNavigation()
        
        await MainActor.run {
            self.isNavigating = false
            self.routeProgress = nil
            self.navigationUpdate = nil
            self.routeDeviation = false
        }
    }
    
    /// Recalculate route from current location
    func recalculateRoute() async throws {
        guard let currentLocation = locationManager.currentLocation else {
            throw RouteManagerError.locationUnavailable
        }
        
        let newRoute = try await navigationService.recalculateRoute(from: currentLocation.coordinate)
        
        await MainActor.run {
            self.currentRoute = newRoute
            self.routeDeviation = false
        }
        
        // Display updated route
        try await mapService.displayRoute(newRoute)
        
        // Notify participants about route recalculation
        await notifyRouteRecalculation(newRoute)
    }
    
    /// Add a new destination to the current route
    func addDestination(_ destination: Destination, at index: Int? = nil) async throws {
        guard var route = currentRoute else {
            throw RouteManagerError.noRouteAvailable
        }
        
        if let index = index, index <= route.destinations.count {
            route.destinations.insert(destination, at: index)
        } else {
            route.destinations.append(destination)
        }
        
        // Recalculate route with new destination
        let updatedRoute = try await mapService.calculateMultiDestinationRoute(destinations: route.destinations)
        
        await MainActor.run {
            self.currentRoute = updatedRoute
        }
        
        // Display updated route
        try await mapService.displayRoute(updatedRoute)
        
        // If currently navigating, restart navigation with updated route
        if isNavigating {
            try await navigationService.stopNavigation()
            try await navigationService.startNavigation(route: updatedRoute)
        }
        
        await notifyDestinationAdded(updatedRoute)
    }
    
    /// Add a waypoint (fuel stop, food stop, etc.) to the current route
    func addWaypoint(_ destination: Destination) async throws {
        guard let route = currentRoute else {
            throw RouteManagerError.noRouteAvailable
        }
        
        // Find the best position to insert the waypoint based on route optimization
        let optimalIndex = try await findOptimalWaypointPosition(destination, in: route)
        
        try await addDestination(destination, at: optimalIndex)
    }
    
    /// Remove a destination from the current route
    func removeDestination(at index: Int) async throws {
        guard var route = currentRoute,
              index < route.destinations.count else {
            throw RouteManagerError.invalidDestinationIndex
        }
        
        route.destinations.remove(at: index)
        
        guard !route.destinations.isEmpty else {
            // If no destinations left, clear the route
            await MainActor.run {
                self.currentRoute = nil
            }
            
            if isNavigating {
                try await stopNavigation()
            }
            return
        }
        
        // Recalculate route without removed destination
        let updatedRoute = try await mapService.calculateMultiDestinationRoute(destinations: route.destinations)
        
        await MainActor.run {
            self.currentRoute = updatedRoute
        }
        
        // Display updated route
        try await mapService.displayRoute(updatedRoute)
        
        // If currently navigating, restart navigation with updated route
        if isNavigating {
            try await navigationService.stopNavigation()
            try await navigationService.startNavigation(route: updatedRoute)
        }
        
        await notifyDestinationRemoved(updatedRoute)
    }
    
    /// Reorder destinations in the current route
    func reorderDestinations(_ destinations: [Destination]) async throws {
        guard !destinations.isEmpty else {
            throw RouteManagerError.noDestinations
        }
        
        let updatedRoute = try await mapService.calculateMultiDestinationRoute(destinations: destinations)
        
        await MainActor.run {
            self.currentRoute = updatedRoute
        }
        
        // Display updated route
        try await mapService.displayRoute(updatedRoute)
        
        // If currently navigating, restart navigation with updated route
        if isNavigating {
            try await navigationService.stopNavigation()
            try await navigationService.startNavigation(route: updatedRoute)
        }
        
        await notifyRouteUpdate(updatedRoute)
    }
    
    /// Get turn-by-turn directions for the current route
    func getDirections() async throws -> [RouteStep] {
        guard let route = currentRoute else {
            throw RouteManagerError.noRouteAvailable
        }
        
        return try await mapService.getDirections(for: route)
    }
    
    /// Check if current location is off the planned route
    func checkRouteDeviation() async -> Bool {
        guard let currentLocation = locationManager.currentLocation,
              isNavigating else {
            return false
        }
        
        let isOffRoute = navigationService.isOffRoute(currentLocation: currentLocation.coordinate)
        
        await MainActor.run {
            self.routeDeviation = isOffRoute
        }
        
        if isOffRoute {
            await notifyRouteDeviation()
        }
        
        return isOffRoute
    }
    
    // MARK: - Private Methods
    
    private func setupBindings() {
        // Bind navigation updates
        navigationService.navigationUpdates
            .receive(on: DispatchQueue.main)
            .sink { [weak self] update in
                self?.navigationUpdate = update
                
                // Check for route deviation
                if update.isOffRoute {
                    self?.routeDeviation = true
                }
            }
            .store(in: &cancellables)
        
        // Bind route progress
        navigationService.routeProgress
            .receive(on: DispatchQueue.main)
            .sink { [weak self] progress in
                self?.routeProgress = progress
            }
            .store(in: &cancellables)
        
        // Bind current route from navigation service
        if let navigationService = navigationService as? NavigationService {
            navigationService.$currentRoute
                .receive(on: DispatchQueue.main)
                .sink { [weak self] route in
                    if self?.currentRoute != route {
                        self?.currentRoute = route
                    }
                }
                .store(in: &cancellables)
        }
    }
    
    private func notifyRouteUpdate(_ route: Route) async {
        await MainActor.run {
            NotificationCenter.default.post(
                name: .routeUpdated,
                object: RouteUpdateNotification(
                    route: route,
                    updateType: .routeChanged,
                    timestamp: Date()
                )
            )
        }
        
        // Send push notification to all trip participants
        await sendRouteUpdateToParticipants(route: route, updateType: .routeChanged)
    }
    
    private func notifyRouteRecalculation(_ route: Route) async {
        await MainActor.run {
            NotificationCenter.default.post(
                name: .routeRecalculated,
                object: RouteUpdateNotification(
                    route: route,
                    updateType: .routeRecalculated,
                    timestamp: Date()
                )
            )
        }
        
        // Send push notification to all trip participants
        await sendRouteUpdateToParticipants(route: route, updateType: .routeRecalculated)
    }
    
    private func notifyDestinationAdded(_ route: Route) async {
        await MainActor.run {
            NotificationCenter.default.post(
                name: .routeUpdated,
                object: RouteUpdateNotification(
                    route: route,
                    updateType: .destinationAdded,
                    timestamp: Date()
                )
            )
        }
        
        // Send push notification to all trip participants
        await sendRouteUpdateToParticipants(route: route, updateType: .destinationAdded)
    }
    
    private func notifyDestinationRemoved(_ route: Route) async {
        await MainActor.run {
            NotificationCenter.default.post(
                name: .routeUpdated,
                object: RouteUpdateNotification(
                    route: route,
                    updateType: .destinationRemoved,
                    timestamp: Date()
                )
            )
        }
        
        // Send push notification to all trip participants
        await sendRouteUpdateToParticipants(route: route, updateType: .destinationRemoved)
    }
    
    private func notifyRouteDeviation() async {
        await MainActor.run {
            NotificationCenter.default.post(
                name: .routeDeviationDetected,
                object: RouteUpdateNotification(
                    route: currentRoute,
                    updateType: .routeDeviation,
                    timestamp: Date()
                )
            )
        }
        
        // Send push notification to all trip participants
        if let route = currentRoute {
            await sendRouteUpdateToParticipants(route: route, updateType: .routeDeviation)
        }
    }
    
    /// Find the optimal position to insert a waypoint in the route
    private func findOptimalWaypointPosition(_ waypoint: Destination, in route: Route) async throws -> Int {
        // Simple implementation: find the position that minimizes total route distance
        var bestIndex = route.destinations.count
        var shortestDistance = Double.infinity
        
        for i in 0...route.destinations.count {
            var testDestinations = route.destinations
            testDestinations.insert(waypoint, at: i)
            
            // Calculate total distance for this configuration
            let totalDistance = calculateTotalRouteDistance(testDestinations)
            
            if totalDistance < shortestDistance {
                shortestDistance = totalDistance
                bestIndex = i
            }
        }
        
        return bestIndex
    }
    
    /// Calculate total distance for a set of destinations
    private func calculateTotalRouteDistance(_ destinations: [Destination]) -> Double {
        guard destinations.count > 1 else { return 0 }
        
        var totalDistance: Double = 0
        
        for i in 0..<destinations.count - 1 {
            let from = CLLocation(
                latitude: destinations[i].coordinate.latitude,
                longitude: destinations[i].coordinate.longitude
            )
            let to = CLLocation(
                latitude: destinations[i + 1].coordinate.latitude,
                longitude: destinations[i + 1].coordinate.longitude
            )
            
            totalDistance += from.distance(from: to)
        }
        
        return totalDistance
    }
    
    private func sendRouteUpdateToParticipants(route: Route, updateType: RouteUpdateType) async {
        // This would integrate with a notification service to send push notifications
        // For now, we'll use local notifications as a placeholder
        
        let content = UNMutableNotificationContent()
        content.title = "Route Update"
        
        switch updateType {
        case .routeChanged:
            content.body = "The trip route has been updated with new destinations."
        case .routeRecalculated:
            content.body = "The route has been recalculated due to traffic or road conditions."
        case .routeDeviation:
            content.body = "A participant has deviated from the planned route."
        case .destinationAdded:
            content.body = "A new destination has been added to the trip."
        case .destinationRemoved:
            content.body = "A destination has been removed from the trip."
        }
        
        content.sound = .default
        content.userInfo = [
            "routeId": route.id.uuidString,
            "updateType": updateType.rawValue
        ]
        
        let request = UNNotificationRequest(
            identifier: "route_update_\(UUID().uuidString)",
            content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        )
        
        do {
            try await UNUserNotificationCenter.current().add(request)
        } catch {
            print("Failed to send route update notification: \(error)")
        }
    }
}

// MARK: - Route Manager Error
enum RouteManagerError: LocalizedError {
    case noDestinations
    case noRouteAvailable
    case locationUnavailable
    case invalidDestinationIndex
    case routeCalculationFailed
    case navigationError(Error)
    
    var errorDescription: String? {
        switch self {
        case .noDestinations:
            return "No destinations provided"
        case .noRouteAvailable:
            return "No route available"
        case .locationUnavailable:
            return "Current location unavailable"
        case .invalidDestinationIndex:
            return "Invalid destination index"
        case .routeCalculationFailed:
            return "Failed to calculate route"
        case .navigationError(let error):
            return "Navigation error: \(error.localizedDescription)"
        }
    }
}

// MARK: - Supporting Types

struct RouteUpdateNotification {
    let route: Route?
    let updateType: RouteUpdateType
    let timestamp: Date
}

enum RouteUpdateType: String, CaseIterable {
    case routeChanged = "route_changed"
    case routeRecalculated = "route_recalculated"
    case routeDeviation = "route_deviation"
    case destinationAdded = "destination_added"
    case destinationRemoved = "destination_removed"
}

// MARK: - Additional Notification Names
extension Notification.Name {
    static let routeUpdated = Notification.Name("routeUpdated")
}