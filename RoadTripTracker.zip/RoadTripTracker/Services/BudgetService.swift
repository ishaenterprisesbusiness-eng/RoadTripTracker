import Foundation
import Combine
import CoreData
import CoreLocation

// MARK: - Budget Service Implementation
class BudgetService: BudgetServiceProtocol {
    
    // MARK: - Properties
    private let persistenceController: PersistenceController
    private let notificationService: NotificationServiceProtocol
    private let budgetUpdateSubject = PassthroughSubject<BudgetUpdate, Never>()
    
    var budgetUpdates: AnyPublisher<BudgetUpdate, Never> {
        budgetUpdateSubject.eraseToAnyPublisher()
    }
    
    // MARK: - Initialization
    init(persistenceController: PersistenceController, notificationService: NotificationServiceProtocol) {
        self.persistenceController = persistenceController
        self.notificationService = notificationService
    }
    
    // MARK: - Budget Management
    func createBudget(for tripId: UUID, totalBudget: Double, perPersonBudget: Double?) async throws -> Budget {
        let context = persistenceController.container.viewContext
        
        return try await context.perform {
            // Find the trip
            let request: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
            request.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
            
            guard let cdTrip = try context.fetch(request).first else {
                throw BudgetServiceError.budgetNotFound
            }
            
            // Update trip budget
            cdTrip.totalBudget = totalBudget
            
            try context.save()
            
            let budget = Budget(
                totalBudget: totalBudget,
                perPersonBudget: perPersonBudget,
                expenses: [],
                categories: [:]
            )
            
            return budget
        }
    }
    
    func addExpense(_ expense: Expense, to tripId: UUID) async throws {
        let context = persistenceController.container.viewContext
        
        try await context.perform {
            // Find the trip
            let tripRequest: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
            tripRequest.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
            
            guard let cdTrip = try context.fetch(tripRequest).first else {
                throw BudgetServiceError.budgetNotFound
            }
            
            // Create new expense entity
            let cdExpense = CDExpense(context: context)
            cdExpense.id = expense.id
            cdExpense.amount = expense.amount
            cdExpense.category = expense.category.rawValue
            cdExpense.descriptionText = expense.description
            cdExpense.participantId = expense.participantId
            cdExpense.timestamp = expense.timestamp
            
            if let location = expense.location {
                cdExpense.latitude = location.latitude
                cdExpense.longitude = location.longitude
            }
            
            cdExpense.trip = cdTrip
            
            try context.save()
            
            // Get updated budget summary and send notification
            let summary = try await self.getBudgetSummary(for: tripId)
            let update = BudgetUpdate(
                tripId: tripId,
                updateType: .expenseAdded,
                expense: expense,
                summary: summary
            )
            
            self.budgetUpdateSubject.send(update)
            
            // Check if approaching budget limit
            await self.checkBudgetLimits(summary: summary)
        }
    }
    
    func updateExpense(_ expense: Expense) async throws {
        let context = persistenceController.container.viewContext
        
        try await context.perform {
            let request: NSFetchRequest<CDExpense> = CDExpense.fetchRequest()
            request.predicate = NSPredicate(format: "id == %@", expense.id as CVarArg)
            
            guard let cdExpense = try context.fetch(request).first else {
                throw BudgetServiceError.expenseNotFound
            }
            
            cdExpense.amount = expense.amount
            cdExpense.category = expense.category.rawValue
            cdExpense.descriptionText = expense.description
            cdExpense.timestamp = expense.timestamp
            
            if let location = expense.location {
                cdExpense.latitude = location.latitude
                cdExpense.longitude = location.longitude
            }
            
            try context.save()
            
            // Get trip ID and send update
            if let tripId = cdExpense.trip?.id {
                let summary = try await self.getBudgetSummary(for: tripId)
                let update = BudgetUpdate(
                    tripId: tripId,
                    updateType: .expenseUpdated,
                    expense: expense,
                    summary: summary
                )
                
                self.budgetUpdateSubject.send(update)
            }
        }
    }
    
    func deleteExpense(_ expenseId: UUID, from tripId: UUID) async throws {
        let context = persistenceController.container.viewContext
        
        try await context.perform {
            let request: NSFetchRequest<CDExpense> = CDExpense.fetchRequest()
            request.predicate = NSPredicate(format: "id == %@ AND trip.id == %@", expenseId as CVarArg, tripId as CVarArg)
            
            guard let cdExpense = try context.fetch(request).first else {
                throw BudgetServiceError.expenseNotFound
            }
            
            context.delete(cdExpense)
            try context.save()
            
            let summary = try await self.getBudgetSummary(for: tripId)
            let update = BudgetUpdate(
                tripId: tripId,
                updateType: .expenseDeleted,
                summary: summary
            )
            
            self.budgetUpdateSubject.send(update)
        }
    }
    
    func getBudgetSummary(for tripId: UUID) async throws -> BudgetSummary {
        let context = persistenceController.container.viewContext
        
        return try await context.perform {
            // Fetch trip with expenses
            let tripRequest: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
            tripRequest.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
            tripRequest.relationshipKeyPathsForPrefetching = ["expenses", "participants"]
            
            guard let cdTrip = try context.fetch(tripRequest).first else {
                throw BudgetServiceError.budgetNotFound
            }
            
            let expenses = cdTrip.expenses?.allObjects as? [CDExpense] ?? []
            let totalBudget = cdTrip.totalBudget
            let totalSpent = expenses.reduce(0) { $0 + $1.amount }
            let remainingBudget = totalBudget - totalSpent
            
            // Calculate spending by category
            var spendingByCategory: [ExpenseCategory: Double] = [:]
            for expense in expenses {
                if let categoryString = expense.category,
                   let category = ExpenseCategory(rawValue: categoryString) {
                    spendingByCategory[category, default: 0] += expense.amount
                }
            }
            
            // Calculate spending by participant
            var spendingByParticipant: [UUID: Double] = [:]
            for expense in expenses {
                if let participantId = expense.participantId {
                    spendingByParticipant[participantId, default: 0] += expense.amount
                }
            }
            
            // Calculate average spending per day
            let tripStartDate = cdTrip.startedAt ?? cdTrip.createdAt ?? Date()
            let daysSinceStart = max(1, Calendar.current.dateComponents([.day], from: tripStartDate, to: Date()).day ?? 1)
            let averageSpendingPerDay = totalSpent / Double(daysSinceStart)
            
            // Project total spending (simple linear projection)
            let projectedTotalSpending = totalSpent + (averageSpendingPerDay * 7) // Project for next week
            
            return BudgetSummary(
                tripId: tripId,
                totalBudget: totalBudget,
                totalSpent: totalSpent,
                remainingBudget: remainingBudget,
                spendingByCategory: spendingByCategory,
                spendingByParticipant: spendingByParticipant,
                averageSpendingPerDay: averageSpendingPerDay,
                projectedTotalSpending: projectedTotalSpending
            )
        }
    }
    
    // MARK: - Private Methods
    private func checkBudgetLimits(summary: BudgetSummary) async {
        let spentPercentage = summary.totalSpent / summary.totalBudget
        
        // Send notification if approaching budget limit (80% or 90%)
        if spentPercentage >= 0.9 {
            await sendBudgetNotification(
                tripId: summary.tripId,
                title: "Budget Alert",
                message: "You've spent 90% of your trip budget. Remaining: $\(String(format: "%.2f", summary.remainingBudget))"
            )
        } else if spentPercentage >= 0.8 {
            await sendBudgetNotification(
                tripId: summary.tripId,
                title: "Budget Warning",
                message: "You've spent 80% of your trip budget. Remaining: $\(String(format: "%.2f", summary.remainingBudget))"
            )
        }
    }
    
    private func sendBudgetNotification(tripId: UUID, title: String, message: String) async {
        do {
            // Get trip participants to send notification to
            let context = persistenceController.container.viewContext
            let tripRequest: NSFetchRequest<CDTrip> = CDTrip.fetchRequest()
            tripRequest.predicate = NSPredicate(format: "id == %@", tripId as CVarArg)
            tripRequest.relationshipKeyPathsForPrefetching = ["participants"]
            
            let recipientIds: [UUID] = try await context.perform {
                guard let cdTrip = try context.fetch(tripRequest).first,
                      let participants = cdTrip.participants?.allObjects as? [CDParticipant] else {
                    return []
                }
                return participants.compactMap { $0.userId }
            }
            
            let pushNotification = PushNotification(
                recipientIds: recipientIds,
                title: title,
                body: message,
                data: [
                    "tripId": tripId.uuidString,
                    "type": "budget_alert"
                ],
                priority: .normal
            )
            
            try await notificationService.sendPushNotification(pushNotification)
        } catch {
            print("Failed to send budget notification: \(error)")
        }
    }
}

// MARK: - Core Data Extensions
extension CDExpense {
    func toExpense() -> Expense {
        return Expense(
            id: self.id ?? UUID(),
            amount: self.amount,
            category: ExpenseCategory(rawValue: self.category ?? "other") ?? .other,
            description: self.descriptionText ?? "",
            participantId: self.participantId ?? UUID(),
            timestamp: self.timestamp ?? Date(),
            location: (self.latitude != 0 || self.longitude != 0) ? 
                CLLocationCoordinate2D(latitude: self.latitude, longitude: self.longitude) : nil
        )
    }
}