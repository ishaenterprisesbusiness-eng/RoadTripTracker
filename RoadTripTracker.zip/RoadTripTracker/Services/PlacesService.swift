import Foundation
import MapKit
import CoreLocation

// MARK: - Places Service Protocol
protocol PlacesServiceProtocol {
    func searchPlaces(query: String, region: MKCoordinateRegion?) async throws -> [PlaceSearchResult]
    func getPlaceDetails(for placeId: String) async throws -> PlaceDetails
    func getNearbyPlaces(coordinate: CLLocationCoordinate2D, radius: Double, category: PlaceCategory) async throws -> [PlaceSearchResult]
}

// MARK: - Place Search Result
struct PlaceSearchResult: Identifiable, Codable {
    let id: String
    let name: String
    let address: String
    let coordinate: CLLocationCoordinate2D
    let category: PlaceCategory
    let rating: Double?
    let priceLevel: Int?
    let isOpen: Bool?
    
    init(id: String, name: String, address: String, coordinate: CLLocationCoordinate2D, category: PlaceCategory, rating: Double? = nil, priceLevel: Int? = nil, isOpen: Bool? = nil) {
        self.id = id
        self.name = name
        self.address = address
        self.coordinate = coordinate
        self.category = category
        self.rating = rating
        self.priceLevel = priceLevel
        self.isOpen = isOpen
    }
}

// MARK: - Place Details
struct PlaceDetails: Codable {
    let id: String
    let name: String
    let address: String
    let coordinate: CLLocationCoordinate2D
    let phoneNumber: String?
    let website: URL?
    let openingHours: [String]?
    let rating: Double?
    let priceLevel: Int?
    let photos: [URL]?
    let reviews: [PlaceReview]?
}

// MARK: - Place Review
struct PlaceReview: Codable {
    let author: String
    let rating: Double
    let text: String
    let timestamp: Date
}

// MARK: - Place Category
enum PlaceCategory: String, CaseIterable, Codable {
    case restaurant = "restaurant"
    case gasStation = "gas_station"
    case hotel = "lodging"
    case attraction = "tourist_attraction"
    case shopping = "shopping_mall"
    case hospital = "hospital"
    case bank = "bank"
    case pharmacy = "pharmacy"
    case general = "establishment"
    
    var displayName: String {
        switch self {
        case .restaurant: return "Restaurant"
        case .gasStation: return "Gas Station"
        case .hotel: return "Hotel"
        case .attraction: return "Attraction"
        case .shopping: return "Shopping"
        case .hospital: return "Hospital"
        case .bank: return "Bank"
        case .pharmacy: return "Pharmacy"
        case .general: return "General"
        }
    }
}

// MARK: - Places Service Implementation
class PlacesService: PlacesServiceProtocol {
    private let localSearchCompleter = MKLocalSearchCompleter()
    
    init() {
        localSearchCompleter.resultTypes = [.address, .pointOfInterest]
    }
    
    func searchPlaces(query: String, region: MKCoordinateRegion?) async throws -> [PlaceSearchResult] {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        
        if let region = region {
            request.region = region
        }
        
        let search = MKLocalSearch(request: request)
        
        do {
            let response = try await search.start()
            
            return response.mapItems.compactMap { mapItem in
                guard let name = mapItem.name,
                      let placemark = mapItem.placemark.location?.coordinate else {
                    return nil
                }
                
                let address = formatAddress(from: mapItem.placemark)
                let category = determineCategory(from: mapItem)
                
                return PlaceSearchResult(
                    id: mapItem.placemark.description,
                    name: name,
                    address: address,
                    coordinate: placemark,
                    category: category
                )
            }
        } catch {
            throw PlacesServiceError.searchFailed(error.localizedDescription)
        }
    }
    
    func getPlaceDetails(for placeId: String) async throws -> PlaceDetails {
        // For now, we'll use a simplified implementation
        // In a real app, you might use Google Places API or similar
        throw PlacesServiceError.notImplemented
    }
    
    func getNearbyPlaces(coordinate: CLLocationCoordinate2D, radius: Double, category: PlaceCategory) async throws -> [PlaceSearchResult] {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = category.displayName
        
        let region = MKCoordinateRegion(
            center: coordinate,
            latitudinalMeters: radius * 2,
            longitudinalMeters: radius * 2
        )
        request.region = region
        
        let search = MKLocalSearch(request: request)
        
        do {
            let response = try await search.start()
            
            return response.mapItems.compactMap { mapItem in
                guard let name = mapItem.name,
                      let placemark = mapItem.placemark.location?.coordinate else {
                    return nil
                }
                
                let address = formatAddress(from: mapItem.placemark)
                
                return PlaceSearchResult(
                    id: mapItem.placemark.description,
                    name: name,
                    address: address,
                    coordinate: placemark,
                    category: category
                )
            }
        } catch {
            throw PlacesServiceError.searchFailed(error.localizedDescription)
        }
    }
    
    // MARK: - Private Methods
    
    private func formatAddress(from placemark: CLPlacemark) -> String {
        var addressComponents: [String] = []
        
        if let subThoroughfare = placemark.subThoroughfare {
            addressComponents.append(subThoroughfare)
        }
        
        if let thoroughfare = placemark.thoroughfare {
            addressComponents.append(thoroughfare)
        }
        
        if let locality = placemark.locality {
            addressComponents.append(locality)
        }
        
        if let administrativeArea = placemark.administrativeArea {
            addressComponents.append(administrativeArea)
        }
        
        if let postalCode = placemark.postalCode {
            addressComponents.append(postalCode)
        }
        
        return addressComponents.joined(separator: ", ")
    }
    
    private func determineCategory(from mapItem: MKMapItem) -> PlaceCategory {
        // Simple category determination based on point of interest category
        if let category = mapItem.pointOfInterestCategory {
            switch category {
            case .restaurant, .foodMarket, .bakery, .brewery, .cafe, .winery:
                return .restaurant
            case .gasStation, .evCharger:
                return .gasStation
            case .hotel:
                return .hotel
            case .museum, .nationalPark, .zoo, .aquarium, .amusementPark:
                return .attraction
            case .store, .departmentStore:
                return .shopping
            case .hospital:
                return .hospital
            case .bank, .atm:
                return .bank
            case .pharmacy:
                return .pharmacy
            default:
                return .general
            }
        }
        
        return .general
    }
}

// MARK: - Places Service Error
enum PlacesServiceError: LocalizedError {
    case searchFailed(String)
    case notImplemented
    case networkError
    case invalidQuery
    
    var errorDescription: String? {
        switch self {
        case .searchFailed(let message):
            return "Search failed: \(message)"
        case .notImplemented:
            return "Feature not implemented"
        case .networkError:
            return "Network connection error"
        case .invalidQuery:
            return "Invalid search query"
        }
    }
}