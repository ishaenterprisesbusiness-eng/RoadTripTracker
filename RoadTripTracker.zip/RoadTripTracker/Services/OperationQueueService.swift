import Foundation
import Combine
import CloudKit

// MARK: - Operation Queue Service
@MainActor
class OperationQueueService: ObservableObject {
    
    // MARK: - Properties
    static let shared = OperationQueueService()
    
    private let offlineManager = OfflineManager.shared
    private let persistenceController = PersistenceController.shared
    
    @Published var queuedOperations: [QueuedOperation] = []
    @Published var isProcessing: Bool = false
    @Published var lastProcessedDate: Date?
    
    private var processingCancellables = Set<AnyCancellable>()
    private let operationQueue = OperationQueue()
    
    // MARK: - Initialization
    private init() {
        setupOperationQueue()
        loadQueuedOperations()
        observeNetworkChanges()
    }
    
    private func setupOperationQueue() {
        operationQueue.maxConcurrentOperationCount = 3
        operationQueue.qualityOfService = .utility
    }
    
    private func observeNetworkChanges() {
        offlineManager.$isOnline
            .sink { [weak self] isOnline in
                if isOnline {
                    Task {
                        await self?.processQueuedOperations()
                    }
                }
            }
            .store(in: &processingCancellables)
    }
    
    // MARK: - Operation Queuing
    func queueLocationUpdate(tripId: UUID, participantId: UUID, location: CLLocation) {
        let locationData = CachedLocationData(
            tripId: tripId,
            participantId: participantId,
            latitude: location.coordinate.latitude,
            longitude: location.coordinate.longitude,
            timestamp: location.timestamp,
            speed: location.speed >= 0 ? location.speed : nil,
            heading: location.course >= 0 ? location.course : nil,
            accuracy: location.horizontalAccuracy
        )
        
        queueOperation(.locationUpdate, data: locationData, priority: .high)
    }
    
    func queueMessageSend(tripId: UUID, senderId: UUID, content: String, type: MessageType, location: CLLocation? = nil, photoURL: URL? = nil) {
        let messageData = CachedMessageData(
            tripId: tripId,
            senderId: senderId,
            content: content,
            type: type.rawValue,
            timestamp: Date(),
            latitude: location?.coordinate.latitude,
            longitude: location?.coordinate.longitude,
            photoURL: photoURL
        )
        
        queueOperation(.messageSync, data: messageData, priority: .normal)
    }
    
    func queuePhotoUpload(tripId: UUID, sharedBy: UUID, photoURL: URL, caption: String?, location: CLLocation, tags: [String]?) {
        let photoData = CachedPhotoData(
            tripId: tripId,
            sharedBy: sharedBy,
            caption: caption,
            timestamp: Date(),
            latitude: location.coordinate.latitude,
            longitude: location.coordinate.longitude,
            localPhotoURL: photoURL,
            tags: tags
        )
        
        queueOperation(.photoUpload, data: photoData, priority: .low)
    }
    
    func queueExpenseLog(tripId: UUID, participantId: UUID, amount: Double, category: String, description: String, location: CLLocation) {
        let expenseData = CachedExpenseData(
            tripId: tripId,
            participantId: participantId,
            amount: amount,
            category: category,
            description: description,
            timestamp: Date(),
            latitude: location.coordinate.latitude,
            longitude: location.coordinate.longitude
        )
        
        queueOperation(.expenseSync, data: expenseData, priority: .normal)
    }
    
    func queueTripUpdate(tripId: UUID, name: String, status: String, currentDestinationIndex: Int32, createdBy: UUID, code: String, createdAt: Date) {
        let tripData = CachedTripData(
            tripId: tripId,
            name: name,
            status: status,
            currentDestinationIndex: currentDestinationIndex,
            createdBy: createdBy,
            code: code,
            createdAt: createdAt
        )
        
        queueOperation(.tripUpdate, data: tripData, priority: .normal)
    }
    
    private func queueOperation<T: Codable>(_ type: OfflineOperationType, data: T, priority: OperationPriority) {
        do {
            let encodedData = try JSONEncoder().encode(data)
            let operation = QueuedOperation(
                type: type,
                data: encodedData,
                priority: priority,
                createdAt: Date()
            )
            
            queuedOperations.append(operation)
            saveQueuedOperations()
            
            // Try to process immediately if online
            if offlineManager.isOnline {
                Task {
                    await processOperation(operation)
                }
            }
            
        } catch {
            print("Failed to queue operation: \(error)")
        }
    }
    
    // MARK: - Operation Processing
    func processQueuedOperations() async {
        guard !isProcessing && offlineManager.isOnline else { return }
        
        isProcessing = true
        
        // Sort operations by priority and creation date
        let sortedOperations = queuedOperations.sorted { lhs, rhs in
            if lhs.priority != rhs.priority {
                return lhs.priority.rawValue > rhs.priority.rawValue
            }
            return lhs.createdAt < rhs.createdAt
        }
        
        for operation in sortedOperations {
            await processOperation(operation)
        }
        
        isProcessing = false
        lastProcessedDate = Date()
    }
    
    private func processOperation(_ operation: QueuedOperation) async {
        guard offlineManager.isOnline else { return }
        
        do {
            switch operation.type {
            case .locationUpdate:
                await processLocationUpdate(operation)
            case .messageSync:
                await processMessageSync(operation)
            case .photoUpload:
                await processPhotoUpload(operation)
            case .expenseSync:
                await processExpenseSync(operation)
            case .tripUpdate:
                await processTripUpdate(operation)
            }
            
            // Remove successful operation
            removeOperation(operation)
            
        } catch {
            print("Failed to process operation \(operation.id): \(error)")
            
            // Update retry count
            operation.retryCount += 1
            operation.lastAttempt = Date()
            
            // Remove if max retries exceeded
            if operation.retryCount >= operation.maxRetries {
                removeOperation(operation)
            } else {
                saveQueuedOperations()
            }
        }
    }
    
    // MARK: - Specific Operation Processors
    private func processLocationUpdate(_ operation: QueuedOperation) async throws {
        guard let data = operation.data,
              let locationData = try? JSONDecoder().decode(CachedLocationData.self, from: data) else {
            throw OperationError.invalidData
        }
        
        let record = CKRecord(recordType: "ParticipantLocation")
        record["tripId"] = locationData.tripId.uuidString
        record["participantId"] = locationData.participantId.uuidString
        record["latitude"] = locationData.latitude
        record["longitude"] = locationData.longitude
        record["timestamp"] = locationData.timestamp
        record["speed"] = locationData.speed
        record["heading"] = locationData.heading
        record["accuracy"] = locationData.accuracy
        
        let database = CKContainer.default().publicCloudDatabase
        _ = try await database.save(record)
    }
    
    private func processMessageSync(_ operation: QueuedOperation) async throws {
        guard let data = operation.data,
              let messageData = try? JSONDecoder().decode(CachedMessageData.self, from: data) else {
            throw OperationError.invalidData
        }
        
        let record = CKRecord(recordType: "Message")
        record["tripId"] = messageData.tripId.uuidString
        record["senderId"] = messageData.senderId.uuidString
        record["content"] = messageData.content
        record["type"] = messageData.type
        record["timestamp"] = messageData.timestamp
        
        if let latitude = messageData.latitude, let longitude = messageData.longitude {
            record["latitude"] = latitude
            record["longitude"] = longitude
        }
        
        if let photoURL = messageData.photoURL {
            record["photoURL"] = photoURL.absoluteString
        }
        
        let database = CKContainer.default().publicCloudDatabase
        _ = try await database.save(record)
    }
    
    private func processPhotoUpload(_ operation: QueuedOperation) async throws {
        guard let data = operation.data,
              let photoData = try? JSONDecoder().decode(CachedPhotoData.self, from: data) else {
            throw OperationError.invalidData
        }
        
        let record = CKRecord(recordType: "PhotoShare")
        record["tripId"] = photoData.tripId.uuidString
        record["sharedBy"] = photoData.sharedBy.uuidString
        record["caption"] = photoData.caption
        record["timestamp"] = photoData.timestamp
        record["latitude"] = photoData.latitude
        record["longitude"] = photoData.longitude
        
        // Handle photo asset upload
        if let photoURL = photoData.localPhotoURL,
           FileManager.default.fileExists(atPath: photoURL.path) {
            let asset = CKAsset(fileURL: photoURL)
            record["photoAsset"] = asset
        }
        
        let database = CKContainer.default().publicCloudDatabase
        _ = try await database.save(record)
    }
    
    private func processExpenseSync(_ operation: QueuedOperation) async throws {
        guard let data = operation.data,
              let expenseData = try? JSONDecoder().decode(CachedExpenseData.self, from: data) else {
            throw OperationError.invalidData
        }
        
        let record = CKRecord(recordType: "Expense")
        record["tripId"] = expenseData.tripId.uuidString
        record["participantId"] = expenseData.participantId.uuidString
        record["amount"] = expenseData.amount
        record["category"] = expenseData.category
        record["description"] = expenseData.description
        record["timestamp"] = expenseData.timestamp
        record["latitude"] = expenseData.latitude
        record["longitude"] = expenseData.longitude
        
        let database = CKContainer.default().publicCloudDatabase
        _ = try await database.save(record)
    }
    
    private func processTripUpdate(_ operation: QueuedOperation) async throws {
        guard let data = operation.data,
              let tripData = try? JSONDecoder().decode(CachedTripData.self, from: data) else {
            throw OperationError.invalidData
        }
        
        let database = CKContainer.default().publicCloudDatabase
        let recordID = CKRecord.ID(recordName: tripData.tripId.uuidString)
        
        do {
            let record = try await database.record(for: recordID)
            record["name"] = tripData.name
            record["status"] = tripData.status
            record["currentDestinationIndex"] = tripData.currentDestinationIndex
            
            _ = try await database.save(record)
        } catch {
            // If record doesn't exist, create new one
            let record = CKRecord(recordType: "Trip", recordID: recordID)
            record["name"] = tripData.name
            record["status"] = tripData.status
            record["currentDestinationIndex"] = tripData.currentDestinationIndex
            record["createdBy"] = tripData.createdBy.uuidString
            record["code"] = tripData.code
            record["createdAt"] = tripData.createdAt
            
            _ = try await database.save(record)
        }
    }
    
    // MARK: - Operation Management
    private func removeOperation(_ operation: QueuedOperation) {
        queuedOperations.removeAll { $0.id == operation.id }
        saveQueuedOperations()
    }
    
    func clearAllOperations() {
        queuedOperations.removeAll()
        saveQueuedOperations()
    }
    
    func retryFailedOperations() async {
        let failedOperations = queuedOperations.filter { $0.retryCount > 0 }
        
        for operation in failedOperations {
            operation.retryCount = 0
            operation.lastAttempt = nil
        }
        
        saveQueuedOperations()
        
        if offlineManager.isOnline {
            await processQueuedOperations()
        }
    }
    
    // MARK: - Persistence
    private func saveQueuedOperations() {
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(queuedOperations)
            UserDefaults.standard.set(data, forKey: "QueuedOperations")
        } catch {
            print("Failed to save queued operations: \(error)")
        }
    }
    
    private func loadQueuedOperations() {
        guard let data = UserDefaults.standard.data(forKey: "QueuedOperations"),
              let operations = try? JSONDecoder().decode([QueuedOperation].self, from: data) else {
            return
        }
        
        queuedOperations = operations
    }
    
    // MARK: - Statistics
    func getOperationStatistics() -> OperationStatistics {
        let totalOperations = queuedOperations.count
        let failedOperations = queuedOperations.filter { $0.retryCount > 0 }.count
        let highPriorityOperations = queuedOperations.filter { $0.priority == .high }.count
        let oldestOperation = queuedOperations.min(by: { $0.createdAt < $1.createdAt })?.createdAt
        
        return OperationStatistics(
            totalQueued: totalOperations,
            failed: failedOperations,
            highPriority: highPriorityOperations,
            oldestOperation: oldestOperation,
            lastProcessed: lastProcessedDate
        )
    }
}

// MARK: - Supporting Models

enum OperationPriority: Int, Codable {
    case low = 1
    case normal = 2
    case high = 3
}

class QueuedOperation: Codable, Identifiable {
    let id: UUID
    let type: OfflineOperationType
    let data: Data?
    let priority: OperationPriority
    let createdAt: Date
    var retryCount: Int
    var lastAttempt: Date?
    let maxRetries: Int
    
    init(type: OfflineOperationType, data: Data?, priority: OperationPriority, createdAt: Date, maxRetries: Int = 3) {
        self.id = UUID()
        self.type = type
        self.data = data
        self.priority = priority
        self.createdAt = createdAt
        self.retryCount = 0
        self.maxRetries = maxRetries
    }
}

struct OperationStatistics {
    let totalQueued: Int
    let failed: Int
    let highPriority: Int
    let oldestOperation: Date?
    let lastProcessed: Date?
}

enum OperationError: LocalizedError {
    case invalidData
    case networkUnavailable
    case cloudKitUnavailable
    case maxRetriesExceeded
    
    var errorDescription: String? {
        switch self {
        case .invalidData:
            return "Invalid operation data"
        case .networkUnavailable:
            return "Network connection unavailable"
        case .cloudKitUnavailable:
            return "CloudKit service unavailable"
        case .maxRetriesExceeded:
            return "Maximum retry attempts exceeded"
        }
    }
}

// MARK: - Message Type
enum MessageType: String, Codable {
    case text
    case location
    case photo
    case system
}