import Foundation
import CoreLocation
@testable import RoadTripTracker

/// Configuration for integration tests
struct IntegrationTestConfig {
    
    // MARK: - Test Environment Settings
    
    static let testTimeout: TimeInterval = 30.0
    static let shortTimeout: TimeInterval = 5.0
    static let longTimeout: TimeInterval = 60.0
    
    // MARK: - Test Data Constants
    
    struct TestLocations {
        static let sydney = CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)
        static let melbourne = CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631)
        static let canberra = CLLocationCoordinate2D(latitude: -35.2809, longitude: 149.1300)
        static let brisbane = CLLocationCoordinate2D(latitude: -27.4698, longitude: 153.0251)
        static let perth = CLLocationCoordinate2D(latitude: -31.9505, longitude: 115.8605)
    }
    
    struct TestUsers {
        static let user1 = TestUser(
            id: UUID(uuidString: "11111111-1111-1111-1111-111111111111")!,
            username: "testuser1",
            email: "test1@example.com"
        )
        
        static let user2 = TestUser(
            id: UUID(uuidString: "22222222-2222-2222-2222-222222222222")!,
            username: "testuser2",
            email: "test2@example.com"
        )
        
        static let user3 = TestUser(
            id: UUID(uuidString: "33333333-3333-3333-3333-333333333333")!,
            username: "testuser3",
            email: "test3@example.com"
        )
    }
    
    struct TestTrips {
        static let shortTrip = TestTrip(
            id: UUID(uuidString: "AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA")!,
            name: "Short Test Trip",
            code: "SHORT001",
            destinations: [TestLocations.sydney, TestLocations.canberra]
        )
        
        static let longTrip = TestTrip(
            id: UUID(uuidString: "BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB")!,
            name: "Long Test Trip",
            code: "LONG001",
            destinations: [
                TestLocations.sydney,
                TestLocations.canberra,
                TestLocations.melbourne,
                TestLocations.brisbane,
                TestLocations.perth
            ]
        )
    }
    
    // MARK: - Performance Test Settings
    
    struct PerformanceThresholds {
        static let locationUpdateMaxTime: TimeInterval = 0.1
        static let messageSyncMaxTime: TimeInterval = 1.0
        static let routeCalculationMaxTime: TimeInterval = 5.0
        static let cloudKitSyncMaxTime: TimeInterval = 10.0
        
        static let maxMemoryUsageMB: Double = 100.0
        static let maxCPUUsagePercent: Double = 80.0
        static let maxBatteryDrainPercent: Double = 5.0
    }
    
    // MARK: - API Test Settings
    
    struct APISettings {
        static let weatherAPIKey = "test_weather_api_key"
        static let placesAPIKey = "test_places_api_key"
        static let maxRetryAttempts = 3
        static let retryDelay: TimeInterval = 1.0
        static let rateLimitDelay: TimeInterval = 0.1
    }
}

// MARK: - Test Data Structures

struct TestUser {
    let id: UUID
    let username: String
    let email: String
    let city: String = "Sydney"
    let age: Int = 25
    
    var vehicle: TestVehicle {
        return TestVehicle(
            make: "Toyota",
            model: "Camry",
            vehicleNumber: "TEST\(String(id.uuidString.prefix(3)))",
            type: .sedan
        )
    }
}

struct TestVehicle {
    let make: String
    let model: String
    let vehicleNumber: String
    let odometerReading: Int = 50000
    let type: VehicleType
    let color: String = "Blue"
}

struct TestTrip {
    let id: UUID
    let name: String
    let code: String
    let destinations: [CLLocationCoordinate2D]
    let createdAt: Date = Date()
    let budget: Double = 1000.0
}

// MARK: - Test Environment Setup

class IntegrationTestEnvironment {
    
    static let shared = IntegrationTestEnvironment()
    
    private init() {}
    
    func setUp() {
        // Set up test environment
        UserDefaults.standard.set(true, forKey: "isTestEnvironment")
        UserDefaults.standard.set(false, forKey: "simulateNetworkFailure")
        UserDefaults.standard.set(true, forKey: "isNetworkConnected")
    }
    
    func tearDown() {
        // Clean up test environment
        UserDefaults.standard.removeObject(forKey: "isTestEnvironment")
        UserDefaults.standard.removeObject(forKey: "simulateNetworkFailure")
        UserDefaults.standard.removeObject(forKey: "isNetworkConnected")
        UserDefaults.standard.removeObject(forKey: "shouldFailMessageSync")
        UserDefaults.standard.removeObject(forKey: "shouldFailExpenseSync")
    }
    
    func resetToDefaults() {
        tearDown()
        setUp()
    }
}