import XCTest
import CloudKit
import CoreData
@testable import RoadTripTracker

@available(iOS 15.0, *)
class CloudKitIntegrationTests: XCTestCase {
    
    var persistenceController: PersistenceController!
    var container: CKContainer!
    var database: CKDatabase!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        
        // Use test container for CloudKit
        container = CKContainer(identifier: "iCloud.com.roadtriptracker.test")
        database = container.privateCloudDatabase
        
        // Set up test persistence controller
        persistenceController = PersistenceController(inMemory: true)
    }
    
    override func tearDownWithError() throws {
        persistenceController = nil
        container = nil
        database = nil
        try super.tearDownWithError()
    }
    
    // MARK: - CloudKit Synchronization Tests
    
    func testTripSynchronization() async throws {
        // Create a test trip locally
        let context = persistenceController.container.viewContext
        let trip = Trip(context: context)
        trip.id = UUID()
        trip.name = "Test Trip"
        trip.code = "TEST123"
        trip.createdAt = Date()
        
        try context.save()
        
        // Simulate CloudKit sync
        let record = CKRecord(recordType: "Trip", recordID: CKRecord.ID(recordName: trip.id!.uuidString))
        record["name"] = trip.name
        record["code"] = trip.code
        record["createdAt"] = trip.createdAt
        
        let expectation = XCTestExpectation(description: "CloudKit save")
        
        database.save(record) { savedRecord, error in
            XCTAssertNil(error, "CloudKit save should succeed")
            XCTAssertNotNil(savedRecord, "Saved record should exist")
            expectation.fulfill()
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
    
    func testConflictResolution() async throws {
        let tripId = UUID()
        
        // Create two conflicting records
        let record1 = CKRecord(recordType: "Trip", recordID: CKRecord.ID(recordName: tripId.uuidString))
        record1["name"] = "Trip Version 1"
        record1["modifiedAt"] = Date()
        
        let record2 = CKRecord(recordType: "Trip", recordID: CKRecord.ID(recordName: tripId.uuidString))
        record2["name"] = "Trip Version 2"
        record2["modifiedAt"] = Date().addingTimeInterval(60) // 1 minute later
        
        // Test conflict resolution - should keep the later version
        let resolvedRecord = resolveConflict(local: record1, remote: record2)
        XCTAssertEqual(resolvedRecord["name"] as? String, "Trip Version 2")
    }
    
    func testRealTimeSynchronization() async throws {
        let expectation = XCTestExpectation(description: "Real-time sync")
        
        // Set up subscription for real-time updates
        let subscription = CKQuerySubscription(
            recordType: "Trip",
            predicate: NSPredicate(value: true),
            options: [.firesOnRecordCreation, .firesOnRecordUpdate]
        )
        
        let notificationInfo = CKSubscription.NotificationInfo()
        notificationInfo.shouldSendContentAvailable = true
        subscription.notificationInfo = notificationInfo
        
        database.save(subscription) { savedSubscription, error in
            XCTAssertNil(error, "Subscription should be saved successfully")
            expectation.fulfill()
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
    
    func testDataConsistencyAcrossDevices() async throws {
        // Simulate data from multiple devices
        let device1Record = CKRecord(recordType: "Participant", recordID: CKRecord.ID(recordName: "device1-participant"))
        device1Record["userId"] = "user1"
        device1Record["deviceId"] = "device1"
        device1Record["lastUpdate"] = Date()
        
        let device2Record = CKRecord(recordType: "Participant", recordID: CKRecord.ID(recordName: "device2-participant"))
        device2Record["userId"] = "user2"
        device2Record["deviceId"] = "device2"
        device2Record["lastUpdate"] = Date()
        
        let expectation = XCTestExpectation(description: "Multi-device sync")
        expectation.expectedFulfillmentCount = 2
        
        database.save(device1Record) { _, error in
            XCTAssertNil(error)
            expectation.fulfill()
        }
        
        database.save(device2Record) { _, error in
            XCTAssertNil(error)
            expectation.fulfill()
        }
        
        await fulfillment(of: [expectation], timeout: 15.0)
    }
    
    // MARK: - Helper Methods
    
    private func resolveConflict(local: CKRecord, remote: CKRecord) -> CKRecord {
        let localModified = local["modifiedAt"] as? Date ?? Date.distantPast
        let remoteModified = remote["modifiedAt"] as? Date ?? Date.distantPast
        
        return remoteModified > localModified ? remote : local
    }
}