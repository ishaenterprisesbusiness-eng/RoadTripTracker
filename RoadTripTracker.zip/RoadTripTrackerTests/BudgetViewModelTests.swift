import XCTest
import Combine
import CoreLocation
@testable import RoadTripTracker

@MainActor
class BudgetViewModelTests: XCTestCase {
    
    var viewModel: BudgetViewModel!
    var mockBudgetService: MockBudgetService!
    var mockLocationService: MockLocationService!
    var cancellables: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        
        mockBudgetService = MockBudgetService()
        mockLocationService = MockLocationService()
        viewModel = BudgetViewModel(
            budgetService: mockBudgetService,
            locationService: mockLocationService
        )
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDownWithError() throws {
        cancellables = nil
        viewModel = nil
        mockLocationService = nil
        mockBudgetService = nil
        try super.tearDownWithError()
    }
    
    // MARK: - Initialization Tests
    
    func testInitialState() {
        XCTAssertNil(viewModel.budgetSummary)
        XCTAssertTrue(viewModel.expenses.isEmpty)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertNil(viewModel.errorMessage)
        XCTAssertFalse(viewModel.showingAddExpense)
        XCTAssertFalse(viewModel.showingBudgetSettings)
        
        // Form properties
        XCTAssertTrue(viewModel.newExpenseAmount.isEmpty)
        XCTAssertEqual(viewModel.newExpenseCategory, .fuel)
        XCTAssertTrue(viewModel.newExpenseDescription.isEmpty)
        XCTAssertNil(viewModel.selectedParticipantId)
        
        // Budget settings
        XCTAssertTrue(viewModel.totalBudget.isEmpty)
        XCTAssertTrue(viewModel.perPersonBudget.isEmpty)
    }
    
    // MARK: - Budget Summary Loading Tests
    
    func testLoadBudgetSummarySuccess() async {
        // Given
        let tripId = UUID()
        let expectedSummary = BudgetSummary(
            tripId: tripId,
            totalBudget: 1000.0,
            totalSpent: 400.0,
            remainingBudget: 600.0,
            spendingByCategory: [.fuel: 200.0, .food: 200.0],
            spendingByParticipant: [UUID(): 400.0]
        )
        mockBudgetService.mockBudgetSummary = expectedSummary
        
        // When
        viewModel.loadBudgetSummary(for: tripId)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertEqual(viewModel.budgetSummary?.tripId, tripId)
        XCTAssertEqual(viewModel.budgetSummary?.totalBudget, 1000.0)
        XCTAssertEqual(viewModel.budgetSummary?.totalSpent, 400.0)
        XCTAssertEqual(viewModel.totalBudget, "1000.00")
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertNil(viewModel.errorMessage)
    }
    
    func testLoadBudgetSummaryFailure() async {
        // Given
        let tripId = UUID()
        mockBudgetService.shouldThrowError = true
        mockBudgetService.errorToThrow = BudgetServiceError.budgetNotFound
        
        // When
        viewModel.loadBudgetSummary(for: tripId)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertNil(viewModel.budgetSummary)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertEqual(viewModel.errorMessage, "Budget not found")
    }
    
    // MARK: - Budget Creation Tests
    
    func testCreateBudgetSuccess() async {
        // Given
        let tripId = UUID()
        viewModel.totalBudget = "1500.00"
        viewModel.perPersonBudget = "375.00"
        
        // When
        viewModel.createBudget(for: tripId)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertFalse(viewModel.showingBudgetSettings)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertNil(viewModel.errorMessage)
        XCTAssertTrue(mockBudgetService.createBudgetCalled)
        XCTAssertEqual(mockBudgetService.lastTotalBudget, 1500.0)
        XCTAssertEqual(mockBudgetService.lastPerPersonBudget, 375.0)
    }
    
    func testCreateBudgetWithInvalidAmount() {
        // Given
        let tripId = UUID()
        viewModel.totalBudget = "invalid"
        
        // When
        viewModel.createBudget(for: tripId)
        
        // Then
        XCTAssertEqual(viewModel.errorMessage, "Please enter a valid total budget")
        XCTAssertFalse(mockBudgetService.createBudgetCalled)
    }
    
    func testCreateBudgetWithZeroAmount() {
        // Given
        let tripId = UUID()
        viewModel.totalBudget = "0"
        
        // When
        viewModel.createBudget(for: tripId)
        
        // Then
        XCTAssertEqual(viewModel.errorMessage, "Please enter a valid total budget")
        XCTAssertFalse(mockBudgetService.createBudgetCalled)
    }
    
    // MARK: - Add Expense Tests
    
    func testAddExpenseSuccess() async {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        viewModel.newExpenseAmount = "50.00"
        viewModel.newExpenseCategory = .fuel
        viewModel.newExpenseDescription = "Gas station fill-up"
        
        mockLocationService.mockLocation = CLLocation(latitude: 37.7749, longitude: -122.4194)
        
        // When
        viewModel.addExpense(for: tripId, participantId: participantId)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertTrue(viewModel.newExpenseAmount.isEmpty)
        XCTAssertEqual(viewModel.newExpenseCategory, .fuel)
        XCTAssertTrue(viewModel.newExpenseDescription.isEmpty)
        XCTAssertFalse(viewModel.showingAddExpense)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertNil(viewModel.errorMessage)
        XCTAssertTrue(mockBudgetService.addExpenseCalled)
    }
    
    func testAddExpenseWithInvalidAmount() {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        viewModel.newExpenseAmount = "invalid"
        viewModel.newExpenseDescription = "Test expense"
        
        // When
        viewModel.addExpense(for: tripId, participantId: participantId)
        
        // Then
        XCTAssertEqual(viewModel.errorMessage, "Please enter a valid amount")
        XCTAssertFalse(mockBudgetService.addExpenseCalled)
    }
    
    func testAddExpenseWithEmptyDescription() {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        viewModel.newExpenseAmount = "50.00"
        viewModel.newExpenseDescription = "   "
        
        // When
        viewModel.addExpense(for: tripId, participantId: participantId)
        
        // Then
        XCTAssertEqual(viewModel.errorMessage, "Please enter a description")
        XCTAssertFalse(mockBudgetService.addExpenseCalled)
    }
    
    // MARK: - Form Validation Tests
    
    func testIsAddExpenseFormValidWithValidData() {
        // Given
        viewModel.newExpenseAmount = "50.00"
        viewModel.newExpenseDescription = "Valid description"
        
        // Then
        XCTAssertTrue(viewModel.isAddExpenseFormValid)
    }
    
    func testIsAddExpenseFormValidWithInvalidAmount() {
        // Given
        viewModel.newExpenseAmount = "0"
        viewModel.newExpenseDescription = "Valid description"
        
        // Then
        XCTAssertFalse(viewModel.isAddExpenseFormValid)
    }
    
    func testIsAddExpenseFormValidWithEmptyDescription() {
        // Given
        viewModel.newExpenseAmount = "50.00"
        viewModel.newExpenseDescription = ""
        
        // Then
        XCTAssertFalse(viewModel.isAddExpenseFormValid)
    }
    
    // MARK: - Computed Properties Tests
    
    func testBudgetUtilizationPercentage() {
        // Given
        let summary = BudgetSummary(
            tripId: UUID(),
            totalBudget: 1000.0,
            totalSpent: 400.0,
            remainingBudget: 600.0
        )
        viewModel.budgetSummary = summary
        
        // Then
        XCTAssertEqual(viewModel.budgetUtilizationPercentage, 0.4, accuracy: 0.001)
    }
    
    func testBudgetUtilizationPercentageWithZeroBudget() {
        // Given
        let summary = BudgetSummary(
            tripId: UUID(),
            totalBudget: 0.0,
            totalSpent: 100.0,
            remainingBudget: -100.0
        )
        viewModel.budgetSummary = summary
        
        // Then
        XCTAssertEqual(viewModel.budgetUtilizationPercentage, 0.0)
    }
    
    func testBudgetStatusColor() {
        // Test green status (under 60%)
        viewModel.budgetSummary = BudgetSummary(
            tripId: UUID(),
            totalBudget: 1000.0,
            totalSpent: 500.0,
            remainingBudget: 500.0
        )
        XCTAssertEqual(viewModel.budgetStatusColor, "green")
        
        // Test yellow status (60-80%)
        viewModel.budgetSummary = BudgetSummary(
            tripId: UUID(),
            totalBudget: 1000.0,
            totalSpent: 700.0,
            remainingBudget: 300.0
        )
        XCTAssertEqual(viewModel.budgetStatusColor, "yellow")
        
        // Test orange status (80-90%)
        viewModel.budgetSummary = BudgetSummary(
            tripId: UUID(),
            totalBudget: 1000.0,
            totalSpent: 850.0,
            remainingBudget: 150.0
        )
        XCTAssertEqual(viewModel.budgetStatusColor, "orange")
        
        // Test red status (over 90%)
        viewModel.budgetSummary = BudgetSummary(
            tripId: UUID(),
            totalBudget: 1000.0,
            totalSpent: 950.0,
            remainingBudget: 50.0
        )
        XCTAssertEqual(viewModel.budgetStatusColor, "red")
    }
    
    // MARK: - Helper Methods Tests
    
    func testFormattedAmount() {
        XCTAssertEqual(viewModel.formattedAmount(123.456), "123.46")
        XCTAssertEqual(viewModel.formattedAmount(0.0), "0.00")
        XCTAssertEqual(viewModel.formattedAmount(1000.0), "1000.00")
    }
    
    func testCategoryIcon() {
        XCTAssertEqual(viewModel.categoryIcon(for: .fuel), "fuelpump.fill")
        XCTAssertEqual(viewModel.categoryIcon(for: .food), "fork.knife")
        XCTAssertEqual(viewModel.categoryIcon(for: .accommodation), "bed.double.fill")
        XCTAssertEqual(viewModel.categoryIcon(for: .activities), "figure.hiking")
        XCTAssertEqual(viewModel.categoryIcon(for: .other), "ellipsis.circle.fill")
    }
    
    func testCategoryColor() {
        XCTAssertEqual(viewModel.categoryColor(for: .fuel), "blue")
        XCTAssertEqual(viewModel.categoryColor(for: .food), "orange")
        XCTAssertEqual(viewModel.categoryColor(for: .accommodation), "purple")
        XCTAssertEqual(viewModel.categoryColor(for: .activities), "green")
        XCTAssertEqual(viewModel.categoryColor(for: .other), "gray")
    }
    
    func testClearExpenseForm() {
        // Given
        viewModel.newExpenseAmount = "50.00"
        viewModel.newExpenseCategory = .food
        viewModel.newExpenseDescription = "Test description"
        viewModel.selectedParticipantId = UUID()
        
        // When
        viewModel.clearExpenseForm()
        
        // Then
        XCTAssertTrue(viewModel.newExpenseAmount.isEmpty)
        XCTAssertEqual(viewModel.newExpenseCategory, .fuel)
        XCTAssertTrue(viewModel.newExpenseDescription.isEmpty)
        XCTAssertNil(viewModel.selectedParticipantId)
    }
    
    func testClearError() {
        // Given
        viewModel.errorMessage = "Test error"
        
        // When
        viewModel.clearError()
        
        // Then
        XCTAssertNil(viewModel.errorMessage)
    }
    
    // MARK: - Budget Updates Tests
    
    func testBudgetUpdateHandling() {
        // Given
        let tripId = UUID()
        let summary = BudgetSummary(
            tripId: tripId,
            totalBudget: 1000.0,
            totalSpent: 500.0,
            remainingBudget: 500.0
        )
        
        let update = BudgetUpdate(
            tripId: tripId,
            updateType: .expenseAdded,
            summary: summary
        )
        
        // When
        mockBudgetService.budgetUpdateSubject.send(update)
        
        // Then
        XCTAssertEqual(viewModel.budgetSummary?.tripId, tripId)
        XCTAssertEqual(viewModel.budgetSummary?.totalSpent, 500.0)
    }
}

// MARK: - Mock Budget Service

class MockBudgetService: BudgetServiceProtocol {
    var shouldThrowError = false
    var errorToThrow: Error = BudgetServiceError.unknown("Mock error")
    var mockBudgetSummary: BudgetSummary?
    
    // Tracking properties
    var createBudgetCalled = false
    var addExpenseCalled = false
    var updateExpenseCalled = false
    var deleteExpenseCalled = false
    var getBudgetSummaryCalled = false
    
    var lastTotalBudget: Double?
    var lastPerPersonBudget: Double?
    var lastExpense: Expense?
    
    let budgetUpdateSubject = PassthroughSubject<BudgetUpdate, Never>()
    
    var budgetUpdates: AnyPublisher<BudgetUpdate, Never> {
        budgetUpdateSubject.eraseToAnyPublisher()
    }
    
    func createBudget(for tripId: UUID, totalBudget: Double, perPersonBudget: Double?) async throws -> Budget {
        createBudgetCalled = true
        lastTotalBudget = totalBudget
        lastPerPersonBudget = perPersonBudget
        
        if shouldThrowError {
            throw errorToThrow
        }
        
        return Budget(totalBudget: totalBudget, perPersonBudget: perPersonBudget)
    }
    
    func addExpense(_ expense: Expense, to tripId: UUID) async throws {
        addExpenseCalled = true
        lastExpense = expense
        
        if shouldThrowError {
            throw errorToThrow
        }
    }
    
    func updateExpense(_ expense: Expense) async throws {
        updateExpenseCalled = true
        lastExpense = expense
        
        if shouldThrowError {
            throw errorToThrow
        }
    }
    
    func deleteExpense(_ expenseId: UUID, from tripId: UUID) async throws {
        deleteExpenseCalled = true
        
        if shouldThrowError {
            throw errorToThrow
        }
    }
    
    func getBudgetSummary(for tripId: UUID) async throws -> BudgetSummary {
        getBudgetSummaryCalled = true
        
        if shouldThrowError {
            throw errorToThrow
        }
        
        return mockBudgetSummary ?? BudgetSummary(
            tripId: tripId,
            totalBudget: 0,
            totalSpent: 0,
            remainingBudget: 0
        )
    }
}

// MARK: - Mock Location Service

class MockLocationService: LocationServiceProtocol {
    var mockLocation: CLLocation?
    var shouldThrowError = false
    var errorToThrow: Error = NSError(domain: "MockError", code: 1, userInfo: nil)
    
    var currentLocation: CLLocation? { mockLocation }
    var authorizationStatus: CLAuthorizationStatus = .authorizedWhenInUse
    var locationUpdates: AnyPublisher<CLLocation, Never> = Empty().eraseToAnyPublisher()
    var authorizationUpdates: AnyPublisher<CLAuthorizationStatus, Never> = Empty().eraseToAnyPublisher()
    var isLocationSharingEnabled: Bool = true
    
    func requestLocationPermission() async throws {
        if shouldThrowError {
            throw errorToThrow
        }
    }
    
    func startLocationSharing() async throws {
        if shouldThrowError {
            throw errorToThrow
        }
    }
    
    func stopLocationSharing() {}
    
    func getCurrentLocation() async throws -> CLLocation {
        if shouldThrowError {
            throw errorToThrow
        }
        
        return mockLocation ?? CLLocation(latitude: 0, longitude: 0)
    }
    
    func startMonitoringSignificantLocationChanges() {}
    func stopMonitoringSignificantLocationChanges() {}
    func calculateDistance(from: CLLocation, to: CLLocation) -> CLLocationDistance { return 0 }
    func calculateDrivingDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) async throws -> CLLocationDistance { return 0 }
    func isLocationStale(_ location: CLLocation, threshold: TimeInterval) -> Bool { return false }
}