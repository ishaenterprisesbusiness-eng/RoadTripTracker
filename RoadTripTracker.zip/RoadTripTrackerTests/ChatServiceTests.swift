import XCTest
import Combine
import CoreLocation
@testable import RoadTripTracker

// MARK: - Chat Service Tests
final class ChatServiceTests: XCTestCase {
    
    var chatService: ChatService!
    var mockPersistenceController: MockPersistenceController!
    var subscriptions: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        mockPersistenceController = MockPersistenceController()
        chatService = ChatService(persistenceController: mockPersistenceController)
        subscriptions = Set<AnyCancellable>()
    }
    
    override func tearDownWithError() throws {
        subscriptions = nil
        chatService = nil
        mockPersistenceController = nil
        try super.tearDownWithError()
    }
    
    // MARK: - Send Message Tests
    
    func testSendTextMessage() async throws {
        // Given
        let tripId = UUID()
        let content = "Hello, world!"
        
        // When
        let message = try await chatService.sendMessage(content, to: tripId)
        
        // Then
        XCTAssertEqual(message.content, content)
        XCTAssertEqual(message.tripId, tripId)
        XCTAssertEqual(message.type, .text)
        XCTAssertNotNil(message.id)
        XCTAssertNotNil(message.timestamp)
    }
    
    func testSendLocationMessage() async throws {
        // Given
        let tripId = UUID()
        let location = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        
        // When
        let message = try await chatService.sendLocationMessage(location, to: tripId)
        
        // Then
        XCTAssertEqual(message.tripId, tripId)
        XCTAssertEqual(message.type, .location)
        XCTAssertEqual(message.location?.latitude, location.latitude, accuracy: 0.0001)
        XCTAssertEqual(message.location?.longitude, location.longitude, accuracy: 0.0001)
        XCTAssertEqual(message.content, "Shared location")
    }
    
    func testSendEmergencyMessage() async throws {
        // Given
        let tripId = UUID()
        let content = "Need help!"
        let location = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        
        // When
        let message = try await chatService.sendEmergencyMessage(content, location: location, to: tripId)
        
        // Then
        XCTAssertEqual(message.content, content)
        XCTAssertEqual(message.tripId, tripId)
        XCTAssertEqual(message.type, .emergency)
        XCTAssertEqual(message.location?.latitude, location.latitude, accuracy: 0.0001)
        XCTAssertEqual(message.location?.longitude, location.longitude, accuracy: 0.0001)
    }
    
    // MARK: - Message Updates Tests
    
    func testMessageUpdatesPublisher() throws {
        // Given
        let expectation = XCTestExpectation(description: "Message received")
        var receivedMessage: Message?
        
        chatService.messageUpdates
            .sink { message in
                receivedMessage = message
                expectation.fulfill()
            }
            .store(in: &subscriptions)
        
        // When
        let tripId = UUID()
        Task {
            _ = try await chatService.sendMessage("Test message", to: tripId)
        }
        
        // Then
        wait(for: [expectation], timeout: 5.0)
        XCTAssertNotNil(receivedMessage)
        XCTAssertEqual(receivedMessage?.content, "Test message")
    }
    
    // MARK: - Connection Status Tests
    
    func testConnectionStatusPublisher() throws {
        // Given
        let expectation = XCTestExpectation(description: "Connection status received")
        var receivedStatus: ConnectionStatus?
        
        chatService.connectionStatus
            .sink { status in
                receivedStatus = status
                expectation.fulfill()
            }
            .store(in: &subscriptions)
        
        // Then
        wait(for: [expectation], timeout: 1.0)
        XCTAssertNotNil(receivedStatus)
    }
    
    // MARK: - Mark Message as Read Tests
    
    func testMarkMessageAsRead() async throws {
        // Given
        let tripId = UUID()
        let userId = UUID()
        let message = try await chatService.sendMessage("Test message", to: tripId)
        
        // When
        try await chatService.markMessageAsRead(message.id, by: userId)
        
        // Then
        // In a real implementation, we would verify the message was marked as read
        // This is a placeholder test
        XCTAssertTrue(true)
    }
    
    // MARK: - Get Messages Tests
    
    func testGetMessages() async throws {
        // Given
        let tripId = UUID()
        _ = try await chatService.sendMessage("Message 1", to: tripId)
        _ = try await chatService.sendMessage("Message 2", to: tripId)
        
        // When
        let messages = try await chatService.getMessages(for: tripId, limit: 10, offset: 0)
        
        // Then
        // In a real implementation with proper CloudKit integration,
        // we would expect to get the messages back
        XCTAssertNotNil(messages)
    }
    
    // MARK: - Subscription Tests
    
    func testSubscribeToMessages() async throws {
        // Given
        let tripId = UUID()
        
        // When & Then
        // This should not throw an error
        try await chatService.subscribeToMessages(for: tripId)
    }
    
    func testUnsubscribeFromMessages() async throws {
        // Given
        let tripId = UUID()
        try await chatService.subscribeToMessages(for: tripId)
        
        // When & Then
        // This should not throw an error
        try await chatService.unsubscribeFromMessages(for: tripId)
    }
    
    // MARK: - Delete Message Tests
    
    func testDeleteMessage() async throws {
        // Given
        let tripId = UUID()
        let message = try await chatService.sendMessage("Test message", to: tripId)
        
        // When & Then
        // In a real implementation, this would actually delete the message
        // For now, we just test that it doesn't throw
        do {
            try await chatService.deleteMessage(message.id)
        } catch ChatServiceError.messageNotFound {
            // This is expected in our mock implementation
            XCTAssertTrue(true)
        }
    }
    
    // MARK: - Error Handling Tests
    
    func testSendMessageWithEmptyContent() async {
        // Given
        let tripId = UUID()
        let content = ""
        
        // When & Then
        do {
            _ = try await chatService.sendMessage(content, to: tripId)
            // If we get here, the message was sent (which is fine)
            XCTAssertTrue(true)
        } catch {
            // If an error is thrown, that's also acceptable behavior
            XCTAssertTrue(true)
        }
    }
}

// MARK: - Mock Persistence Controller
class MockPersistenceController: PersistenceController {
    override init() {
        super.init()
        // Initialize with in-memory store for testing
    }
}

// MARK: - Message Test Helpers
extension Message {
    static func testMessage(
        tripId: UUID = UUID(),
        senderId: UUID = UUID(),
        content: String = "Test message",
        type: MessageType = .text
    ) -> Message {
        return Message(
            tripId: tripId,
            senderId: senderId,
            content: content,
            type: type
        )
    }
}