import XCTest
import CoreLocation
@testable import RoadTripTracker

class DistanceCalculationServiceTests: XCTestCase {
    
    var distanceService: DistanceCalculationService!
    var mockLocationManager: MockLocationManager!
    var mockMapService: MockMapService!
    
    override func setUp() {
        super.setUp()
        mockLocationManager = MockLocationManager()
        mockMapService = MockMapService()
        distanceService = DistanceCalculationService(
            locationManager: mockLocationManager,
            mapService: mockMapService
        )
    }
    
    override func tearDown() {
        distanceService = nil
        mockLocationManager = nil
        mockMapService = nil
        super.tearDown()
    }
    
    // MARK: - Distance Calculation Tests
    
    func testCalculateDistanceBetweenParticipants() async {
        // Given
        let participant1 = createMockParticipant(
            id: UUID(),
            location: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194) // San Francisco
        )
        let participant2 = createMockParticipant(
            id: UUID(),
            location: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437) // Los Angeles
        )
        
        mockMapService.mockRoute = createMockRoute(distance: 600000) // 600km
        
        // When
        let calculation = await distanceService.calculateDistanceBetweenParticipants(participant1, participant2)
        
        // Then
        XCTAssertNotNil(calculation)
        XCTAssertEqual(calculation?.fromParticipant, participant1.id)
        XCTAssertEqual(calculation?.toParticipant, participant2.id)
        XCTAssertGreaterThan(calculation?.straightLineDistance ?? 0, 0)
        XCTAssertEqual(calculation?.drivingDistance, 600000)
    }
    
    func testCalculateDistanceToDestination() async {
        // Given
        let participant = createMockParticipant(
            id: UUID(),
            location: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let destination = createMockDestination(
            coordinate: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437)
        )
        
        mockMapService.mockRoute = createMockRoute(distance: 600000)
        
        // When
        let calculation = await distanceService.calculateDistanceToDestination(participant, destination)
        
        // Then
        XCTAssertNotNil(calculation)
        XCTAssertEqual(calculation?.fromParticipant, participant.id)
        XCTAssertEqual(calculation?.toDestination, destination.id)
        XCTAssertGreaterThan(calculation?.straightLineDistance ?? 0, 0)
        XCTAssertEqual(calculation?.drivingDistance, 600000)
    }
    
    func testCalculateDistancesToDestinations() async {
        // Given
        let participant = createMockParticipant(
            id: UUID(),
            location: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let destinations = [
            createMockDestination(coordinate: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437)),
            createMockDestination(coordinate: CLLocationCoordinate2D(latitude: 32.7157, longitude: -117.1611))
        ]
        
        mockMapService.mockRoute = createMockRoute(distance: 500000)
        
        // When
        let calculations = await distanceService.calculateDistancesToDestinations(
            participant,
            destinations: destinations,
            currentDestinationIndex: 0
        )
        
        // Then
        XCTAssertEqual(calculations.count, 2) // Next and final destination
        XCTAssertTrue(calculations.allSatisfy { $0.fromParticipant == participant.id })
    }
    
    func testUpdateDistanceCalculations() async {
        // Given
        let trip = createMockTrip()
        
        // When
        await distanceService.updateDistanceCalculations(for: trip)
        
        // Then
        XCTAssertFalse(distanceService.distanceCalculations.isEmpty)
        XCTAssertFalse(distanceService.participantDistances.isEmpty)
        XCTAssertFalse(distanceService.destinationDistances.isEmpty)
    }
    
    func testGetDistanceBetweenParticipants() async {
        // Given
        let trip = createMockTrip()
        await distanceService.updateDistanceCalculations(for: trip)
        
        let participant1Id = trip.participants[0].id
        let participant2Id = trip.participants[1].id
        
        // When
        let distance = distanceService.getDistanceBetweenParticipants(participant1Id, participant2Id)
        
        // Then
        XCTAssertNotNil(distance)
        XCTAssertGreaterThan(distance ?? 0, 0)
    }
    
    func testGetParticipantsBehind() async {
        // Given
        let trip = createMockTripWithDistantParticipants()
        await distanceService.updateDistanceCalculations(for: trip)
        
        // When
        let behindParticipants = distanceService.getParticipantsBehind(for: trip, threshold: 1000) // 1km
        
        // Then
        XCTAssertGreaterThan(behindParticipants.count, 0)
    }
    
    func testFindLeadParticipant() async {
        // Given
        let trip = createMockTrip()
        await distanceService.updateDistanceCalculations(for: trip)
        
        // When
        let leadParticipant = distanceService.findLeadParticipant(in: trip)
        
        // Then
        XCTAssertNotNil(leadParticipant)
        XCTAssertTrue(trip.participants.contains { $0.id == leadParticipant?.id })
    }
    
    // MARK: - Helper Methods
    
    private func createMockParticipant(id: UUID, location: CLLocationCoordinate2D) -> Participant {
        let user = User(
            id: UUID(),
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date(),
            age: 25
        )
        
        return Participant(
            id: id,
            userId: user.id,
            user: user,
            currentLocation: location,
            lastLocationUpdate: Date(),
            isLocationSharingEnabled: true,
            status: .active
        )
    }
    
    private func createMockDestination(coordinate: CLLocationCoordinate2D) -> Destination {
        return Destination(
            name: "Test Destination",
            address: "123 Test St",
            coordinate: coordinate,
            type: .waypoint
        )
    }
    
    private func createMockRoute(distance: CLLocationDistance) -> Route {
        return Route(
            name: "Test Route",
            destinations: [],
            waypoints: [],
            distance: distance,
            estimatedTravelTime: distance / 20, // Rough estimate
            steps: []
        )
    }
    
    private func createMockTrip() -> Trip {
        let participants = [
            createMockParticipant(
                id: UUID(),
                location: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
            ),
            createMockParticipant(
                id: UUID(),
                location: CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094)
            )
        ]
        
        let destinations = [
            createMockDestination(coordinate: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437))
        ]
        
        return Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: participants[0].userId,
            participants: participants,
            destinations: destinations,
            status: .active
        )
    }
    
    private func createMockTripWithDistantParticipants() -> Trip {
        let participants = [
            createMockParticipant(
                id: UUID(),
                location: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194) // San Francisco
            ),
            createMockParticipant(
                id: UUID(),
                location: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437) // Los Angeles (far away)
            )
        ]
        
        let destinations = [
            createMockDestination(coordinate: CLLocationCoordinate2D(latitude: 37.8000, longitude: -122.4000))
        ]
        
        return Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: participants[0].userId,
            participants: participants,
            destinations: destinations,
            status: .active
        )
    }
}

// MARK: - Mock Classes

class MockMapService: MapServiceProtocol {
    var mockRoute: Route?
    var mockPOIs: [PointOfInterest] = []
    var mockPlaces: [Place] = []
    
    func displayRoute(_ route: Route) async throws {
        // Mock implementation
    }
    
    func showParticipants(_ participants: [Participant]) async throws {
        // Mock implementation
    }
    
    func findNearbyPOIs(category: POICategory, near location: CLLocationCoordinate2D, radius: CLLocationDistance) async throws -> [PointOfInterest] {
        return mockPOIs
    }
    
    func calculateRoute(from origin: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D, waypoints: [CLLocationCoordinate2D]) async throws -> Route {
        return mockRoute ?? Route(name: "Mock Route", destinations: [], waypoints: [], distance: 1000, estimatedTravelTime: 60, steps: [])
    }
    
    func calculateMultiDestinationRoute(destinations: [Destination]) async throws -> Route {
        return mockRoute ?? Route(name: "Mock Multi Route", destinations: destinations, waypoints: [], distance: 5000, estimatedTravelTime: 300, steps: [])
    }
    
    func getDirections(for route: Route) async throws -> [RouteStep] {
        return route.steps
    }
    
    func searchPlaces(query: String, near location: CLLocationCoordinate2D) async throws -> [Place] {
        return mockPlaces
    }
}