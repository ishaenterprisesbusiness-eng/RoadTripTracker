import XCTest
import CoreLocation
@testable import RoadTripTracker

final class POIServiceTests: XCTestCase {
    var poiService: POIService!
    var mockPlacesService: MockPlacesService!
    var mockNotificationService: MockNotificationService!
    var mockTripService: MockTripService!
    
    override func setUpWithError() throws {
        mockPlacesService = MockPlacesService()
        mockNotificationService = MockNotificationService()
        mockTripService = MockTripService()
        poiService = POIService(
            placesService: mockPlacesService,
            notificationService: mockNotificationService,
            tripService: mockTripService
        )
    }
    
    override func tearDownWithError() throws {
        poiService = nil
        mockPlacesService = nil
        mockNotificationService = nil
        mockTripService = nil
    }
    
    func testDiscoverPOIsNearLocation() async throws {
        // Given
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        let filter = POISearchFilter(categories: [.nature, .history])
        
        mockPlacesService.mockSearchResults = [
            PlaceSearchResult(
                id: "1",
                name: "Golden Gate Park",
                address: "San Francisco, CA",
                coordinate: coordinate,
                category: .attraction,
                rating: 4.5
            )
        ]
        
        // When
        let pois = try await poiService.discoverPOIsNearLocation(
            coordinate: coordinate,
            radius: 5000,
            filter: filter
        )
        
        // Then
        XCTAssertEqual(pois.count, 1)
        XCTAssertEqual(pois.first?.name, "Golden Gate Park")
        XCTAssertEqual(pois.first?.category, .entertainment)
    }
    
    func testProposePOI() async throws {
        // Given
        let poi = PointOfInterest(
            placeId: "test-poi",
            name: "Test Attraction",
            address: "Test Address",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            category: .entertainment
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: [
                Participant(
                    userId: UUID(),
                    user: User(
                        id: UUID(),
                        username: "testuser",
                        email: "test@example.com",
                        city: "Test City",
                        dateOfBirth: Date(),
                        age: 25
                    )
                )
            ]
        )
        
        // When
        let proposal = try await poiService.proposePOI(
            poi: poi,
            for: trip,
            insertionIndex: 0,
            message: "This looks interesting!"
        )
        
        // Then
        XCTAssertEqual(proposal.poi.name, "Test Attraction")
        XCTAssertEqual(proposal.proposalMessage, "This looks interesting!")
        XCTAssertEqual(proposal.status, .pending)
        XCTAssertEqual(proposal.proposedInsertionIndex, 0)
    }
    
    func testVotePOIProposal() async throws {
        // Given
        let poi = PointOfInterest(
            placeId: "test-poi",
            name: "Test Attraction",
            address: "Test Address",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            category: .entertainment
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: [
                Participant(
                    userId: UUID(),
                    user: User(
                        id: UUID(),
                        username: "testuser",
                        email: "test@example.com",
                        city: "Test City",
                        dateOfBirth: Date(),
                        age: 25
                    )
                )
            ]
        )
        
        let proposal = try await poiService.proposePOI(
            poi: poi,
            for: trip,
            insertionIndex: 0,
            message: nil
        )
        
        // When
        try await poiService.votePOIProposal(
            proposalId: proposal.id,
            participantId: trip.participants.first!.id,
            vote: .approve,
            comment: "Great idea!"
        )
        
        // Then
        let proposals = try await poiService.getPOIProposals(for: trip.id)
        let updatedProposal = proposals.first { $0.id == proposal.id }
        
        XCTAssertNotNil(updatedProposal)
        XCTAssertEqual(updatedProposal?.votes.count, 1)
        XCTAssertEqual(updatedProposal?.votes.first?.vote, .approve)
        XCTAssertEqual(updatedProposal?.votes.first?.comment, "Great idea!")
    }
    
    func testFilterPOIsByCategory() async throws {
        // Given
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        let filter = POISearchFilter(categories: [.nature])
        
        mockPlacesService.mockSearchResults = [
            PlaceSearchResult(
                id: "1",
                name: "Golden Gate Park",
                address: "San Francisco, CA",
                coordinate: coordinate,
                category: .attraction,
                rating: 4.5
            ),
            PlaceSearchResult(
                id: "2",
                name: "Shopping Mall",
                address: "San Francisco, CA",
                coordinate: coordinate,
                category: .shopping,
                rating: 4.0
            )
        ]
        
        // When
        let pois = try await poiService.discoverPOIsNearLocation(
            coordinate: coordinate,
            radius: 5000,
            filter: filter
        )
        
        // Then
        // Should only return nature-related POIs (mapped from attraction category)
        XCTAssertEqual(pois.count, 1)
        XCTAssertEqual(pois.first?.name, "Golden Gate Park")
    }
}

// MARK: - Mock Services

class MockPlacesService: PlacesServiceProtocol {
    var mockSearchResults: [PlaceSearchResult] = []
    var mockPlaceDetails: PlaceDetails?
    
    func searchPlaces(query: String, region: MKCoordinateRegion?) async throws -> [PlaceSearchResult] {
        return mockSearchResults
    }
    
    func getPlaceDetails(for placeId: String) async throws -> PlaceDetails {
        guard let details = mockPlaceDetails else {
            throw PlacesServiceError.notImplemented
        }
        return details
    }
    
    func getNearbyPlaces(coordinate: CLLocationCoordinate2D, radius: Double, category: PlaceCategory) async throws -> [PlaceSearchResult] {
        return mockSearchResults.filter { $0.category == category }
    }
}

class MockNotificationService: NotificationServiceProtocol {
    var sentNotifications: [Notification] = []
    
    func sendNotification(_ notification: Notification, to userId: UUID) async throws {
        sentNotifications.append(notification)
    }
    
    func scheduleLocalNotification(_ notification: LocalNotification) async throws {
        // Mock implementation
    }
    
    func cancelNotification(withIdentifier identifier: String) async throws {
        // Mock implementation
    }
    
    func requestPermissions() async throws -> Bool {
        return true
    }
    
    func getNotificationSettings() async -> UNNotificationSettings {
        // Mock implementation
        return UNNotificationSettings()
    }
}

class MockTripService: TripServiceProtocol {
    var mockTrips: [Trip] = []
    
    func createTrip(_ trip: Trip) async throws -> Trip {
        mockTrips.append(trip)
        return trip
    }
    
    func getTrip(id: UUID) async throws -> Trip {
        guard let trip = mockTrips.first(where: { $0.id == id }) else {
            throw TripServiceError.tripNotFound
        }
        return trip
    }
    
    func updateTrip(_ trip: Trip) async throws -> Trip {
        if let index = mockTrips.firstIndex(where: { $0.id == trip.id }) {
            mockTrips[index] = trip
        }
        return trip
    }
    
    func deleteTrip(id: UUID) async throws {
        mockTrips.removeAll { $0.id == id }
    }
    
    func addDestination(_ destination: Destination, to trip: Trip, at index: Int) async throws -> Trip {
        var updatedTrip = trip
        updatedTrip.destinations.insert(destination, at: index)
        return try await updateTrip(updatedTrip)
    }
    
    func removeDestination(at index: Int, from trip: Trip) async throws -> Trip {
        var updatedTrip = trip
        updatedTrip.destinations.remove(at: index)
        return try await updateTrip(updatedTrip)
    }
    
    func joinTrip(code: String, participant: Participant) async throws -> Trip {
        guard let trip = mockTrips.first(where: { $0.code == code }) else {
            throw TripServiceError.tripNotFound
        }
        var updatedTrip = trip
        updatedTrip.participants.append(participant)
        return try await updateTrip(updatedTrip)
    }
    
    func leaveTrip(tripId: UUID, participantId: UUID) async throws -> Trip {
        guard let trip = mockTrips.first(where: { $0.id == tripId }) else {
            throw TripServiceError.tripNotFound
        }
        var updatedTrip = trip
        updatedTrip.participants.removeAll { $0.id == participantId }
        return try await updateTrip(updatedTrip)
    }
    
    func getUserTrips(userId: UUID) async throws -> [Trip] {
        return mockTrips.filter { trip in
            trip.participants.contains { $0.userId == userId }
        }
    }
}

// MARK: - Service Errors

enum TripServiceError: Error {
    case tripNotFound
}