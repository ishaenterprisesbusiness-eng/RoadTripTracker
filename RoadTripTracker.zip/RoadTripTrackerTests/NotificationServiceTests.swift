import XCTest
import UserNotifications
import Combine
import CoreLocation
@testable import RoadTripTracker

class NotificationServiceTests: XCTestCase {
    
    var notificationService: NotificationService!
    var cancellables: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        notificationService = NotificationService()
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDownWithError() throws {
        notificationService = nil
        cancellables = nil
    }
    
    // MARK: - Permission Tests
    
    func testRequestNotificationPermission() async throws {
        // Test requesting notification permission
        let granted = try await notificationService.requestNotificationPermission()
        
        // In a test environment, this might not grant actual permission
        // but we can test that the method doesn't throw
        XCTAssertNotNil(granted)
    }
    
    func testNotificationPermissionStatus() {
        // Test that permission status publisher is available
        let expectation = XCTestExpectation(description: "Permission status received")
        
        notificationService.notificationPermissionStatus
            .sink { status in
                XCTAssertNotNil(status)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    // MARK: - Local Notification Tests
    
    func testScheduleLocalNotification() async throws {
        let notification = LocalNotification(
            identifier: "test_notification",
            title: "Test Title",
            body: "Test Body",
            sound: .default
        )
        
        // This should not throw
        try await notificationService.scheduleLocalNotification(notification)
    }
    
    func testScheduleLocalNotificationWithTrigger() async throws {
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let notification = LocalNotification(
            identifier: "test_notification_with_trigger",
            title: "Test Title",
            body: "Test Body",
            trigger: trigger
        )
        
        try await notificationService.scheduleLocalNotification(notification)
    }
    
    func testCancelNotification() async throws {
        // First schedule a notification
        let notification = LocalNotification(
            identifier: "test_cancel_notification",
            title: "Test Title",
            body: "Test Body"
        )
        
        try await notificationService.scheduleLocalNotification(notification)
        
        // Then cancel it
        try await notificationService.cancelNotification(withIdentifier: "test_cancel_notification")
    }
    
    func testCancelAllNotifications() async throws {
        // Schedule multiple notifications
        for i in 1...3 {
            let notification = LocalNotification(
                identifier: "test_notification_\(i)",
                title: "Test Title \(i)",
                body: "Test Body \(i)"
            )
            try await notificationService.scheduleLocalNotification(notification)
        }
        
        // Cancel all
        try await notificationService.cancelAllNotifications()
    }
    
    // MARK: - Push Notification Tests
    
    func testSendPushNotification() async throws {
        let notification = PushNotification(
            recipientIds: [UUID(), UUID()],
            title: "Test Push",
            body: "Test push notification body",
            priority: .normal
        )
        
        // This should not throw (simulated push notification)
        try await notificationService.sendPushNotification(notification)
    }
    
    func testSendEmergencyPushNotification() async throws {
        let notification = PushNotification(
            recipientIds: [UUID()],
            title: "Emergency Alert",
            body: "Emergency notification",
            priority: .emergency
        )
        
        try await notificationService.sendPushNotification(notification)
    }
    
    // MARK: - Trip Event Notification Tests
    
    func testSendParticipantJoinedNotification() async throws {
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: [participant]
        )
        
        try await notificationService.sendParticipantJoinedNotification(
            participant: participant,
            trip: trip
        )
    }
    
    func testSendParticipantLeftNotification() async throws {
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: []
        )
        
        try await notificationService.sendParticipantLeftNotification(
            participant: participant,
            trip: trip
        )
    }
    
    func testSendApproachingDestinationNotification() async throws {
        let destination = Destination(
            name: "Test Destination",
            address: "123 Test St",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: [participant],
            destinations: [destination]
        )
        
        try await notificationService.sendApproachingDestinationNotification(
            destination: destination,
            participant: participant,
            trip: trip,
            distance: 1500.0
        )
    }
    
    func testSendEmergencyNotification() async throws {
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: [participant]
        )
        
        let location = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        
        try await notificationService.sendEmergencyNotification(
            participant: participant,
            trip: trip,
            message: "Need help!",
            location: location
        )
    }
    
    // MARK: - Location-Based Notification Tests
    
    func testScheduleLocationBasedNotification() async throws {
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        
        try await notificationService.scheduleLocationBasedNotification(
            identifier: "location_test",
            title: "Location Alert",
            body: "You are approaching the destination",
            coordinate: coordinate,
            radius: 1000.0
        )
    }
    
    // MARK: - Notification Preferences Tests
    
    func testUpdateNotificationPreferences() async throws {
        let preferences = NotificationPreferences()
        
        try await notificationService.updateNotificationPreferences(preferences)
        
        let retrievedPreferences = notificationService.getNotificationPreferences()
        XCTAssertEqual(preferences.tripEvents, retrievedPreferences.tripEvents)
        XCTAssertEqual(preferences.emergencyAlerts, retrievedPreferences.emergencyAlerts)
    }
    
    func testGetNotificationPreferences() {
        let preferences = notificationService.getNotificationPreferences()
        
        XCTAssertNotNil(preferences)
        XCTAssertTrue(preferences.emergencyAlerts) // Should default to true
    }
    
    // MARK: - Remote Notification Handling Tests
    
    func testHandleRemoteNotification() async {
        let userInfo: [AnyHashable: Any] = [
            "type": "participant_joined",
            "tripId": UUID().uuidString,
            "participantId": UUID().uuidString
        ]
        
        // This should not throw
        await notificationService.handleRemoteNotification(userInfo)
    }
    
    func testHandleEmergencyRemoteNotification() async {
        let userInfo: [AnyHashable: Any] = [
            "type": "emergency",
            "tripId": UUID().uuidString,
            "participantId": UUID().uuidString,
            "message": "Emergency situation",
            "latitude": 37.7749,
            "longitude": -122.4194
        ]
        
        await notificationService.handleRemoteNotification(userInfo)
    }
    
    // MARK: - Register for Remote Notifications Tests
    
    func testRegisterForRemoteNotifications() async throws {
        let deviceToken = try await notificationService.registerForRemoteNotifications()
        
        XCTAssertNotNil(deviceToken)
        // In a real implementation, this would return actual device token data
    }
}

// MARK: - Mock Notification Service for Testing

class MockNotificationService: NotificationServiceProtocol {
    var notificationPermissionStatus: AnyPublisher<UNAuthorizationStatus, Never> {
        Just(.authorized).eraseToAnyPublisher()
    }
    
    var pushNotificationSent = false
    var localNotificationScheduled = false
    var lastNotificationIdentifier: String?
    var lastPushNotification: PushNotification?
    
    func requestNotificationPermission() async throws -> Bool {
        return true
    }
    
    func scheduleLocalNotification(_ notification: LocalNotification) async throws {
        localNotificationScheduled = true
        lastNotificationIdentifier = notification.identifier
    }
    
    func cancelNotification(withIdentifier identifier: String) async throws {
        // Mock implementation
    }
    
    func cancelAllNotifications() async throws {
        // Mock implementation
    }
    
    func sendPushNotification(_ notification: PushNotification) async throws {
        pushNotificationSent = true
        lastPushNotification = notification
    }
    
    func registerForRemoteNotifications() async throws -> Data {
        return Data()
    }
    
    func handleRemoteNotification(_ userInfo: [AnyHashable: Any]) async {
        // Mock implementation
    }
    
    func sendParticipantJoinedNotification(participant: Participant, trip: Trip) async throws {
        pushNotificationSent = true
    }
    
    func sendParticipantLeftNotification(participant: Participant, trip: Trip) async throws {
        pushNotificationSent = true
    }
    
    func sendApproachingDestinationNotification(destination: Destination, participant: Participant, trip: Trip, distance: CLLocationDistance) async throws {
        pushNotificationSent = true
    }
    
    func sendEmergencyNotification(participant: Participant, trip: Trip, message: String, location: CLLocationCoordinate2D) async throws {
        pushNotificationSent = true
    }
    
    func sendTripUpdateNotification(trip: Trip, updateType: TripUpdateType, message: String) async throws {
        pushNotificationSent = true
    }
    
    func scheduleLocationBasedNotification(identifier: String, title: String, body: String, coordinate: CLLocationCoordinate2D, radius: CLLocationDistance, notifyOnEntry: Bool, notifyOnExit: Bool) async throws {
        localNotificationScheduled = true
        lastNotificationIdentifier = identifier
    }
    
    func updateNotificationPreferences(_ preferences: NotificationPreferences) async throws {
        // Mock implementation
    }
    
    func getNotificationPreferences() -> NotificationPreferences {
        return NotificationPreferences()
    }
}