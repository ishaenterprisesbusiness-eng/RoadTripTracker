import XCTest
import Combine
@testable import RoadTripTracker

// MARK: - Mock Authentication Service
class MockAuthenticationService: AuthenticationServiceProtocol {
    var currentUser: User?
    var isAuthenticated: Bool = false
    var authenticationStatePublisher: AnyPublisher<AuthenticationState, Never> {
        Just(.unauthenticated).eraseToAnyPublisher()
    }
    
    var updateVehicleCalled = false
    var updatedVehicle: Vehicle?
    var shouldThrowError = false
    
    func signUp(userData: UserRegistrationData) async throws -> User {
        throw AuthenticationError.unknown("Not implemented")
    }
    
    func signIn(email: String, password: String) async throws -> User {
        throw AuthenticationError.unknown("Not implemented")
    }
    
    func signOut() async throws {
        // Not implemented
    }
    
    func resetPassword(email: String) async throws {
        // Not implemented
    }
    
    func verifyEmail(token: String) async throws {
        // Not implemented
    }
    
    func refreshToken() async throws {
        // Not implemented
    }
    
    func enableBiometricAuth() async throws -> Bool {
        return false
    }
    
    func authenticateWithBiometrics() async throws -> User {
        throw AuthenticationError.unknown("Not implemented")
    }
    
    func getCurrentUser() async throws -> User? {
        if shouldThrowError {
            throw AuthenticationError.unknown("Test error")
        }
        return currentUser
    }
    
    func updateUserVehicle(_ vehicle: Vehicle) async throws {
        if shouldThrowError {
            throw AuthenticationError.unknown("Test error")
        }
        updateVehicleCalled = true
        updatedVehicle = vehicle
        currentUser?.vehicle = vehicle
    }
    
    func updateUserProfile(_ user: User) async throws {
        if shouldThrowError {
            throw AuthenticationError.unknown("Test error")
        }
        currentUser = user
    }
}

// MARK: - Vehicle Entry View Model Tests
@MainActor
class VehicleEntryViewModelTests: XCTestCase {
    var viewModel: VehicleEntryViewModel!
    var mockAuthService: MockAuthenticationService!
    
    override func setUp() {
        super.setUp()
        mockAuthService = MockAuthenticationService()
        viewModel = VehicleEntryViewModel(authenticationService: mockAuthService)
    }
    
    override func tearDown() {
        viewModel = nil
        mockAuthService = nil
        super.tearDown()
    }
    
    // MARK: - Form Validation Tests
    
    func testInitialFormState() {
        XCTAssertEqual(viewModel.make, "")
        XCTAssertEqual(viewModel.model, "")
        XCTAssertEqual(viewModel.vehicleNumber, "")
        XCTAssertEqual(viewModel.odometerReading, "")
        XCTAssertEqual(viewModel.selectedVehicleType, .sedan)
        XCTAssertEqual(viewModel.color, "")
        XCTAssertFalse(viewModel.isFormValid)
    }
    
    func testFormValidationWithValidData() {
        // Given
        viewModel.make = "Toyota"
        viewModel.model = "Camry"
        viewModel.vehicleNumber = "ABC123"
        viewModel.odometerReading = "50000"
        
        // Wait for validation debounce
        let expectation = XCTestExpectation(description: "Validation completed")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1.0)
        
        // Then
        XCTAssertTrue(viewModel.isFormValid)
        XCTAssertNil(viewModel.makeError)
        XCTAssertNil(viewModel.modelError)
        XCTAssertNil(viewModel.vehicleNumberError)
        XCTAssertNil(viewModel.odometerError)
    }
    
    func testMakeValidation() {
        // Test empty make
        viewModel.make = ""
        
        let expectation1 = XCTestExpectation(description: "Empty make validation")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            XCTAssertEqual(self.viewModel.makeError, "Vehicle make is required")
            expectation1.fulfill()
        }
        wait(for: [expectation1], timeout: 1.0)
        
        // Test short make
        viewModel.make = "A"
        
        let expectation2 = XCTestExpectation(description: "Short make validation")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            XCTAssertEqual(self.viewModel.makeError, "Vehicle make must be at least 2 characters")
            expectation2.fulfill()
        }
        wait(for: [expectation2], timeout: 1.0)
        
        // Test valid make
        viewModel.make = "Toyota"
        
        let expectation3 = XCTestExpectation(description: "Valid make validation")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            XCTAssertNil(self.viewModel.makeError)
            expectation3.fulfill()
        }
        wait(for: [expectation3], timeout: 1.0)
    }
    
    func testOdometerValidation() {
        // Test empty odometer
        viewModel.odometerReading = ""
        
        let expectation1 = XCTestExpectation(description: "Empty odometer validation")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            XCTAssertEqual(self.viewModel.odometerError, "Odometer reading is required")
            expectation1.fulfill()
        }
        wait(for: [expectation1], timeout: 1.0)
        
        // Test invalid odometer (non-numeric)
        viewModel.odometerReading = "abc"
        
        let expectation2 = XCTestExpectation(description: "Invalid odometer validation")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            XCTAssertEqual(self.viewModel.odometerError, "Odometer reading must be a valid number")
            expectation2.fulfill()
        }
        wait(for: [expectation2], timeout: 1.0)
        
        // Test negative odometer
        viewModel.odometerReading = "-100"
        
        let expectation3 = XCTestExpectation(description: "Negative odometer validation")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            XCTAssertEqual(self.viewModel.odometerError, "Odometer reading cannot be negative")
            expectation3.fulfill()
        }
        wait(for: [expectation3], timeout: 1.0)
        
        // Test valid odometer
        viewModel.odometerReading = "50000"
        
        let expectation4 = XCTestExpectation(description: "Valid odometer validation")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            XCTAssertNil(self.viewModel.odometerError)
            expectation4.fulfill()
        }
        wait(for: [expectation4], timeout: 1.0)
    }
    
    // MARK: - Save Vehicle Tests
    
    func testSaveVehicleDetailsSuccess() async {
        // Given
        viewModel.make = "Toyota"
        viewModel.model = "Camry"
        viewModel.vehicleNumber = "ABC123"
        viewModel.odometerReading = "50000"
        viewModel.selectedVehicleType = .sedan
        viewModel.color = "Silver"
        
        // Wait for validation
        try? await Task.sleep(nanoseconds: 500_000_000)
        
        // When
        await viewModel.saveVehicleDetails()
        
        // Then
        XCTAssertTrue(mockAuthService.updateVehicleCalled)
        XCTAssertNotNil(mockAuthService.updatedVehicle)
        XCTAssertEqual(mockAuthService.updatedVehicle?.make, "Toyota")
        XCTAssertEqual(mockAuthService.updatedVehicle?.model, "Camry")
        XCTAssertEqual(mockAuthService.updatedVehicle?.vehicleNumber, "ABC123")
        XCTAssertEqual(mockAuthService.updatedVehicle?.odometerReading, 50000)
        XCTAssertEqual(mockAuthService.updatedVehicle?.type, .sedan)
        XCTAssertEqual(mockAuthService.updatedVehicle?.color, "Silver")
        XCTAssertTrue(viewModel.showingSuccessAlert)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    func testSaveVehicleDetailsError() async {
        // Given
        viewModel.make = "Toyota"
        viewModel.model = "Camry"
        viewModel.vehicleNumber = "ABC123"
        viewModel.odometerReading = "50000"
        mockAuthService.shouldThrowError = true
        
        // Wait for validation
        try? await Task.sleep(nanoseconds: 500_000_000)
        
        // When
        await viewModel.saveVehicleDetails()
        
        // Then
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertFalse(viewModel.showingSuccessAlert)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    func testSaveVehicleDetailsWithInvalidForm() async {
        // Given - empty form
        
        // When
        await viewModel.saveVehicleDetails()
        
        // Then
        XCTAssertFalse(mockAuthService.updateVehicleCalled)
        XCTAssertFalse(viewModel.showingSuccessAlert)
        XCTAssertNotNil(viewModel.makeError)
        XCTAssertNotNil(viewModel.modelError)
        XCTAssertNotNil(viewModel.vehicleNumberError)
        XCTAssertNotNil(viewModel.odometerError)
    }
    
    // MARK: - Load Existing Vehicle Data Tests
    
    func testLoadExistingVehicleData() async {
        // Given
        let existingVehicle = Vehicle(
            make: "Honda",
            model: "Civic",
            vehicleNumber: "XYZ789",
            odometerReading: 30000,
            type: .hatchback,
            color: "Blue"
        )
        let user = User(
            id: UUID(),
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date(),
            vehicle: existingVehicle
        )
        mockAuthService.currentUser = user
        
        // When
        let newViewModel = VehicleEntryViewModel(authenticationService: mockAuthService)
        
        // Wait for data loading
        try? await Task.sleep(nanoseconds: 500_000_000)
        
        // Then
        XCTAssertEqual(newViewModel.make, "Honda")
        XCTAssertEqual(newViewModel.model, "Civic")
        XCTAssertEqual(newViewModel.vehicleNumber, "XYZ789")
        XCTAssertEqual(newViewModel.odometerReading, "30000")
        XCTAssertEqual(newViewModel.selectedVehicleType, .hatchback)
        XCTAssertEqual(newViewModel.color, "Blue")
    }
    
    // MARK: - Clear Form Tests
    
    func testClearForm() {
        // Given
        viewModel.make = "Toyota"
        viewModel.model = "Camry"
        viewModel.vehicleNumber = "ABC123"
        viewModel.odometerReading = "50000"
        viewModel.selectedVehicleType = .suv
        viewModel.color = "Red"
        
        // When
        viewModel.clearForm()
        
        // Then
        XCTAssertEqual(viewModel.make, "")
        XCTAssertEqual(viewModel.model, "")
        XCTAssertEqual(viewModel.vehicleNumber, "")
        XCTAssertEqual(viewModel.odometerReading, "")
        XCTAssertEqual(viewModel.selectedVehicleType, .sedan)
        XCTAssertEqual(viewModel.color, "")
        XCTAssertNil(viewModel.makeError)
        XCTAssertNil(viewModel.modelError)
        XCTAssertNil(viewModel.vehicleNumberError)
        XCTAssertNil(viewModel.odometerError)
    }
}