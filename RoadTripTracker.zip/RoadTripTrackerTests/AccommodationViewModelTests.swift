import XCTest
import CoreLocation
@testable import RoadTripTracker

@MainActor
class AccommodationViewModelTests: XCTestCase {
    var viewModel: AccommodationViewModel!
    var mockAccommodationService: MockAccommodationService!
    var mockTripService: MockTripService!
    
    override func setUpWithError() throws {
        mockAccommodationService = MockAccommodationService()
        mockTripService = MockTripService()
        viewModel = AccommodationViewModel(
            accommodationService: mockAccommodationService,
            tripService: mockTripService
        )
    }
    
    override func tearDownWithError() throws {
        viewModel = nil
        mockAccommodationService = nil
        mockTripService = nil
    }
    
    // MARK: - Search Tests
    
    func testSearchAccommodationsSuccess() async {
        // Given
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        let mockAccommodations = [
            Accommodation(
                id: "hotel1",
                name: "Test Hotel",
                address: "123 Test St",
                coordinate: coordinate,
                type: .hotel,
                rating: 4.5
            )
        ]
        
        mockAccommodationService.mockAccommodations = mockAccommodations
        
        // When
        viewModel.searchAccommodations(near: coordinate)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertEqual(viewModel.accommodations.count, 1)
        XCTAssertEqual(viewModel.accommodations.first?.name, "Test Hotel")
        XCTAssertNil(viewModel.errorMessage)
    }
    
    func testSearchAccommodationsFailure() async {
        // Given
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        mockAccommodationService.shouldThrowError = true
        
        // When
        viewModel.searchAccommodations(near: coordinate)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertTrue(viewModel.accommodations.isEmpty)
        XCTAssertNotNil(viewModel.errorMessage)
    }
    
    func testSearchAccommodationsEmptyResults() async {
        // Given
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        mockAccommodationService.mockAccommodations = []
        
        // When
        viewModel.searchAccommodations(near: coordinate)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertTrue(viewModel.accommodations.isEmpty)
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertTrue(viewModel.errorMessage?.contains("No accommodations found") == true)
    }
    
    func testSearchAccommodationsAlongRoute() async {
        // Given
        let route = [
            CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094)
        ]
        let mockAccommodations = [
            Accommodation(
                id: "hotel1",
                name: "Route Hotel",
                address: "123 Route St",
                coordinate: route[0],
                type: .hotel
            )
        ]
        
        mockAccommodationService.mockAccommodations = mockAccommodations
        
        // When
        viewModel.searchAccommodationsAlongRoute(route)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertEqual(viewModel.accommodations.count, 1)
        XCTAssertEqual(viewModel.accommodations.first?.name, "Route Hotel")
    }
    
    // MARK: - Selection Tests
    
    func testSelectAccommodation() async {
        // Given
        let accommodation = Accommodation(
            id: "hotel1",
            name: "Test Hotel",
            address: "123 Test St",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            type: .hotel
        )
        
        // When
        viewModel.selectAccommodation(accommodation)
        
        // Then
        XCTAssertEqual(viewModel.selectedAccommodation?.id, accommodation.id)
    }
    
    // MARK: - Availability Tests
    
    func testCheckAvailability() async {
        // Given
        let accommodation = Accommodation(
            id: "hotel1",
            name: "Test Hotel",
            address: "123 Test St",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            type: .hotel
        )
        
        let checkIn = Date()
        let checkOut = Date().addingTimeInterval(86400)
        let guests = 2
        
        let mockAvailability = AccommodationAvailability(
            isAvailable: true,
            availableRooms: 5,
            pricePerNight: 120.0,
            currency: "USD",
            checkInDate: checkIn,
            checkOutDate: checkOut
        )
        
        mockAccommodationService.mockAvailability = mockAvailability
        
        // When
        viewModel.checkAvailability(for: accommodation, checkIn: checkIn, checkOut: checkOut, guests: guests)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertNotNil(viewModel.availability)
        XCTAssertTrue(viewModel.availability?.isAvailable == true)
        XCTAssertEqual(viewModel.availability?.availableRooms, 5)
        XCTAssertEqual(viewModel.availability?.pricePerNight, 120.0)
    }
    
    // MARK: - Booking Info Tests
    
    func testLoadBookingInfo() async {
        // Given
        let accommodation = Accommodation(
            id: "hotel1",
            name: "Test Hotel",
            address: "123 Test St",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            type: .hotel
        )
        
        let mockBookingInfo = AccommodationBookingInfo(
            accommodationId: accommodation.id,
            bookingURL: URL(string: "https://booking.com"),
            phoneNumber: "+1-555-0123",
            directBookingAvailable: true
        )
        
        mockAccommodationService.mockBookingInfo = mockBookingInfo
        
        // When
        viewModel.loadBookingInfo(for: accommodation)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertNotNil(viewModel.bookingInfo)
        XCTAssertEqual(viewModel.bookingInfo?.accommodationId, accommodation.id)
        XCTAssertTrue(viewModel.bookingInfo?.directBookingAvailable == true)
    }
    
    // MARK: - Add to Trip Tests
    
    func testAddAccommodationToTrip() async {
        // Given
        let accommodation = Accommodation(
            id: "hotel1",
            name: "Test Hotel",
            address: "123 Test St",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            type: .hotel
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            destinations: []
        )
        
        let updatedTrip = Trip(
            id: trip.id,
            name: trip.name,
            code: trip.code,
            createdBy: trip.createdBy,
            destinations: [
                Destination(
                    name: accommodation.name,
                    address: accommodation.address,
                    coordinate: accommodation.coordinate,
                    type: .accommodation
                )
            ]
        )
        
        mockAccommodationService.mockUpdatedTrip = updatedTrip
        
        // When
        viewModel.addAccommodationToTrip(accommodation, trip: trip)
        
        // Wait for async operation
        try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        
        // Then
        XCTAssertNil(viewModel.errorMessage)
        XCTAssertTrue(mockTripService.updateTripCalled)
    }
    
    // MARK: - Filter Tests
    
    func testUpdateFilters() {
        // Given
        var newFilters = AccommodationSearchFilters()
        newFilters.types = [.hotel, .motel]
        newFilters.minRating = 4.0
        
        // When
        viewModel.updateFilters(newFilters)
        
        // Then
        XCTAssertEqual(viewModel.searchFilters.types, [.hotel, .motel])
        XCTAssertEqual(viewModel.searchFilters.minRating, 4.0)
    }
    
    func testGetFilteredAccommodations() {
        // Given
        let accommodations = [
            Accommodation(id: "hotel1", name: "Hotel 1", address: "Address 1", coordinate: CLLocationCoordinate2D(latitude: 0, longitude: 0), type: .hotel, rating: 4.5),
            Accommodation(id: "motel1", name: "Motel 1", address: "Address 2", coordinate: CLLocationCoordinate2D(latitude: 0, longitude: 0), type: .motel, rating: 3.5),
            Accommodation(id: "hotel2", name: "Hotel 2", address: "Address 3", coordinate: CLLocationCoordinate2D(latitude: 0, longitude: 0), type: .hotel, rating: 4.8)
        ]
        
        viewModel.accommodations = accommodations
        
        var filters = AccommodationSearchFilters()
        filters.types = [.hotel]
        filters.minRating = 4.0
        viewModel.updateFilters(filters)
        
        // When
        let filteredAccommodations = viewModel.getFilteredAccommodations()
        
        // Then
        XCTAssertEqual(filteredAccommodations.count, 2)
        XCTAssertTrue(filteredAccommodations.allSatisfy { $0.type == .hotel })
        XCTAssertTrue(filteredAccommodations.allSatisfy { ($0.rating ?? 0) >= 4.0 })
    }
    
    // MARK: - Clear Results Tests
    
    func testClearResults() {
        // Given
        viewModel.accommodations = [
            Accommodation(id: "hotel1", name: "Hotel 1", address: "Address 1", coordinate: CLLocationCoordinate2D(latitude: 0, longitude: 0), type: .hotel)
        ]
        viewModel.selectedAccommodation = viewModel.accommodations.first
        viewModel.errorMessage = "Some error"
        
        // When
        viewModel.clearResults()
        
        // Then
        XCTAssertTrue(viewModel.accommodations.isEmpty)
        XCTAssertNil(viewModel.selectedAccommodation)
        XCTAssertNil(viewModel.errorMessage)
        XCTAssertNil(viewModel.bookingInfo)
        XCTAssertNil(viewModel.availability)
    }
}

// MARK: - Mock Services

class MockAccommodationService: AccommodationServiceProtocol {
    var mockAccommodations: [Accommodation] = []
    var mockAvailability: AccommodationAvailability?
    var mockBookingInfo: AccommodationBookingInfo?
    var mockUpdatedTrip: Trip?
    var shouldThrowError = false
    
    func searchAccommodations(near coordinate: CLLocationCoordinate2D, radius: Double, filters: AccommodationSearchFilters) async throws -> [Accommodation] {
        if shouldThrowError {
            throw AccommodationServiceError.searchFailed("Mock error")
        }
        return mockAccommodations
    }
    
    func searchAccommodationsAlongRoute(route: [CLLocationCoordinate2D], filters: AccommodationSearchFilters) async throws -> [Accommodation] {
        if shouldThrowError {
            throw AccommodationServiceError.searchFailed("Mock error")
        }
        return mockAccommodations
    }
    
    func getAccommodationDetails(accommodationId: String) async throws -> Accommodation {
        if shouldThrowError {
            throw AccommodationServiceError.accommodationNotFound
        }
        return mockAccommodations.first { $0.id == accommodationId } ?? mockAccommodations.first!
    }
    
    func checkAvailability(accommodationId: String, checkIn: Date, checkOut: Date, guests: Int) async throws -> AccommodationAvailability {
        if shouldThrowError {
            throw AccommodationServiceError.availabilityCheckFailed
        }
        return mockAvailability ?? AccommodationAvailability(isAvailable: true)
    }
    
    func getBookingInfo(accommodationId: String) async throws -> AccommodationBookingInfo {
        if shouldThrowError {
            throw AccommodationServiceError.bookingInfoUnavailable
        }
        return mockBookingInfo ?? AccommodationBookingInfo(accommodationId: accommodationId)
    }
    
    func addAccommodationToTrip(accommodation: Accommodation, trip: Trip) async throws -> Trip {
        if shouldThrowError {
            throw AccommodationServiceError.networkError
        }
        return mockUpdatedTrip ?? trip
    }
}

class MockTripService: TripServiceProtocol {
    var updateTripCalled = false
    
    func createTrip(name: String, destinations: [Destination]) async throws -> Trip {
        return Trip(name: name, code: "TEST", createdBy: UUID(), destinations: destinations)
    }
    
    func joinTrip(code: String) async throws -> Trip {
        return Trip(name: "Test", code: code, createdBy: UUID())
    }
    
    func updateTrip(_ trip: Trip) async throws {
        updateTripCalled = true
    }
    
    func deleteTrip(_ tripId: UUID) async throws {
        // Mock implementation
    }
    
    func getTripById(_ tripId: UUID) async throws -> Trip? {
        return nil
    }
    
    func getUserTrips() async throws -> [Trip] {
        return []
    }
}