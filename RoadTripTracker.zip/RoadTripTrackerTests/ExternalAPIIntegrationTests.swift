import XCTest
import MapKit
@testable import RoadTripTracker

class ExternalAPIIntegrationTests: XCTestCase {
    
    var weatherService: WeatherService!
    var placesService: PlacesService!
    var mapService: MapService!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        weatherService = WeatherService()
        placesService = PlacesService()
        mapService = MapService()
    }
    
    override func tearDownWithError() throws {
        weatherService = nil
        placesService = nil
        mapService = nil
        try super.tearDownWithError()
    }
    
    // MARK: - Weather API Integration Tests
    
    func testWeatherAPIConnection() async throws {
        let expectation = XCTestExpectation(description: "Weather API connection")
        
        let coordinate = CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)
        
        do {
            let weather = try await weatherService.getCurrentWeather(for: coordinate)
            XCTAssertNotNil(weather, "Weather data should be retrieved")
            XCTAssertNotNil(weather.temperature, "Temperature should be available")
            XCTAssertNotNil(weather.condition, "Weather condition should be available")
            expectation.fulfill()
        } catch {
            XCTFail("Weather API should not fail: \(error)")
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
    
    func testWeatherForecast() async throws {
        let expectation = XCTestExpectation(description: "Weather forecast")
        
        let coordinate = CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)
        
        do {
            let forecast = try await weatherService.getForecast(for: coordinate, days: 5)
            XCTAssertGreaterThan(forecast.count, 0, "Forecast should contain data")
            XCTAssertLessThanOrEqual(forecast.count, 5, "Forecast should not exceed requested days")
            expectation.fulfill()
        } catch {
            XCTFail("Weather forecast should not fail: \(error)")
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
    
    func testWeatherAPIErrorHandling() async throws {
        let expectation = XCTestExpectation(description: "Weather API error handling")
        
        // Test with invalid coordinates
        let invalidCoordinate = CLLocationCoordinate2D(latitude: 999, longitude: 999)
        
        do {
            _ = try await weatherService.getCurrentWeather(for: invalidCoordinate)
            XCTFail("Should throw error for invalid coordinates")
        } catch {
            XCTAssertTrue(error is WeatherServiceError, "Should throw WeatherServiceError")
            expectation.fulfill()
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
}    
    //
 MARK: - Places API Integration Tests
    
    func testPlacesAPISearch() async throws {
        let expectation = XCTestExpectation(description: "Places API search")
        
        let searchQuery = "restaurants"
        let coordinate = CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)
        
        do {
            let places = try await placesService.searchPlaces(query: searchQuery, near: coordinate, radius: 1000)
            XCTAssertGreaterThan(places.count, 0, "Should find places")
            
            let firstPlace = places.first!
            XCTAssertNotNil(firstPlace.name, "Place should have a name")
            XCTAssertNotNil(firstPlace.coordinate, "Place should have coordinates")
            expectation.fulfill()
        } catch {
            XCTFail("Places search should not fail: \(error)")
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
    
    func testPlaceDetails() async throws {
        let expectation = XCTestExpectation(description: "Place details")
        
        // First search for a place
        let coordinate = CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)
        let places = try await placesService.searchPlaces(query: "gas station", near: coordinate, radius: 1000)
        
        guard let firstPlace = places.first else {
            XCTFail("Should find at least one place")
            return
        }
        
        do {
            let details = try await placesService.getPlaceDetails(placeId: firstPlace.id)
            XCTAssertNotNil(details.phoneNumber, "Details should include phone number")
            XCTAssertNotNil(details.openingHours, "Details should include opening hours")
            expectation.fulfill()
        } catch {
            XCTFail("Place details should not fail: \(error)")
        }
        
        await fulfillment(of: [expectation], timeout: 15.0)
    }
    
    // MARK: - MapKit Integration Tests
    
    func testRouteCalculation() async throws {
        let expectation = XCTestExpectation(description: "Route calculation")
        
        let origin = CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093) // Sydney
        let destination = CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631) // Melbourne
        
        do {
            let route = try await mapService.calculateRoute(from: origin, to: destination)
            XCTAssertNotNil(route, "Route should be calculated")
            XCTAssertGreaterThan(route.distance, 0, "Route should have distance")
            XCTAssertGreaterThan(route.expectedTravelTime, 0, "Route should have travel time")
            expectation.fulfill()
        } catch {
            XCTFail("Route calculation should not fail: \(error)")
        }
        
        await fulfillment(of: [expectation], timeout: 15.0)
    }
    
    func testMultiDestinationRoute() async throws {
        let expectation = XCTestExpectation(description: "Multi-destination route")
        
        let destinations = [
            CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093), // Sydney
            CLLocationCoordinate2D(latitude: -35.2809, longitude: 149.1300), // Canberra
            CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631)  // Melbourne
        ]
        
        do {
            let routes = try await mapService.calculateMultiDestinationRoute(destinations: destinations)
            XCTAssertEqual(routes.count, destinations.count - 1, "Should have routes between each destination")
            
            let totalDistance = routes.reduce(0) { $0 + $1.distance }
            XCTAssertGreaterThan(totalDistance, 0, "Total route should have distance")
            expectation.fulfill()
        } catch {
            XCTFail("Multi-destination route should not fail: \(error)")
        }
        
        await fulfillment(of: [expectation], timeout: 20.0)
    }
    
    func testMapServiceErrorHandling() async throws {
        let expectation = XCTestExpectation(description: "Map service error handling")
        
        // Test with invalid coordinates
        let invalidOrigin = CLLocationCoordinate2D(latitude: 999, longitude: 999)
        let validDestination = CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631)
        
        do {
            _ = try await mapService.calculateRoute(from: invalidOrigin, to: validDestination)
            XCTFail("Should throw error for invalid coordinates")
        } catch {
            XCTAssertTrue(error is MapServiceError, "Should throw MapServiceError")
            expectation.fulfill()
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
    
    // MARK: - Network Resilience Tests
    
    func testAPIRetryMechanism() async throws {
        let expectation = XCTestExpectation(description: "API retry mechanism")
        
        // Simulate network failure and recovery
        let coordinate = CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)
        
        // Mock network failure
        weatherService.simulateNetworkFailure = true
        
        do {
            _ = try await weatherService.getCurrentWeather(for: coordinate)
            XCTFail("Should fail on first attempt")
        } catch {
            // Expected failure
        }
        
        // Simulate network recovery
        weatherService.simulateNetworkFailure = false
        
        do {
            let weather = try await weatherService.getCurrentWeather(for: coordinate)
            XCTAssertNotNil(weather, "Should succeed after network recovery")
            expectation.fulfill()
        } catch {
            XCTFail("Should succeed after network recovery: \(error)")
        }
        
        await fulfillment(of: [expectation], timeout: 15.0)
    }
    
    func testAPIRateLimiting() async throws {
        let expectation = XCTestExpectation(description: "API rate limiting")
        
        let coordinate = CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)
        var successCount = 0
        var rateLimitedCount = 0
        
        // Make multiple rapid requests
        for _ in 0..<10 {
            do {
                _ = try await weatherService.getCurrentWeather(for: coordinate)
                successCount += 1
            } catch WeatherServiceError.rateLimited {
                rateLimitedCount += 1
            } catch {
                // Other errors
            }
        }
        
        XCTAssertGreaterThan(successCount, 0, "Some requests should succeed")
        // Rate limiting behavior depends on API implementation
        expectation.fulfill()
        
        await fulfillment(of: [expectation], timeout: 30.0)
    }
}