import XCTest
import CoreLocation
@testable import RoadTripTracker

final class TripServiceTests: XCTestCase {
    var tripService: TripService!
    var mockPersistenceController: MockPersistenceController!
    
    override func setUpWithError() throws {
        mockPersistenceController = MockPersistenceController()
        tripService = TripService(persistenceController: mockPersistenceController)
    }
    
    override func tearDownWithError() throws {
        tripService = nil
        mockPersistenceController = nil
    }
    
    // MARK: - Trip Creation Tests
    
    func testCreateTrip_ValidData_Success() async throws {
        // Given
        let destinations = [
            Destination(
                id: UUID(),
                name: "Test Destination",
                address: "123 Test St",
                coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
                plannedArrival: Date().addingTimeInterval(3600),
                plannedDuration: 1800,
                type: .attraction,
                notes: "Test notes"
            )
        ]
        let settings = TripSettings(
            name: "Test Trip",
            budget: Budget(totalAmount: 1000, perPersonAmount: 250),
            isPublic: false
        )
        
        // When
        let trip = try await tripService.createTrip(destinations: destinations, settings: settings)
        
        // Then
        XCTAssertEqual(trip.name, "Test Trip")
        XCTAssertEqual(trip.destinations.count, 1)
        XCTAssertEqual(trip.destinations.first?.name, "Test Destination")
        XCTAssertNotNil(trip.code)
        XCTAssertEqual(trip.code.count, 6) // Trip codes should be 6 characters
        XCTAssertEqual(trip.status, .planning)
    }
    
    func testCreateTrip_EmptyDestinations_ThrowsError() async {
        // Given
        let destinations: [Destination] = []
        let settings = TripSettings(name: "Test Trip", budget: nil, isPublic: false)
        
        // When/Then
        do {
            _ = try await tripService.createTrip(destinations: destinations, settings: settings)
            XCTFail("Expected error to be thrown")
        } catch {
            XCTAssertTrue(error is AppError)
            if case AppError.invalidTripData(let message) = error {
                XCTAssertTrue(message.contains("destinations"))
            }
        }
    }
    
    // MARK: - Trip Joining Tests
    
    func testJoinTrip_ValidCode_Success() async throws {
        // Given
        let existingTrip = createMockTrip()
        mockPersistenceController.mockTrips = [existingTrip]
        
        // When
        let joinedTrip = try await tripService.joinTrip(code: existingTrip.code)
        
        // Then
        XCTAssertEqual(joinedTrip.id, existingTrip.id)
        XCTAssertEqual(joinedTrip.code, existingTrip.code)
    }
    
    func testJoinTrip_InvalidCode_ThrowsError() async {
        // Given
        let invalidCode = "INVALID"
        
        // When/Then
        do {
            _ = try await tripService.joinTrip(code: invalidCode)
            XCTFail("Expected error to be thrown")
        } catch {
            XCTAssertTrue(error is AppError)
            if case AppError.tripNotFound = error {
                // Expected error
            } else {
                XCTFail("Unexpected error type: \(error)")
            }
        }
    }
    
    // MARK: - Route Optimization Tests
    
    func testOptimizeRoute_MultipleDestinations_ReturnsOptimizedOrder() async throws {
        // Given
        let destinations = [
            createMockDestination(name: "Start", latitude: 37.7749, longitude: -122.4194),
            createMockDestination(name: "Middle", latitude: 37.7849, longitude: -122.4094),
            createMockDestination(name: "End", latitude: 37.7949, longitude: -122.3994)
        ]
        
        // When
        let optimizedDestinations = try await tripService.optimizeRoute(destinations: destinations)
        
        // Then
        XCTAssertEqual(optimizedDestinations.count, destinations.count)
        // Verify that destinations are reordered (implementation specific)
        XCTAssertTrue(optimizedDestinations.allSatisfy { dest in
            destinations.contains { $0.id == dest.id }
        })
    }
    
    func testOptimizeRoute_SingleDestination_ReturnsSameOrder() async throws {
        // Given
        let destinations = [createMockDestination(name: "Only", latitude: 37.7749, longitude: -122.4194)]
        
        // When
        let optimizedDestinations = try await tripService.optimizeRoute(destinations: destinations)
        
        // Then
        XCTAssertEqual(optimizedDestinations.count, 1)
        XCTAssertEqual(optimizedDestinations.first?.id, destinations.first?.id)
    }
    
    // MARK: - Trip Update Tests
    
    func testUpdateTripDestinations_ValidTrip_Success() async throws {
        // Given
        let trip = createMockTrip()
        let newDestinations = [
            createMockDestination(name: "New Destination", latitude: 38.0, longitude: -122.0)
        ]
        
        // When
        try await tripService.updateTripDestinations(trip, destinations: newDestinations)
        
        // Then
        // Verify the trip was updated (implementation specific)
        XCTAssertTrue(mockPersistenceController.saveContextCalled)
    }
    
    // MARK: - Trip Status Tests
    
    func testStartTrip_ValidTrip_UpdatesStatus() async throws {
        // Given
        let trip = createMockTrip()
        
        // When
        try await tripService.startTrip(trip)
        
        // Then
        XCTAssertEqual(trip.status, .active)
        XCTAssertNotNil(trip.startedAt)
    }
    
    func testCompleteTrip_ActiveTrip_UpdatesStatus() async throws {
        // Given
        let trip = createMockTrip()
        trip.status = .active
        trip.startedAt = Date()
        
        // When
        try await tripService.completeTrip(trip)
        
        // Then
        XCTAssertEqual(trip.status, .completed)
        XCTAssertNotNil(trip.completedAt)
    }
    
    // MARK: - Helper Methods
    
    private func createMockTrip() -> Trip {
        return Trip(
            id: UUID(),
            name: "Mock Trip",
            code: "ABC123",
            createdBy: UUID(),
            participants: [],
            destinations: [createMockDestination(name: "Mock Destination", latitude: 37.7749, longitude: -122.4194)],
            currentDestinationIndex: 0,
            status: .planning,
            createdAt: Date(),
            startedAt: nil,
            budget: nil
        )
    }
    
    private func createMockDestination(name: String, latitude: Double, longitude: Double) -> Destination {
        return Destination(
            id: UUID(),
            name: name,
            address: "\(name) Address",
            coordinate: CLLocationCoordinate2D(latitude: latitude, longitude: longitude),
            plannedArrival: Date().addingTimeInterval(3600),
            plannedDuration: 1800,
            type: .attraction,
            notes: nil
        )
    }
}

// MARK: - Mock Classes

class MockPersistenceController {
    var mockTrips: [Trip] = []
    var saveContextCalled = false
    
    func saveContext() {
        saveContextCalled = true
    }
}

// MARK: - Test Data Structures

struct TripSettings {
    let name: String
    let budget: Budget?
    let isPublic: Bool
}

struct Budget {
    let totalAmount: Double
    let perPersonAmount: Double
}