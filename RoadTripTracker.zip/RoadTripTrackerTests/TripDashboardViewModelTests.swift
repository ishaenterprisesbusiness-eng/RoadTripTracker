import XCTest
import Combine
import CoreLocation
@testable import RoadTripTracker

@MainActor
final class TripDashboardViewModelTests: XCTestCase {
    
    var viewModel: TripDashboardViewModel!
    var mockTripService: MockTripService!
    var mockLocationManager: MockLocationManager!
    var mockDistanceCalculationService: MockDistanceCalculationService!
    var mockMapService: MockMapService!
    var cancellables: Set<AnyCancellable>!
    
    override func setUp() {
        super.setUp()
        
        mockTripService = MockTripService()
        mockLocationManager = MockLocationManager()
        mockDistanceCalculationService = MockDistanceCalculationService()
        mockMapService = MockMapService()
        cancellables = Set<AnyCancellable>()
        
        viewModel = TripDashboardViewModel(
            tripService: mockTripService,
            locationManager: mockLocationManager,
            distanceCalculationService: mockDistanceCalculationService,
            mapService: mockMapService
        )
    }
    
    override func tearDown() {
        viewModel = nil
        mockTripService = nil
        mockLocationManager = nil
        mockDistanceCalculationService = nil
        mockMapService = nil
        cancellables = nil
        super.tearDown()
    }
    
    // MARK: - Dashboard Loading Tests
    
    func testLoadDashboard_WithActiveTrip_UpdatesMetrics() async {
        // Given
        let trip = createMockTrip()
        mockTripService.activeTrip = trip
        
        // When
        await viewModel.loadDashboard()
        
        // Then
        XCTAssertEqual(viewModel.activeTrip?.id, trip.id)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertEqual(viewModel.activeVehicleCount, 2) // Based on mock trip
    }
    
    func testLoadDashboard_WithNoActiveTrip_ShowsEmptyState() async {
        // Given
        mockTripService.activeTrip = nil
        
        // When
        await viewModel.loadDashboard()
        
        // Then
        XCTAssertNil(viewModel.activeTrip)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertEqual(viewModel.activeVehicleCount, 0)
    }
    
    // MARK: - Metrics Calculation Tests
    
    func testUpdateTripMetrics_CalculatesCorrectDistances() async {
        // Given
        let trip = createMockTrip()
        let userLocation = CLLocation(latitude: 37.7749, longitude: -122.4194)
        mockTripService.activeTrip = trip
        mockLocationManager.currentLocation = userLocation
        mockMapService.mockRoute = createMockRoute(distance: 50000) // 50km
        
        // When
        await viewModel.loadDashboard()
        
        // Then
        XCTAssertGreaterThan(viewModel.distanceToNext, 0)
        XCTAssertGreaterThan(viewModel.timeToNextDestination, 0)
    }
    
    func testActiveVehicleCount_CountsOnlyActiveParticipants() async {
        // Given
        let trip = createMockTripWithMixedParticipants()
        mockTripService.activeTrip = trip
        
        // When
        await viewModel.loadDashboard()
        
        // Then
        XCTAssertEqual(viewModel.activeVehicleCount, 1) // Only one active participant
    }
    
    // MARK: - Real-time Updates Tests
    
    func testLocationUpdates_TriggersMetricsUpdate() async {
        // Given
        let trip = createMockTrip()
        mockTripService.activeTrip = trip
        await viewModel.loadDashboard()
        
        let expectation = XCTestExpectation(description: "Metrics updated")
        
        // When
        let newLocation = CLLocation(latitude: 37.7849, longitude: -122.4094)
        mockLocationManager.simulateLocationUpdate(newLocation)
        
        // Then
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            XCTAssertEqual(self.viewModel.currentUserLocation, newLocation)
            expectation.fulfill()
        }
        
        await fulfillment(of: [expectation], timeout: 1.0)
    }
    
    // MARK: - Formatted Output Tests
    
    func testFormattedTimeToNext_ReturnsCorrectFormat() {
        // Given
        viewModel.timeToNextDestination = 3665 // 1 hour, 1 minute, 5 seconds
        
        // When
        let formatted = viewModel.formattedTimeToNext
        
        // Then
        XCTAssertEqual(formatted, "1h 1m")
    }
    
    func testFormattedDistanceToNext_ReturnsCorrectFormat() {
        // Given
        viewModel.distanceToNext = 25.7
        
        // When
        let formatted = viewModel.formattedDistanceToNext
        
        // Then
        XCTAssertEqual(formatted, "25.7 km")
    }
    
    // MARK: - Error Handling Tests
    
    func testLoadDashboard_WithError_ShowsErrorMessage() async {
        // Given
        mockTripService.shouldThrowError = true
        
        // When
        await viewModel.loadDashboard()
        
        // Then
        XCTAssertTrue(viewModel.showingError)
        XCTAssertNotNil(viewModel.errorMessage)
    }
    
    // MARK: - Helper Methods
    
    private func createMockTrip() -> Trip {
        let destination1 = Destination(
            name: "San Francisco",
            address: "San Francisco, CA",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            type: .start
        )
        
        let destination2 = Destination(
            name: "Los Angeles",
            address: "Los Angeles, CA",
            coordinate: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437),
            type: .end
        )
        
        let participant1 = Participant(
            userId: UUID(),
            user: createMockUser(),
            currentLocation: CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094),
            isLocationSharingEnabled: true,
            status: .active
        )
        
        let participant2 = Participant(
            userId: UUID(),
            user: createMockUser(),
            currentLocation: CLLocationCoordinate2D(latitude: 37.7649, longitude: -122.4294),
            isLocationSharingEnabled: true,
            status: .active
        )
        
        return Trip(
            name: "California Road Trip",
            code: "ABC123",
            createdBy: UUID(),
            participants: [participant1, participant2],
            destinations: [destination1, destination2],
            status: .active
        )
    }
    
    private func createMockTripWithMixedParticipants() -> Trip {
        let destination = Destination(
            name: "Test Destination",
            address: "Test Address",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            type: .waypoint
        )
        
        let activeParticipant = Participant(
            userId: UUID(),
            user: createMockUser(),
            currentLocation: CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094),
            isLocationSharingEnabled: true,
            status: .active
        )
        
        let inactiveParticipant = Participant(
            userId: UUID(),
            user: createMockUser(),
            currentLocation: nil,
            isLocationSharingEnabled: false,
            status: .inactive
        )
        
        return Trip(
            name: "Mixed Participants Trip",
            code: "DEF456",
            createdBy: UUID(),
            participants: [activeParticipant, inactiveParticipant],
            destinations: [destination],
            status: .active
        )
    }
    
    private func createMockUser() -> User {
        return User(
            username: "Test User",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
    }
    
    private func createMockRoute(distance: CLLocationDistance) -> Route {
        return Route(
            name: "Mock Route",
            destinations: [],
            waypoints: [],
            distance: distance,
            estimatedTravelTime: distance / (60 * 1000 / 3600), // 60 km/h
            polyline: nil,
            steps: []
        )
    }
}

// MARK: - Mock Services

class MockTripService: TripServiceProtocol {
    @Published var activeTrip: Trip?
    var shouldThrowError = false
    
    var tripUpdates: AnyPublisher<Trip?, Never> {
        $activeTrip.eraseToAnyPublisher()
    }
    
    func createTrip(name: String, destinations: [Destination], settings: TripSettings) async throws -> Trip {
        if shouldThrowError {
            throw TripServiceError.unknown("Mock error")
        }
        let trip = Trip(name: name, code: "TEST123", createdBy: UUID(), destinations: destinations)
        activeTrip = trip
        return trip
    }
    
    func joinTrip(code: String) async throws -> Trip {
        if shouldThrowError {
            throw TripServiceError.invalidTripCode
        }
        let trip = Trip(name: "Joined Trip", code: code, createdBy: UUID())
        activeTrip = trip
        return trip
    }
    
    func leaveTrip(_ tripId: UUID) async throws {
        if shouldThrowError {
            throw TripServiceError.unknown("Mock error")
        }
        activeTrip = nil
    }
    
    func updateTrip(_ trip: Trip) async throws {
        if shouldThrowError {
            throw TripServiceError.unknown("Mock error")
        }
        activeTrip = trip
    }
    
    func deleteTrip(_ tripId: UUID) async throws {
        if shouldThrowError {
            throw TripServiceError.unknown("Mock error")
        }
        activeTrip = nil
    }
    
    func generateTripCode() -> String {
        return "MOCK123"
    }
    
    func validateTripCode(_ code: String) async throws -> Bool {
        return !shouldThrowError
    }
    
    func getTripHistory(for userId: UUID) async throws -> [Trip] {
        if shouldThrowError {
            throw TripServiceError.unknown("Mock error")
        }
        return []
    }
    
    func addDestination(_ destination: Destination, to tripId: UUID) async throws {
        // Mock implementation
    }
    
    func removeDestination(_ destinationId: UUID, from tripId: UUID) async throws {
        // Mock implementation
    }
    
    func reorderDestinations(_ destinations: [Destination], in tripId: UUID) async throws {
        // Mock implementation
    }
    
    func optimizeRoute(destinations: [Destination]) async throws -> [Destination] {
        return destinations
    }
}

class MockLocationManager: LocationServiceProtocol {
    @Published var currentLocation: CLLocation?
    @Published var authorizationStatus: CLAuthorizationStatus = .authorizedWhenInUse
    @Published var isLocationSharingEnabled: Bool = true
    
    private let locationSubject = PassthroughSubject<CLLocation, Never>()
    private let authorizationSubject = PassthroughSubject<CLAuthorizationStatus, Never>()
    
    var locationUpdates: AnyPublisher<CLLocation, Never> {
        locationSubject.eraseToAnyPublisher()
    }
    
    var authorizationUpdates: AnyPublisher<CLAuthorizationStatus, Never> {
        authorizationSubject.eraseToAnyPublisher()
    }
    
    func requestLocationPermission() async throws {
        authorizationStatus = .authorizedWhenInUse
    }
    
    func startLocationSharing() async throws {
        isLocationSharingEnabled = true
    }
    
    func stopLocationSharing() {
        isLocationSharingEnabled = false
    }
    
    func getCurrentLocation() async throws -> CLLocation {
        return currentLocation ?? CLLocation(latitude: 37.7749, longitude: -122.4194)
    }
    
    func startMonitoringSignificantLocationChanges() {
        // Mock implementation
    }
    
    func stopMonitoringSignificantLocationChanges() {
        // Mock implementation
    }
    
    func calculateDistance(from: CLLocation, to: CLLocation) -> CLLocationDistance {
        return from.distance(from: to)
    }
    
    func calculateDrivingDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) async throws -> CLLocationDistance {
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        return fromLocation.distance(from: toLocation) * 1.3 // Simulate driving distance
    }
    
    func isLocationStale(_ location: CLLocation, threshold: TimeInterval) -> Bool {
        return Date().timeIntervalSince(location.timestamp) > threshold
    }
    
    func simulateLocationUpdate(_ location: CLLocation) {
        currentLocation = location
        locationSubject.send(location)
    }
}

class MockDistanceCalculationService: DistanceCalculationService {
    override init(locationManager: LocationServiceProtocol, mapService: MapServiceProtocol) {
        super.init(locationManager: locationManager, mapService: mapService)
    }
}

class MockMapService: MapServiceProtocol {
    var mockRoute: Route?
    
    func displayRoute(_ route: Route) async throws {
        // Mock implementation
    }
    
    func showParticipants(_ participants: [Participant]) async throws {
        // Mock implementation
    }
    
    func findNearbyPOIs(category: POICategory, near location: CLLocationCoordinate2D, radius: CLLocationDistance) async throws -> [PointOfInterest] {
        return []
    }
    
    func calculateRoute(from origin: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D, waypoints: [CLLocationCoordinate2D]) async throws -> Route {
        return mockRoute ?? Route(
            name: "Mock Route",
            destinations: [],
            waypoints: waypoints,
            distance: 10000,
            estimatedTravelTime: 600,
            polyline: nil,
            steps: []
        )
    }
    
    func calculateMultiDestinationRoute(destinations: [Destination]) async throws -> Route {
        return mockRoute ?? Route(
            name: "Mock Multi Route",
            destinations: destinations,
            waypoints: [],
            distance: 50000,
            estimatedTravelTime: 3000,
            polyline: nil,
            steps: []
        )
    }
    
    func getDirections(for route: Route) async throws -> [RouteStep] {
        return []
    }
    
    func searchPlaces(query: String, near location: CLLocationCoordinate2D) async throws -> [Place] {
        return []
    }
}