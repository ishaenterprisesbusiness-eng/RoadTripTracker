import XCTest
import CoreLocation
import Combine
@testable import RoadTripTracker

class RouteManagerTests: XCTestCase {
    
    var routeManager: RouteManager!
    var mockNavigationService: MockNavigationService!
    var mockMapService: MockMapService!
    var mockLocationManager: MockLocationManager!
    var cancellables: Set<AnyCancellable>!
    
    override func setUp() {
        super.setUp()
        mockNavigationService = MockNavigationService()
        mockMapService = MockMapService()
        mockLocationManager = MockLocationManager()
        cancellables = Set<AnyCancellable>()
        
        routeManager = RouteManager(
            navigationService: mockNavigationService,
            mapService: mockMapService,
            locationManager: mockLocationManager
        )
    }
    
    override func tearDown() {
        routeManager = nil
        mockNavigationService = nil
        mockMapService = nil
        mockLocationManager = nil
        cancellables = nil
        super.tearDown()
    }
    
    // MARK: - Route Calculation Tests
    
    func testCalculateRoute() async throws {
        // Given
        let destinations = [
            createMockDestination(name: "Start", coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)),
            createMockDestination(name: "End", coordinate: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437))
        ]
        
        let expectedRoute = createMockRoute(destinations: destinations)
        mockMapService.mockRoute = expectedRoute
        
        // When
        let route = try await routeManager.calculateRoute(for: destinations)
        
        // Then
        XCTAssertEqual(route.id, expectedRoute.id)
        XCTAssertEqual(route.destinations.count, destinations.count)
        XCTAssertEqual(routeManager.currentRoute?.id, route.id)
    }
    
    func testCalculateRouteWithNoDestinations() async {
        // Given
        let destinations: [Destination] = []
        
        // When/Then
        do {
            _ = try await routeManager.calculateRoute(for: destinations)
            XCTFail("Should have thrown an error")
        } catch RouteManagerError.noDestinations {
            // Expected error
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    func testStartNavigation() async throws {
        // Given
        let destinations = [createMockDestination()]
        let route = try await routeManager.calculateRoute(for: destinations)
        
        // When
        try await routeManager.startNavigation()
        
        // Then
        XCTAssertTrue(routeManager.isNavigating)
        XCTAssertTrue(mockNavigationService.isNavigationStarted)
    }
    
    func testStartNavigationWithoutRoute() async {
        // Given - no route set
        
        // When/Then
        do {
            try await routeManager.startNavigation()
            XCTFail("Should have thrown an error")
        } catch RouteManagerError.noRouteAvailable {
            // Expected error
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    func testStopNavigation() async throws {
        // Given
        let destinations = [createMockDestination()]
        _ = try await routeManager.calculateRoute(for: destinations)
        try await routeManager.startNavigation()
        
        // When
        try await routeManager.stopNavigation()
        
        // Then
        XCTAssertFalse(routeManager.isNavigating)
        XCTAssertFalse(mockNavigationService.isNavigationStarted)
        XCTAssertNil(routeManager.routeProgress)
        XCTAssertNil(routeManager.navigationUpdate)
        XCTAssertFalse(routeManager.routeDeviation)
    }
    
    func testRecalculateRoute() async throws {
        // Given
        let destinations = [createMockDestination()]
        _ = try await routeManager.calculateRoute(for: destinations)
        
        let currentLocation = CLLocation(latitude: 37.7749, longitude: -122.4194)
        mockLocationManager.mockCurrentLocation = currentLocation
        
        let recalculatedRoute = createMockRoute(destinations: destinations)
        mockNavigationService.mockRecalculatedRoute = recalculatedRoute
        
        // When
        let route = try await routeManager.recalculateRoute()
        
        // Then
        XCTAssertEqual(route.id, recalculatedRoute.id)
        XCTAssertEqual(routeManager.currentRoute?.id, recalculatedRoute.id)
        XCTAssertFalse(routeManager.routeDeviation)
    }
    
    func testRecalculateRouteWithoutLocation() async {
        // Given
        let destinations = [createMockDestination()]
        _ = try await routeManager.calculateRoute(for: destinations)
        mockLocationManager.mockCurrentLocation = nil
        
        // When/Then
        do {
            _ = try await routeManager.recalculateRoute()
            XCTFail("Should have thrown an error")
        } catch RouteManagerError.locationUnavailable {
            // Expected error
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    // MARK: - Destination Management Tests
    
    func testAddDestination() async throws {
        // Given
        let initialDestinations = [createMockDestination(name: "Start")]
        _ = try await routeManager.calculateRoute(for: initialDestinations)
        
        let newDestination = createMockDestination(name: "New Stop")
        let updatedRoute = createMockRoute(destinations: initialDestinations + [newDestination])
        mockMapService.mockRoute = updatedRoute
        
        // When
        try await routeManager.addDestination(newDestination)
        
        // Then
        XCTAssertEqual(routeManager.currentRoute?.destinations.count, 2)
        XCTAssertTrue(routeManager.currentRoute?.destinations.contains { $0.id == newDestination.id } ?? false)
    }
    
    func testAddDestinationAtIndex() async throws {
        // Given
        let initialDestinations = [
            createMockDestination(name: "Start"),
            createMockDestination(name: "End")
        ]
        _ = try await routeManager.calculateRoute(for: initialDestinations)
        
        let newDestination = createMockDestination(name: "Middle")
        let updatedDestinations = [initialDestinations[0], newDestination, initialDestinations[1]]
        let updatedRoute = createMockRoute(destinations: updatedDestinations)
        mockMapService.mockRoute = updatedRoute
        
        // When
        try await routeManager.addDestination(newDestination, at: 1)
        
        // Then
        XCTAssertEqual(routeManager.currentRoute?.destinations.count, 3)
        XCTAssertEqual(routeManager.currentRoute?.destinations[1].id, newDestination.id)
    }
    
    func testRemoveDestination() async throws {
        // Given
        let destinations = [
            createMockDestination(name: "Start"),
            createMockDestination(name: "Middle"),
            createMockDestination(name: "End")
        ]
        _ = try await routeManager.calculateRoute(for: destinations)
        
        let updatedDestinations = [destinations[0], destinations[2]]
        let updatedRoute = createMockRoute(destinations: updatedDestinations)
        mockMapService.mockRoute = updatedRoute
        
        // When
        try await routeManager.removeDestination(at: 1)
        
        // Then
        XCTAssertEqual(routeManager.currentRoute?.destinations.count, 2)
        XCTAssertFalse(routeManager.currentRoute?.destinations.contains { $0.id == destinations[1].id } ?? true)
    }
    
    func testRemoveLastDestination() async throws {
        // Given
        let destinations = [createMockDestination()]
        _ = try await routeManager.calculateRoute(for: destinations)
        
        // When
        try await routeManager.removeDestination(at: 0)
        
        // Then
        XCTAssertNil(routeManager.currentRoute)
    }
    
    func testReorderDestinations() async throws {
        // Given
        let destinations = [
            createMockDestination(name: "First"),
            createMockDestination(name: "Second"),
            createMockDestination(name: "Third")
        ]
        _ = try await routeManager.calculateRoute(for: destinations)
        
        let reorderedDestinations = [destinations[2], destinations[0], destinations[1]]
        let updatedRoute = createMockRoute(destinations: reorderedDestinations)
        mockMapService.mockRoute = updatedRoute
        
        // When
        try await routeManager.reorderDestinations(reorderedDestinations)
        
        // Then
        XCTAssertEqual(routeManager.currentRoute?.destinations.count, 3)
        XCTAssertEqual(routeManager.currentRoute?.destinations[0].id, destinations[2].id)
        XCTAssertEqual(routeManager.currentRoute?.destinations[1].id, destinations[0].id)
        XCTAssertEqual(routeManager.currentRoute?.destinations[2].id, destinations[1].id)
    }
    
    // MARK: - Route Deviation Tests
    
    func testCheckRouteDeviation() async throws {
        // Given
        let destinations = [createMockDestination()]
        _ = try await routeManager.calculateRoute(for: destinations)
        try await routeManager.startNavigation()
        
        let currentLocation = CLLocation(latitude: 37.7749, longitude: -122.4194)
        mockLocationManager.mockCurrentLocation = currentLocation
        mockNavigationService.mockIsOffRoute = true
        
        // When
        let isOffRoute = await routeManager.checkRouteDeviation()
        
        // Then
        XCTAssertTrue(isOffRoute)
        XCTAssertTrue(routeManager.routeDeviation)
    }
    
    func testCheckRouteDeviationWhenNotNavigating() async {
        // Given - not navigating
        
        // When
        let isOffRoute = await routeManager.checkRouteDeviation()
        
        // Then
        XCTAssertFalse(isOffRoute)
    }
    
    // MARK: - Navigation Updates Tests
    
    func testNavigationUpdatesBinding() async throws {
        // Given
        let destinations = [createMockDestination()]
        _ = try await routeManager.calculateRoute(for: destinations)
        
        let expectation = XCTestExpectation(description: "Navigation update received")
        
        routeManager.$navigationUpdate
            .dropFirst() // Skip initial nil value
            .sink { update in
                if update != nil {
                    expectation.fulfill()
                }
            }
            .store(in: &cancellables)
        
        // When
        let navigationUpdate = NavigationUpdate(
            currentLocation: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            nextStep: nil,
            distanceToNextStep: 1000,
            timeToNextStep: 60,
            isOffRoute: false
        )
        mockNavigationService.sendNavigationUpdate(navigationUpdate)
        
        // Then
        await fulfillment(of: [expectation], timeout: 1.0)
        XCTAssertNotNil(routeManager.navigationUpdate)
    }
    
    // MARK: - Helper Methods
    
    private func createMockDestination(name: String = "Test Destination", coordinate: CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)) -> Destination {
        return Destination(
            name: name,
            address: "123 Test St",
            coordinate: coordinate,
            type: .waypoint
        )
    }
    
    private func createMockRoute(destinations: [Destination]) -> Route {
        return Route(
            name: "Test Route",
            destinations: destinations,
            waypoints: destinations.map { $0.coordinate },
            distance: 10000,
            estimatedTravelTime: 600,
            steps: []
        )
    }
}

// MARK: - Mock Navigation Service

class MockNavigationService: NavigationServiceProtocol {
    var currentRoute: Route?
    var isNavigationStarted = false
    var mockIsOffRoute = false
    var mockRecalculatedRoute: Route?
    
    private let navigationUpdateSubject = PassthroughSubject<NavigationUpdate, Never>()
    private let routeProgressSubject = PassthroughSubject<RouteProgress, Never>()
    
    var navigationUpdates: AnyPublisher<NavigationUpdate, Never> {
        navigationUpdateSubject.eraseToAnyPublisher()
    }
    
    var routeProgress: AnyPublisher<RouteProgress, Never> {
        routeProgressSubject.eraseToAnyPublisher()
    }
    
    func startNavigation(route: Route) async throws {
        currentRoute = route
        isNavigationStarted = true
    }
    
    func stopNavigation() async throws {
        currentRoute = nil
        isNavigationStarted = false
    }
    
    func recalculateRoute(from currentLocation: CLLocationCoordinate2D) async throws -> Route {
        guard let recalculatedRoute = mockRecalculatedRoute else {
            throw NavigationServiceError.routeRecalculationFailed
        }
        currentRoute = recalculatedRoute
        return recalculatedRoute
    }
    
    func getNextInstruction() -> RouteStep? {
        return currentRoute?.steps.first
    }
    
    func isOffRoute(currentLocation: CLLocationCoordinate2D, threshold: CLLocationDistance = 100) -> Bool {
        return mockIsOffRoute
    }
    
    func sendNavigationUpdate(_ update: NavigationUpdate) {
        navigationUpdateSubject.send(update)
    }
    
    func sendRouteProgress(_ progress: RouteProgress) {
        routeProgressSubject.send(progress)
    }
}