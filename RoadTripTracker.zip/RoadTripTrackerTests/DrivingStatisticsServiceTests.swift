import XCTest
import CoreLocation
import Combine
@testable import RoadTripTracker

// MARK: - Driving Statistics Service Tests
final class DrivingStatisticsServiceTests: XCTestCase {
    
    var sut: DrivingStatisticsService!
    var mockPersistenceController: MockPersistenceController!
    var mockLocationManager: MockLocationManager!
    var cancellables: Set<AnyCancellable>!
    
    override func setUp() {
        super.setUp()
        mockPersistenceController = MockPersistenceController()
        mockLocationManager = MockLocationManager()
        sut = DrivingStatisticsService(
            persistenceController: mockPersistenceController,
            locationManager: mockLocationManager
        )
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDown() {
        cancellables = nil
        sut = nil
        mockLocationManager = nil
        mockPersistenceController = nil
        super.tearDown()
    }
    
    // MARK: - Tracking Management Tests
    
    @MainActor
    func testStartTracking_ShouldInitializeStatistics() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        
        // When
        try await sut.startTracking(for: tripId, participantId: participantId)
        
        // Then
        XCTAssertTrue(sut.isTracking)
        XCTAssertNotNil(sut.currentStatistics)
        XCTAssertEqual(sut.currentStatistics?.tripId, tripId)
        XCTAssertEqual(sut.currentStatistics?.participantId, participantId)
    }
    
    @MainActor
    func testStartTracking_WhenAlreadyTracking_ShouldThrowError() async {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try! await sut.startTracking(for: tripId, participantId: participantId)
        
        // When/Then
        do {
            try await sut.startTracking(for: UUID(), participantId: UUID())
            XCTFail("Should have thrown error")
        } catch {
            XCTAssertTrue(error is DrivingStatisticsServiceError)
        }
    }
    
    @MainActor
    func testStopTracking_ShouldFinalizeStatistics() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await sut.startTracking(for: tripId, participantId: participantId)
        
        // When
        try await sut.stopTracking()
        
        // Then
        XCTAssertFalse(sut.isTracking)
        XCTAssertNil(sut.currentStatistics)
    }
    
    @MainActor
    func testStopTracking_WhenNotTracking_ShouldThrowError() async {
        // When/Then
        do {
            try await sut.stopTracking()
            XCTFail("Should have thrown error")
        } catch {
            XCTAssertTrue(error is DrivingStatisticsServiceError)
        }
    }
    
    // MARK: - Location Processing Tests
    
    @MainActor
    func testProcessLocationUpdate_ShouldUpdateStatistics() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await sut.startTracking(for: tripId, participantId: participantId)
        
        let location = CLLocation(
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            altitude: 0,
            horizontalAccuracy: 5,
            verticalAccuracy: 5,
            course: 90,
            speed: 15.0, // 54 km/h
            timestamp: Date()
        )
        
        // When
        await sut.processLocationUpdate(location)
        
        // Then
        XCTAssertEqual(sut.currentSpeed, 15.0)
        XCTAssertNotNil(sut.currentStatistics)
    }
    
    @MainActor
    func testProcessLocationUpdate_WithMovement_ShouldUpdateDistance() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await sut.startTracking(for: tripId, participantId: participantId)
        
        let location1 = CLLocation(
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            altitude: 0,
            horizontalAccuracy: 5,
            verticalAccuracy: 5,
            course: 90,
            speed: 15.0,
            timestamp: Date()
        )
        
        let location2 = CLLocation(
            coordinate: CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4194),
            altitude: 0,
            horizontalAccuracy: 5,
            verticalAccuracy: 5,
            course: 90,
            speed: 15.0,
            timestamp: Date().addingTimeInterval(60)
        )
        
        // When
        await sut.processLocationUpdate(location1)
        await sut.processLocationUpdate(location2)
        
        // Then
        XCTAssertGreaterThan(sut.currentStatistics?.totalDistance ?? 0, 0)
        XCTAssertGreaterThan(sut.currentStatistics?.totalDrivingTime ?? 0, 0)
    }
    
    // MARK: - Speed Monitoring Tests
    
    @MainActor
    func testCheckSpeedLimit_WhenSpeeding_ShouldReturnTrue() async {
        // Given
        let currentSpeed = 20.0 // 72 km/h
        let speedLimit = 15.0 // 54 km/h
        
        // When
        let isSpeeding = await sut.checkSpeedLimit(currentSpeed: currentSpeed, speedLimit: speedLimit)
        
        // Then
        XCTAssertTrue(isSpeeding)
        XCTAssertTrue(sut.isSpeedingDetected)
    }
    
    @MainActor
    func testCheckSpeedLimit_WhenNotSpeeding_ShouldReturnFalse() async {
        // Given
        let currentSpeed = 13.0 // 47 km/h
        let speedLimit = 15.0 // 54 km/h
        
        // When
        let isSpeeding = await sut.checkSpeedLimit(currentSpeed: currentSpeed, speedLimit: speedLimit)
        
        // Then
        XCTAssertFalse(isSpeeding)
        XCTAssertFalse(sut.isSpeedingDetected)
    }
    
    @MainActor
    func testSpeedingIncident_ShouldBeRecorded() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await sut.startTracking(for: tripId, participantId: participantId)
        
        let incident = SpeedingIncident(
            timestamp: Date(),
            location: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            actualSpeed: 20.0,
            speedLimit: 15.0,
            duration: 30,
            severity: .moderate
        )
        
        // When
        try await sut.recordSpeedingIncident(incident)
        
        // Then
        XCTAssertEqual(sut.currentStatistics?.speedingIncidents.count, 1)
        XCTAssertEqual(sut.currentStatistics?.speedingIncidents.first?.id, incident.id)
    }
    
    // MARK: - Rest Period Tests
    
    @MainActor
    func testStartManualRestPeriod_ShouldCreateRestPeriod() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await sut.startTracking(for: tripId, participantId: participantId)
        
        let location = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        
        // When
        try await sut.startManualRestPeriod(type: .manual, location: location)
        
        // Then
        XCTAssertNotNil(sut.currentRestPeriod)
        XCTAssertEqual(sut.currentRestPeriod?.type, .manual)
        XCTAssertEqual(sut.currentStatistics?.restPeriods.count, 1)
    }
    
    @MainActor
    func testEndCurrentRestPeriod_ShouldFinalizeRestPeriod() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await sut.startTracking(for: tripId, participantId: participantId)
        
        let location = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        try await sut.startManualRestPeriod(type: .manual, location: location)
        
        // When
        try await sut.endCurrentRestPeriod()
        
        // Then
        XCTAssertNil(sut.currentRestPeriod)
        XCTAssertNotNil(sut.currentStatistics?.restPeriods.first?.endTime)
    }
    
    @MainActor
    func testDetectAutomaticRestPeriod_WhenStationary_ShouldCreateRestPeriod() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await sut.startTracking(for: tripId, participantId: participantId)
        
        // Simulate stationary locations
        let baseTime = Date().addingTimeInterval(-400) // 6+ minutes ago
        for i in 0..<10 {
            let location = CLLocation(
                coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
                altitude: 0,
                horizontalAccuracy: 5,
                verticalAccuracy: 5,
                course: 90,
                speed: 0.5, // Below threshold
                timestamp: baseTime.addingTimeInterval(Double(i * 30))
            )
            await sut.processLocationUpdate(location)
        }
        
        let currentLocation = CLLocation(
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            altitude: 0,
            horizontalAccuracy: 5,
            verticalAccuracy: 5,
            course: 90,
            speed: 0.5,
            timestamp: Date()
        )
        
        // When
        await sut.detectAutomaticRestPeriod(location: currentLocation)
        
        // Then
        XCTAssertNotNil(sut.currentRestPeriod)
        XCTAssertEqual(sut.currentRestPeriod?.type, .automatic)
    }
    
    // MARK: - Break Suggestion Tests
    
    @MainActor
    func testEvaluateBreakNeed_AfterLongDriving_ShouldSuggestBreak() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await sut.startTracking(for: tripId, participantId: participantId)
        
        // Simulate long driving time by manipulating the tracking start time
        let longAgo = Date().addingTimeInterval(-15000) // Over 4 hours ago
        sut.setValue(longAgo, forKey: "trackingStartTime")
        
        // When
        let suggestion = await sut.evaluateBreakNeed()
        
        // Then
        XCTAssertNotNil(suggestion)
        XCTAssertEqual(suggestion?.urgency, .critical)
        XCTAssertEqual(suggestion?.reason, .continuousDriving)
    }
    
    @MainActor
    func testEvaluateBreakNeed_WithRecentBreak_ShouldNotSuggestBreak() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await sut.startTracking(for: tripId, participantId: participantId)
        
        // Simulate recent break suggestion
        sut.setValue(Date().addingTimeInterval(-1000), forKey: "lastBreakSuggestion") // 16 minutes ago
        
        // When
        let suggestion = await sut.evaluateBreakNeed()
        
        // Then
        XCTAssertNil(suggestion)
    }
    
    // MARK: - Safety Score Tests
    
    func testCalculateSafetyScore_WithNoIncidents_ShouldReturnHighScore() {
        // Given
        let statistics = DrivingStatistics(
            tripId: UUID(),
            participantId: UUID(),
            totalDistance: 100000, // 100 km
            totalDrivingTime: 3600, // 1 hour
            averageSpeed: 25.0, // 90 km/h
            maxSpeed: 30.0, // 108 km/h
            speedingIncidents: [],
            restPeriods: [
                RestPeriod(
                    startTime: Date().addingTimeInterval(-1800),
                    endTime: Date().addingTimeInterval(-900),
                    location: CLLocationCoordinate2D(latitude: 0, longitude: 0),
                    type: .automatic
                )
            ]
        )
        
        // When
        let score = sut.calculateSafetyScore(for: statistics)
        
        // Then
        XCTAssertGreaterThanOrEqual(score, 90.0)
    }
    
    func testCalculateSafetyScore_WithManyIncidents_ShouldReturnLowScore() {
        // Given
        let incidents = (0..<10).map { _ in
            SpeedingIncident(
                timestamp: Date(),
                location: CLLocationCoordinate2D(latitude: 0, longitude: 0),
                actualSpeed: 20.0,
                speedLimit: 15.0,
                duration: 30,
                severity: .moderate
            )
        }
        
        let statistics = DrivingStatistics(
            tripId: UUID(),
            participantId: UUID(),
            speedingIncidents: incidents
        )
        
        // When
        let score = sut.calculateSafetyScore(for: statistics)
        
        // Then
        XCTAssertLessThan(score, 60.0)
    }
    
    // MARK: - Performance Summary Tests
    
    @MainActor
    func testGetPerformanceSummary_ShouldReturnSummary() async throws {
        // Given
        let participantId = UUID()
        mockPersistenceController.shouldReturnMockData = true
        
        // When
        let summary = try await sut.getPerformanceSummary(for: participantId)
        
        // Then
        XCTAssertEqual(summary.participantId, participantId)
        XCTAssertGreaterThanOrEqual(summary.totalTrips, 0)
    }
    
    @MainActor
    func testGetTripComparisons_ShouldReturnComparisons() async throws {
        // Given
        let participantId = UUID()
        mockPersistenceController.shouldReturnMockData = true
        
        // When
        let comparisons = try await sut.getTripComparisons(for: participantId, limit: 5)
        
        // Then
        XCTAssertLessThanOrEqual(comparisons.count, 5)
    }
    
    // MARK: - Data Management Tests
    
    @MainActor
    func testSaveStatistics_ShouldPersistData() async throws {
        // Given
        let statistics = DrivingStatistics(
            tripId: UUID(),
            participantId: UUID(),
            totalDistance: 50000,
            totalDrivingTime: 1800,
            averageSpeed: 25.0
        )
        
        // When
        try await sut.saveStatistics(statistics)
        
        // Then
        XCTAssertTrue(mockPersistenceController.saveWasCalled)
    }
    
    @MainActor
    func testDeleteStatistics_ShouldRemoveData() async throws {
        // Given
        let tripId = UUID()
        
        // When
        try await sut.deleteStatistics(for: tripId)
        
        // Then
        XCTAssertTrue(mockPersistenceController.deleteWasCalled)
    }
    
    // MARK: - Export Tests
    
    @MainActor
    func testExportStatistics_JSON_ShouldReturnData() async throws {
        // Given
        let participantId = UUID()
        mockPersistenceController.shouldReturnMockData = true
        
        // When
        let data = try await sut.exportStatistics(for: participantId, format: .json)
        
        // Then
        XCTAssertFalse(data.isEmpty)
        
        // Verify it's valid JSON
        let json = try JSONSerialization.jsonObject(with: data)
        XCTAssertNotNil(json)
    }
    
    @MainActor
    func testExportStatistics_CSV_ShouldReturnData() async throws {
        // Given
        let participantId = UUID()
        mockPersistenceController.shouldReturnMockData = true
        
        // When
        let data = try await sut.exportStatistics(for: participantId, format: .csv)
        
        // Then
        XCTAssertFalse(data.isEmpty)
        
        // Verify it's valid CSV format
        let csvString = String(data: data, encoding: .utf8)
        XCTAssertNotNil(csvString)
        XCTAssertTrue(csvString?.contains("Trip ID,Date,Distance") == true)
    }
    
    @MainActor
    func testExportStatistics_PDF_ShouldThrowError() async {
        // Given
        let participantId = UUID()
        
        // When/Then
        do {
            _ = try await sut.exportStatistics(for: participantId, format: .pdf)
            XCTFail("Should have thrown error for PDF export")
        } catch {
            XCTAssertTrue(error is DrivingStatisticsServiceError)
        }
    }
}

// MARK: - Mock Classes

class MockLocationManager: LocationServiceProtocol {
    @Published var currentLocation: CLLocation?
    @Published var authorizationStatus: CLAuthorizationStatus = .authorizedWhenInUse
    @Published var isLocationSharingEnabled: Bool = false
    
    private let locationSubject = PassthroughSubject<CLLocation, Never>()
    private let authorizationSubject = PassthroughSubject<CLAuthorizationStatus, Never>()
    
    var locationUpdates: AnyPublisher<CLLocation, Never> {
        locationSubject.eraseToAnyPublisher()
    }
    
    var authorizationUpdates: AnyPublisher<CLAuthorizationStatus, Never> {
        authorizationSubject.eraseToAnyPublisher()
    }
    
    func requestLocationPermission() async throws {
        // Mock implementation
    }
    
    func startLocationSharing() async throws {
        isLocationSharingEnabled = true
    }
    
    func stopLocationSharing() {
        isLocationSharingEnabled = false
    }
    
    func getCurrentLocation() async throws -> CLLocation {
        return CLLocation(latitude: 37.7749, longitude: -122.4194)
    }
    
    func startMonitoringSignificantLocationChanges() {
        // Mock implementation
    }
    
    func stopMonitoringSignificantLocationChanges() {
        // Mock implementation
    }
    
    func calculateDistance(from: CLLocation, to: CLLocation) -> CLLocationDistance {
        return from.distance(from: to)
    }
    
    func calculateDrivingDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) async throws -> CLLocationDistance {
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        return calculateDistance(from: fromLocation, to: toLocation)
    }
    
    func isLocationStale(_ location: CLLocation, threshold: TimeInterval) -> Bool {
        return location.timestamp.timeIntervalSinceNow < -threshold
    }
    
    // Helper methods for testing
    func simulateLocationUpdate(_ location: CLLocation) {
        currentLocation = location
        locationSubject.send(location)
    }
    
    func simulateAuthorizationChange(_ status: CLAuthorizationStatus) {
        authorizationStatus = status
        authorizationSubject.send(status)
    }
}

class MockPersistenceController: PersistenceController {
    var shouldReturnMockData = false
    var saveWasCalled = false
    var deleteWasCalled = false
    
    override init() {
        super.init()
    }
    
    // Override save behavior for testing
    func mockSave() throws {
        saveWasCalled = true
    }
    
    func mockDelete() {
        deleteWasCalled = true
    }
}

// MARK: - Test Extensions

extension DrivingStatisticsService {
    func setValue(_ value: Any?, forKey key: String) {
        // Helper method to set private properties for testing
        // In a real implementation, you might use reflection or make properties internal
    }
}