import XCTest
import Combine
import CoreLocation
import UserNotifications
@testable import RoadTripTracker

class NotificationManagerTests: XCTestCase {
    
    var notificationManager: NotificationManager!
    var mockNotificationService: MockNotificationService!
    var mockLocationManager: MockLocationManager!
    var cancellables: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        mockNotificationService = MockNotificationService()
        mockLocationManager = MockLocationManager()
        notificationManager = NotificationManager(
            notificationService: mockNotificationService,
            locationManager: mockLocationManager
        )
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDownWithError() throws {
        notificationManager = nil
        mockNotificationService = nil
        mockLocationManager = nil
        cancellables = nil
    }
    
    // MARK: - Participant Notification Tests
    
    func testNotifyParticipantJoined() async {
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: [participant]
        )
        
        await notificationManager.notifyParticipantJoined(participant, in: trip)
        
        XCTAssertTrue(mockNotificationService.pushNotificationSent)
        XCTAssertEqual(notificationManager.notificationHistory.notifications.count, 1)
        
        let notification = notificationManager.notificationHistory.notifications.first!
        XCTAssertEqual(notification.type, .participantJoined)
        XCTAssertEqual(notification.tripId, trip.id)
        XCTAssertFalse(notification.isRead)
    }
    
    func testNotifyParticipantLeft() async {
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: []
        )
        
        await notificationManager.notifyParticipantLeft(participant, from: trip)
        
        XCTAssertTrue(mockNotificationService.pushNotificationSent)
        XCTAssertEqual(notificationManager.notificationHistory.notifications.count, 1)
        
        let notification = notificationManager.notificationHistory.notifications.first!
        XCTAssertEqual(notification.type, .participantLeft)
        XCTAssertEqual(notification.tripId, trip.id)
    }
    
    // MARK: - Location Notification Tests
    
    func testNotifyApproachingDestination() async {
        let destination = Destination(
            name: "Test Destination",
            address: "123 Test St",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: [participant],
            destinations: [destination]
        )
        
        let distance: CLLocationDistance = 1500.0
        
        await notificationManager.notifyApproachingDestination(
            destination,
            participant: participant,
            trip: trip,
            distance: distance
        )
        
        XCTAssertTrue(mockNotificationService.pushNotificationSent)
        XCTAssertEqual(notificationManager.notificationHistory.notifications.count, 1)
        
        let notification = notificationManager.notificationHistory.notifications.first!
        XCTAssertEqual(notification.type, .approachingDestination)
        XCTAssertEqual(notification.priority, .high)
        XCTAssertTrue(notification.message.contains("1.5 km"))
    }
    
    func testNotifyApproachingDestinationMeters() async {
        let destination = Destination(
            name: "Test Destination",
            address: "123 Test St",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: [participant],
            destinations: [destination]
        )
        
        let distance: CLLocationDistance = 500.0
        
        await notificationManager.notifyApproachingDestination(
            destination,
            participant: participant,
            trip: trip,
            distance: distance
        )
        
        let notification = notificationManager.notificationHistory.notifications.first!
        XCTAssertTrue(notification.message.contains("500 meters"))
    }
    
    // MARK: - Emergency Notification Tests
    
    func testNotifyEmergency() async {
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: [participant]
        )
        
        let location = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        let emergency = EmergencyNotification(
            tripId: trip.id,
            participantId: participant.id,
            type: .accident,
            message: "Car accident, need help!",
            location: location
        )
        
        await notificationManager.notifyEmergency(emergency, participant: participant, trip: trip)
        
        XCTAssertTrue(mockNotificationService.pushNotificationSent)
        XCTAssertEqual(notificationManager.notificationHistory.notifications.count, 1)
        XCTAssertEqual(notificationManager.notificationHistory.emergencyNotifications.count, 1)
        XCTAssertTrue(notificationManager.hasEmergencyAlert)
        
        let notification = notificationManager.notificationHistory.notifications.first!
        XCTAssertEqual(notification.type, .emergencyAlert)
        XCTAssertEqual(notification.priority, .emergency)
        XCTAssertTrue(notification.title.contains("🚨"))
    }
    
    // MARK: - Trip Status Notification Tests
    
    func testNotifyTripStarted() async {
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            status: .active
        )
        
        await notificationManager.notifyTripStarted(trip)
        
        XCTAssertTrue(mockNotificationService.pushNotificationSent)
        XCTAssertEqual(notificationManager.notificationHistory.notifications.count, 1)
        
        let notification = notificationManager.notificationHistory.notifications.first!
        XCTAssertEqual(notification.type, .tripStarted)
        XCTAssertTrue(notification.message.contains("has begun"))
    }
    
    func testNotifyTripCompleted() async {
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            status: .completed
        )
        
        await notificationManager.notifyTripCompleted(trip)
        
        XCTAssertTrue(mockNotificationService.pushNotificationSent)
        XCTAssertEqual(notificationManager.notificationHistory.notifications.count, 1)
        
        let notification = notificationManager.notificationHistory.notifications.first!
        XCTAssertEqual(notification.type, .tripCompleted)
        XCTAssertTrue(notification.message.contains("completed"))
    }
    
    // MARK: - Budget Notification Tests
    
    func testNotifyBudgetAlert() async {
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID()
        )
        
        let budgetAlert = BudgetAlert(
            type: .approaching,
            message: "Budget limit approaching",
            threshold: 1000.0,
            currentAmount: 800.0,
            category: .fuel
        )
        
        await notificationManager.notifyBudgetAlert(budgetAlert, trip: trip)
        
        XCTAssertTrue(mockNotificationService.localNotificationScheduled)
        XCTAssertEqual(notificationManager.notificationHistory.notifications.count, 1)
        
        let notification = notificationManager.notificationHistory.notifications.first!
        XCTAssertEqual(notification.type, .budgetAlert)
        XCTAssertEqual(notification.priority, .low)
        XCTAssertTrue(notification.message.contains("80%"))
    }
    
    // MARK: - Weather Notification Tests
    
    func testNotifyWeatherAlert() async {
        let weatherAlert = WeatherAlert(
            title: "Severe Weather Warning",
            description: "Heavy rain and strong winds expected",
            severity: .severe,
            startTime: Date(),
            endTime: Date().addingTimeInterval(3600),
            affectedAreas: ["Test City"]
        )
        
        await notificationManager.notifyWeatherAlert(weatherAlert, location: "Test City")
        
        XCTAssertTrue(mockNotificationService.localNotificationScheduled)
        XCTAssertEqual(notificationManager.notificationHistory.notifications.count, 1)
        
        let notification = notificationManager.notificationHistory.notifications.first!
        XCTAssertEqual(notification.type, .weatherAlert)
        XCTAssertEqual(notification.priority, .high)
        XCTAssertTrue(notification.title.contains("⚠️"))
    }
    
    // MARK: - Check-in Reminder Tests
    
    func testScheduleCheckInReminder() async {
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            participants: [participant]
        )
        
        await notificationManager.scheduleCheckInReminder(
            for: participant,
            trip: trip,
            after: 3600 // 1 hour
        )
        
        XCTAssertTrue(mockNotificationService.localNotificationScheduled)
        XCTAssertEqual(mockNotificationService.lastNotificationIdentifier, "checkin_reminder_\(participant.id.uuidString)")
    }
    
    func testCancelCheckInReminder() async {
        let user = User(
            username: "testuser",
            email: "test@example.com",
            city: "Test City",
            dateOfBirth: Date()
        )
        
        let participant = Participant(
            userId: user.id,
            user: user
        )
        
        await notificationManager.cancelCheckInReminder(for: participant)
        
        // Mock service doesn't track cancellations, but method should not throw
    }
    
    // MARK: - Destination Alert Setup Tests
    
    func testSetupDestinationAlerts() async {
        let destination1 = Destination(
            name: "Destination 1",
            address: "123 Test St",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        
        let destination2 = Destination(
            name: "Destination 2",
            address: "456 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094)
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            destinations: [destination1, destination2]
        )
        
        await notificationManager.setupDestinationAlerts(for: trip)
        
        XCTAssertTrue(mockNotificationService.localNotificationScheduled)
        // Should schedule 3 alerts per destination (approaching, nearby, arrived) = 6 total
    }
    
    // MARK: - Notification History Tests
    
    func testMarkNotificationAsRead() {
        let notification = TripNotification(
            tripId: UUID(),
            type: .participantJoined,
            title: "Test",
            message: "Test message"
        )
        
        notificationManager.notificationHistory.addNotification(notification)
        XCTAssertEqual(notificationManager.unreadCount, 1)
        
        notificationManager.markNotificationAsRead(notification.id)
        XCTAssertEqual(notificationManager.unreadCount, 0)
    }
    
    func testClearEmergencyAlert() {
        notificationManager.hasEmergencyAlert = true
        XCTAssertTrue(notificationManager.hasEmergencyAlert)
        
        notificationManager.clearEmergencyAlert()
        XCTAssertFalse(notificationManager.hasEmergencyAlert)
    }
    
    // MARK: - Notification Preferences Tests
    
    func testUpdateNotificationPreferences() async {
        var preferences = NotificationPreferences()
        preferences.tripEvents = false
        preferences.weatherAlerts = false
        
        await notificationManager.updateNotificationPreferences(preferences)
        
        // Mock service doesn't actually store preferences, but method should not throw
    }
    
    func testGetNotificationPreferences() {
        let preferences = notificationManager.getNotificationPreferences()
        
        XCTAssertNotNil(preferences)
        XCTAssertTrue(preferences.emergencyAlerts) // Should default to true
    }
    
    // MARK: - Permission Tests
    
    func testRequestNotificationPermission() async {
        let granted = await notificationManager.requestNotificationPermission()
        
        XCTAssertTrue(granted) // Mock service always returns true
    }
    
    func testNotificationPermissionStatusPublisher() {
        let expectation = XCTestExpectation(description: "Permission status received")
        
        notificationManager.notificationPermissionStatus
            .sink { status in
                XCTAssertEqual(status, .authorized)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        wait(for: [expectation], timeout: 1.0)
    }
}

// MARK: - Mock Location Manager for Testing

class MockLocationManager: LocationManager {
    private let locationSubject = PassthroughSubject<CLLocation, Never>()
    
    override var locationUpdates: AnyPublisher<CLLocation, Never> {
        locationSubject.eraseToAnyPublisher()
    }
    
    func simulateLocationUpdate(_ location: CLLocation) {
        locationSubject.send(location)
    }
}