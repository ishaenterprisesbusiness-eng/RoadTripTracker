import XCTest
import CoreLocation
import CloudKit
@testable import RoadTripTracker

// MARK: - Test Helper Extensions

extension LocationManager {
    /// Test helper to process location updates directly
    func processLocationUpdate(_ location: CLLocation) {
        // Simulate location update processing
        self.currentLocation = location
        self.onLocationUpdate?(location)
    }
    
    /// Test helper to simulate sync to cloud
    func syncLocationToCloud(_ location: CLLocation, for tripId: UUID, completion: @escaping (Bool) -> Void) {
        // Simulate cloud sync with delay
        DispatchQueue.global().asyncAfter(deadline: .now() + 0.1) {
            completion(true)
        }
    }
}

extension TripService {
    /// Test helper to process trip data
    func processTrip(_ trip: Trip) {
        // Simulate trip processing
        print("Processing trip: \(trip.name ?? "Unknown")")
    }
}

extension ChatService {
    /// Test helper to process messages
    func processMessage(_ message: Message) {
        // Simulate message processing
        print("Processing message: \(message.content ?? "Empty")")
    }
    
    /// Test helper to clean up old messages
    func cleanupOldMessages(olderThan date: Date) {
        // Simulate cleanup
        print("Cleaning up messages older than \(date)")
    }
}

extension WeatherService {
    /// Test property to simulate network failures
    var simulateNetworkFailure: Bool {
        get { return UserDefaults.standard.bool(forKey: "simulateNetworkFailure") }
        set { UserDefaults.standard.set(newValue, forKey: "simulateNetworkFailure") }
    }
}

extension MapService {
    /// Test helper to add annotations
    func addAnnotations(_ annotations: [MKPointAnnotation]) {
        // Simulate adding annotations
        print("Adding \(annotations.count) annotations to map")
    }
    
    /// Test helper to remove all annotations
    func removeAllAnnotations() {
        // Simulate removing annotations
        print("Removing all annotations from map")
    }
    
    /// Test helper to update map region
    func updateMapRegion(_ region: MKCoordinateRegion) {
        // Simulate map region update
        print("Updating map region to center: \(region.center)")
    }
}

extension OfflineManager {
    /// Test helper to simulate network status changes
    func setNetworkStatus(isConnected: Bool) {
        self.isNetworkConnected = isConnected
        self.onNetworkStateChange?(isConnected)
        
        if isConnected {
            self.onSyncTriggered?()
        }
    }
    
    /// Test helper to simulate remote expense
    func simulateRemoteExpense(_ expense: OfflineExpense, for tripId: String) {
        // Simulate remote expense for conflict resolution testing
        print("Simulating remote expense: \(expense.description)")
    }
    
    /// Test helper to simulate partial sync failure
    func simulatePartialSyncFailure(failMessages: Bool, failExpenses: Bool) {
        self.shouldFailMessageSync = failMessages
        self.shouldFailExpenseSync = failExpenses
    }
    
    /// Test helper to get synced locations
    func getSyncedLocations(for tripId: String) -> [CLLocation] {
        // Return mock synced locations
        return []
    }
    
    /// Test helper to get synced expenses
    func getSyncedExpenses(for tripId: String) -> [OfflineExpense] {
        // Return mock synced expenses
        return []
    }
}

// MARK: - Test Data Factories

struct TestDataFactory {
    
    static func createTestTrip(withDestinations count: Int = 3) -> Trip {
        let trip = Trip()
        trip.id = UUID()
        trip.name = "Test Trip"
        trip.code = "TEST\(Int.random(in: 100...999))"
        trip.createdAt = Date()
        
        var destinations: [Destination] = []
        for i in 0..<count {
            let destination = Destination()
            destination.id = UUID()
            destination.name = "Destination \(i + 1)"
            destination.coordinate = CLLocationCoordinate2D(
                latitude: -33.8688 + Double(i) * 0.1,
                longitude: 151.2093 + Double(i) * 0.1
            )
            destinations.append(destination)
        }
        trip.destinations = destinations
        
        return trip
    }
    
    static func createTestUser() -> User {
        let user = User()
        user.id = UUID()
        user.username = "testuser"
        user.email = "test@example.com"
        user.city = "Sydney"
        user.dateOfBirth = Calendar.current.date(byAdding: .year, value: -25, to: Date())!
        user.age = 25
        
        let vehicle = Vehicle()
        vehicle.make = "Toyota"
        vehicle.model = "Camry"
        vehicle.vehicleNumber = "ABC123"
        vehicle.odometerReading = 50000
        vehicle.type = .sedan
        user.vehicle = vehicle
        
        return user
    }
    
    static func createTestMessage(for tripId: UUID) -> Message {
        let message = Message()
        message.id = UUID()
        message.tripId = tripId
        message.senderId = UUID()
        message.content = "Test message content"
        message.timestamp = Date()
        message.type = .text
        return message
    }
    
    static func createTestLocations(count: Int, startingFrom coordinate: CLLocationCoordinate2D) -> [CLLocation] {
        var locations: [CLLocation] = []
        
        for i in 0..<count {
            let location = CLLocation(
                coordinate: CLLocationCoordinate2D(
                    latitude: coordinate.latitude + Double(i) * 0.001,
                    longitude: coordinate.longitude + Double(i) * 0.001
                ),
                altitude: 10,
                horizontalAccuracy: 5,
                verticalAccuracy: 5,
                timestamp: Date().addingTimeInterval(Double(i) * 30)
            )
            locations.append(location)
        }
        
        return locations
    }
}

// MARK: - Test Assertions

extension XCTestCase {
    
    /// Assert that two coordinates are approximately equal
    func assertCoordinatesEqual(
        _ coordinate1: CLLocationCoordinate2D,
        _ coordinate2: CLLocationCoordinate2D,
        accuracy: Double = 0.0001,
        file: StaticString = #filePath,
        line: UInt = #line
    ) {
        XCTAssertEqual(coordinate1.latitude, coordinate2.latitude, accuracy: accuracy, file: file, line: line)
        XCTAssertEqual(coordinate1.longitude, coordinate2.longitude, accuracy: accuracy, file: file, line: line)
    }
    
    /// Assert that a location is within a certain distance of another location
    func assertLocationWithinDistance(
        _ location1: CLLocation,
        _ location2: CLLocation,
        maxDistance: CLLocationDistance,
        file: StaticString = #filePath,
        line: UInt = #line
    ) {
        let distance = location1.distance(from: location2)
        XCTAssertLessThanOrEqual(distance, maxDistance, "Locations should be within \(maxDistance) meters", file: file, line: line)
    }
    
    /// Assert that an async operation completes within a timeout
    func assertAsyncCompletion<T>(
        timeout: TimeInterval = 5.0,
        operation: @escaping () async throws -> T,
        file: StaticString = #filePath,
        line: UInt = #line
    ) async throws -> T {
        return try await withTimeout(timeout) {
            try await operation()
        }
    }
    
    private func withTimeout<T>(_ timeout: TimeInterval, operation: @escaping () async throws -> T) async throws -> T {
        return try await withThrowingTaskGroup(of: T.self) { group in
            group.addTask {
                try await operation()
            }
            
            group.addTask {
                try await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                throw TimeoutError()
            }
            
            guard let result = try await group.next() else {
                throw TimeoutError()
            }
            
            group.cancelAll()
            return result
        }
    }
}

// MARK: - Custom Errors

struct TimeoutError: Error, LocalizedError {
    var errorDescription: String? {
        return "Operation timed out"
    }
}

enum IntegrationTestError: Error, LocalizedError {
    case setupFailed(String)
    case testDataCreationFailed
    case mockServiceUnavailable
    case unexpectedTestResult(String)
    
    var errorDescription: String? {
        switch self {
        case .setupFailed(let message):
            return "Test setup failed: \(message)"
        case .testDataCreationFailed:
            return "Failed to create test data"
        case .mockServiceUnavailable:
            return "Mock service is unavailable"
        case .unexpectedTestResult(let message):
            return "Unexpected test result: \(message)"
        }
    }
}

// MARK: - Mock Service Extensions

extension OfflineManager {
    var isNetworkConnected: Bool {
        get { return UserDefaults.standard.bool(forKey: "isNetworkConnected") }
        set { UserDefaults.standard.set(newValue, forKey: "isNetworkConnected") }
    }
    
    var shouldFailMessageSync: Bool {
        get { return UserDefaults.standard.bool(forKey: "shouldFailMessageSync") }
        set { UserDefaults.standard.set(newValue, forKey: "shouldFailMessageSync") }
    }
    
    var shouldFailExpenseSync: Bool {
        get { return UserDefaults.standard.bool(forKey: "shouldFailExpenseSync") }
        set { UserDefaults.standard.set(newValue, forKey: "shouldFailExpenseSync") }
    }
    
    var onNetworkStateChange: ((Bool) -> Void)?
    var onSyncTriggered: (() -> Void)?
}