import XCTest
import CoreData
@testable import RoadTripTracker

@MainActor
final class TripJoiningIntegrationTests: XCTestCase {
    var persistenceController: PersistenceController!
    var tripService: TripService!
    var placesService: PlacesService!
    
    override func setUp() {
        super.setUp()
        
        // Create in-memory Core Data stack for testing
        persistenceController = PersistenceController(inMemory: true)
        placesService = PlacesService()
        tripService = TripService(
            persistenceController: persistenceController,
            placesService: placesService
        )
    }
    
    override func tearDown() {
        tripService = nil
        placesService = nil
        persistenceController = nil
        super.tearDown()
    }
    
    func testTripCodeGenerationAndValidation() async throws {
        // Test trip code generation
        let tripCode1 = tripService.generateTripCode()
        let tripCode2 = tripService.generateTripCode()
        
        // Trip codes should be 6 characters long
        XCTAssertEqual(tripCode1.count, 6)
        XCTAssertEqual(tripCode2.count, 6)
        
        // Trip codes should be different (very high probability)
        XCTAssertNotEqual(tripCode1, tripCode2)
        
        // Trip codes should only contain valid characters
        let validCharacters = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
        XCTAssertTrue(tripCode1.unicodeScalars.allSatisfy { validCharacters.contains($0) })
        XCTAssertTrue(tripCode2.unicodeScalars.allSatisfy { validCharacters.contains($0) })
    }
    
    func testCreateTripAndJoin() async throws {
        // Given - Create a trip
        let destinations = [
            Destination(
                name: "Sydney",
                address: "Sydney, NSW, Australia",
                coordinate: CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)
            ),
            Destination(
                name: "Melbourne",
                address: "Melbourne, VIC, Australia",
                coordinate: CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631)
            )
        ]
        
        let settings = TripSettings()
        
        // When - Create trip
        let createdTrip = try await tripService.createTrip(
            name: "Sydney to Melbourne",
            destinations: destinations,
            settings: settings
        )
        
        // Then - Trip should be created with valid code
        XCTAssertEqual(createdTrip.name, "Sydney to Melbourne")
        XCTAssertEqual(createdTrip.code.count, 6)
        XCTAssertEqual(createdTrip.destinations.count, 2)
        XCTAssertEqual(createdTrip.status, .planning)
        
        // Validate the trip code exists
        let isValidCode = try await tripService.validateTripCode(createdTrip.code)
        XCTAssertTrue(isValidCode)
        
        // Test joining the trip with the code
        let joinedTrip = try await tripService.joinTrip(code: createdTrip.code)
        XCTAssertEqual(joinedTrip.id, createdTrip.id)
        XCTAssertEqual(joinedTrip.code, createdTrip.code)
    }
    
    func testJoinTripWithInvalidCode() async {
        // Given - Invalid trip code
        let invalidCode = "INVALID"
        
        // When/Then - Should throw invalid trip code error
        do {
            _ = try await tripService.joinTrip(code: invalidCode)
            XCTFail("Should have thrown invalidTripCode error")
        } catch TripServiceError.invalidTripCode {
            // Expected error
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    func testValidateTripCodeWithNonExistentCode() async throws {
        // Given - Non-existent trip code
        let nonExistentCode = "NOEXIST"
        
        // When
        let isValid = try await tripService.validateTripCode(nonExistentCode)
        
        // Then
        XCTAssertFalse(isValid)
    }
    
    func testTripParticipantManagement() async throws {
        // Given - Create a trip
        let destinations = [
            Destination(
                name: "Brisbane",
                address: "Brisbane, QLD, Australia",
                coordinate: CLLocationCoordinate2D(latitude: -27.4698, longitude: 153.0251)
            )
        ]
        
        let settings = TripSettings()
        let trip = try await tripService.createTrip(
            name: "Brisbane Trip",
            destinations: destinations,
            settings: settings
        )
        
        // When - Join trip (this would normally add current user as participant)
        let joinedTrip = try await tripService.joinTrip(code: trip.code)
        
        // Then - Trip should have the participant
        // Note: In the current implementation, participant addition is simplified
        // In a full implementation, this would add the current authenticated user
        XCTAssertEqual(joinedTrip.id, trip.id)
        
        // Test leaving trip
        try await tripService.leaveTrip(trip.id)
        
        // Verify trip is no longer active
        XCTAssertNil(tripService.activeTrip)
    }
}

// MARK: - PersistenceController Extension for Testing
extension PersistenceController {
    convenience init(inMemory: Bool) {
        self.init()
        
        if inMemory {
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }
        
        container.loadPersistentStores { _, error in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }
        
        container.viewContext.automaticallyMergesChangesFromParent = true
    }
}