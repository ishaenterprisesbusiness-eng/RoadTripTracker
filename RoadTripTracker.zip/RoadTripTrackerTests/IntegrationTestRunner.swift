import XCTest
@testable import RoadTripTracker

/// Integration Test Runner
/// This class orchestrates all integration tests and provides a comprehensive test suite
class IntegrationTestRunner: XCTestCase {
    
    static var allTests = [
        ("testCloudKitIntegration", testCloudKitIntegration),
        ("testLocationIntegration", testLocationIntegration),
        ("testExternalAPIIntegration", testExternalAPIIntegration),
        ("testOfflineOnlineSync", testOfflineOnlineSync),
        ("testPerformanceIntegration", testPerformanceIntegration),
    ]
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        // Global test setup
        continueAfterFailure = false
    }
    
    override func tearDownWithError() throws {
        // Global test cleanup
        try super.tearDownWithError()
    }
    
    // MARK: - Integration Test Orchestration
    
    func testCloudKitIntegration() throws {
        let cloudKitTests = CloudKitIntegrationTests()
        
        // Run CloudKit integration tests
        try cloudKitTests.setUpWithError()
        
        // Execute key CloudKit tests
        let testMethods = [
            cloudKitTests.testTripSynchronization,
            cloudKitTests.testConflictResolution,
            cloudKitTests.testRealTimeSynchronization,
            cloudKitTests.testDataConsistencyAcrossDevices
        ]
        
        for testMethod in testMethods {
            do {
                try testMethod()
                print("✅ CloudKit test passed")
            } catch {
                XCTFail("CloudKit integration test failed: \(error)")
            }
        }
        
        try cloudKitTests.tearDownWithError()
    }
    
    func testLocationIntegration() throws {
        let locationTests = LocationIntegrationTests()
        
        try locationTests.setUpWithError()
        
        // Execute location integration tests
        let testMethods = [
            locationTests.testLocationPermissionFlow,
            locationTests.testGPSAccuracy,
            locationTests.testLocationUpdateFrequency,
            locationTests.testBackgroundLocationTracking,
            locationTests.testGeofencingFunctionality
        ]
        
        for testMethod in testMethods {
            do {
                try testMethod()
                print("✅ Location test passed")
            } catch {
                XCTFail("Location integration test failed: \(error)")
            }
        }
        
        try locationTests.tearDownWithError()
    }
    
    func testExternalAPIIntegration() throws {
        let apiTests = ExternalAPIIntegrationTests()
        
        try apiTests.setUpWithError()
        
        // Execute external API tests
        let testMethods = [
            apiTests.testWeatherAPIConnection,
            apiTests.testWeatherForecast,
            apiTests.testPlacesAPISearch,
            apiTests.testRouteCalculation,
            apiTests.testMultiDestinationRoute
        ]
        
        for testMethod in testMethods {
            do {
                try testMethod()
                print("✅ External API test passed")
            } catch {
                XCTFail("External API integration test failed: \(error)")
            }
        }
        
        try apiTests.tearDownWithError()
    }
    
    func testOfflineOnlineSync() throws {
        let syncTests = OfflineOnlineSyncTests()
        
        try syncTests.setUpWithError()
        
        // Execute offline/online sync tests
        let testMethods = [
            syncTests.testOfflineLocationCaching,
            syncTests.testOfflineMessageQueuing,
            syncTests.testLocationSyncWhenOnline,
            syncTests.testMessageSyncWhenOnline,
            syncTests.testConflictResolutionDuringSync,
            syncTests.testNetworkStateDetection
        ]
        
        for testMethod in testMethods {
            do {
                try testMethod()
                print("✅ Offline/Online sync test passed")
            } catch {
                XCTFail("Offline/Online sync test failed: \(error)")
            }
        }
        
        try syncTests.tearDownWithError()
    }
    
    func testPerformanceIntegration() throws {
        let performanceTests = PerformanceIntegrationTests()
        
        try performanceTests.setUpWithError()
        
        // Execute performance tests
        let testMethods = [
            performanceTests.testLocationTrackingBatteryUsage,
            performanceTests.testLargeDatasetMemoryUsage,
            performanceTests.testRealTimeSyncPerformance,
            performanceTests.testCoreDataPerformance,
            performanceTests.testMapRenderingPerformance
        ]
        
        for testMethod in testMethods {
            do {
                try testMethod()
                print("✅ Performance test passed")
            } catch {
                XCTFail("Performance integration test failed: \(error)")
            }
        }
        
        try performanceTests.tearDownWithError()
    }
    
    // MARK: - Comprehensive Integration Test
    
    func testFullIntegrationScenario() async throws {
        // This test runs a complete end-to-end scenario
        let expectation = XCTestExpectation(description: "Full integration scenario")
        
        // 1. Set up services
        let locationManager = LocationManager()
        let tripService = TripService()
        let chatService = ChatService()
        let offlineManager = OfflineManager(persistenceController: PersistenceController(inMemory: true))
        
        // 2. Create a trip
        let trip = Trip()
        trip.id = UUID()
        trip.name = "Integration Test Trip"
        trip.code = "INT001"
        trip.createdAt = Date()
        
        // 3. Add destinations
        let destinations = [
            Destination(name: "Start", coordinate: CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)),
            Destination(name: "Middle", coordinate: CLLocationCoordinate2D(latitude: -35.2809, longitude: 149.1300)),
            Destination(name: "End", coordinate: CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631))
        ]
        trip.destinations = destinations
        
        // 4. Start location tracking
        locationManager.startLocationTracking(accuracy: .high)
        
        // 5. Simulate trip progression
        for (index, destination) in destinations.enumerated() {
            // Simulate moving towards destination
            let location = CLLocation(coordinate: destination.coordinate)
            locationManager.processLocationUpdate(location)
            
            // Send chat message
            let message = "Arrived at \(destination.name)"
            try await chatService.sendMessage(message, to: trip)
            
            // Log expense
            let expense = OfflineExpense(
                amount: Double.random(in: 20...100),
                category: .fuel,
                description: "Stop at \(destination.name)",
                timestamp: Date()
            )
            offlineManager.logExpense(expense, for: trip.id!.uuidString)
            
            print("✅ Completed destination \(index + 1)/\(destinations.count)")
        }
        
        // 6. Test offline/online sync
        offlineManager.setNetworkStatus(isConnected: false)
        // Add some offline data
        offlineManager.cacheLocation(CLLocation(latitude: -37.8136, longitude: 144.9631), for: trip.id!.uuidString)
        
        offlineManager.setNetworkStatus(isConnected: true)
        offlineManager.syncCachedData { result in
            switch result {
            case .success:
                print("✅ Offline data synced successfully")
            case .failure(let error):
                XCTFail("Sync failed: \(error)")
            }
            expectation.fulfill()
        }
        
        await fulfillment(of: [expectation], timeout: 30.0)
        
        // 7. Clean up
        locationManager.stopLocationTracking()
        
        print("✅ Full integration scenario completed successfully")
    }
}