import XCTest
@testable import RoadTripTracker

final class EmailVerificationServiceTests: XCTestCase {
    var emailVerificationService: EmailVerificationService!
    var mockNetworkService: MockNetworkService!
    
    override func setUpWithError() throws {
        mockNetworkService = MockNetworkService()
        emailVerificationService = EmailVerificationService(networkService: mockNetworkService)
    }
    
    override func tearDownWithError() throws {
        emailVerificationService = nil
        mockNetworkService = nil
    }
    
    // MARK: - Send Verification Email Tests
    
    func testSendVerificationEmail_ValidEmail_Success() async throws {
        // Given
        let email = "test@example.com"
        mockNetworkService.shouldSucceed = true
        
        // When
        try await emailVerificationService.sendVerificationEmail(to: email)
        
        // Then
        XCTAssertTrue(mockNetworkService.sendVerificationEmailCalled)
        XCTAssertEqual(mockNetworkService.lastEmailSent, email)
    }
    
    func testSendVerificationEmail_InvalidEmail_ThrowsError() async {
        // Given
        let invalidEmail = "invalid-email"
        
        // When/Then
        do {
            try await emailVerificationService.sendVerificationEmail(to: invalidEmail)
            XCTFail("Expected error to be thrown")
        } catch {
            XCTAssertTrue(error is AppError)
            if case AppError.invalidEmailFormat = error {
                // Expected error
            } else {
                XCTFail("Unexpected error type: \(error)")
            }
        }
    }
    
    func testSendVerificationEmail_NetworkError_ThrowsError() async {
        // Given
        let email = "test@example.com"
        mockNetworkService.shouldSucceed = false
        mockNetworkService.errorToThrow = AppError.networkUnavailable
        
        // When/Then
        do {
            try await emailVerificationService.sendVerificationEmail(to: email)
            XCTFail("Expected error to be thrown")
        } catch {
            XCTAssertTrue(error is AppError)
            if case AppError.networkUnavailable = error {
                // Expected error
            } else {
                XCTFail("Unexpected error type: \(error)")
            }
        }
    }
    
    // MARK: - Verify Email Tests
    
    func testVerifyEmail_ValidToken_Success() async throws {
        // Given
        let token = "valid-token-123"
        mockNetworkService.shouldSucceed = true
        
        // When
        let result = try await emailVerificationService.verifyEmail(token: token)
        
        // Then
        XCTAssertTrue(result)
        XCTAssertTrue(mockNetworkService.verifyEmailCalled)
        XCTAssertEqual(mockNetworkService.lastTokenVerified, token)
    }
    
    func testVerifyEmail_InvalidToken_ReturnsFalse() async throws {
        // Given
        let invalidToken = "invalid-token"
        mockNetworkService.shouldSucceed = false
        mockNetworkService.verificationResult = false
        
        // When
        let result = try await emailVerificationService.verifyEmail(token: invalidToken)
        
        // Then
        XCTAssertFalse(result)
        XCTAssertTrue(mockNetworkService.verifyEmailCalled)
    }
    
    func testVerifyEmail_ExpiredToken_ThrowsError() async {
        // Given
        let expiredToken = "expired-token"
        mockNetworkService.shouldSucceed = false
        mockNetworkService.errorToThrow = AppError.verificationTokenExpired
        
        // When/Then
        do {
            _ = try await emailVerificationService.verifyEmail(token: expiredToken)
            XCTFail("Expected error to be thrown")
        } catch {
            XCTAssertTrue(error is AppError)
            if case AppError.verificationTokenExpired = error {
                // Expected error
            } else {
                XCTFail("Unexpected error type: \(error)")
            }
        }
    }
    
    // MARK: - Resend Verification Tests
    
    func testResendVerificationEmail_ValidEmail_Success() async throws {
        // Given
        let email = "test@example.com"
        mockNetworkService.shouldSucceed = true
        
        // When
        try await emailVerificationService.resendVerificationEmail(to: email)
        
        // Then
        XCTAssertTrue(mockNetworkService.resendVerificationEmailCalled)
        XCTAssertEqual(mockNetworkService.lastEmailResent, email)
    }
    
    func testResendVerificationEmail_TooManyRequests_ThrowsError() async {
        // Given
        let email = "test@example.com"
        mockNetworkService.shouldSucceed = false
        mockNetworkService.errorToThrow = AppError.tooManyVerificationRequests
        
        // When/Then
        do {
            try await emailVerificationService.resendVerificationEmail(to: email)
            XCTFail("Expected error to be thrown")
        } catch {
            XCTAssertTrue(error is AppError)
            if case AppError.tooManyVerificationRequests = error {
                // Expected error
            } else {
                XCTFail("Unexpected error type: \(error)")
            }
        }
    }
    
    // MARK: - Email Validation Tests
    
    func testIsValidEmail_ValidEmails_ReturnsTrue() {
        // Given
        let validEmails = [
            "test@example.com",
            "user.name@domain.co.uk",
            "user+tag@example.org",
            "123@example.com"
        ]
        
        // When/Then
        for email in validEmails {
            XCTAssertTrue(emailVerificationService.isValidEmail(email), "Email \(email) should be valid")
        }
    }
    
    func testIsValidEmail_InvalidEmails_ReturnsFalse() {
        // Given
        let invalidEmails = [
            "invalid-email",
            "@example.com",
            "test@",
            "test..test@example.com",
            "test@example",
            ""
        ]
        
        // When/Then
        for email in invalidEmails {
            XCTAssertFalse(emailVerificationService.isValidEmail(email), "Email \(email) should be invalid")
        }
    }
}

// MARK: - Mock Classes

class MockNetworkService {
    var shouldSucceed = true
    var errorToThrow: Error?
    var verificationResult = true
    
    var sendVerificationEmailCalled = false
    var verifyEmailCalled = false
    var resendVerificationEmailCalled = false
    
    var lastEmailSent: String?
    var lastTokenVerified: String?
    var lastEmailResent: String?
    
    func sendVerificationEmail(to email: String) async throws {
        sendVerificationEmailCalled = true
        lastEmailSent = email
        
        if !shouldSucceed {
            throw errorToThrow ?? AppError.networkUnavailable
        }
    }
    
    func verifyEmail(token: String) async throws -> Bool {
        verifyEmailCalled = true
        lastTokenVerified = token
        
        if !shouldSucceed {
            if let error = errorToThrow {
                throw error
            }
            return verificationResult
        }
        
        return true
    }
    
    func resendVerificationEmail(to email: String) async throws {
        resendVerificationEmailCalled = true
        lastEmailResent = email
        
        if !shouldSucceed {
            throw errorToThrow ?? AppError.networkUnavailable
        }
    }
}