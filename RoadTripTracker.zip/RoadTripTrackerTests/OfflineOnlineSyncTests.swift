import XCTest
import CoreData
import Network
@testable import RoadTripTracker

class OfflineOnlineSyncTests: XCTestCase {
    
    var offlineManager: OfflineManager!
    var persistenceController: PersistenceController!
    var networkMonitor: NWPathMonitor!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        persistenceController = PersistenceController(inMemory: true)
        offlineManager = OfflineManager(persistenceController: persistenceController)
        networkMonitor = NWPathMonitor()
    }
    
    override func tearDownWithError() throws {
        offlineManager = nil
        persistenceController = nil
        networkMonitor?.cancel()
        networkMonitor = nil
        try super.tearDownWithError()
    }
    
    // MARK: - Offline Data Storage Tests
    
    func testOfflineLocationCaching() async throws {
        let expectation = XCTestExpectation(description: "Offline location caching")
        
        // Simulate going offline
        offlineManager.setNetworkStatus(isConnected: false)
        
        let locations = [
            CLLocation(latitude: -33.8688, longitude: 151.2093),
            CLLocation(latitude: -33.8700, longitude: 151.2100),
            CLLocation(latitude: -33.8712, longitude: 151.2110)
        ]
        
        // Cache locations while offline
        for location in locations {
            offlineManager.cacheLocation(location, for: "test-trip")
        }
        
        let cachedLocations = offlineManager.getCachedLocations(for: "test-trip")
        XCTAssertEqual(cachedLocations.count, 3, "Should cache all locations")
        
        expectation.fulfill()
        await fulfillment(of: [expectation], timeout: 5.0)
    }
    
    func testOfflineMessageQueuing() async throws {
        let expectation = XCTestExpectation(description: "Offline message queuing")
        
        // Simulate going offline
        offlineManager.setNetworkStatus(isConnected: false)
        
        let messages = [
            "Test message 1",
            "Test message 2",
            "Test message 3"
        ]
        
        // Queue messages while offline
        for message in messages {
            offlineManager.queueMessage(message, for: "test-trip")
        }
        
        let queuedMessages = offlineManager.getQueuedMessages(for: "test-trip")
        XCTAssertEqual(queuedMessages.count, 3, "Should queue all messages")
        
        expectation.fulfill()
        await fulfillment(of: [expectation], timeout: 5.0)
    }
    
    func testOfflineExpenseLogging() async throws {
        let expectation = XCTestExpectation(description: "Offline expense logging")
        
        // Simulate going offline
        offlineManager.setNetworkStatus(isConnected: false)
        
        let expenses = [
            OfflineExpense(amount: 50.0, category: .fuel, description: "Gas station", timestamp: Date()),
            OfflineExpense(amount: 25.0, category: .food, description: "Lunch", timestamp: Date()),
            OfflineExpense(amount: 120.0, category: .accommodation, description: "Hotel", timestamp: Date())
        ]
        
        // Log expenses while offline
        for expense in expenses {
            offlineManager.logExpense(expense, for: "test-trip")
        }
        
        let cachedExpenses = offlineManager.getCachedExpenses(for: "test-trip")
        XCTAssertEqual(cachedExpenses.count, 3, "Should cache all expenses")
        
        expectation.fulfill()
        await fulfillment(of: [expectation], timeout: 5.0)
    }
}    
  
  // MARK: - Online Synchronization Tests
    
    func testLocationSyncWhenOnline() async throws {
        let expectation = XCTestExpectation(description: "Location sync when online")
        
        // First cache locations offline
        offlineManager.setNetworkStatus(isConnected: false)
        
        let locations = [
            CLLocation(latitude: -33.8688, longitude: 151.2093),
            CLLocation(latitude: -33.8700, longitude: 151.2100)
        ]
        
        for location in locations {
            offlineManager.cacheLocation(location, for: "test-trip")
        }
        
        // Simulate going online
        offlineManager.setNetworkStatus(isConnected: true)
        
        // Trigger sync
        offlineManager.syncCachedData { result in
            switch result {
            case .success:
                let remainingCachedLocations = self.offlineManager.getCachedLocations(for: "test-trip")
                XCTAssertEqual(remainingCachedLocations.count, 0, "Cached locations should be cleared after sync")
                expectation.fulfill()
            case .failure(let error):
                XCTFail("Sync should succeed: \(error)")
            }
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
    
    func testMessageSyncWhenOnline() async throws {
        let expectation = XCTestExpectation(description: "Message sync when online")
        
        // Cache messages offline
        offlineManager.setNetworkStatus(isConnected: false)
        
        let messages = ["Offline message 1", "Offline message 2"]
        for message in messages {
            offlineManager.queueMessage(message, for: "test-trip")
        }
        
        // Go online and sync
        offlineManager.setNetworkStatus(isConnected: true)
        
        offlineManager.syncCachedData { result in
            switch result {
            case .success:
                let remainingMessages = self.offlineManager.getQueuedMessages(for: "test-trip")
                XCTAssertEqual(remainingMessages.count, 0, "Queued messages should be cleared after sync")
                expectation.fulfill()
            case .failure(let error):
                XCTFail("Message sync should succeed: \(error)")
            }
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
    
    func testConflictResolutionDuringSync() async throws {
        let expectation = XCTestExpectation(description: "Conflict resolution during sync")
        
        let tripId = "test-trip"
        
        // Create conflicting data
        let localExpense = OfflineExpense(
            id: UUID(),
            amount: 50.0,
            category: .fuel,
            description: "Local version",
            timestamp: Date()
        )
        
        let remoteExpense = OfflineExpense(
            id: localExpense.id,
            amount: 55.0,
            category: .fuel,
            description: "Remote version",
            timestamp: Date().addingTimeInterval(60) // 1 minute later
        )
        
        // Cache local version
        offlineManager.setNetworkStatus(isConnected: false)
        offlineManager.logExpense(localExpense, for: tripId)
        
        // Simulate remote version exists
        offlineManager.setNetworkStatus(isConnected: true)
        offlineManager.simulateRemoteExpense(remoteExpense, for: tripId)
        
        offlineManager.syncCachedData { result in
            switch result {
            case .success:
                // Check that conflict was resolved (should keep remote version as it's newer)
                let syncedExpenses = self.offlineManager.getSyncedExpenses(for: tripId)
                let resolvedExpense = syncedExpenses.first { $0.id == localExpense.id }
                XCTAssertEqual(resolvedExpense?.description, "Remote version", "Should resolve to remote version")
                expectation.fulfill()
            case .failure(let error):
                XCTFail("Conflict resolution should succeed: \(error)")
            }
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
    
    // MARK: - Network State Transition Tests
    
    func testNetworkStateDetection() async throws {
        let expectation = XCTestExpectation(description: "Network state detection")
        
        var stateChanges: [Bool] = []
        
        offlineManager.onNetworkStateChange = { isConnected in
            stateChanges.append(isConnected)
            if stateChanges.count == 3 {
                expectation.fulfill()
            }
        }
        
        // Simulate network state changes
        offlineManager.setNetworkStatus(isConnected: false)
        offlineManager.setNetworkStatus(isConnected: true)
        offlineManager.setNetworkStatus(isConnected: false)
        
        await fulfillment(of: [expectation], timeout: 5.0)
        
        XCTAssertEqual(stateChanges, [false, true, false], "Should detect all network state changes")
    }
    
    func testAutomaticSyncOnNetworkReconnection() async throws {
        let expectation = XCTestExpectation(description: "Automatic sync on reconnection")
        
        // Cache data while offline
        offlineManager.setNetworkStatus(isConnected: false)
        offlineManager.cacheLocation(CLLocation(latitude: -33.8688, longitude: 151.2093), for: "test-trip")
        offlineManager.queueMessage("Test message", for: "test-trip")
        
        var syncTriggered = false
        offlineManager.onSyncTriggered = {
            syncTriggered = true
            expectation.fulfill()
        }
        
        // Simulate network reconnection
        offlineManager.setNetworkStatus(isConnected: true)
        
        await fulfillment(of: [expectation], timeout: 5.0)
        XCTAssertTrue(syncTriggered, "Sync should be automatically triggered on reconnection")
    }
    
    func testPartialSyncFailureHandling() async throws {
        let expectation = XCTestExpectation(description: "Partial sync failure handling")
        
        // Cache multiple types of data
        offlineManager.setNetworkStatus(isConnected: false)
        offlineManager.cacheLocation(CLLocation(latitude: -33.8688, longitude: 151.2093), for: "test-trip")
        offlineManager.queueMessage("Test message", for: "test-trip")
        offlineManager.logExpense(OfflineExpense(amount: 50.0, category: .fuel, description: "Gas", timestamp: Date()), for: "test-trip")
        
        // Simulate partial sync failure (locations succeed, messages fail)
        offlineManager.setNetworkStatus(isConnected: true)
        offlineManager.simulatePartialSyncFailure(failMessages: true, failExpenses: false)
        
        offlineManager.syncCachedData { result in
            switch result {
            case .success:
                XCTFail("Should report partial failure")
            case .failure(let error):
                if case OfflineManagerError.partialSyncFailure(let details) = error {
                    XCTAssertTrue(details.contains("messages"), "Should report message sync failure")
                    
                    // Verify that successful syncs were completed
                    let remainingLocations = self.offlineManager.getCachedLocations(for: "test-trip")
                    XCTAssertEqual(remainingLocations.count, 0, "Locations should be synced")
                    
                    // Verify that failed syncs remain cached
                    let remainingMessages = self.offlineManager.getQueuedMessages(for: "test-trip")
                    XCTAssertGreaterThan(remainingMessages.count, 0, "Messages should remain cached")
                    
                    expectation.fulfill()
                } else {
                    XCTFail("Should be partial sync failure error")
                }
            }
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
    
    // MARK: - Data Integrity Tests
    
    func testDataIntegrityAfterSync() async throws {
        let expectation = XCTestExpectation(description: "Data integrity after sync")
        
        let originalLocation = CLLocation(
            coordinate: CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093),
            altitude: 10,
            horizontalAccuracy: 5,
            verticalAccuracy: 5,
            timestamp: Date()
        )
        
        // Cache location offline
        offlineManager.setNetworkStatus(isConnected: false)
        offlineManager.cacheLocation(originalLocation, for: "test-trip")
        
        // Sync when online
        offlineManager.setNetworkStatus(isConnected: true)
        
        offlineManager.syncCachedData { result in
            switch result {
            case .success:
                // Verify data integrity
                let syncedLocations = self.offlineManager.getSyncedLocations(for: "test-trip")
                guard let syncedLocation = syncedLocations.first else {
                    XCTFail("Should have synced location")
                    return
                }
                
                XCTAssertEqual(syncedLocation.coordinate.latitude, originalLocation.coordinate.latitude, accuracy: 0.0001)
                XCTAssertEqual(syncedLocation.coordinate.longitude, originalLocation.coordinate.longitude, accuracy: 0.0001)
                XCTAssertEqual(syncedLocation.altitude, originalLocation.altitude, accuracy: 0.1)
                XCTAssertEqual(syncedLocation.horizontalAccuracy, originalLocation.horizontalAccuracy, accuracy: 0.1)
                
                expectation.fulfill()
            case .failure(let error):
                XCTFail("Sync should succeed: \(error)")
            }
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
    }
}