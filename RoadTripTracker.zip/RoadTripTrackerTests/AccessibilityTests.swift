import XCTest
import SwiftUI
import UIKit
@testable import RoadTripTracker

class AccessibilityTests: XCTestCase {
    var accessibilityManager: AccessibilityManager!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        accessibilityManager = AccessibilityManager.shared
    }
    
    override func tearDownWithError() throws {
        accessibilityManager = nil
        try super.tearDownWithError()
    }
    
    // MARK: - VoiceOver Tests
    
    func testVoiceOverSupport() {
        // Given
        let elements: [AccessibilityElement] = [
            .tripDashboard, .mapView, .chatView, .profileView,
            .createTrip, .joinTrip, .emergencyButton, .locationSharing,
            .fuelStop, .foodStop
        ]
        
        // When/Then
        for element in elements {
            let label = accessibilityManager.getAccessibilityLabel(for: element)
            let hint = accessibilityManager.getAccessibilityHint(for: element)
            
            // Verify labels are descriptive
            XCTAssertFalse(label.isEmpty, "Accessibility label should not be empty for \(element)")
            XCTAssertGreaterThan(label.count, 5, "Label should be descriptive for \(element)")
            
            // Verify hints are helpful
            XCTAssertFalse(hint.isEmpty, "Accessibility hint should not be empty for \(element)")
            XCTAssertGreaterThan(hint.count, 10, "Hint should be helpful for \(element)")
            
            // Verify labels don't end with punctuation (VoiceOver best practice)
            XCTAssertFalse(label.hasSuffix("."), "Label should not end with period for \(element)")
            XCTAssertFalse(label.hasSuffix("!"), "Label should not end with exclamation for \(element)")
        }
    }
    
    func testAccessibilityAnnouncements() {
        // Given
        let testMessage = "Test announcement"
        
        // When
        accessibilityManager.announceForAccessibility(testMessage)
        
        // Then
        // Verify method doesn't crash (actual announcement testing requires UI tests)
        XCTAssertTrue(true)
    }
    
    func testSpeechSynthesis() {
        // Given
        let testText = "Test speech synthesis"
        
        // When
        accessibilityManager.speakText(testText)
        
        // Then
        // Verify method doesn't crash
        XCTAssertTrue(true)
        
        // Cleanup
        accessibilityManager.stopSpeaking()
    }
    
    // MARK: - Dynamic Type Tests
    
    func testDynamicTypeSupport() {
        // Given
        let contentSizeCategories: [UIContentSizeCategory] = [
            .extraSmall, .small, .medium, .large, .extraLarge,
            .extraExtraLarge, .extraExtraExtraLarge,
            .accessibilityMedium, .accessibilityLarge,
            .accessibilityExtraLarge, .accessibilityExtraExtraLarge,
            .accessibilityExtraExtraExtraLarge
        ]
        
        // When/Then
        for category in contentSizeCategories {
            let swiftUICategory = ContentSizeCategory(category)
            XCTAssertNotNil(swiftUICategory, "Should support content size category: \(category)")
        }
    }
    
    func testAccessibilityContentSizeDetection() {
        // Given
        let accessibilityCategories: [UIContentSizeCategory] = [
            .accessibilityMedium, .accessibilityLarge,
            .accessibilityExtraLarge, .accessibilityExtraExtraLarge,
            .accessibilityExtraExtraExtraLarge
        ]
        
        // When/Then
        for category in accessibilityCategories {
            XCTAssertTrue(category.isAccessibilityCategory, "Should detect accessibility category: \(category)")
        }
        
        let regularCategories: [UIContentSizeCategory] = [
            .extraSmall, .small, .medium, .large, .extraLarge
        ]
        
        for category in regularCategories {
            XCTAssertFalse(category.isAccessibilityCategory, "Should not detect regular category as accessibility: \(category)")
        }
    }
    
    // MARK: - Reduce Motion Tests
    
    func testReduceMotionSupport() {
        // Given
        let originalValue = accessibilityManager.isReduceMotionEnabled
        
        // When - Simulate reduce motion enabled
        accessibilityManager.isReduceMotionEnabled = true
        
        // Then
        XCTAssertTrue(accessibilityManager.shouldReduceAnimations())
        XCTAssertEqual(accessibilityManager.getAdaptiveAnimationDuration(), 0.1)
        
        // When - Simulate reduce motion disabled
        accessibilityManager.isReduceMotionEnabled = false
        
        // Then
        XCTAssertFalse(accessibilityManager.shouldReduceAnimations())
        XCTAssertEqual(accessibilityManager.getAdaptiveAnimationDuration(), 0.3)
        
        // Cleanup
        accessibilityManager.isReduceMotionEnabled = originalValue
    }
    
    func testAdaptiveAnimations() {
        // Given
        let originalValue = accessibilityManager.isReduceMotionEnabled
        
        // When - Test with reduce motion enabled
        accessibilityManager.isReduceMotionEnabled = true
        let reducedAnimation = accessibilityManager.getAdaptiveSpringAnimation()
        
        // Then
        // Animation should be linear and short when reduce motion is enabled
        XCTAssertNotNil(reducedAnimation)
        
        // When - Test with reduce motion disabled
        accessibilityManager.isReduceMotionEnabled = false
        let normalAnimation = accessibilityManager.getAdaptiveSpringAnimation()
        
        // Then
        XCTAssertNotNil(normalAnimation)
        
        // Cleanup
        accessibilityManager.isReduceMotionEnabled = originalValue
    }
    
    // MARK: - Reduce Transparency Tests
    
    func testReduceTransparencySupport() {
        // Given
        let originalValue = accessibilityManager.isReduceTransparencyEnabled
        
        // When - Simulate reduce transparency enabled
        accessibilityManager.isReduceTransparencyEnabled = true
        
        // Then
        XCTAssertTrue(accessibilityManager.shouldReduceTransparency())
        
        // When - Simulate reduce transparency disabled
        accessibilityManager.isReduceTransparencyEnabled = false
        
        // Then
        XCTAssertFalse(accessibilityManager.shouldReduceTransparency())
        
        // Cleanup
        accessibilityManager.isReduceTransparencyEnabled = originalValue
    }
    
    // MARK: - High Contrast Tests
    
    func testHighContrastSupport() {
        // Given
        let originalValue = accessibilityManager.isHighContrastEnabled
        
        // When - Simulate high contrast enabled
        accessibilityManager.isHighContrastEnabled = true
        
        // Then
        XCTAssertTrue(accessibilityManager.shouldUseHighContrast())
        
        // When - Simulate high contrast disabled
        accessibilityManager.isHighContrastEnabled = false
        
        // Then
        XCTAssertFalse(accessibilityManager.shouldUseHighContrast())
        
        // Cleanup
        accessibilityManager.isHighContrastEnabled = originalValue
    }
    
    // MARK: - Switch Control Tests
    
    func testSwitchControlSupport() {
        // Given
        let originalValue = accessibilityManager.isSwitchControlEnabled
        
        // When - Simulate switch control enabled
        accessibilityManager.isSwitchControlEnabled = true
        
        // Then
        XCTAssertTrue(accessibilityManager.isSwitchControlEnabled)
        
        // Cleanup
        accessibilityManager.isSwitchControlEnabled = originalValue
    }
    
    // MARK: - Assistive Touch Tests
    
    func testAssistiveTouchSupport() {
        // Given
        let originalValue = accessibilityManager.isAssistiveTouchEnabled
        
        // When - Simulate assistive touch enabled
        accessibilityManager.isAssistiveTouchEnabled = true
        
        // Then
        XCTAssertTrue(accessibilityManager.isAssistiveTouchEnabled)
        
        // Cleanup
        accessibilityManager.isAssistiveTouchEnabled = originalValue
    }
    
    // MARK: - Accessibility Element Tests
    
    func testAccessibilityElementLabels() {
        let testCases: [(AccessibilityElement, String)] = [
            (.tripDashboard, "dashboard"),
            (.mapView, "map"),
            (.chatView, "chat"),
            (.profileView, "profile"),
            (.createTrip, "create"),
            (.joinTrip, "join"),
            (.emergencyButton, "emergency"),
            (.locationSharing, "location"),
            (.fuelStop, "fuel"),
            (.foodStop, "food")
        ]
        
        for (element, expectedKeyword) in testCases {
            let label = accessibilityManager.getAccessibilityLabel(for: element)
            XCTAssertTrue(
                label.lowercased().contains(expectedKeyword),
                "Label '\(label)' should contain '\(expectedKeyword)' for element \(element)"
            )
        }
    }
    
    func testAccessibilityElementHints() {
        let testCases: [(AccessibilityElement, String)] = [
            (.tripDashboard, "double tap"),
            (.mapView, "double tap"),
            (.chatView, "double tap"),
            (.profileView, "double tap"),
            (.createTrip, "double tap"),
            (.joinTrip, "double tap"),
            (.emergencyButton, "double tap"),
            (.locationSharing, "double tap"),
            (.fuelStop, "double tap"),
            (.foodStop, "double tap")
        ]
        
        for (element, expectedKeyword) in testCases {
            let hint = accessibilityManager.getAccessibilityHint(for: element)
            XCTAssertTrue(
                hint.lowercased().contains(expectedKeyword),
                "Hint '\(hint)' should contain '\(expectedKeyword)' for element \(element)"
            )
        }
    }
    
    // MARK: - Performance Tests
    
    func testAccessibilityPerformance() {
        measure {
            for _ in 0..<1000 {
                _ = accessibilityManager.getAccessibilityLabel(for: .tripDashboard)
                _ = accessibilityManager.getAccessibilityHint(for: .mapView)
                _ = accessibilityManager.shouldReduceAnimations()
                _ = accessibilityManager.shouldReduceTransparency()
                _ = accessibilityManager.shouldUseHighContrast()
            }
        }
    }
    
    // MARK: - Integration Tests
    
    func testAccessibilitySettingsObservation() {
        // Given
        let expectation = XCTestExpectation(description: "Accessibility settings updated")
        
        // When
        // Simulate accessibility setting change
        NotificationCenter.default.post(name: UIAccessibility.voiceOverStatusDidChangeNotification, object: nil)
        
        // Then
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            // Verify the manager responded to the notification
            expectation.fulfill()
        }
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testContentSizeCategoryMapping() {
        let mappingTests: [(UIContentSizeCategory, ContentSizeCategory)] = [
            (.extraSmall, .extraSmall),
            (.small, .small),
            (.medium, .medium),
            (.large, .large),
            (.extraLarge, .extraLarge),
            (.extraExtraLarge, .extraExtraLarge),
            (.extraExtraExtraLarge, .extraExtraExtraLarge),
            (.accessibilityMedium, .accessibilityMedium),
            (.accessibilityLarge, .accessibilityLarge),
            (.accessibilityExtraLarge, .accessibilityExtraLarge),
            (.accessibilityExtraExtraLarge, .accessibilityExtraExtraLarge),
            (.accessibilityExtraExtraExtraLarge, .accessibilityExtraExtraExtraLarge)
        ]
        
        for (uiCategory, expectedSwiftUICategory) in mappingTests {
            let mappedCategory = ContentSizeCategory(uiCategory)
            XCTAssertEqual(mappedCategory, expectedSwiftUICategory, "Mapping failed for \(uiCategory)")
        }
    }
    
    // MARK: - Error Handling Tests
    
    func testAccessibilityErrorHandling() {
        // Test that accessibility methods handle edge cases gracefully
        
        // Empty string announcement
        accessibilityManager.announceForAccessibility("")
        XCTAssertTrue(true) // Should not crash
        
        // Very long string announcement
        let longString = String(repeating: "A", count: 10000)
        accessibilityManager.announceForAccessibility(longString)
        XCTAssertTrue(true) // Should not crash
        
        // Special characters
        accessibilityManager.announceForAccessibility("Test with émojis 🚗🗺️💬")
        XCTAssertTrue(true) // Should not crash
    }
}