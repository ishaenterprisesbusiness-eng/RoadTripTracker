import XCTest
import Combine
import CoreLocation
import UIKit
@testable import RoadTripTracker

// MARK: - Photo Sharing View Model Tests
@MainActor
final class PhotoSharingViewModelTests: XCTestCase {
    
    var viewModel: PhotoSharingViewModel!
    var mockPhotoSharingService: MockPhotoSharingService!
    var mockLocationManager: MockLocationManager!
    var subscriptions: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        mockPhotoSharingService = MockPhotoSharingService()
        mockLocationManager = MockLocationManager()
        
        viewModel = PhotoSharingViewModel(
            photoSharingService: mockPhotoSharingService,
            locationManager: mockLocationManager
        )
        
        subscriptions = Set<AnyCancellable>()
    }
    
    override func tearDownWithError() throws {
        subscriptions = nil
        viewModel = nil
        mockLocationManager = nil
        mockPhotoSharingService = nil
        try super.tearDownWithError()
    }
    
    // MARK: - Load Trip Photos Tests
    
    func testLoadTripPhotos() async {
        // Given
        let tripId = UUID()
        let testPhotos = [
            PhotoShare.testPhotoShare(tripId: tripId, caption: "Photo 1"),
            PhotoShare.testPhotoShare(tripId: tripId, caption: "Photo 2")
        ]
        mockPhotoSharingService.mockTripPhotos = testPhotos
        
        // When
        await viewModel.loadTripPhotos(for: tripId)
        
        // Then
        XCTAssertEqual(viewModel.tripPhotos.count, 2)
        XCTAssertEqual(viewModel.tripPhotos[0].caption, "Photo 1")
        XCTAssertEqual(viewModel.tripPhotos[1].caption, "Photo 2")
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertEqual(viewModel.groupedPhotos.count, 1) // All photos from same day
    }
    
    func testLoadTripPhotosWithError() async {
        // Given
        let tripId = UUID()
        mockPhotoSharingService.shouldThrowError = true
        
        // When
        await viewModel.loadTripPhotos(for: tripId)
        
        // Then
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertTrue(viewModel.tripPhotos.isEmpty)
    }
    
    // MARK: - Share Photo Tests
    
    func testSharePhoto() async {
        // Given
        let tripId = UUID()
        await viewModel.loadTripPhotos(for: tripId)
        let testImage = createTestImage()
        let caption = "Beautiful sunset"
        let testLocation = CLLocation(latitude: 37.7749, longitude: -122.4194)
        mockLocationManager.mockLocation = testLocation
        
        // When
        await viewModel.sharePhoto(testImage, caption: caption)
        
        // Then
        XCTAssertTrue(mockPhotoSharingService.sharePhotoCalled)
        XCTAssertEqual(mockPhotoSharingService.lastPhotoCaption, caption)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    func testSharePhotoWithoutLocation() async {
        // Given
        let tripId = UUID()
        await viewModel.loadTripPhotos(for: tripId)
        let testImage = createTestImage()
        mockLocationManager.shouldThrowError = true
        
        // When
        await viewModel.sharePhoto(testImage)
        
        // Then
        XCTAssertTrue(mockPhotoSharingService.sharePhotoCalled)
        XCTAssertNil(mockPhotoSharingService.lastPhotoLocation)
    }
    
    func testSharePhotoError() async {
        // Given
        let tripId = UUID()
        await viewModel.loadTripPhotos(for: tripId)
        let testImage = createTestImage()
        mockPhotoSharingService.shouldThrowError = true
        
        // When
        await viewModel.sharePhoto(testImage)
        
        // Then
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    // MARK: - Share Multiple Photos Tests
    
    func testShareMultiplePhotos() async {
        // Given
        let tripId = UUID()
        await viewModel.loadTripPhotos(for: tripId)
        let testImages = [createTestImage(), createTestImage()]
        let captions = ["Photo 1", "Photo 2"]
        
        // When
        await viewModel.shareMultiplePhotos(testImages, captions: captions)
        
        // Then
        XCTAssertTrue(mockPhotoSharingService.sharePhotoCalled)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    // MARK: - Delete Photo Tests
    
    func testDeletePhoto() async {
        // Given
        let tripId = UUID()
        let photoShare = PhotoShare.testPhotoShare(tripId: tripId)
        viewModel.tripPhotos = [photoShare]
        viewModel.selectedPhotos = [photoShare]
        
        // When
        await viewModel.deletePhoto(photoShare)
        
        // Then
        XCTAssertTrue(mockPhotoSharingService.deletePhotoCalled)
        XCTAssertTrue(viewModel.tripPhotos.isEmpty)
        XCTAssertTrue(viewModel.selectedPhotos.isEmpty)
    }
    
    func testDeleteSelectedPhotos() async {
        // Given
        let tripId = UUID()
        let photo1 = PhotoShare.testPhotoShare(tripId: tripId)
        let photo2 = PhotoShare.testPhotoShare(tripId: tripId)
        viewModel.tripPhotos = [photo1, photo2]
        viewModel.selectedPhotos = [photo1, photo2]
        viewModel.isSelectionMode = true
        
        // When
        await viewModel.deleteSelectedPhotos()
        
        // Then
        XCTAssertTrue(viewModel.selectedPhotos.isEmpty)
        XCTAssertFalse(viewModel.isSelectionMode)
    }
    
    // MARK: - Download Photo Tests
    
    func testDownloadPhoto() async {
        // Given
        let photoShare = PhotoShare.testPhotoShare()
        
        // When
        let image = await viewModel.downloadPhoto(photoShare)
        
        // Then
        // In mock implementation, this returns nil due to network error
        // In real implementation, it would return the downloaded image
        XCTAssertNil(image)
    }
    
    // MARK: - Create Trip Album Tests
    
    func testCreateTripAlbum() async {
        // Given
        let tripId = UUID()
        await viewModel.loadTripPhotos(for: tripId)
        
        // When
        await viewModel.createTripAlbum()
        
        // Then
        XCTAssertTrue(mockPhotoSharingService.createTripAlbumCalled)
        XCTAssertNotNil(viewModel.tripAlbum)
        XCTAssertFalse(viewModel.showingAlbumCreation)
    }
    
    // MARK: - Photo Selection Tests
    
    func testTogglePhotoSelection() {
        // Given
        let photoShare = PhotoShare.testPhotoShare()
        
        // When - Select photo
        viewModel.togglePhotoSelection(photoShare)
        
        // Then
        XCTAssertTrue(viewModel.selectedPhotos.contains { $0.id == photoShare.id })
        
        // When - Deselect photo
        viewModel.togglePhotoSelection(photoShare)
        
        // Then
        XCTAssertFalse(viewModel.selectedPhotos.contains { $0.id == photoShare.id })
        XCTAssertFalse(viewModel.isSelectionMode)
    }
    
    func testSelectAllPhotos() {
        // Given
        let photo1 = PhotoShare.testPhotoShare()
        let photo2 = PhotoShare.testPhotoShare()
        viewModel.tripPhotos = [photo1, photo2]
        
        // When
        viewModel.selectAllPhotos()
        
        // Then
        XCTAssertEqual(viewModel.selectedPhotos.count, 2)
        XCTAssertTrue(viewModel.selectedPhotos.contains { $0.id == photo1.id })
        XCTAssertTrue(viewModel.selectedPhotos.contains { $0.id == photo2.id })
    }
    
    func testDeselectAllPhotos() {
        // Given
        let photoShare = PhotoShare.testPhotoShare()
        viewModel.selectedPhotos = [photoShare]
        viewModel.isSelectionMode = true
        
        // When
        viewModel.deselectAllPhotos()
        
        // Then
        XCTAssertTrue(viewModel.selectedPhotos.isEmpty)
        XCTAssertFalse(viewModel.isSelectionMode)
    }
    
    // MARK: - Sort and Filter Tests
    
    func testSetSortOption() {
        // Given
        let photo1 = PhotoShare.testPhotoShare()
        photo1.timestamp = Date().addingTimeInterval(-3600) // 1 hour ago
        let photo2 = PhotoShare.testPhotoShare()
        photo2.timestamp = Date() // Now
        viewModel.tripPhotos = [photo1, photo2]
        
        // When - Sort by oldest first
        viewModel.setSortOption(.dateAscending)
        
        // Then
        XCTAssertEqual(viewModel.sortOption, .dateAscending)
        // Verify photos are organized (would need to check groupedPhotos order)
    }
    
    func testSetFilterOption() {
        // Given
        let photoWithLocation = PhotoShare.testPhotoShare(location: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194))
        let photoWithoutLocation = PhotoShare.testPhotoShare(location: nil)
        viewModel.tripPhotos = [photoWithLocation, photoWithoutLocation]
        
        // When - Filter by photos with location
        viewModel.setFilterOption(.withLocation)
        
        // Then
        XCTAssertEqual(viewModel.filterOption, .withLocation)
        // Verify filtering is applied (would need to check groupedPhotos)
    }
    
    // MARK: - Photo Updates Tests
    
    func testPhotoUpdates() {
        // Given
        let expectation = XCTestExpectation(description: "Photo update received")
        let newPhoto = PhotoShare.testPhotoShare()
        
        viewModel.$tripPhotos
            .dropFirst() // Skip initial empty array
            .sink { photos in
                if !photos.isEmpty {
                    expectation.fulfill()
                }
            }
            .store(in: &subscriptions)
        
        // When
        mockPhotoSharingService.photoSubject.send(newPhoto)
        
        // Then
        wait(for: [expectation], timeout: 1.0)
        XCTAssertTrue(viewModel.tripPhotos.contains { $0.id == newPhoto.id })
    }
    
    // MARK: - Photo Organization Tests
    
    func testPhotoGrouping() {
        // Given
        let today = Date()
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: today)!
        
        let todayPhoto = PhotoShare.testPhotoShare()
        todayPhoto.timestamp = today
        
        let yesterdayPhoto = PhotoShare.testPhotoShare()
        yesterdayPhoto.timestamp = yesterday
        
        viewModel.tripPhotos = [todayPhoto, yesterdayPhoto]
        
        // When
        viewModel.organizePhotos()
        
        // Then
        XCTAssertEqual(viewModel.groupedPhotos.count, 2)
        XCTAssertEqual(viewModel.groupedPhotos[0].displayDate, "Today")
        XCTAssertEqual(viewModel.groupedPhotos[1].displayDate, "Yesterday")
    }
    
    // MARK: - Error Handling Tests
    
    func testClearError() {
        // Given
        viewModel.errorMessage = "Test error"
        
        // When
        viewModel.clearError()
        
        // Then
        XCTAssertNil(viewModel.errorMessage)
    }
    
    // MARK: - Helper Methods
    
    private func createTestImage(size: CGSize = CGSize(width: 100, height: 100)) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { context in
            UIColor.blue.setFill()
            context.fill(CGRect(origin: .zero, size: size))
        }
    }
}

// MARK: - Enhanced Mock Photo Sharing Service
extension MockPhotoSharingService {
    var mockTripPhotos: [PhotoShare] = []
    var sharePhotoCalled = false
    var deletePhotoCalled = false
    var createTripAlbumCalled = false
    var lastPhotoCaption: String?
    var lastPhotoLocation: CLLocationCoordinate2D?
    
    override func sharePhoto(_ photo: UIImage, caption: String?, location: CLLocationCoordinate2D?, to tripId: UUID) async throws -> PhotoShare {
        sharePhotoCalled = true
        lastPhotoCaption = caption
        lastPhotoLocation = location
        
        if shouldThrowError {
            throw ChatServiceError.photoUploadFailed
        }
        
        let photoShare = PhotoShare.testPhotoShare(tripId: tripId, caption: caption, location: location)
        photoSubject.send(photoShare)
        return photoShare
    }
    
    override func getTripPhotos(for tripId: UUID) async throws -> [PhotoShare] {
        if shouldThrowError {
            throw ChatServiceError.networkError
        }
        
        return mockTripPhotos
    }
    
    override func deletePhoto(_ photoId: UUID) async throws {
        deletePhotoCalled = true
        
        if shouldThrowError {
            throw ChatServiceError.photoDownloadFailed
        }
    }
    
    override func createTripAlbum(for tripId: UUID) async throws -> TripAlbum {
        createTripAlbumCalled = true
        
        if shouldThrowError {
            throw ChatServiceError.unknown("Failed to create album")
        }
        
        return TripAlbum.testTripAlbum(tripId: tripId)
    }
}