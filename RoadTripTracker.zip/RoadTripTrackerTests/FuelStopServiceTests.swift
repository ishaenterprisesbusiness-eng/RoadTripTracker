import XCTest
import CoreLocation
import Combine
@testable import RoadTripTracker

final class FuelStopServiceTests: XCTestCase {
    var fuelStopService: FuelStopService!
    var mockPlacesService: MockPlacesService!
    var mockNotificationService: MockNotificationService!
    var mockRouteManager: MockRouteManager!
    var cancellables: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        mockPlacesService = MockPlacesService()
        mockNotificationService = MockNotificationService()
        mockRouteManager = MockRouteManager()
        fuelStopService = FuelStopService(
            placesService: mockPlacesService,
            notificationService: mockNotificationService,
            routeManager: mockRouteManager
        )
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDownWithError() throws {
        fuelStopService = nil
        mockPlacesService = nil
        mockNotificationService = nil
        mockRouteManager = nil
        cancellables = nil
    }
    
    // MARK: - Gas Station Discovery Tests
    
    func testFindNearbyGasStations() async throws {
        // Given
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        let radius: Double = 5000
        
        let mockPlaces = [
            PlaceSearchResult(
                id: "1",
                name: "Shell Station",
                address: "123 Main St",
                coordinate: coordinate,
                category: .gasStation,
                rating: 4.2
            )
        ]
        
        mockPlacesService.mockNearbyPlaces = mockPlaces
        
        // When
        let gasStations = try await fuelStopService.findNearbyGasStations(
            coordinate: coordinate,
            radius: radius
        )
        
        // Then
        XCTAssertEqual(gasStations.count, 1)
        XCTAssertEqual(gasStations.first?.name, "Shell Station")
        XCTAssertEqual(gasStations.first?.address, "123 Main St")
        XCTAssertEqual(gasStations.first?.rating, 4.2)
    }
    
    func testFindGasStationsAlongRoute() async throws {
        // Given
        let route = [
            CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094)
        ]
        let searchRadius: Double = 2000
        
        let mockPlaces = [
            PlaceSearchResult(
                id: "1",
                name: "Chevron",
                address: "456 Route St",
                coordinate: route[0],
                category: .gasStation,
                rating: 4.0
            )
        ]
        
        mockPlacesService.mockNearbyPlaces = mockPlaces
        
        // When
        let gasStations = try await fuelStopService.findGasStationsAlongRoute(
            route: route,
            searchRadius: searchRadius
        )
        
        // Then
        XCTAssertEqual(gasStations.count, 1)
        XCTAssertEqual(gasStations.first?.name, "Chevron")
        XCTAssertNotNil(gasStations.first?.distanceFromRoute)
    }
    
    // MARK: - Fuel Stop Proposal Tests
    
    func testProposeFuelStop() async throws {
        // Given
        let gasStation = GasStation(
            id: "test-station",
            name: "Test Station",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let notes = "Good location for fuel stop"
        
        var receivedFuelStop: FuelStop?
        
        fuelStopService.fuelStopUpdates
            .sink { fuelStop in
                receivedFuelStop = fuelStop
            }
            .store(in: &cancellables)
        
        // When
        let fuelStop = try await fuelStopService.proposeFuelStop(
            gasStation: gasStation,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: notes
        )
        
        // Then
        XCTAssertEqual(fuelStop.tripId, tripId)
        XCTAssertEqual(fuelStop.proposedBy, proposedBy)
        XCTAssertEqual(fuelStop.gasStation.name, "Test Station")
        XCTAssertEqual(fuelStop.notes, notes)
        XCTAssertEqual(fuelStop.proposalStatus, .pending)
        XCTAssertTrue(fuelStop.approvals.isEmpty)
        XCTAssertTrue(fuelStop.rejections.isEmpty)
        
        // Verify notification was sent
        XCTAssertTrue(mockNotificationService.pushNotificationSent)
        
        // Verify update was published
        XCTAssertNotNil(receivedFuelStop)
        XCTAssertEqual(receivedFuelStop?.id, fuelStop.id)
    }
    
    func testApproveFuelStop() async throws {
        // Given
        let gasStation = GasStation(
            id: "test-station",
            name: "Test Station",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let participantId = UUID()
        
        let fuelStop = try await fuelStopService.proposeFuelStop(
            gasStation: gasStation,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: nil
        )
        
        var receivedUpdates: [FuelStop] = []
        
        fuelStopService.fuelStopUpdates
            .sink { update in
                receivedUpdates.append(update)
            }
            .store(in: &cancellables)
        
        // When
        try await fuelStopService.approveFuelStop(
            fuelStopId: fuelStop.id,
            participantId: participantId
        )
        
        // Add another approval to reach threshold
        let secondParticipant = UUID()
        try await fuelStopService.approveFuelStop(
            fuelStopId: fuelStop.id,
            participantId: secondParticipant
        )
        
        // Then
        let finalUpdate = receivedUpdates.last
        XCTAssertNotNil(finalUpdate)
        XCTAssertEqual(finalUpdate?.proposalStatus, .approved)
        XCTAssertTrue(finalUpdate?.approvals.contains(participantId) ?? false)
        XCTAssertTrue(finalUpdate?.approvals.contains(secondParticipant) ?? false)
        
        // Verify route was updated
        XCTAssertTrue(mockRouteManager.waypointAdded)
    }
    
    func testRejectFuelStop() async throws {
        // Given
        let gasStation = GasStation(
            id: "test-station",
            name: "Test Station",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let participantId = UUID()
        
        let fuelStop = try await fuelStopService.proposeFuelStop(
            gasStation: gasStation,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: nil
        )
        
        var receivedUpdates: [FuelStop] = []
        
        fuelStopService.fuelStopUpdates
            .sink { update in
                receivedUpdates.append(update)
            }
            .store(in: &cancellables)
        
        // When
        try await fuelStopService.rejectFuelStop(
            fuelStopId: fuelStop.id,
            participantId: participantId,
            reason: "Too far from route"
        )
        
        // Add another rejection to reach threshold
        let secondParticipant = UUID()
        try await fuelStopService.rejectFuelStop(
            fuelStopId: fuelStop.id,
            participantId: secondParticipant,
            reason: nil
        )
        
        // Then
        let finalUpdate = receivedUpdates.last
        XCTAssertNotNil(finalUpdate)
        XCTAssertEqual(finalUpdate?.proposalStatus, .rejected)
        XCTAssertTrue(finalUpdate?.rejections.contains(participantId) ?? false)
        XCTAssertTrue(finalUpdate?.rejections.contains(secondParticipant) ?? false)
    }
    
    // MARK: - Check-in System Tests
    
    func testCheckInAtFuelStop() async throws {
        // Given
        let gasStation = GasStation(
            id: "test-station",
            name: "Test Station",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let participantId = UUID()
        
        var fuelStop = try await fuelStopService.proposeFuelStop(
            gasStation: gasStation,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: nil
        )
        
        // Approve the fuel stop first
        try await fuelStopService.approveFuelStop(fuelStopId: fuelStop.id, participantId: UUID())
        try await fuelStopService.approveFuelStop(fuelStopId: fuelStop.id, participantId: UUID())
        
        let fuelAmount: Double = 45.5
        let fuelCost: Double = 67.25
        let notes = "Quick fill-up"
        
        // When
        try await fuelStopService.checkInAtFuelStop(
            fuelStopId: fuelStop.id,
            participantId: participantId,
            fuelAmount: fuelAmount,
            fuelCost: fuelCost,
            notes: notes
        )
        
        // Then
        let fuelStops = try await fuelStopService.getFuelStopsForTrip(tripId: tripId)
        let updatedFuelStop = fuelStops.first { $0.id == fuelStop.id }
        
        XCTAssertNotNil(updatedFuelStop)
        XCTAssertEqual(updatedFuelStop?.proposalStatus, .active)
        XCTAssertNotNil(updatedFuelStop?.actualArrivalTime)
        XCTAssertEqual(updatedFuelStop?.checkIns.count, 1)
        
        let checkIn = updatedFuelStop?.checkIns.first
        XCTAssertEqual(checkIn?.participantId, participantId)
        XCTAssertEqual(checkIn?.fuelAmount, fuelAmount)
        XCTAssertEqual(checkIn?.fuelCost, fuelCost)
        XCTAssertEqual(checkIn?.notes, notes)
        XCTAssertFalse(checkIn?.isReadyToContinue ?? true)
    }
    
    func testMarkReadyToContinue() async throws {
        // Given
        let gasStation = GasStation(
            id: "test-station",
            name: "Test Station",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let participantId = UUID()
        
        let fuelStop = try await fuelStopService.proposeFuelStop(
            gasStation: gasStation,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: nil
        )
        
        // Approve and check in first
        try await fuelStopService.approveFuelStop(fuelStopId: fuelStop.id, participantId: UUID())
        try await fuelStopService.approveFuelStop(fuelStopId: fuelStop.id, participantId: UUID())
        
        try await fuelStopService.checkInAtFuelStop(
            fuelStopId: fuelStop.id,
            participantId: participantId,
            fuelAmount: 40.0,
            fuelCost: 60.0,
            notes: nil
        )
        
        // When
        try await fuelStopService.markReadyToContinue(
            fuelStopId: fuelStop.id,
            participantId: participantId
        )
        
        // Then
        let fuelStops = try await fuelStopService.getFuelStopsForTrip(tripId: tripId)
        let updatedFuelStop = fuelStops.first { $0.id == fuelStop.id }
        
        XCTAssertNotNil(updatedFuelStop)
        
        let checkIn = updatedFuelStop?.checkIns.first { $0.participantId == participantId }
        XCTAssertTrue(checkIn?.isReadyToContinue ?? false)
        
        // Since only one participant, fuel stop should be completed
        XCTAssertEqual(updatedFuelStop?.proposalStatus, .completed)
    }
    
    // MARK: - Data Retrieval Tests
    
    func testGetFuelStopsForTrip() async throws {
        // Given
        let tripId = UUID()
        let otherTripId = UUID()
        
        let gasStation1 = GasStation(
            id: "station-1",
            name: "Station 1",
            address: "Address 1",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        
        let gasStation2 = GasStation(
            id: "station-2",
            name: "Station 2",
            address: "Address 2",
            coordinate: CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094)
        )
        
        // Create fuel stops for different trips
        let fuelStop1 = try await fuelStopService.proposeFuelStop(
            gasStation: gasStation1,
            tripId: tripId,
            proposedBy: UUID(),
            notes: nil
        )
        
        let fuelStop2 = try await fuelStopService.proposeFuelStop(
            gasStation: gasStation2,
            tripId: otherTripId,
            proposedBy: UUID(),
            notes: nil
        )
        
        // When
        let fuelStops = try await fuelStopService.getFuelStopsForTrip(tripId: tripId)
        
        // Then
        XCTAssertEqual(fuelStops.count, 1)
        XCTAssertEqual(fuelStops.first?.id, fuelStop1.id)
        XCTAssertEqual(fuelStops.first?.tripId, tripId)
    }
    
    func testGetActiveFuelStop() async throws {
        // Given
        let tripId = UUID()
        
        let gasStation = GasStation(
            id: "station-1",
            name: "Station 1",
            address: "Address 1",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        
        let fuelStop = try await fuelStopService.proposeFuelStop(
            gasStation: gasStation,
            tripId: tripId,
            proposedBy: UUID(),
            notes: nil
        )
        
        // Approve and activate the fuel stop
        try await fuelStopService.approveFuelStop(fuelStopId: fuelStop.id, participantId: UUID())
        try await fuelStopService.approveFuelStop(fuelStopId: fuelStop.id, participantId: UUID())
        
        try await fuelStopService.checkInAtFuelStop(
            fuelStopId: fuelStop.id,
            participantId: UUID(),
            fuelAmount: 40.0,
            fuelCost: 60.0,
            notes: nil
        )
        
        // When
        let activeFuelStop = try await fuelStopService.getActiveFuelStop(tripId: tripId)
        
        // Then
        XCTAssertNotNil(activeFuelStop)
        XCTAssertEqual(activeFuelStop?.id, fuelStop.id)
        XCTAssertEqual(activeFuelStop?.proposalStatus, .active)
    }
    
    // MARK: - Error Handling Tests
    
    func testFuelStopNotFoundError() async {
        // Given
        let nonExistentFuelStopId = UUID()
        let participantId = UUID()
        
        // When/Then
        do {
            try await fuelStopService.approveFuelStop(
                fuelStopId: nonExistentFuelStopId,
                participantId: participantId
            )
            XCTFail("Expected FuelStopServiceError.fuelStopNotFound")
        } catch FuelStopServiceError.fuelStopNotFound {
            // Expected error
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
}

// MARK: - Mock Services

class MockPlacesService: PlacesServiceProtocol {
    var mockNearbyPlaces: [PlaceSearchResult] = []
    var mockSearchResults: [PlaceSearchResult] = []
    var mockPlaceDetails: PlaceDetails?
    
    func searchPlaces(query: String, region: MKCoordinateRegion?) async throws -> [PlaceSearchResult] {
        return mockSearchResults
    }
    
    func getPlaceDetails(for placeId: String) async throws -> PlaceDetails {
        guard let details = mockPlaceDetails else {
            throw PlacesServiceError.notImplemented
        }
        return details
    }
    
    func getNearbyPlaces(coordinate: CLLocationCoordinate2D, radius: Double, category: PlaceCategory) async throws -> [PlaceSearchResult] {
        return mockNearbyPlaces
    }
}

class MockNotificationService: NotificationServiceProtocol {
    var notificationPermissionStatus: AnyPublisher<UNAuthorizationStatus, Never> {
        Just(.authorized).eraseToAnyPublisher()
    }
    
    var pushNotificationSent = false
    var localNotificationScheduled = false
    
    func requestNotificationPermission() async throws -> Bool {
        return true
    }
    
    func scheduleLocalNotification(_ notification: LocalNotification) async throws {
        localNotificationScheduled = true
    }
    
    func cancelNotification(withIdentifier identifier: String) async throws {}
    
    func cancelAllNotifications() async throws {}
    
    func sendPushNotification(_ notification: PushNotification) async throws {
        pushNotificationSent = true
    }
    
    func registerForRemoteNotifications() async throws -> Data {
        return Data()
    }
    
    func handleRemoteNotification(_ userInfo: [AnyHashable: Any]) async {}
}

class MockRouteManager: RouteManager {
    var waypointAdded = false
    
    override func addWaypoint(_ destination: Destination) async throws {
        waypointAdded = true
    }
}