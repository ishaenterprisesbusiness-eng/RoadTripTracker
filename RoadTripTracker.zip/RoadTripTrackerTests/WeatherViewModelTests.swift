import XCTest
import CoreLocation
@testable import RoadTripTracker

@MainActor
final class WeatherViewModelTests: XCTestCase {
    
    var viewModel: WeatherViewModel!
    var mockWeatherService: MockWeatherService!
    var mockNotificationService: MockNotificationService!
    let testCoordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
    
    override func setUpWithError() throws {
        super.setUp()
        mockWeatherService = MockWeatherService()
        mockNotificationService = MockNotificationService()
        viewModel = WeatherViewModel(
            weatherService: mockWeatherService,
            notificationService: mockNotificationService
        )
    }
    
    override func tearDownWithError() throws {
        viewModel = nil
        mockWeatherService = nil
        mockNotificationService = nil
        super.tearDown()
    }
    
    // MARK: - Current Weather Tests
    
    func testLoadCurrentWeatherSuccess() async {
        // Given
        let expectedWeather = WeatherData(
            location: testCoordinate,
            temperature: 25.0,
            feelsLike: 27.0,
            humidity: 60.0,
            windSpeed: 10.0,
            windDirection: 180.0,
            visibility: 10.0,
            uvIndex: 5.0,
            condition: .clear,
            description: "Clear sky"
        )
        mockWeatherService.mockWeatherData = expectedWeather
        
        // When
        await viewModel.loadCurrentWeather(for: testCoordinate)
        
        // Then
        XCTAssertEqual(viewModel.currentWeather?.temperature, 25.0)
        XCTAssertEqual(viewModel.currentWeather?.condition, .clear)
        XCTAssertEqual(viewModel.currentWeather?.description, "Clear sky")
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertNil(viewModel.errorMessage)
    }
    
    func testLoadCurrentWeatherFailure() async {
        // Given
        mockWeatherService.shouldThrowError = true
        
        // When
        await viewModel.loadCurrentWeather(for: testCoordinate)
        
        // Then
        XCTAssertNil(viewModel.currentWeather)
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertTrue(viewModel.showingError)
    }
    
    func testLoadCurrentWeatherLoading() async {
        // Given
        let expectation = XCTestExpectation(description: "Loading state")
        
        // When
        Task {
            await viewModel.loadCurrentWeather(for: testCoordinate)
            expectation.fulfill()
        }
        
        // Then (check loading state briefly)
        XCTAssertTrue(viewModel.isLoading)
        
        await fulfillment(of: [expectation], timeout: 5.0)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    // MARK: - Weather Forecast Tests
    
    func testLoadWeatherForecastSuccess() async {
        // Given
        let expectedForecast = [
            WeatherData(
                location: testCoordinate,
                timestamp: Date(),
                temperature: 25.0,
                feelsLike: 27.0,
                humidity: 60.0,
                windSpeed: 10.0,
                windDirection: 180.0,
                visibility: 10.0,
                uvIndex: 5.0,
                condition: .clear,
                description: "Clear sky"
            ),
            WeatherData(
                location: testCoordinate,
                timestamp: Date().addingTimeInterval(86400),
                temperature: 23.0,
                feelsLike: 25.0,
                humidity: 65.0,
                windSpeed: 12.0,
                windDirection: 200.0,
                visibility: 8.0,
                uvIndex: 4.0,
                condition: .partlyCloudy,
                description: "Partly cloudy"
            )
        ]
        mockWeatherService.mockForecast = expectedForecast
        
        // When
        await viewModel.loadWeatherForecast(for: testCoordinate, days: 2)
        
        // Then
        XCTAssertEqual(viewModel.weatherForecast.count, 2)
        XCTAssertEqual(viewModel.weatherForecast[0].temperature, 25.0)
        XCTAssertEqual(viewModel.weatherForecast[1].temperature, 23.0)
        XCTAssertEqual(viewModel.weatherForecast[0].condition, .clear)
        XCTAssertEqual(viewModel.weatherForecast[1].condition, .partlyCloudy)
    }
    
    func testLoadWeatherForecastFailure() async {
        // Given
        mockWeatherService.shouldThrowError = true
        
        // When
        await viewModel.loadWeatherForecast(for: testCoordinate, days: 5)
        
        // Then
        XCTAssertTrue(viewModel.weatherForecast.isEmpty)
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertTrue(viewModel.showingError)
    }
    
    // MARK: - Weather Alerts Tests
    
    func testLoadWeatherAlertsSuccess() async {
        // Given
        let expectedAlerts = [
            WeatherAlert(
                title: "Thunderstorm Warning",
                description: "Severe thunderstorms expected",
                severity: .severe,
                startTime: Date(),
                endTime: Date().addingTimeInterval(3600),
                affectedArea: "San Francisco Bay Area"
            ),
            WeatherAlert(
                title: "High Wind Advisory",
                description: "Strong winds expected",
                severity: .moderate,
                startTime: Date().addingTimeInterval(1800),
                endTime: Date().addingTimeInterval(7200),
                affectedArea: "Coastal Areas"
            )
        ]
        mockWeatherService.mockAlerts = expectedAlerts
        
        // When
        await viewModel.loadWeatherAlerts(for: testCoordinate)
        
        // Then
        XCTAssertEqual(viewModel.weatherAlerts.count, 2)
        XCTAssertEqual(viewModel.weatherAlerts[0].title, "Thunderstorm Warning")
        XCTAssertEqual(viewModel.weatherAlerts[0].severity, .severe)
        XCTAssertEqual(viewModel.weatherAlerts[1].title, "High Wind Advisory")
        XCTAssertEqual(viewModel.weatherAlerts[1].severity, .moderate)
        
        // Check severe weather warnings
        XCTAssertEqual(viewModel.severeWeatherWarnings.count, 1)
        XCTAssertEqual(viewModel.severeWeatherWarnings[0].title, "Thunderstorm Warning")
    }
    
    func testLoadWeatherAlertsFailure() async {
        // Given
        mockWeatherService.shouldThrowError = true
        
        // When
        await viewModel.loadWeatherAlerts(for: testCoordinate)
        
        // Then
        XCTAssertTrue(viewModel.weatherAlerts.isEmpty)
        XCTAssertTrue(viewModel.severeWeatherWarnings.isEmpty)
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertTrue(viewModel.showingError)
    }
    
    // MARK: - Destination Weather Tests
    
    func testLoadDestinationWeatherSuccess() async {
        // Given
        let destinations = [
            Destination(
                name: "Golden Gate Bridge",
                address: "Golden Gate Bridge, San Francisco, CA",
                coordinate: CLLocationCoordinate2D(latitude: 37.8199, longitude: -122.4783),
                type: .attraction
            ),
            Destination(
                name: "Alcatraz Island",
                address: "Alcatraz Island, San Francisco, CA",
                coordinate: CLLocationCoordinate2D(latitude: 37.8267, longitude: -122.4233),
                type: .attraction
            )
        ]
        
        // When
        await viewModel.loadDestinationWeather(for: destinations)
        
        // Then
        XCTAssertEqual(viewModel.destinationWeather.count, 2)
        XCTAssertEqual(viewModel.destinationForecasts.count, 2)
        XCTAssertEqual(viewModel.destinationAlerts.count, 2)
        
        for destination in destinations {
            XCTAssertNotNil(viewModel.destinationWeather[destination.id])
            XCTAssertNotNil(viewModel.destinationForecasts[destination.id])
            XCTAssertNotNil(viewModel.destinationAlerts[destination.id])
        }
    }
    
    // MARK: - Weather Recommendations Tests
    
    func testWeatherRecommendationsRain() async {
        // Given
        let rainyWeather = WeatherData(
            location: testCoordinate,
            temperature: 20.0,
            feelsLike: 18.0,
            humidity: 85.0,
            windSpeed: 15.0,
            windDirection: 180.0,
            visibility: 5.0,
            uvIndex: 2.0,
            condition: .rain,
            description: "Heavy rain"
        )
        mockWeatherService.mockWeatherData = rainyWeather
        
        // When
        await viewModel.loadCurrentWeather(for: testCoordinate)
        
        // Then
        XCTAssertFalse(viewModel.weatherRecommendations.isEmpty)
        let drivingRecommendation = viewModel.weatherRecommendations.first { $0.type == .drivingCondition }
        XCTAssertNotNil(drivingRecommendation)
        XCTAssertEqual(drivingRecommendation?.title, "Rainy Conditions")
    }
    
    func testWeatherRecommendationsCold() async {
        // Given
        let coldWeather = WeatherData(
            location: testCoordinate,
            temperature: 2.0,
            feelsLike: -1.0,
            humidity: 70.0,
            windSpeed: 20.0,
            windDirection: 180.0,
            visibility: 10.0,
            uvIndex: 1.0,
            condition: .clear,
            description: "Cold and clear"
        )
        mockWeatherService.mockWeatherData = coldWeather
        
        // When
        await viewModel.loadCurrentWeather(for: testCoordinate)
        
        // Then
        XCTAssertFalse(viewModel.weatherRecommendations.isEmpty)
        let clothingRecommendation = viewModel.weatherRecommendations.first { $0.type == .clothing }
        XCTAssertNotNil(clothingRecommendation)
        XCTAssertEqual(clothingRecommendation?.title, "Cold Weather")
    }
    
    func testWeatherRecommendationsHot() async {
        // Given
        let hotWeather = WeatherData(
            location: testCoordinate,
            temperature: 38.0,
            feelsLike: 42.0,
            humidity: 40.0,
            windSpeed: 5.0,
            windDirection: 180.0,
            visibility: 10.0,
            uvIndex: 9.0,
            condition: .clear,
            description: "Hot and sunny"
        )
        mockWeatherService.mockWeatherData = hotWeather
        
        // When
        await viewModel.loadCurrentWeather(for: testCoordinate)
        
        // Then
        XCTAssertFalse(viewModel.weatherRecommendations.isEmpty)
        let hydrationRecommendation = viewModel.weatherRecommendations.first { $0.type == .hydration }
        XCTAssertNotNil(hydrationRecommendation)
        XCTAssertEqual(hydrationRecommendation?.title, "Hot Weather")
        
        let sunProtectionRecommendation = viewModel.weatherRecommendations.first { $0.type == .sunProtection }
        XCTAssertNotNil(sunProtectionRecommendation)
        XCTAssertEqual(sunProtectionRecommendation?.title, "High UV Index")
    }
    
    // MARK: - Weather Icon Tests
    
    func testGetWeatherIcon() {
        XCTAssertEqual(viewModel.getWeatherIcon(for: .clear), "sun.max.fill")
        XCTAssertEqual(viewModel.getWeatherIcon(for: .partlyCloudy), "cloud.sun.fill")
        XCTAssertEqual(viewModel.getWeatherIcon(for: .cloudy), "cloud.fill")
        XCTAssertEqual(viewModel.getWeatherIcon(for: .rain), "cloud.rain.fill")
        XCTAssertEqual(viewModel.getWeatherIcon(for: .snow), "cloud.snow.fill")
        XCTAssertEqual(viewModel.getWeatherIcon(for: .thunderstorm), "cloud.bolt.rain.fill")
        XCTAssertEqual(viewModel.getWeatherIcon(for: .fog), "cloud.fog.fill")
        XCTAssertEqual(viewModel.getWeatherIcon(for: .unknown), "questionmark.circle.fill")
    }
    
    // MARK: - Alert Color Tests
    
    func testGetAlertColor() {
        XCTAssertEqual(viewModel.getAlertColor(for: .minor), "blue")
        XCTAssertEqual(viewModel.getAlertColor(for: .moderate), "yellow")
        XCTAssertEqual(viewModel.getAlertColor(for: .severe), "orange")
        XCTAssertEqual(viewModel.getAlertColor(for: .extreme), "red")
    }
    
    // MARK: - Weather Stop Recommendations Tests
    
    func testWeatherStopRecommendationsThunderstorm() async {
        // Given
        let thunderstormWeather = WeatherData(
            location: testCoordinate,
            temperature: 25.0,
            feelsLike: 27.0,
            humidity: 85.0,
            windSpeed: 40.0,
            windDirection: 180.0,
            visibility: 3.0,
            uvIndex: 2.0,
            condition: .thunderstorm,
            description: "Thunderstorm"
        )
        mockWeatherService.mockWeatherData = thunderstormWeather
        
        // When
        await viewModel.loadCurrentWeather(for: testCoordinate)
        
        // Then
        XCTAssertFalse(viewModel.weatherStopRecommendations.isEmpty)
        let shelterRecommendation = viewModel.weatherStopRecommendations.first { $0.type == .shelter }
        XCTAssertNotNil(shelterRecommendation)
        XCTAssertEqual(shelterRecommendation?.priority, .high)
    }
    
    func testWeatherStopRecommendationsHeat() async {
        // Given
        let hotWeather = WeatherData(
            location: testCoordinate,
            temperature: 40.0,
            feelsLike: 45.0,
            humidity: 30.0,
            windSpeed: 5.0,
            windDirection: 180.0,
            visibility: 10.0,
            uvIndex: 10.0,
            condition: .clear,
            description: "Hot and sunny"
        )
        mockWeatherService.mockWeatherData = hotWeather
        
        // When
        await viewModel.loadCurrentWeather(for: testCoordinate)
        
        // Then
        XCTAssertFalse(viewModel.weatherStopRecommendations.isEmpty)
        let heatRecommendation = viewModel.weatherStopRecommendations.first { $0.type == .heatWarning }
        XCTAssertNotNil(heatRecommendation)
        XCTAssertEqual(heatRecommendation?.priority, .medium)
    }
    
    // MARK: - Approaching Destinations Weather Tests
    
    func testLoadWeatherForApproachingDestinations() async {
        // Given
        let currentLocation = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        let nearbyDestination = Destination(
            name: "Nearby Attraction",
            address: "123 Nearby St",
            coordinate: CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4294), // ~1.5km away
            type: .attraction
        )
        let farDestination = Destination(
            name: "Far Attraction",
            address: "456 Far St",
            coordinate: CLLocationCoordinate2D(latitude: 38.7749, longitude: -123.4194), // ~100km away
            type: .attraction
        )
        let destinations = [nearbyDestination, farDestination]
        
        // When
        await viewModel.loadWeatherForApproachingDestinations(
            destinations: destinations,
            currentLocation: currentLocation,
            proximityThreshold: 50000 // 50km
        )
        
        // Then
        XCTAssertEqual(viewModel.destinationWeather.count, 1) // Only nearby destination
        XCTAssertNotNil(viewModel.destinationWeather[nearbyDestination.id])
        XCTAssertNil(viewModel.destinationWeather[farDestination.id])
    }
    
    // MARK: - Refresh Weather Data Tests
    
    func testRefreshWeatherData() async {
        // Given
        let initialWeather = WeatherData(
            location: testCoordinate,
            temperature: 20.0,
            feelsLike: 22.0,
            humidity: 50.0,
            windSpeed: 8.0,
            windDirection: 180.0,
            visibility: 10.0,
            uvIndex: 3.0,
            condition: .clear,
            description: "Clear sky"
        )
        mockWeatherService.mockWeatherData = initialWeather
        
        // When
        await viewModel.refreshWeatherData(for: testCoordinate)
        
        // Then
        XCTAssertNotNil(viewModel.currentWeather)
        XCTAssertFalse(viewModel.weatherForecast.isEmpty)
        XCTAssertFalse(viewModel.isLoading)
    }
}

// MARK: - Mock Notification Service
class MockNotificationService: NotificationServiceProtocol {
    var sentNotifications: [String] = []
    
    func requestPermission() async throws -> Bool {
        return true
    }
    
    func sendNotification(title: String, body: String, userInfo: [AnyHashable: Any]) async throws {
        sentNotifications.append("\(title): \(body)")
    }
    
    func scheduleNotification(title: String, body: String, trigger: UNNotificationTrigger, userInfo: [AnyHashable: Any]) async throws {
        sentNotifications.append("Scheduled: \(title): \(body)")
    }
    
    func cancelNotification(withIdentifier identifier: String) {
        // Mock implementation
    }
    
    func cancelAllNotifications() {
        sentNotifications.removeAll()
    }
    
    func getPendingNotifications() async -> [UNNotificationRequest] {
        return []
    }
}