import XCTest
import SwiftUI
@testable import RoadTripTracker

// MARK: - Glassmorphic Design System Tests
class GlasmorphicDesignSystemTests: XCTestCase {
    
    // MARK: - Haptic System Tests
    func testHapticSystemInitialization() {
        let hapticSystem = AdvancedHapticSystem()
        XCTAssertNotNil(hapticSystem, "Haptic system should initialize successfully")
    }
    
    func testHapticTypes() {
        let hapticSystem = AdvancedHapticSystem()
        
        // Test that all haptic types can be played without crashing
        XCTAssertNoThrow(hapticSystem.playHaptic(.glassTouch))
        XCTAssertNoThrow(hapticSystem.playHaptic(.glassPress))
        XCTAssertNoThrow(hapticSystem.playHaptic(.glassSlide))
        XCTAssertNoThrow(hapticSystem.playHaptic(.glassShatter))
        XCTAssertNoThrow(hapticSystem.playHaptic(.glassChime))
    }
    
    // MARK: - Adaptive Lighting System Tests
    func testAdaptiveLightingSystemInitialization() {
        let lightingSystem = AdaptiveLightingSystem()
        XCTAssertNotNil(lightingSystem, "Lighting system should initialize successfully")
        XCTAssertEqual(lightingSystem.currentCondition, .normal, "Should start with normal lighting condition")
    }
    
    func testLightingConditionProperties() {
        let brightCondition = AdvancedMaterialSystem.LightingCondition.bright
        let darkCondition = AdvancedMaterialSystem.LightingCondition.dark
        
        XCTAssertLessThan(brightCondition.adaptiveOpacity, darkCondition.adaptiveOpacity, "Bright condition should have lower opacity than dark")
        XCTAssertGreaterThan(brightCondition.borderOpacity, darkCondition.borderOpacity, "Bright condition should have higher border opacity than dark")
    }
    
    func testForceLightingUpdate() {
        let lightingSystem = AdaptiveLightingSystem()
        
        lightingSystem.forceUpdate(to: .bright)
        XCTAssertEqual(lightingSystem.currentCondition, .bright, "Should update to bright condition")
        
        lightingSystem.forceUpdate(to: .veryDark)
        XCTAssertEqual(lightingSystem.currentCondition, .veryDark, "Should update to very dark condition")
    }
    
    // MARK: - Material System Tests
    func testMaterialTypeProperties() {
        let ultraThin = AdvancedMaterialSystem.MaterialType.ultraThin
        let ultraThick = AdvancedMaterialSystem.MaterialType.ultraThick
        
        XCTAssertLessThan(ultraThin.blurRadius, ultraThick.blurRadius, "Ultra thin should have less blur than ultra thick")
        XCTAssertLessThan(ultraThin.opacity, ultraThick.opacity, "Ultra thin should have less opacity than ultra thick")
    }
    
    func testAllMaterialTypes() {
        let materialTypes: [AdvancedMaterialSystem.MaterialType] = [
            .ultraThin, .thin, .regular, .thick, .ultraThick
        ]
        
        for (index, materialType) in materialTypes.enumerated() {
            XCTAssertGreaterThan(materialType.blurRadius, 0, "Material type \(materialType) should have positive blur radius")
            XCTAssertGreaterThan(materialType.opacity, 0, "Material type \(materialType) should have positive opacity")
            XCTAssertLessThanOrEqual(materialType.opacity, 1, "Material type \(materialType) should have opacity <= 1")
            
            // Test that blur radius increases with material thickness
            if index > 0 {
                let previousType = materialTypes[index - 1]
                XCTAssertGreaterThanOrEqual(materialType.blurRadius, previousType.blurRadius, "Thicker materials should have equal or greater blur radius")
            }
        }
    }
    
    // MARK: - Animation System Tests
    func testFluidAnimationSystem() {
        // Test that all animation types are properly configured
        XCTAssertNotNil(FluidAnimationSystem.glassSpring, "Glass spring animation should be configured")
        XCTAssertNotNil(FluidAnimationSystem.quickSpring, "Quick spring animation should be configured")
        XCTAssertNotNil(FluidAnimationSystem.smoothSpring, "Smooth spring animation should be configured")
        XCTAssertNotNil(FluidAnimationSystem.elasticSpring, "Elastic spring animation should be configured")
        
        XCTAssertNotNil(FluidAnimationSystem.glassEaseIn, "Glass ease in animation should be configured")
        XCTAssertNotNil(FluidAnimationSystem.glassEaseOut, "Glass ease out animation should be configured")
        XCTAssertNotNil(FluidAnimationSystem.glassEaseInOut, "Glass ease in out animation should be configured")
    }
    
    // MARK: - Configuration Tests
    func testGlasmorphicConfig() {
        XCTAssertGreaterThan(GlasmorphicConfig.cornerRadius, 0, "Corner radius should be positive")
        XCTAssertGreaterThan(GlasmorphicConfig.borderWidth, 0, "Border width should be positive")
        XCTAssertGreaterThan(GlasmorphicConfig.shadowRadius, 0, "Shadow radius should be positive")
        XCTAssertGreaterThan(GlasmorphicConfig.animationDuration, 0, "Animation duration should be positive")
        XCTAssertGreaterThan(GlasmorphicConfig.springResponse, 0, "Spring response should be positive")
        XCTAssertGreaterThan(GlasmorphicConfig.springDamping, 0, "Spring damping should be positive")
        XCTAssertLessThanOrEqual(GlasmorphicConfig.springDamping, 1, "Spring damping should be <= 1")
    }
    
    // MARK: - Button Style Tests
    func testFluidGlassButtonStyles() {
        let styles: [FluidGlassButton.ButtonStyle] = [
            .primary, .secondary, .destructive, .ghost, .success
        ]
        
        for style in styles {
            XCTAssertNotNil(style.colors, "Button style \(style) should have colors defined")
            XCTAssertNotNil(style.textColor, "Button style \(style) should have text color defined")
            XCTAssertNotNil(style.glowColor, "Button style \(style) should have glow color defined")
            XCTAssertFalse(style.colors.isEmpty, "Button style \(style) should have at least one color")
        }
    }
    
    // MARK: - Integration Tests
    func testComponentIntegration() {
        // Test that components can be created without crashing
        let lightingSystem = AdaptiveLightingSystem()
        let hapticSystem = AdvancedHapticSystem()
        
        XCTAssertNotNil(lightingSystem, "Lighting system should be created successfully")
        XCTAssertNotNil(hapticSystem, "Haptic system should be created successfully")
        
        // Test that systems can work together
        lightingSystem.forceUpdate(to: .bright)
        hapticSystem.playHaptic(.glassTouch)
        
        // Should not crash when used together
        XCTAssertEqual(lightingSystem.currentCondition, .bright, "Lighting system should maintain state while haptic system is used")
    }
    
    // MARK: - Performance Tests
    func testHapticSystemPerformance() {
        let hapticSystem = AdvancedHapticSystem()
        
        measure {
            for _ in 0..<10 {
                hapticSystem.playHaptic(.glassTouch)
            }
        }
    }
    
    func testLightingSystemPerformance() {
        let lightingSystem = AdaptiveLightingSystem()
        
        measure {
            for condition in [AdvancedMaterialSystem.LightingCondition.bright, .normal, .dark, .veryDark] {
                lightingSystem.forceUpdate(to: condition)
            }
        }
    }
    
    // MARK: - Edge Case Tests
    func testLightingSystemEdgeCases() {
        let lightingSystem = AdaptiveLightingSystem()
        
        // Test rapid condition changes
        for _ in 0..<100 {
            let randomCondition = [AdvancedMaterialSystem.LightingCondition.bright, .normal, .dark, .veryDark].randomElement()!
            lightingSystem.forceUpdate(to: randomCondition)
        }
        
        // Should not crash and should maintain valid state
        XCTAssertTrue([AdvancedMaterialSystem.LightingCondition.bright, .normal, .dark, .veryDark].contains(lightingSystem.currentCondition), "Should maintain valid lighting condition")
    }
    
    func testMaterialTypeEdgeCases() {
        // Test all material types have valid properties
        let allTypes: [AdvancedMaterialSystem.MaterialType] = [.ultraThin, .thin, .regular, .thick, .ultraThick]
        
        for materialType in allTypes {
            XCTAssertGreaterThan(materialType.blurRadius, 0, "Blur radius should be positive for \(materialType)")
            XCTAssertGreaterThan(materialType.opacity, 0, "Opacity should be positive for \(materialType)")
            XCTAssertLessThanOrEqual(materialType.opacity, 1, "Opacity should not exceed 1 for \(materialType)")
            XCTAssertLessThan(materialType.blurRadius, 100, "Blur radius should be reasonable for \(materialType)")
        }
    }
    
    // MARK: - Accessibility Tests
    func testAccessibilityCompliance() {
        // Test that the design system respects accessibility settings
        let lightingSystem = AdaptiveLightingSystem()
        
        // Test that opacity values are within accessible ranges
        for condition in [AdvancedMaterialSystem.LightingCondition.bright, .normal, .dark, .veryDark] {
            XCTAssertGreaterThanOrEqual(condition.adaptiveOpacity, 0.5, "Opacity should be high enough for accessibility in \(condition)")
            XCTAssertLessThanOrEqual(condition.adaptiveOpacity, 1.0, "Opacity should not exceed 1.0 in \(condition)")
        }
    }
    
    // MARK: - Memory Management Tests
    func testMemoryManagement() {
        weak var weakLightingSystem: AdaptiveLightingSystem?
        weak var weakHapticSystem: AdvancedHapticSystem?
        
        autoreleasepool {
            let lightingSystem = AdaptiveLightingSystem()
            let hapticSystem = AdvancedHapticSystem()
            
            weakLightingSystem = lightingSystem
            weakHapticSystem = hapticSystem
            
            // Use the systems
            lightingSystem.forceUpdate(to: .bright)
            hapticSystem.playHaptic(.glassTouch)
        }
        
        // Systems should be deallocated when no longer referenced
        // Note: This test might be flaky due to timing, but it's good to have
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            XCTAssertNil(weakLightingSystem, "Lighting system should be deallocated")
            XCTAssertNil(weakHapticSystem, "Haptic system should be deallocated")
        }
    }
}