import XCTest
import CoreLocation
@testable import RoadTripTracker

class AccommodationServiceTests: XCTestCase {
    var accommodationService: AccommodationService!
    var mockPlacesService: MockPlacesService!
    var mockDistanceService: MockDistanceCalculationService!
    
    override func setUpWithError() throws {
        mockPlacesService = MockPlacesService()
        mockDistanceService = MockDistanceCalculationService()
        accommodationService = AccommodationService(
            placesService: mockPlacesService,
            distanceCalculationService: mockDistanceService
        )
    }
    
    override func tearDownWithError() throws {
        accommodationService = nil
        mockPlacesService = nil
        mockDistanceService = nil
    }
    
    // MARK: - Search Accommodations Tests
    
    func testSearchAccommodationsNearLocation() async throws {
        // Given
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        let radius = 10000.0 // 10km
        let filters = AccommodationSearchFilters(types: [.hotel])
        
        let mockPlaces = [
            PlaceSearchResult(
                id: "hotel1",
                name: "Test Hotel",
                address: "123 Test St",
                coordinate: coordinate,
                category: .hotel
            )
        ]
        
        mockPlacesService.mockSearchResults = mockPlaces
        
        // When
        let accommodations = try await accommodationService.searchAccommodations(
            near: coordinate,
            radius: radius,
            filters: filters
        )
        
        // Then
        XCTAssertEqual(accommodations.count, 1)
        XCTAssertEqual(accommodations.first?.name, "Test Hotel")
        XCTAssertEqual(accommodations.first?.type, .hotel)
    }
    
    func testSearchAccommodationsWithMultipleTypes() async throws {
        // Given
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        let radius = 10000.0
        let filters = AccommodationSearchFilters(types: [.hotel, .motel])
        
        let mockPlaces = [
            PlaceSearchResult(id: "hotel1", name: "Test Hotel", address: "123 Test St", coordinate: coordinate, category: .hotel),
            PlaceSearchResult(id: "motel1", name: "Test Motel", address: "456 Test Ave", coordinate: coordinate, category: .hotel)
        ]
        
        mockPlacesService.mockSearchResults = mockPlaces
        
        // When
        let accommodations = try await accommodationService.searchAccommodations(
            near: coordinate,
            radius: radius,
            filters: filters
        )
        
        // Then
        XCTAssertEqual(accommodations.count, 2)
    }
    
    func testSearchAccommodationsWithFilters() async throws {
        // Given
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        let radius = 10000.0
        var filters = AccommodationSearchFilters(types: [.hotel])
        filters.minRating = 4.0
        filters.maxDistance = 5.0 // 5km
        
        let mockPlaces = [
            PlaceSearchResult(id: "hotel1", name: "Test Hotel", address: "123 Test St", coordinate: coordinate, category: .hotel)
        ]
        
        mockPlacesService.mockSearchResults = mockPlaces
        
        // When
        let accommodations = try await accommodationService.searchAccommodations(
            near: coordinate,
            radius: radius,
            filters: filters
        )
        
        // Then
        XCTAssertTrue(accommodations.allSatisfy { $0.rating ?? 0 >= 4.0 })
        XCTAssertTrue(accommodations.allSatisfy { $0.distance ?? 0 <= 5.0 })
    }
    
    func testSearchAccommodationsAlongRoute() async throws {
        // Given
        let route = [
            CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094),
            CLLocationCoordinate2D(latitude: 37.7949, longitude: -122.3994)
        ]
        let filters = AccommodationSearchFilters(types: [.hotel])
        
        let mockPlaces = [
            PlaceSearchResult(id: "hotel1", name: "Route Hotel 1", address: "123 Route St", coordinate: route[0], category: .hotel),
            PlaceSearchResult(id: "hotel2", name: "Route Hotel 2", address: "456 Route Ave", coordinate: route[1], category: .hotel)
        ]
        
        mockPlacesService.mockSearchResults = mockPlaces
        
        // When
        let accommodations = try await accommodationService.searchAccommodationsAlongRoute(
            route: route,
            filters: filters
        )
        
        // Then
        XCTAssertGreaterThanOrEqual(accommodations.count, 0)
    }
    
    func testSearchAccommodationsEmptyRoute() async {
        // Given
        let emptyRoute: [CLLocationCoordinate2D] = []
        let filters = AccommodationSearchFilters()
        
        // When/Then
        do {
            _ = try await accommodationService.searchAccommodationsAlongRoute(route: emptyRoute, filters: filters)
            XCTFail("Should throw invalid location error")
        } catch AccommodationServiceError.invalidLocation {
            // Expected
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    // MARK: - Availability Tests
    
    func testCheckAvailability() async throws {
        // Given
        let accommodationId = "test-hotel"
        let checkIn = Date()
        let checkOut = Date().addingTimeInterval(86400) // Next day
        let guests = 2
        
        // When
        let availability = try await accommodationService.checkAvailability(
            accommodationId: accommodationId,
            checkIn: checkIn,
            checkOut: checkOut,
            guests: guests
        )
        
        // Then
        XCTAssertEqual(availability.checkInDate, checkIn)
        XCTAssertEqual(availability.checkOutDate, checkOut)
        XCTAssertEqual(availability.currency, "USD")
    }
    
    func testCheckAvailabilityInvalidDateRange() async {
        // Given
        let accommodationId = "test-hotel"
        let checkIn = Date()
        let checkOut = Date().addingTimeInterval(-86400) // Previous day (invalid)
        let guests = 2
        
        // When/Then
        do {
            _ = try await accommodationService.checkAvailability(
                accommodationId: accommodationId,
                checkIn: checkIn,
                checkOut: checkOut,
                guests: guests
            )
            XCTFail("Should throw invalid date range error")
        } catch AccommodationServiceError.invalidDateRange {
            // Expected
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    // MARK: - Booking Info Tests
    
    func testGetBookingInfo() async throws {
        // Given
        let accommodationId = "test-hotel"
        
        // When
        let bookingInfo = try await accommodationService.getBookingInfo(accommodationId: accommodationId)
        
        // Then
        XCTAssertEqual(bookingInfo.accommodationId, accommodationId)
        XCTAssertTrue(bookingInfo.directBookingAvailable)
        XCTAssertFalse(bookingInfo.bookingPlatforms.isEmpty)
        XCTAssertFalse(bookingInfo.paymentMethods.isEmpty)
    }
    
    // MARK: - Add to Trip Tests
    
    func testAddAccommodationToTrip() async throws {
        // Given
        let accommodation = Accommodation(
            id: "test-hotel",
            name: "Test Hotel",
            address: "123 Test St",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            type: .hotel
        )
        
        let trip = Trip(
            name: "Test Trip",
            code: "TEST123",
            createdBy: UUID(),
            destinations: []
        )
        
        // When
        let updatedTrip = try await accommodationService.addAccommodationToTrip(
            accommodation: accommodation,
            trip: trip
        )
        
        // Then
        XCTAssertEqual(updatedTrip.destinations.count, 1)
        XCTAssertEqual(updatedTrip.destinations.first?.name, "Test Hotel")
        XCTAssertEqual(updatedTrip.destinations.first?.type, .accommodation)
    }
}

// MARK: - Mock Services

class MockPlacesService: PlacesServiceProtocol {
    var mockSearchResults: [PlaceSearchResult] = []
    var shouldThrowError = false
    
    func searchPlaces(query: String, region: MKCoordinateRegion?) async throws -> [PlaceSearchResult] {
        if shouldThrowError {
            throw PlacesServiceError.searchFailed("Mock error")
        }
        return mockSearchResults
    }
    
    func getPlaceDetails(for placeId: String) async throws -> PlaceDetails {
        throw PlacesServiceError.notImplemented
    }
    
    func getNearbyPlaces(coordinate: CLLocationCoordinate2D, radius: Double, category: PlaceCategory) async throws -> [PlaceSearchResult] {
        if shouldThrowError {
            throw PlacesServiceError.searchFailed("Mock error")
        }
        return mockSearchResults
    }
}

class MockDistanceCalculationService {
    func calculateDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> Double {
        // Return a mock distance in kilometers
        return 5.0
    }
}