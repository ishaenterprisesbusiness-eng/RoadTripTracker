import XCTest
import Combine
@testable import RoadTripTracker

@MainActor
final class TripJoinViewModelTests: XCTestCase {
    var viewModel: TripJoinViewModel!
    var mockTripService: MockTripService!
    var cancellables: Set<AnyCancellable>!
    
    override func setUp() {
        super.setUp()
        mockTripService = MockTripService()
        viewModel = TripJoinViewModel(tripService: mockTripService)
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDown() {
        viewModel = nil
        mockTripService = nil
        cancellables = nil
        super.tearDown()
    }
    
    func testJoinTripSuccess() async {
        // Given
        let tripCode = "ABC123"
        let expectedTrip = Trip(
            name: "Test Trip",
            code: tripCode,
            createdBy: UUID()
        )
        mockTripService.joinTripResult = .success(expectedTrip)
        
        // When
        await viewModel.joinTrip(code: tripCode)
        
        // Then
        XCTAssertEqual(viewModel.joinedTrip?.code, tripCode)
        XCTAssertEqual(viewModel.joinedTrip?.name, "Test Trip")
        XCTAssertNil(viewModel.errorMessage)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    func testJoinTripInvalidCode() async {
        // Given
        let tripCode = "INVALID"
        mockTripService.joinTripResult = .failure(TripServiceError.invalidTripCode)
        
        // When
        await viewModel.joinTrip(code: tripCode)
        
        // Then
        XCTAssertNil(viewModel.joinedTrip)
        XCTAssertEqual(viewModel.errorMessage, TripServiceError.invalidTripCode.errorDescription)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    func testJoinTripTripNotFound() async {
        // Given
        let tripCode = "NOTFOUND"
        mockTripService.joinTripResult = .failure(TripServiceError.tripNotFound)
        
        // When
        await viewModel.joinTrip(code: tripCode)
        
        // Then
        XCTAssertNil(viewModel.joinedTrip)
        XCTAssertEqual(viewModel.errorMessage, TripServiceError.tripNotFound.errorDescription)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    func testJoinTripAlreadyParticipant() async {
        // Given
        let tripCode = "ABC123"
        mockTripService.joinTripResult = .failure(TripServiceError.alreadyParticipant)
        
        // When
        await viewModel.joinTrip(code: tripCode)
        
        // Then
        XCTAssertNil(viewModel.joinedTrip)
        XCTAssertEqual(viewModel.errorMessage, TripServiceError.alreadyParticipant.errorDescription)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    func testLoadingStatesDuringJoinTrip() async {
        // Given
        let tripCode = "ABC123"
        let expectedTrip = Trip(
            name: "Test Trip",
            code: tripCode,
            createdBy: UUID()
        )
        mockTripService.joinTripResult = .success(expectedTrip)
        mockTripService.joinTripDelay = 0.1 // Add small delay to test loading state
        
        // When
        let joinTask = Task {
            await viewModel.joinTrip(code: tripCode)
        }
        
        // Then - Check loading state is true during operation
        try? await Task.sleep(nanoseconds: 50_000_000) // 0.05 seconds
        XCTAssertTrue(viewModel.isLoading)
        
        // Wait for completion
        await joinTask.value
        
        // Then - Check loading state is false after completion
        XCTAssertFalse(viewModel.isLoading)
        XCTAssertNotNil(viewModel.joinedTrip)
    }
}

// MARK: - Mock Trip Service
class MockTripService: TripServiceProtocol {
    var activeTrip: Trip?
    var tripUpdates: AnyPublisher<Trip?, Never> {
        Just(activeTrip).eraseToAnyPublisher()
    }
    
    var joinTripResult: Result<Trip, Error> = .failure(TripServiceError.tripNotFound)
    var joinTripDelay: TimeInterval = 0
    
    func createTrip(name: String, destinations: [Destination], settings: TripSettings) async throws -> Trip {
        throw TripServiceError.unknown("Not implemented in mock")
    }
    
    func joinTrip(code: String) async throws -> Trip {
        if joinTripDelay > 0 {
            try await Task.sleep(nanoseconds: UInt64(joinTripDelay * 1_000_000_000))
        }
        
        switch joinTripResult {
        case .success(let trip):
            activeTrip = trip
            return trip
        case .failure(let error):
            throw error
        }
    }
    
    func leaveTrip(_ tripId: UUID) async throws {
        activeTrip = nil
    }
    
    func updateTrip(_ trip: Trip) async throws {
        activeTrip = trip
    }
    
    func deleteTrip(_ tripId: UUID) async throws {
        if activeTrip?.id == tripId {
            activeTrip = nil
        }
    }
    
    func generateTripCode() -> String {
        return "ABC123"
    }
    
    func validateTripCode(_ code: String) async throws -> Bool {
        return code == "ABC123"
    }
    
    func getTripHistory(for userId: UUID) async throws -> [Trip] {
        return []
    }
    
    func optimizeRoute(destinations: [Destination]) async throws -> [Destination] {
        return destinations
    }
    
    func addDestination(_ destination: Destination, to tripId: UUID) async throws {
        // Mock implementation
    }
    
    func removeDestination(_ destinationId: UUID, from tripId: UUID) async throws {
        // Mock implementation
    }
    
    func reorderDestinations(_ destinations: [Destination], in tripId: UUID) async throws {
        // Mock implementation
    }
}