import XCTest
import CoreLocation
import Combine
@testable import RoadTripTracker

final class FoodStopServiceTests: XCTestCase {
    var foodStopService: FoodStopService!
    var mockPlacesService: MockPlacesService!
    var mockNotificationService: MockNotificationService!
    var mockRouteManager: MockRouteManager!
    var cancellables: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        mockPlacesService = MockPlacesService()
        mockNotificationService = MockNotificationService()
        mockRouteManager = MockRouteManager()
        foodStopService = FoodStopService(
            placesService: mockPlacesService,
            notificationService: mockNotificationService,
            routeManager: mockRouteManager
        )
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDownWithError() throws {
        foodStopService = nil
        mockPlacesService = nil
        mockNotificationService = nil
        mockRouteManager = nil
        cancellables = nil
    }
    
    // MARK: - Restaurant Discovery Tests
    
    func testFindNearbyRestaurants() async throws {
        // Given
        let coordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        let radius: Double = 5000
        
        let mockPlaces = [
            PlaceSearchResult(
                id: "1",
                name: "Italian Bistro",
                address: "123 Main St",
                coordinate: coordinate,
                category: .restaurant,
                rating: 4.5,
                priceLevel: 3
            )
        ]
        
        mockPlacesService.mockNearbyPlaces = mockPlaces
        
        // When
        let restaurants = try await foodStopService.findNearbyRestaurants(
            coordinate: coordinate,
            radius: radius,
            cuisineFilter: nil
        )
        
        // Then
        XCTAssertEqual(restaurants.count, 1)
        XCTAssertEqual(restaurants.first?.name, "Italian Bistro")
        XCTAssertEqual(restaurants.first?.address, "123 Main St")
        XCTAssertEqual(restaurants.first?.rating, 4.5)
        XCTAssertEqual(restaurants.first?.priceLevel, 3)
    }
    
    func testFindRestaurantsAlongRoute() async throws {
        // Given
        let route = [
            CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094)
        ]
        let searchRadius: Double = 2000
        
        let mockPlaces = [
            PlaceSearchResult(
                id: "1",
                name: "Roadside Diner",
                address: "456 Route St",
                coordinate: route[0],
                category: .restaurant,
                rating: 4.0
            )
        ]
        
        mockPlacesService.mockNearbyPlaces = mockPlaces
        
        // When
        let restaurants = try await foodStopService.findRestaurantsAlongRoute(
            route: route,
            searchRadius: searchRadius,
            cuisineFilter: .american
        )
        
        // Then
        XCTAssertEqual(restaurants.count, 1)
        XCTAssertEqual(restaurants.first?.name, "Roadside Diner")
        XCTAssertNotNil(restaurants.first?.distanceFromRoute)
    }
    
    // MARK: - Food Stop Proposal Tests
    
    func testProposeFoodStop() async throws {
        // Given
        let restaurant = Restaurant(
            id: "test-restaurant",
            name: "Test Restaurant",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            cuisine: .italian,
            rating: 4.2
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let notes = "Great Italian food"
        
        var receivedFoodStop: FoodStop?
        
        foodStopService.foodStopUpdates
            .sink { foodStop in
                receivedFoodStop = foodStop
            }
            .store(in: &cancellables)
        
        // When
        let foodStop = try await foodStopService.proposeFoodStop(
            restaurant: restaurant,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: notes
        )
        
        // Then
        XCTAssertEqual(foodStop.tripId, tripId)
        XCTAssertEqual(foodStop.proposedBy, proposedBy)
        XCTAssertEqual(foodStop.restaurant.name, "Test Restaurant")
        XCTAssertEqual(foodStop.restaurant.cuisine, .italian)
        XCTAssertEqual(foodStop.notes, notes)
        XCTAssertEqual(foodStop.proposalStatus, .pending)
        XCTAssertTrue(foodStop.approvals.isEmpty)
        XCTAssertTrue(foodStop.rejections.isEmpty)
        XCTAssertTrue(foodStop.orders.isEmpty)
        
        // Verify notification was sent
        XCTAssertTrue(mockNotificationService.pushNotificationSent)
        
        // Verify update was published
        XCTAssertNotNil(receivedFoodStop)
        XCTAssertEqual(receivedFoodStop?.id, foodStop.id)
    }
    
    func testApproveFoodStop() async throws {
        // Given
        let restaurant = Restaurant(
            id: "test-restaurant",
            name: "Test Restaurant",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let participantId = UUID()
        
        let foodStop = try await foodStopService.proposeFoodStop(
            restaurant: restaurant,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: nil
        )
        
        var receivedUpdates: [FoodStop] = []
        
        foodStopService.foodStopUpdates
            .sink { update in
                receivedUpdates.append(update)
            }
            .store(in: &cancellables)
        
        // When
        try await foodStopService.approveFoodStop(
            foodStopId: foodStop.id,
            participantId: participantId
        )
        
        // Add another approval to reach threshold
        let secondParticipant = UUID()
        try await foodStopService.approveFoodStop(
            foodStopId: foodStop.id,
            participantId: secondParticipant
        )
        
        // Then
        let finalUpdate = receivedUpdates.last
        XCTAssertNotNil(finalUpdate)
        XCTAssertEqual(finalUpdate?.proposalStatus, .approved)
        XCTAssertTrue(finalUpdate?.approvals.contains(participantId) ?? false)
        XCTAssertTrue(finalUpdate?.approvals.contains(secondParticipant) ?? false)
        
        // Verify route was updated
        XCTAssertTrue(mockRouteManager.waypointAdded)
    }
    
    func testRejectFoodStop() async throws {
        // Given
        let restaurant = Restaurant(
            id: "test-restaurant",
            name: "Test Restaurant",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let participantId = UUID()
        
        let foodStop = try await foodStopService.proposeFoodStop(
            restaurant: restaurant,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: nil
        )
        
        var receivedUpdates: [FoodStop] = []
        
        foodStopService.foodStopUpdates
            .sink { update in
                receivedUpdates.append(update)
            }
            .store(in: &cancellables)
        
        // When
        try await foodStopService.rejectFoodStop(
            foodStopId: foodStop.id,
            participantId: participantId,
            reason: "Too expensive"
        )
        
        // Add another rejection to reach threshold
        let secondParticipant = UUID()
        try await foodStopService.rejectFoodStop(
            foodStopId: foodStop.id,
            participantId: secondParticipant,
            reason: nil
        )
        
        // Then
        let finalUpdate = receivedUpdates.last
        XCTAssertNotNil(finalUpdate)
        XCTAssertEqual(finalUpdate?.proposalStatus, .rejected)
        XCTAssertTrue(finalUpdate?.rejections.contains(participantId) ?? false)
        XCTAssertTrue(finalUpdate?.rejections.contains(secondParticipant) ?? false)
    }
    
    // MARK: - Order Management Tests
    
    func testPlaceOrder() async throws {
        // Given
        let restaurant = Restaurant(
            id: "test-restaurant",
            name: "Test Restaurant",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let participantId = UUID()
        
        var foodStop = try await foodStopService.proposeFoodStop(
            restaurant: restaurant,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: nil
        )
        
        // Approve the food stop first
        try await foodStopService.approveFoodStop(foodStopId: foodStop.id, participantId: UUID())
        try await foodStopService.approveFoodStop(foodStopId: foodStop.id, participantId: UUID())
        
        let orderItems = [
            OrderItem(name: "Pasta", quantity: 1, price: 15.99),
            OrderItem(name: "Salad", quantity: 1, price: 8.99)
        ]
        let specialInstructions = "No onions please"
        
        var receivedOrder: FoodOrder?
        
        foodStopService.orderUpdates
            .sink { order in
                receivedOrder = order
            }
            .store(in: &cancellables)
        
        // When
        let order = try await foodStopService.placeOrder(
            foodStopId: foodStop.id,
            participantId: participantId,
            items: orderItems,
            specialInstructions: specialInstructions
        )
        
        // Then
        XCTAssertEqual(order.participantId, participantId)
        XCTAssertEqual(order.orderStatus, .placed)
        XCTAssertEqual(order.items.count, 2)
        XCTAssertEqual(order.items[0].name, "Pasta")
        XCTAssertEqual(order.items[1].name, "Salad")
        XCTAssertEqual(order.specialInstructions, specialInstructions)
        XCTAssertEqual(order.totalCost, 24.98)
        XCTAssertNotNil(order.estimatedReadyTime)
        XCTAssertFalse(order.isReadyToContinue)
        
        // Verify order update was published
        XCTAssertNotNil(receivedOrder)
        XCTAssertEqual(receivedOrder?.id, order.id)
        
        // Verify food stop was updated to active
        let foodStops = try await foodStopService.getFoodStopsForTrip(tripId: tripId)
        let updatedFoodStop = foodStops.first { $0.id == foodStop.id }
        XCTAssertEqual(updatedFoodStop?.proposalStatus, .active)
        XCTAssertNotNil(updatedFoodStop?.actualArrivalTime)
        XCTAssertEqual(updatedFoodStop?.orders.count, 1)
    }
    
    func testUpdateOrderStatus() async throws {
        // Given
        let restaurant = Restaurant(
            id: "test-restaurant",
            name: "Test Restaurant",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let participantId = UUID()
        
        let foodStop = try await foodStopService.proposeFoodStop(
            restaurant: restaurant,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: nil
        )
        
        // Approve and place order first
        try await foodStopService.approveFoodStop(foodStopId: foodStop.id, participantId: UUID())
        try await foodStopService.approveFoodStop(foodStopId: foodStop.id, participantId: UUID())
        
        let order = try await foodStopService.placeOrder(
            foodStopId: foodStop.id,
            participantId: participantId,
            items: [OrderItem(name: "Burger", quantity: 1, price: 12.99)],
            specialInstructions: nil
        )
        
        var receivedOrderUpdates: [FoodOrder] = []
        
        foodStopService.orderUpdates
            .sink { orderUpdate in
                receivedOrderUpdates.append(orderUpdate)
            }
            .store(in: &cancellables)
        
        // When
        try await foodStopService.updateOrderStatus(
            orderId: order.id,
            status: .preparing,
            estimatedReadyTime: Date().addingTimeInterval(600) // 10 minutes
        )
        
        try await foodStopService.markOrderReady(orderId: order.id)
        
        // Then
        XCTAssertEqual(receivedOrderUpdates.count, 2)
        
        let preparingUpdate = receivedOrderUpdates[0]
        XCTAssertEqual(preparingUpdate.orderStatus, .preparing)
        XCTAssertNotNil(preparingUpdate.estimatedReadyTime)
        
        let readyUpdate = receivedOrderUpdates[1]
        XCTAssertEqual(readyUpdate.orderStatus, .ready)
        XCTAssertNotNil(readyUpdate.actualReadyTime)
        
        // Verify notification was sent for ready status
        XCTAssertTrue(mockNotificationService.pushNotificationSent)
    }
    
    func testMarkReadyToContinue() async throws {
        // Given
        let restaurant = Restaurant(
            id: "test-restaurant",
            name: "Test Restaurant",
            address: "789 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        let tripId = UUID()
        let proposedBy = UUID()
        let participantId = UUID()
        
        let foodStop = try await foodStopService.proposeFoodStop(
            restaurant: restaurant,
            tripId: tripId,
            proposedBy: proposedBy,
            notes: nil
        )
        
        // Approve and place order first
        try await foodStopService.approveFoodStop(foodStopId: foodStop.id, participantId: UUID())
        try await foodStopService.approveFoodStop(foodStopId: foodStop.id, participantId: UUID())
        
        try await foodStopService.placeOrder(
            foodStopId: foodStop.id,
            participantId: participantId,
            items: [OrderItem(name: "Pizza", quantity: 1, price: 18.99)],
            specialInstructions: nil
        )
        
        // When
        try await foodStopService.markReadyToContinue(
            foodStopId: foodStop.id,
            participantId: participantId
        )
        
        // Then
        let foodStops = try await foodStopService.getFoodStopsForTrip(tripId: tripId)
        let updatedFoodStop = foodStops.first { $0.id == foodStop.id }
        
        XCTAssertNotNil(updatedFoodStop)
        
        let order = updatedFoodStop?.orders.first { $0.participantId == participantId }
        XCTAssertTrue(order?.isReadyToContinue ?? false)
        
        // Since only one participant, food stop should be completed
        XCTAssertEqual(updatedFoodStop?.proposalStatus, .completed)
    }
    
    // MARK: - Data Retrieval Tests
    
    func testGetFoodStopsForTrip() async throws {
        // Given
        let tripId = UUID()
        let otherTripId = UUID()
        
        let restaurant1 = Restaurant(
            id: "restaurant-1",
            name: "Restaurant 1",
            address: "Address 1",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        
        let restaurant2 = Restaurant(
            id: "restaurant-2",
            name: "Restaurant 2",
            address: "Address 2",
            coordinate: CLLocationCoordinate2D(latitude: 37.7849, longitude: -122.4094)
        )
        
        // Create food stops for different trips
        let foodStop1 = try await foodStopService.proposeFoodStop(
            restaurant: restaurant1,
            tripId: tripId,
            proposedBy: UUID(),
            notes: nil
        )
        
        let foodStop2 = try await foodStopService.proposeFoodStop(
            restaurant: restaurant2,
            tripId: otherTripId,
            proposedBy: UUID(),
            notes: nil
        )
        
        // When
        let foodStops = try await foodStopService.getFoodStopsForTrip(tripId: tripId)
        
        // Then
        XCTAssertEqual(foodStops.count, 1)
        XCTAssertEqual(foodStops.first?.id, foodStop1.id)
        XCTAssertEqual(foodStops.first?.tripId, tripId)
    }
    
    func testGetActiveFoodStop() async throws {
        // Given
        let tripId = UUID()
        
        let restaurant = Restaurant(
            id: "restaurant-1",
            name: "Restaurant 1",
            address: "Address 1",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        
        let foodStop = try await foodStopService.proposeFoodStop(
            restaurant: restaurant,
            tripId: tripId,
            proposedBy: UUID(),
            notes: nil
        )
        
        // Approve and activate the food stop
        try await foodStopService.approveFoodStop(foodStopId: foodStop.id, participantId: UUID())
        try await foodStopService.approveFoodStop(foodStopId: foodStop.id, participantId: UUID())
        
        try await foodStopService.placeOrder(
            foodStopId: foodStop.id,
            participantId: UUID(),
            items: [OrderItem(name: "Sandwich", quantity: 1, price: 9.99)],
            specialInstructions: nil
        )
        
        // When
        let activeFoodStop = try await foodStopService.getActiveFoodStop(tripId: tripId)
        
        // Then
        XCTAssertNotNil(activeFoodStop)
        XCTAssertEqual(activeFoodStop?.id, foodStop.id)
        XCTAssertEqual(activeFoodStop?.proposalStatus, .active)
    }
    
    // MARK: - Error Handling Tests
    
    func testFoodStopNotFoundError() async {
        // Given
        let nonExistentFoodStopId = UUID()
        let participantId = UUID()
        
        // When/Then
        do {
            try await foodStopService.approveFoodStop(
                foodStopId: nonExistentFoodStopId,
                participantId: participantId
            )
            XCTFail("Expected FoodStopServiceError.foodStopNotFound")
        } catch FoodStopServiceError.foodStopNotFound {
            // Expected error
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    func testOrderNotFoundError() async {
        // Given
        let nonExistentOrderId = UUID()
        
        // When/Then
        do {
            try await foodStopService.updateOrderStatus(
                orderId: nonExistentOrderId,
                status: .ready,
                estimatedReadyTime: nil
            )
            XCTFail("Expected FoodStopServiceError.orderNotFound")
        } catch FoodStopServiceError.orderNotFound {
            // Expected error
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
}

// MARK: - Mock Route Manager Extension

extension MockRouteManager {
    override func addWaypoint(_ destination: Destination) async throws {
        waypointAdded = true
    }
}