import XCTest
import Combine
import CoreLocation
import UIKit
@testable import RoadTripTracker

// MARK: - Chat View Model Tests
@MainActor
final class ChatViewModelTests: XCTestCase {
    
    var viewModel: ChatViewModel!
    var mockChatService: MockChatService!
    var mockPhotoSharingService: MockPhotoSharingService!
    var mockLocationManager: MockLocationManager!
    var subscriptions: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        mockChatService = MockChatService()
        mockPhotoSharingService = MockPhotoSharingService()
        mockLocationManager = MockLocationManager()
        
        viewModel = ChatViewModel(
            chatService: mockChatService,
            photoSharingService: mockPhotoSharingService,
            locationManager: mockLocationManager
        )
        
        subscriptions = Set<AnyCancellable>()
    }
    
    override func tearDownWithError() throws {
        subscriptions = nil
        viewModel = nil
        mockLocationManager = nil
        mockPhotoSharingService = nil
        mockChatService = nil
        try super.tearDownWithError()
    }
    
    // MARK: - Load Messages Tests
    
    func testLoadMessages() async {
        // Given
        let tripId = UUID()
        let testMessages = [
            Message.testMessage(tripId: tripId, content: "Message 1"),
            Message.testMessage(tripId: tripId, content: "Message 2")
        ]
        mockChatService.mockMessages = testMessages
        
        // When
        await viewModel.loadMessages(for: tripId)
        
        // Then
        XCTAssertEqual(viewModel.messages.count, 2)
        XCTAssertEqual(viewModel.messages[0].content, "Message 1")
        XCTAssertEqual(viewModel.messages[1].content, "Message 2")
        XCTAssertFalse(viewModel.isLoading)
    }
    
    func testLoadMessagesWithError() async {
        // Given
        let tripId = UUID()
        mockChatService.shouldThrowError = true
        
        // When
        await viewModel.loadMessages(for: tripId)
        
        // Then
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertFalse(viewModel.isLoading)
    }
    
    // MARK: - Send Message Tests
    
    func testSendMessage() async {
        // Given
        let tripId = UUID()
        await viewModel.loadMessages(for: tripId)
        viewModel.messageText = "Hello, world!"
        
        // When
        await viewModel.sendMessage()
        
        // Then
        XCTAssertTrue(viewModel.messageText.isEmpty)
        XCTAssertTrue(mockChatService.sendMessageCalled)
        XCTAssertEqual(mockChatService.lastSentMessage, "Hello, world!")
    }
    
    func testSendEmptyMessage() async {
        // Given
        let tripId = UUID()
        await viewModel.loadMessages(for: tripId)
        viewModel.messageText = ""
        
        // When
        await viewModel.sendMessage()
        
        // Then
        XCTAssertFalse(mockChatService.sendMessageCalled)
    }
    
    func testSendMessageWithWhitespace() async {
        // Given
        let tripId = UUID()
        await viewModel.loadMessages(for: tripId)
        viewModel.messageText = "   "
        
        // When
        await viewModel.sendMessage()
        
        // Then
        XCTAssertFalse(mockChatService.sendMessageCalled)
    }
    
    func testSendMessageError() async {
        // Given
        let tripId = UUID()
        await viewModel.loadMessages(for: tripId)
        viewModel.messageText = "Test message"
        mockChatService.shouldThrowError = true
        
        // When
        await viewModel.sendMessage()
        
        // Then
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertEqual(viewModel.messageText, "Test message") // Text should be restored
    }
    
    // MARK: - Send Location Message Tests
    
    func testSendLocationMessage() async {
        // Given
        let tripId = UUID()
        await viewModel.loadMessages(for: tripId)
        let testLocation = CLLocation(latitude: 37.7749, longitude: -122.4194)
        mockLocationManager.mockLocation = testLocation
        
        // When
        await viewModel.sendLocationMessage()
        
        // Then
        XCTAssertTrue(mockChatService.sendLocationMessageCalled)
        XCTAssertEqual(mockChatService.lastSentLocation?.latitude, testLocation.coordinate.latitude, accuracy: 0.0001)
        XCTAssertEqual(mockChatService.lastSentLocation?.longitude, testLocation.coordinate.longitude, accuracy: 0.0001)
    }
    
    func testSendLocationMessageError() async {
        // Given
        let tripId = UUID()
        await viewModel.loadMessages(for: tripId)
        mockLocationManager.shouldThrowError = true
        
        // When
        await viewModel.sendLocationMessage()
        
        // Then
        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertEqual(viewModel.errorMessage, "Failed to get current location")
    }
    
    // MARK: - Send Photo Message Tests
    
    func testSendPhotoMessage() async {
        // Given
        let tripId = UUID()
        await viewModel.loadMessages(for: tripId)
        let testImage = createTestImage()
        let caption = "Beautiful sunset"
        
        // When
        await viewModel.sendPhotoMessage(testImage, caption: caption)
        
        // Then
        XCTAssertTrue(mockChatService.sendPhotoMessageCalled)
        XCTAssertEqual(mockChatService.lastPhotoCaption, caption)
    }
    
    // MARK: - Send Emergency Message Tests
    
    func testSendEmergencyMessage() async {
        // Given
        let tripId = UUID()
        await viewModel.loadMessages(for: tripId)
        let emergencyContent = "Need help!"
        let testLocation = CLLocation(latitude: 37.7749, longitude: -122.4194)
        mockLocationManager.mockLocation = testLocation
        
        // When
        await viewModel.sendEmergencyMessage(emergencyContent)
        
        // Then
        XCTAssertTrue(mockChatService.sendEmergencyMessageCalled)
        XCTAssertEqual(mockChatService.lastEmergencyMessage, emergencyContent)
    }
    
    // MARK: - Mark Message as Read Tests
    
    func testMarkMessageAsRead() async {
        // Given
        let tripId = UUID()
        let otherUserId = UUID()
        let message = Message.testMessage(tripId: tripId, senderId: otherUserId)
        
        // When
        await viewModel.markMessageAsRead(message)
        
        // Then
        XCTAssertTrue(mockChatService.markMessageAsReadCalled)
    }
    
    func testMarkOwnMessageAsRead() async {
        // Given
        let tripId = UUID()
        // Assuming current user ID is the default from test message
        let message = Message.testMessage(tripId: tripId)
        
        // When
        await viewModel.markMessageAsRead(message)
        
        // Then
        // Should not mark own messages as read
        // This test would need proper user ID mocking to work correctly
        XCTAssertTrue(true) // Placeholder assertion
    }
    
    // MARK: - Delete Message Tests
    
    func testDeleteMessage() async {
        // Given
        let tripId = UUID()
        let message = Message.testMessage(tripId: tripId)
        
        // When
        await viewModel.deleteMessage(message)
        
        // Then
        XCTAssertTrue(mockChatService.deleteMessageCalled)
    }
    
    // MARK: - Retry Failed Message Tests
    
    func testRetryFailedTextMessage() async {
        // Given
        let tripId = UUID()
        await viewModel.loadMessages(for: tripId)
        var failedMessage = Message.testMessage(tripId: tripId, content: "Failed message")
        failedMessage.deliveryStatus = .failed
        viewModel.messages = [failedMessage]
        
        // When
        await viewModel.retryFailedMessage(failedMessage)
        
        // Then
        XCTAssertEqual(viewModel.messageText, "Failed message")
        XCTAssertFalse(viewModel.messages.contains { $0.id == failedMessage.id })
    }
    
    // MARK: - Connection Status Tests
    
    func testConnectionStatusUpdates() {
        // Given
        let expectation = XCTestExpectation(description: "Connection status updated")
        
        viewModel.$connectionStatus
            .sink { status in
                if status == .connected {
                    expectation.fulfill()
                }
            }
            .store(in: &subscriptions)
        
        // When
        mockChatService.connectionSubject.send(.connected)
        
        // Then
        wait(for: [expectation], timeout: 1.0)
        XCTAssertEqual(viewModel.connectionStatus, .connected)
    }
    
    // MARK: - Message Updates Tests
    
    func testMessageUpdates() {
        // Given
        let expectation = XCTestExpectation(description: "Message received")
        let newMessage = Message.testMessage(content: "New message")
        
        viewModel.$messages
            .dropFirst() // Skip initial empty array
            .sink { messages in
                if !messages.isEmpty {
                    expectation.fulfill()
                }
            }
            .store(in: &subscriptions)
        
        // When
        mockChatService.messageSubject.send(newMessage)
        
        // Then
        wait(for: [expectation], timeout: 1.0)
        XCTAssertTrue(viewModel.messages.contains { $0.id == newMessage.id })
    }
    
    // MARK: - Helper Methods Tests
    
    func testFormatMessageTime() {
        // Given
        let now = Date()
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: now)!
        let lastWeek = Calendar.current.date(byAdding: .day, value: -7, to: now)!
        
        // When & Then
        let todayFormat = viewModel.formatMessageTime(now)
        let yesterdayFormat = viewModel.formatMessageTime(yesterday)
        let lastWeekFormat = viewModel.formatMessageTime(lastWeek)
        
        XCTAssertFalse(todayFormat.isEmpty)
        XCTAssertEqual(yesterdayFormat, "Yesterday")
        XCTAssertFalse(lastWeekFormat.isEmpty)
        XCTAssertNotEqual(lastWeekFormat, "Yesterday")
    }
    
    func testShouldShowTimestamp() {
        // Given
        let now = Date()
        let fiveMinutesAgo = Calendar.current.date(byAdding: .minute, value: -5, to: now)!
        let tenMinutesAgo = Calendar.current.date(byAdding: .minute, value: -10, to: now)!
        
        let recentMessage = Message.testMessage()
        recentMessage.timestamp = fiveMinutesAgo
        
        let olderMessage = Message.testMessage()
        olderMessage.timestamp = tenMinutesAgo
        
        let currentMessage = Message.testMessage()
        currentMessage.timestamp = now
        
        // When & Then
        XCTAssertTrue(viewModel.shouldShowTimestamp(currentMessage, previousMessage: nil))
        XCTAssertFalse(viewModel.shouldShowTimestamp(currentMessage, previousMessage: recentMessage))
        XCTAssertTrue(viewModel.shouldShowTimestamp(currentMessage, previousMessage: olderMessage))
    }
    
    // MARK: - Disconnect Tests
    
    func testDisconnect() async {
        // Given
        let tripId = UUID()
        await viewModel.loadMessages(for: tripId)
        viewModel.messages = [Message.testMessage()]
        
        // When
        await viewModel.disconnect()
        
        // Then
        XCTAssertTrue(mockChatService.unsubscribeFromMessagesCalled)
        XCTAssertTrue(viewModel.messages.isEmpty)
    }
    
    // MARK: - Helper Methods
    
    private func createTestImage(size: CGSize = CGSize(width: 100, height: 100)) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { context in
            UIColor.blue.setFill()
            context.fill(CGRect(origin: .zero, size: size))
        }
    }
}

// MARK: - Mock Chat Service
class MockChatService: ChatServiceProtocol {
    var messageSubject = PassthroughSubject<Message, Never>()
    var connectionSubject = CurrentValueSubject<ConnectionStatus, Never>(.disconnected)
    
    var messageUpdates: AnyPublisher<Message, Never> {
        messageSubject.eraseToAnyPublisher()
    }
    
    var connectionStatus: AnyPublisher<ConnectionStatus, Never> {
        connectionSubject.eraseToAnyPublisher()
    }
    
    var shouldThrowError = false
    var mockMessages: [Message] = []
    
    // Tracking method calls
    var sendMessageCalled = false
    var sendLocationMessageCalled = false
    var sendPhotoMessageCalled = false
    var sendEmergencyMessageCalled = false
    var markMessageAsReadCalled = false
    var deleteMessageCalled = false
    var subscribeToMessagesCalled = false
    var unsubscribeFromMessagesCalled = false
    
    // Tracking parameters
    var lastSentMessage: String?
    var lastSentLocation: CLLocationCoordinate2D?
    var lastPhotoCaption: String?
    var lastEmergencyMessage: String?
    
    func sendMessage(_ content: String, to tripId: UUID) async throws -> Message {
        sendMessageCalled = true
        lastSentMessage = content
        
        if shouldThrowError {
            throw ChatServiceError.messageNotSent
        }
        
        let message = Message.testMessage(tripId: tripId, content: content)
        messageSubject.send(message)
        return message
    }
    
    func sendLocationMessage(_ location: CLLocationCoordinate2D, to tripId: UUID) async throws -> Message {
        sendLocationMessageCalled = true
        lastSentLocation = location
        
        if shouldThrowError {
            throw ChatServiceError.messageNotSent
        }
        
        let message = Message.testMessage(tripId: tripId, content: "Shared location", type: .location)
        messageSubject.send(message)
        return message
    }
    
    func sendPhotoMessage(_ photo: UIImage, caption: String?, to tripId: UUID) async throws -> Message {
        sendPhotoMessageCalled = true
        lastPhotoCaption = caption
        
        if shouldThrowError {
            throw ChatServiceError.photoUploadFailed
        }
        
        let message = Message.testMessage(tripId: tripId, content: caption ?? "Shared a photo", type: .photo)
        messageSubject.send(message)
        return message
    }
    
    func sendEmergencyMessage(_ content: String, location: CLLocationCoordinate2D, to tripId: UUID) async throws -> Message {
        sendEmergencyMessageCalled = true
        lastEmergencyMessage = content
        
        if shouldThrowError {
            throw ChatServiceError.messageNotSent
        }
        
        let message = Message.testMessage(tripId: tripId, content: content, type: .emergency)
        messageSubject.send(message)
        return message
    }
    
    func getMessages(for tripId: UUID, limit: Int, offset: Int) async throws -> [Message] {
        if shouldThrowError {
            throw ChatServiceError.networkError
        }
        
        return mockMessages
    }
    
    func markMessageAsRead(_ messageId: UUID, by userId: UUID) async throws {
        markMessageAsReadCalled = true
        
        if shouldThrowError {
            throw ChatServiceError.messageNotFound
        }
    }
    
    func deleteMessage(_ messageId: UUID) async throws {
        deleteMessageCalled = true
        
        if shouldThrowError {
            throw ChatServiceError.messageNotFound
        }
    }
    
    func subscribeToMessages(for tripId: UUID) async throws {
        subscribeToMessagesCalled = true
        
        if shouldThrowError {
            throw ChatServiceError.connectionFailed
        }
        
        connectionSubject.send(.connected)
    }
    
    func unsubscribeFromMessages(for tripId: UUID) async throws {
        unsubscribeFromMessagesCalled = true
        
        if shouldThrowError {
            throw ChatServiceError.connectionFailed
        }
    }
}

// MARK: - Mock Photo Sharing Service
class MockPhotoSharingService: PhotoSharingServiceProtocol {
    var photoSubject = PassthroughSubject<PhotoShare, Never>()
    
    var photoUpdates: AnyPublisher<PhotoShare, Never> {
        photoSubject.eraseToAnyPublisher()
    }
    
    var shouldThrowError = false
    
    func sharePhoto(_ photo: UIImage, caption: String?, location: CLLocationCoordinate2D?, to tripId: UUID) async throws -> PhotoShare {
        if shouldThrowError {
            throw ChatServiceError.photoUploadFailed
        }
        
        let photoShare = PhotoShare.testPhotoShare(tripId: tripId, caption: caption, location: location)
        photoSubject.send(photoShare)
        return photoShare
    }
    
    func getTripPhotos(for tripId: UUID) async throws -> [PhotoShare] {
        if shouldThrowError {
            throw ChatServiceError.networkError
        }
        
        return []
    }
    
    func downloadPhoto(from url: URL) async throws -> UIImage {
        if shouldThrowError {
            throw ChatServiceError.photoDownloadFailed
        }
        
        return UIImage()
    }
    
    func deletePhoto(_ photoId: UUID) async throws {
        if shouldThrowError {
            throw ChatServiceError.photoDownloadFailed
        }
    }
    
    func createTripAlbum(for tripId: UUID) async throws -> TripAlbum {
        if shouldThrowError {
            throw ChatServiceError.unknown("Failed to create album")
        }
        
        return TripAlbum.testTripAlbum(tripId: tripId)
    }
    
    func downloadAllPhotos(for tripId: UUID) async throws -> [UIImage] {
        if shouldThrowError {
            throw ChatServiceError.photoDownloadFailed
        }
        
        return []
    }
}

// MARK: - Mock Location Manager
class MockLocationManager: LocationManager {
    var shouldThrowError = false
    var mockLocation: CLLocation?
    
    override func getCurrentLocation() async throws -> CLLocation {
        if shouldThrowError {
            throw AppError.locationPermissionDenied
        }
        
        return mockLocation ?? CLLocation(latitude: 0, longitude: 0)
    }
}