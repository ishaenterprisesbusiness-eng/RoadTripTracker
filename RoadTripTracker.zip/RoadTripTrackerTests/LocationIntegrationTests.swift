import XCTest
import CoreLocation
import MapKit
@testable import RoadTripTracker

class LocationIntegrationTests: XCTestCase {
    
    var locationManager: LocationManager!
    var mockCLLocationManager: MockCLLocationManager!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        mockCLLocationManager = MockCLLocationManager()
        locationManager = LocationManager()
        locationManager.clLocationManager = mockCLLocationManager
    }
    
    override func tearDownWithError() throws {
        locationManager = nil
        mockCLLocationManager = nil
        try super.tearDownWithError()
    }
    
    // MARK: - Location Permission Tests
    
    func testLocationPermissionFlow() async throws {
        let expectation = XCTestExpectation(description: "Permission granted")
        
        // Simulate permission request
        mockCLLocationManager.authorizationStatus = .notDetermined
        
        locationManager.requestLocationPermission { granted in
            XCTAssertTrue(granted, "Location permission should be granted")
            expectation.fulfill()
        }
        
        // Simulate user granting permission
        mockCLLocationManager.authorizationStatus = .authorizedWhenInUse
        mockCLLocationManager.delegate?.locationManager?(mockCLLocationManager, didChangeAuthorization: .authorizedWhenInUse)
        
        await fulfillment(of: [expectation], timeout: 5.0)
    }
    
    func testLocationPermissionDenied() async throws {
        let expectation = XCTestExpectation(description: "Permission denied")
        
        mockCLLocationManager.authorizationStatus = .denied
        
        locationManager.requestLocationPermission { granted in
            XCTAssertFalse(granted, "Location permission should be denied")
            expectation.fulfill()
        }
        
        mockCLLocationManager.delegate?.locationManager?(mockCLLocationManager, didChangeAuthorization: .denied)
        
        await fulfillment(of: [expectation], timeout: 5.0)
    }
} 
   
    // MARK: - GPS Functionality Tests
    
    func testGPSAccuracy() async throws {
        let expectation = XCTestExpectation(description: "GPS accuracy test")
        
        // Set desired accuracy
        locationManager.startLocationTracking(accuracy: .high)
        XCTAssertEqual(mockCLLocationManager.desiredAccuracy, kCLLocationAccuracyBest)
        
        // Simulate high accuracy location
        let accurateLocation = CLLocation(
            coordinate: CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093),
            altitude: 10,
            horizontalAccuracy: 5,
            verticalAccuracy: 5,
            timestamp: Date()
        )
        
        mockCLLocationManager.delegate?.locationManager?(mockCLLocationManager, didUpdateLocations: [accurateLocation])
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            XCTAssertEqual(self.locationManager.currentLocation?.coordinate.latitude, -33.8688, accuracy: 0.001)
            expectation.fulfill()
        }
        
        await fulfillment(of: [expectation], timeout: 5.0)
    }
    
    func testLocationUpdateFrequency() async throws {
        let expectation = XCTestExpectation(description: "Location update frequency")
        expectation.expectedFulfillmentCount = 3
        
        var updateCount = 0
        locationManager.onLocationUpdate = { _ in
            updateCount += 1
            expectation.fulfill()
        }
        
        locationManager.startLocationTracking(accuracy: .medium)
        
        // Simulate multiple location updates
        for i in 0..<3 {
            let location = CLLocation(
                coordinate: CLLocationCoordinate2D(latitude: -33.8688 + Double(i) * 0.001, longitude: 151.2093),
                altitude: 10,
                horizontalAccuracy: 10,
                verticalAccuracy: 10,
                timestamp: Date().addingTimeInterval(Double(i) * 30)
            )
            
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 0.5) {
                self.mockCLLocationManager.delegate?.locationManager?(self.mockCLLocationManager, didUpdateLocations: [location])
            }
        }
        
        await fulfillment(of: [expectation], timeout: 10.0)
        XCTAssertEqual(updateCount, 3)
    }
    
    func testBackgroundLocationTracking() async throws {
        let expectation = XCTestExpectation(description: "Background location")
        
        // Test background location capability
        mockCLLocationManager.authorizationStatus = .authorizedAlways
        locationManager.enableBackgroundLocationUpdates()
        
        XCTAssertTrue(mockCLLocationManager.allowsBackgroundLocationUpdates)
        
        // Simulate app going to background
        NotificationCenter.default.post(name: UIApplication.didEnterBackgroundNotification, object: nil)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            XCTAssertTrue(self.locationManager.isTrackingInBackground)
            expectation.fulfill()
        }
        
        await fulfillment(of: [expectation], timeout: 5.0)
    }
    
    func testGeofencingFunctionality() async throws {
        let expectation = XCTestExpectation(description: "Geofencing")
        
        let destination = CLLocationCoordinate2D(latitude: -33.8688, longitude: 151.2093)
        let region = CLCircularRegion(center: destination, radius: 100, identifier: "test-destination")
        
        locationManager.startMonitoring(region: region) { entered in
            XCTAssertTrue(entered, "Should detect geofence entry")
            expectation.fulfill()
        }
        
        // Simulate entering the region
        mockCLLocationManager.delegate?.locationManager?(mockCLLocationManager, didEnterRegion: region)
        
        await fulfillment(of: [expectation], timeout: 5.0)
    }
}

// MARK: - Mock Classes

class MockCLLocationManager: CLLocationManager {
    var authorizationStatus: CLAuthorizationStatus = .notDetermined
    var mockLocations: [CLLocation] = []
    var isUpdatingLocation = false
    var allowsBackgroundLocationUpdates = false
    
    override var authorizationStatus: CLAuthorizationStatus {
        return authorizationStatus
    }
    
    override func requestWhenInUseAuthorization() {
        // Simulate permission request
    }
    
    override func requestAlwaysAuthorization() {
        // Simulate always permission request
    }
    
    override func startUpdatingLocation() {
        isUpdatingLocation = true
    }
    
    override func stopUpdatingLocation() {
        isUpdatingLocation = false
    }
    
    override func startMonitoring(for region: CLRegion) {
        // Simulate geofence monitoring
    }
    
    override func stopMonitoring(for region: CLRegion) {
        // Simulate stopping geofence monitoring
    }
}