import XCTest
import CoreLocation
import Combine
@testable import RoadTripTracker

// MARK: - Emergency Service Tests
class EmergencyServiceTests: XCTestCase {
    
    var emergencyService: EmergencyService!
    var mockLocationManager: MockLocationManager!
    var mockNotificationService: MockNotificationService!
    var mockPersistenceController: MockPersistenceController!
    var cancellables: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        mockLocationManager = MockLocationManager()
        mockNotificationService = MockNotificationService()
        mockPersistenceController = MockPersistenceController()
        
        emergencyService = EmergencyService(
            locationManager: mockLocationManager,
            notificationService: mockNotificationService,
            persistenceController: mockPersistenceController
        )
        
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDownWithError() throws {
        emergencyService = nil
        mockLocationManager = nil
        mockNotificationService = nil
        mockPersistenceController = nil
        cancellables = nil
    }
    
    // MARK: - Emergency Alert Tests
    
    func testTriggerEmergencyAlert() async throws {
        // Given
        let location = CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631)
        let message = "Help needed!"
        
        var receivedAlert: EmergencyAlert?
        let expectation = XCTestExpectation(description: "Emergency alert received")
        
        emergencyService.emergencyAlerts
            .sink { alert in
                receivedAlert = alert
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        // When
        try await emergencyService.triggerEmergencyAlert(location: location, message: message)
        
        // Then
        await fulfillment(of: [expectation], timeout: 1.0)
        
        XCTAssertNotNil(receivedAlert)
        XCTAssertEqual(receivedAlert?.alertType, .panic)
        XCTAssertEqual(receivedAlert?.message, message)
        XCTAssertEqual(receivedAlert?.location.latitude, location.latitude, accuracy: 0.001)
        XCTAssertEqual(receivedAlert?.location.longitude, location.longitude, accuracy: 0.001)
        XCTAssertEqual(receivedAlert?.status, .active)
    }
    
    func testSendBreakdownAssistance() async throws {
        // Given
        let location = CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631)
        let vehicle = Vehicle(
            make: "Toyota",
            model: "Camry",
            vehicleNumber: "ABC123",
            odometerReading: 50000,
            type: .sedan
        )
        
        var receivedAlert: EmergencyAlert?
        let expectation = XCTestExpectation(description: "Breakdown alert received")
        
        emergencyService.emergencyAlerts
            .sink { alert in
                receivedAlert = alert
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        // When
        try await emergencyService.sendBreakdownAssistance(location: location, vehicleInfo: vehicle)
        
        // Then
        await fulfillment(of: [expectation], timeout: 1.0)
        
        XCTAssertNotNil(receivedAlert)
        XCTAssertEqual(receivedAlert?.alertType, .breakdown)
        XCTAssertTrue(receivedAlert?.message?.contains("Toyota Camry") == true)
        XCTAssertTrue(receivedAlert?.message?.contains("ABC123") == true)
    }
    
    func testCancelEmergencyAlert() async throws {
        // Given
        var receivedAlert: EmergencyAlert?
        let expectation = XCTestExpectation(description: "Cancellation alert received")
        
        emergencyService.emergencyAlerts
            .sink { alert in
                receivedAlert = alert
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        // When
        try await emergencyService.cancelEmergencyAlert()
        
        // Then
        await fulfillment(of: [expectation], timeout: 1.0)
        
        XCTAssertNotNil(receivedAlert)
        XCTAssertEqual(receivedAlert?.status, .cancelled)
        XCTAssertTrue(receivedAlert?.message?.contains("cancelled") == true)
    }
    
    // MARK: - Emergency Services Tests
    
    func testFindNearbyEmergencyServices() async throws {
        // Given
        let location = CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631)
        
        // When
        let services = try await emergencyService.findNearbyEmergencyServices(location: location)
        
        // Then
        XCTAssertFalse(services.isEmpty)
        XCTAssertTrue(services.contains { $0.type == .hospital })
        XCTAssertTrue(services.contains { $0.type == .police })
        XCTAssertTrue(services.contains { $0.type == .towingService })
        
        // Verify services are sorted by distance
        for i in 0..<services.count - 1 {
            XCTAssertLessThanOrEqual(services[i].distance, services[i + 1].distance)
        }
    }
    
    func testEmergencyServiceTypes() {
        // Given
        let hospital = EmergencyService(
            name: "Test Hospital",
            type: .hospital,
            phoneNumber: "000",
            address: "123 Test St",
            coordinate: CLLocationCoordinate2D(latitude: 0, longitude: 0),
            distance: 1000,
            isOpen24Hours: true
        )
        
        let police = EmergencyService(
            name: "Test Police",
            type: .police,
            phoneNumber: "000",
            address: "456 Test Ave",
            coordinate: CLLocationCoordinate2D(latitude: 0, longitude: 0),
            distance: 500,
            isOpen24Hours: true
        )
        
        // Then
        XCTAssertEqual(hospital.type, .hospital)
        XCTAssertEqual(police.type, .police)
        XCTAssertTrue(hospital.isOpen24Hours)
        XCTAssertTrue(police.isOpen24Hours)
    }
    
    // MARK: - Error Handling Tests
    
    func testEmergencyServiceError() {
        // Given
        let locationError = EmergencyServiceError.locationNotAvailable
        let networkError = EmergencyServiceError.networkError
        let serviceError = EmergencyServiceError.serviceUnavailable
        let unknownError = EmergencyServiceError.unknown("Test error")
        
        // Then
        XCTAssertEqual(locationError.errorDescription, "Location not available")
        XCTAssertEqual(networkError.errorDescription, "Network connection error")
        XCTAssertEqual(serviceError.errorDescription, "Emergency service unavailable")
        XCTAssertEqual(unknownError.errorDescription, "Test error")
    }
}

// MARK: - Emergency Contact Tests
class EmergencyContactTests: XCTestCase {
    
    func testEmergencyContactCreation() {
        // Given
        let contact = EmergencyContact(
            name: "John Doe",
            relationship: "Spouse",
            phoneNumber: "+61 400 123 456",
            email: "john@example.com",
            contactMethod: .email,
            isPrimary: true
        )
        
        // Then
        XCTAssertEqual(contact.name, "John Doe")
        XCTAssertEqual(contact.relationship, "Spouse")
        XCTAssertEqual(contact.phoneNumber, "+61 400 123 456")
        XCTAssertEqual(contact.email, "john@example.com")
        XCTAssertEqual(contact.contactMethod, .email)
        XCTAssertTrue(contact.isPrimary)
    }
    
    func testEmergencyContactMethodDisplayNames() {
        // Then
        XCTAssertEqual(EmergencyContactMethod.sms.displayName, "SMS")
        XCTAssertEqual(EmergencyContactMethod.email.displayName, "Email")
        XCTAssertEqual(EmergencyContactMethod.call.displayName, "Phone Call")
    }
}

// MARK: - Emergency Alert Tests
class EmergencyAlertTests: XCTestCase {
    
    func testEmergencyAlertCreation() {
        // Given
        let tripId = UUID()
        let userId = UUID()
        let location = CLLocationCoordinate2D(latitude: -37.8136, longitude: 144.9631)
        let message = "Emergency situation"
        
        let alert = EmergencyAlert(
            tripId: tripId,
            userId: userId,
            alertType: .panic,
            location: location,
            message: message
        )
        
        // Then
        XCTAssertEqual(alert.tripId, tripId)
        XCTAssertEqual(alert.userId, userId)
        XCTAssertEqual(alert.alertType, .panic)
        XCTAssertEqual(alert.location.latitude, location.latitude, accuracy: 0.001)
        XCTAssertEqual(alert.location.longitude, location.longitude, accuracy: 0.001)
        XCTAssertEqual(alert.message, message)
        XCTAssertEqual(alert.status, .active)
    }
    
    func testEmergencyAlertTypes() {
        // Then
        XCTAssertEqual(EmergencyAlertType.panic.rawValue, "panic")
        XCTAssertEqual(EmergencyAlertType.breakdown.rawValue, "breakdown")
        XCTAssertEqual(EmergencyAlertType.accident.rawValue, "accident")
        XCTAssertEqual(EmergencyAlertType.medical.rawValue, "medical")
        XCTAssertEqual(EmergencyAlertType.other.rawValue, "other")
    }
    
    func testEmergencyAlertStatus() {
        // Then
        XCTAssertEqual(EmergencyAlertStatus.active.rawValue, "active")
        XCTAssertEqual(EmergencyAlertStatus.acknowledged.rawValue, "acknowledged")
        XCTAssertEqual(EmergencyAlertStatus.resolved.rawValue, "resolved")
        XCTAssertEqual(EmergencyAlertStatus.cancelled.rawValue, "cancelled")
    }
}

// MARK: - Mock Classes

class MockLocationManager: LocationManager {
    override func getCurrentLocation() async throws -> CLLocation {
        return CLLocation(latitude: -37.8136, longitude: 144.9631)
    }
}

class MockNotificationService: NotificationServiceProtocol {
    var notificationUpdates: AnyPublisher<Notification, Never> {
        Empty().eraseToAnyPublisher()
    }
    
    func requestPermission() async throws -> Bool {
        return true
    }
    
    func sendNotification(_ notification: Notification) async throws {
        // Mock implementation
    }
    
    func scheduleNotification(_ notification: Notification, at date: Date) async throws {
        // Mock implementation
    }
    
    func cancelNotification(withId id: UUID) async throws {
        // Mock implementation
    }
    
    func cancelAllNotifications() async throws {
        // Mock implementation
    }
}

class MockPersistenceController: PersistenceController {
    // Mock implementation would override necessary methods
}