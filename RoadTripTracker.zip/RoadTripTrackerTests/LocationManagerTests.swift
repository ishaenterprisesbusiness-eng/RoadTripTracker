import XCTest
import CoreLocation
import Combine
@testable import RoadTripTracker

@MainActor
final class LocationManagerTests: XCTestCase {
    
    var locationManager: LocationManager!
    var cancellables: Set<AnyCancellable>!
    
    override func setUp() {
        super.setUp()
        locationManager = LocationManager()
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDown() {
        cancellables = nil
        locationManager = nil
        super.tearDown()
    }
    
    // MARK: - Initialization Tests
    
    func testLocationManagerInitialization() {
        XCTAssertNotNil(locationManager)
        XCTAssertEqual(locationManager.authorizationStatus, .notDetermined)
        XCTAssertFalse(locationManager.isLocationSharingEnabled)
        XCTAssertNil(locationManager.currentLocation)
    }
    
    // MARK: - Location Updates Tests
    
    func testLocationUpdatesPublisher() {
        let expectation = XCTestExpectation(description: "Location updates received")
        
        locationManager.locationUpdates
            .sink { location in
                XCTAssertNotNil(location)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        // Simulate location update
        let testLocation = CLLocation(latitude: 37.7749, longitude: -122.4194)
        locationManager.currentLocation = testLocation
        
        // This would normally be triggered by CLLocationManagerDelegate
        // For testing, we'll verify the publisher setup
        XCTAssertNotNil(locationManager.locationUpdates)
    }
    
    func testAuthorizationUpdatesPublisher() {
        let expectation = XCTestExpectation(description: "Authorization updates received")
        
        locationManager.authorizationUpdates
            .sink { status in
                XCTAssertNotEqual(status, .notDetermined)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        // Simulate authorization change
        locationManager.authorizationStatus = .authorizedWhenInUse
        
        XCTAssertNotNil(locationManager.authorizationUpdates)
    }
    
    // MARK: - Distance Calculation Tests
    
    func testCalculateDistance() {
        let location1 = CLLocation(latitude: 37.7749, longitude: -122.4194) // San Francisco
        let location2 = CLLocation(latitude: 40.7128, longitude: -74.0060)  // New York
        
        let distance = locationManager.calculateDistance(from: location1, to: location2)
        
        // Distance between SF and NYC is approximately 4,000 km
        XCTAssertGreaterThan(distance, 3_000_000) // 3,000 km in meters
        XCTAssertLessThan(distance, 5_000_000)    // 5,000 km in meters
    }
    
    func testCalculateDistanceSameLocation() {
        let location = CLLocation(latitude: 37.7749, longitude: -122.4194)
        
        let distance = locationManager.calculateDistance(from: location, to: location)
        
        XCTAssertEqual(distance, 0, accuracy: 0.1)
    }
    
    // MARK: - Location Staleness Tests
    
    func testIsLocationStale() {
        // Fresh location (current time)
        let freshLocation = CLLocation(latitude: 37.7749, longitude: -122.4194)
        XCTAssertFalse(locationManager.isLocationStale(freshLocation, threshold: 300))
        
        // Stale location (10 minutes ago)
        let staleTimestamp = Date().addingTimeInterval(-600)
        let staleLocation = CLLocation(
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            altitude: 0,
            horizontalAccuracy: 5,
            verticalAccuracy: 5,
            timestamp: staleTimestamp
        )
        XCTAssertTrue(locationManager.isLocationStale(staleLocation, threshold: 300))
    }
    
    func testIsLocationStaleCustomThreshold() {
        // Location from 2 minutes ago
        let timestamp = Date().addingTimeInterval(-120)
        let location = CLLocation(
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            altitude: 0,
            horizontalAccuracy: 5,
            verticalAccuracy: 5,
            timestamp: timestamp
        )
        
        // Should not be stale with 3-minute threshold
        XCTAssertFalse(locationManager.isLocationStale(location, threshold: 180))
        
        // Should be stale with 1-minute threshold
        XCTAssertTrue(locationManager.isLocationStale(location, threshold: 60))
    }
    
    // MARK: - Trip Context Tests
    
    func testSetTripContext() {
        let tripId = UUID()
        let participantId = UUID()
        
        locationManager.setTripContext(tripId: tripId, participantId: participantId)
        
        // We can't directly test private properties, but we can verify the method doesn't crash
        XCTAssertNotNil(locationManager)
    }
    
    func testClearTripContext() {
        let tripId = UUID()
        let participantId = UUID()
        
        locationManager.setTripContext(tripId: tripId, participantId: participantId)
        locationManager.clearTripContext()
        
        // We can't directly test private properties, but we can verify the method doesn't crash
        XCTAssertNotNil(locationManager)
    }
    
    // MARK: - Location Update Optimization Tests
    
    func testOptimizeLocationUpdatesStationary() {
        // Test optimization for stationary speed
        locationManager.optimizeLocationUpdates(for: 0.0)
        
        // We can't directly test private properties, but we can verify the method doesn't crash
        XCTAssertNotNil(locationManager)
    }
    
    func testOptimizeLocationUpdatesWalking() {
        // Test optimization for walking speed
        locationManager.optimizeLocationUpdates(for: 5.0) // 5 m/s ≈ walking speed
        
        XCTAssertNotNil(locationManager)
    }
    
    func testOptimizeLocationUpdatesDriving() {
        // Test optimization for driving speed
        locationManager.optimizeLocationUpdates(for: 25.0) // 25 m/s ≈ 90 km/h
        
        XCTAssertNotNil(locationManager)
    }
    
    // MARK: - Error Handling Tests
    
    func testLocationSharingWithoutPermission() async {
        // Simulate denied permission
        locationManager.authorizationStatus = .denied
        
        do {
            try await locationManager.startLocationSharing()
            XCTFail("Should have thrown permission denied error")
        } catch LocationServiceError.permissionDenied {
            // Expected error
            XCTAssertTrue(true)
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    func testGetCurrentLocationWithoutPermission() async {
        // Simulate denied permission
        locationManager.authorizationStatus = .denied
        
        do {
            _ = try await locationManager.getCurrentLocation()
            XCTFail("Should have thrown permission denied error")
        } catch LocationServiceError.permissionDenied {
            // Expected error
            XCTAssertTrue(true)
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    // MARK: - State Management Tests
    
    func testLocationSharingState() {
        XCTAssertFalse(locationManager.isLocationSharingEnabled)
        
        // Simulate starting location sharing (would normally require permission)
        locationManager.isLocationSharingEnabled = true
        XCTAssertTrue(locationManager.isLocationSharingEnabled)
        
        // Simulate stopping location sharing
        locationManager.stopLocationSharing()
        XCTAssertFalse(locationManager.isLocationSharingEnabled)
    }
    
    // MARK: - Performance Tests
    
    func testDistanceCalculationPerformance() {
        let location1 = CLLocation(latitude: 37.7749, longitude: -122.4194)
        let location2 = CLLocation(latitude: 40.7128, longitude: -74.0060)
        
        measure {
            for _ in 0..<1000 {
                _ = locationManager.calculateDistance(from: location1, to: location2)
            }
        }
    }
}