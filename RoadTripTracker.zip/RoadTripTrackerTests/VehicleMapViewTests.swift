import XCTest
import MapKit
import CoreLocation
@testable import RoadTripTracker

final class VehicleMapViewTests: XCTestCase {
    
    var clusteringManager: VehicleClusteringManager!
    var testParticipants: [Participant]!
    
    override func setUp() {
        super.setUp()
        clusteringManager = VehicleClusteringManager(clusterRadius: 100)
        setupTestParticipants()
    }
    
    override func tearDown() {
        clusteringManager = nil
        testParticipants = nil
        super.tearDown()
    }
    
    private func setupTestParticipants() {
        testParticipants = [
            // Participant 1 - San Francisco
            Participant(
                userId: UUID(),
                user: User(
                    username: "John Doe",
                    email: "john@example.com",
                    city: "San Francisco",
                    dateOfBirth: Date(),
                    vehicle: Vehicle(
                        make: "Toyota",
                        model: "Camry",
                        vehicleNumber: "ABC123",
                        odometerReading: 50000,
                        type: .sedan
                    )
                ),
                currentLocation: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
                isLocationSharingEnabled: true,
                status: .active
            ),
            
            // Participant 2 - Very close to Participant 1 (should cluster)
            Participant(
                userId: UUID(),
                user: User(
                    username: "Jane Smith",
                    email: "jane@example.com",
                    city: "San Francisco",
                    dateOfBirth: Date(),
                    vehicle: Vehicle(
                        make: "Honda",
                        model: "CR-V",
                        vehicleNumber: "XYZ789",
                        odometerReading: 30000,
                        type: .suv
                    )
                ),
                currentLocation: CLLocationCoordinate2D(latitude: 37.7750, longitude: -122.4195),
                isLocationSharingEnabled: true,
                status: .active
            ),
            
            // Participant 3 - Far away (should not cluster)
            Participant(
                userId: UUID(),
                user: User(
                    username: "Bob Johnson",
                    email: "bob@example.com",
                    city: "Los Angeles",
                    dateOfBirth: Date(),
                    vehicle: Vehicle(
                        make: "Ford",
                        model: "F-150",
                        vehicleNumber: "DEF456",
                        odometerReading: 75000,
                        type: .fourWDUte
                    )
                ),
                currentLocation: CLLocationCoordinate2D(latitude: 34.0522, longitude: -118.2437),
                isLocationSharingEnabled: true,
                status: .active
            )
        ]
    }
    
    // MARK: - Vehicle Clustering Tests
    
    func testVehicleClusteringWithNearbyParticipants() {
        let (individualAnnotations, clusterAnnotations) = clusteringManager.clusterParticipants(testParticipants)
        
        // Should have 1 individual annotation (Bob in LA) and 1 cluster (John and Jane in SF)
        XCTAssertEqual(individualAnnotations.count, 1)
        XCTAssertEqual(clusterAnnotations.count, 1)
        
        // Check cluster contains correct participants
        let cluster = clusterAnnotations[0]
        XCTAssertEqual(cluster.participants.count, 2)
        
        let clusterUsernames = Set(cluster.participants.map { $0.user.username })
        XCTAssertTrue(clusterUsernames.contains("John Doe"))
        XCTAssertTrue(clusterUsernames.contains("Jane Smith"))
        
        // Check individual annotation is for Bob
        let individual = individualAnnotations[0]
        XCTAssertEqual(individual.participant.user.username, "Bob Johnson")
    }
    
    func testVehicleClusteringWithDistantParticipants() {
        // Create participants that are all far apart
        let distantParticipants = [
            testParticipants[0], // San Francisco
            testParticipants[2]  // Los Angeles
        ]
        
        let (individualAnnotations, clusterAnnotations) = clusteringManager.clusterParticipants(distantParticipants)
        
        // Should have 2 individual annotations and no clusters
        XCTAssertEqual(individualAnnotations.count, 2)
        XCTAssertEqual(clusterAnnotations.count, 0)
    }
    
    func testVehicleClusteringWithSingleParticipant() {
        let singleParticipant = [testParticipants[0]]
        
        let (individualAnnotations, clusterAnnotations) = clusteringManager.clusterParticipants(singleParticipant)
        
        // Should have 1 individual annotation and no clusters
        XCTAssertEqual(individualAnnotations.count, 1)
        XCTAssertEqual(clusterAnnotations.count, 0)
    }
    
    func testVehicleClusteringWithNoParticipants() {
        let (individualAnnotations, clusterAnnotations) = clusteringManager.clusterParticipants([])
        
        // Should have no annotations
        XCTAssertEqual(individualAnnotations.count, 0)
        XCTAssertEqual(clusterAnnotations.count, 0)
    }
    
    // MARK: - Vehicle Annotation Tests
    
    func testVehicleAnnotationCreation() {
        let participant = testParticipants[0]
        let annotation = VehicleAnnotation(participant: participant)
        
        XCTAssertEqual(annotation.coordinate.latitude, participant.currentLocation!.latitude, accuracy: 0.0001)
        XCTAssertEqual(annotation.coordinate.longitude, participant.currentLocation!.longitude, accuracy: 0.0001)
        XCTAssertEqual(annotation.title, participant.user.username)
        XCTAssertEqual(annotation.subtitle, "Toyota Camry")
    }
    
    func testVehicleAnnotationWithoutVehicle() {
        var participant = testParticipants[0]
        participant.user.vehicle = nil
        
        let annotation = VehicleAnnotation(participant: participant)
        
        XCTAssertEqual(annotation.title, participant.user.username)
        XCTAssertNil(annotation.subtitle)
    }
    
    // MARK: - Cluster Annotation Tests
    
    func testClusterAnnotationCreation() {
        let participants = Array(testParticipants[0...1]) // John and Jane
        let centerCoordinate = CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        
        let cluster = VehicleClusterAnnotation(
            participants: participants,
            coordinate: centerCoordinate,
            radius: 100
        )
        
        XCTAssertEqual(cluster.participants.count, 2)
        XCTAssertEqual(cluster.coordinate.latitude, centerCoordinate.latitude, accuracy: 0.0001)
        XCTAssertEqual(cluster.coordinate.longitude, centerCoordinate.longitude, accuracy: 0.0001)
        XCTAssertEqual(cluster.title, "2 vehicles")
        XCTAssertEqual(cluster.subtitle, "Tap to see details")
    }
    
    func testClusterAnnotationCenterCalculation() {
        let participants = Array(testParticipants[0...1]) // John and Jane
        let cluster = VehicleClusterAnnotation(
            participants: participants,
            coordinate: CLLocationCoordinate2D(latitude: 0, longitude: 0),
            radius: 100
        )
        
        cluster.updateCenterCoordinate()
        
        // Should be approximately the average of the two locations
        let expectedLat = (37.7749 + 37.7750) / 2
        let expectedLon = (-122.4194 + -122.4195) / 2
        
        XCTAssertEqual(cluster.coordinate.latitude, expectedLat, accuracy: 0.0001)
        XCTAssertEqual(cluster.coordinate.longitude, expectedLon, accuracy: 0.0001)
    }
    
    func testClusterAnnotationAddRemoveParticipant() {
        let participant1 = testParticipants[0]
        let participant2 = testParticipants[1]
        
        let cluster = VehicleClusterAnnotation(
            participants: [participant1],
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
            radius: 100
        )
        
        XCTAssertEqual(cluster.participants.count, 1)
        
        // Add participant
        cluster.addParticipant(participant2)
        XCTAssertEqual(cluster.participants.count, 2)
        
        // Remove participant
        cluster.removeParticipant(participant1)
        XCTAssertEqual(cluster.participants.count, 1)
        XCTAssertEqual(cluster.participants[0].id, participant2.id)
    }
    
    // MARK: - Distance Calculation Tests
    
    func testDistanceCalculationBetweenParticipants() {
        let participant1 = testParticipants[0] // San Francisco
        let participant2 = testParticipants[2] // Los Angeles
        
        let location1 = CLLocation(
            latitude: participant1.currentLocation!.latitude,
            longitude: participant1.currentLocation!.longitude
        )
        let location2 = CLLocation(
            latitude: participant2.currentLocation!.latitude,
            longitude: participant2.currentLocation!.longitude
        )
        
        let distance = location1.distance(from: location2)
        
        // Distance between SF and LA is approximately 560 km
        XCTAssertGreaterThan(distance, 500_000) // 500 km in meters
        XCTAssertLessThan(distance, 700_000)    // 700 km in meters
    }
    
    func testClusteringDistanceThreshold() {
        let participant1 = testParticipants[0]
        let participant2 = testParticipants[1]
        
        let location1 = CLLocation(
            latitude: participant1.currentLocation!.latitude,
            longitude: participant1.currentLocation!.longitude
        )
        let location2 = CLLocation(
            latitude: participant2.currentLocation!.latitude,
            longitude: participant2.currentLocation!.longitude
        )
        
        let distance = location1.distance(from: location2)
        
        // These participants should be within clustering distance (100m)
        XCTAssertLessThan(distance, 100)
    }
    
    // MARK: - Performance Tests
    
    func testClusteringPerformanceWithManyParticipants() {
        // Create 100 participants in a small area
        var manyParticipants: [Participant] = []
        
        for i in 0..<100 {
            let participant = Participant(
                userId: UUID(),
                user: User(
                    username: "User \(i)",
                    email: "user\(i)@example.com",
                    city: "Test City",
                    dateOfBirth: Date(),
                    vehicle: Vehicle(
                        make: "Test",
                        model: "Car",
                        vehicleNumber: "TEST\(i)",
                        odometerReading: 10000,
                        type: .sedan
                    )
                ),
                currentLocation: CLLocationCoordinate2D(
                    latitude: 37.7749 + Double(i) * 0.0001, // Small increments
                    longitude: -122.4194 + Double(i) * 0.0001
                ),
                isLocationSharingEnabled: true,
                status: .active
            )
            manyParticipants.append(participant)
        }
        
        measure {
            let (_, _) = clusteringManager.clusterParticipants(manyParticipants)
        }
    }
}