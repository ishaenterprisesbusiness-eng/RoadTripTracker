import XCTest
import CoreData
import Combine
import UserNotifications
@testable import RoadTripTracker

class BudgetServiceTests: XCTestCase {
    
    var budgetService: BudgetService!
    var mockPersistenceController: PersistenceController!
    var mockNotificationService: MockNotificationService!
    var cancellables: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        
        // Create in-memory Core Data stack for testing
        mockPersistenceController = PersistenceController(inMemory: true)
        mockNotificationService = MockNotificationService()
        budgetService = BudgetService(
            persistenceController: mockPersistenceController,
            notificationService: mockNotificationService
        )
        cancellables = Set<AnyCancellable>()
    }
    
    override func tearDownWithError() throws {
        cancellables = nil
        budgetService = nil
        mockNotificationService = nil
        mockPersistenceController = nil
        try super.tearDownWithError()
    }
    
    // MARK: - Budget Creation Tests
    
    func testCreateBudget() async throws {
        // Given
        let tripId = UUID()
        let totalBudget = 1000.0
        let perPersonBudget = 250.0
        
        // Create a trip first
        try await createTestTrip(id: tripId)
        
        // When
        let budget = try await budgetService.createBudget(
            for: tripId,
            totalBudget: totalBudget,
            perPersonBudget: perPersonBudget
        )
        
        // Then
        XCTAssertEqual(budget.totalBudget, totalBudget)
        XCTAssertEqual(budget.perPersonBudget, perPersonBudget)
        XCTAssertTrue(budget.expenses.isEmpty)
        XCTAssertTrue(budget.categories.isEmpty)
    }
    
    func testCreateBudgetWithoutPerPersonBudget() async throws {
        // Given
        let tripId = UUID()
        let totalBudget = 1500.0
        
        // Create a trip first
        try await createTestTrip(id: tripId)
        
        // When
        let budget = try await budgetService.createBudget(
            for: tripId,
            totalBudget: totalBudget,
            perPersonBudget: nil
        )
        
        // Then
        XCTAssertEqual(budget.totalBudget, totalBudget)
        XCTAssertNil(budget.perPersonBudget)
    }
    
    func testCreateBudgetForNonexistentTrip() async {
        // Given
        let nonexistentTripId = UUID()
        
        // When/Then
        do {
            _ = try await budgetService.createBudget(
                for: nonexistentTripId,
                totalBudget: 1000.0,
                perPersonBudget: nil
            )
            XCTFail("Expected BudgetServiceError.budgetNotFound")
        } catch BudgetServiceError.budgetNotFound {
            // Expected error
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    // MARK: - Expense Management Tests
    
    func testAddExpense() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await createTestTrip(id: tripId)
        
        let expense = Expense(
            amount: 50.0,
            category: .fuel,
            description: "Gas station fill-up",
            participantId: participantId
        )
        
        // Set up budget update expectation
        let expectation = XCTestExpectation(description: "Budget update received")
        budgetService.budgetUpdates
            .sink { update in
                XCTAssertEqual(update.tripId, tripId)
                XCTAssertEqual(update.updateType, .expenseAdded)
                XCTAssertEqual(update.expense?.id, expense.id)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        // When
        try await budgetService.addExpense(expense, to: tripId)
        
        // Then
        await fulfillment(of: [expectation], timeout: 1.0)
        
        // Verify expense was saved
        let summary = try await budgetService.getBudgetSummary(for: tripId)
        XCTAssertEqual(summary.totalSpent, 50.0)
        XCTAssertEqual(summary.spendingByCategory[.fuel], 50.0)
        XCTAssertEqual(summary.spendingByParticipant[participantId], 50.0)
    }
    
    func testAddExpenseToNonexistentTrip() async {
        // Given
        let nonexistentTripId = UUID()
        let expense = Expense(
            amount: 50.0,
            category: .fuel,
            description: "Test expense",
            participantId: UUID()
        )
        
        // When/Then
        do {
            try await budgetService.addExpense(expense, to: nonexistentTripId)
            XCTFail("Expected BudgetServiceError.budgetNotFound")
        } catch BudgetServiceError.budgetNotFound {
            // Expected error
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    func testUpdateExpense() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await createTestTrip(id: tripId)
        
        let originalExpense = Expense(
            amount: 50.0,
            category: .fuel,
            description: "Original description",
            participantId: participantId
        )
        
        try await budgetService.addExpense(originalExpense, to: tripId)
        
        let updatedExpense = Expense(
            id: originalExpense.id,
            amount: 75.0,
            category: .food,
            description: "Updated description",
            participantId: participantId
        )
        
        // When
        try await budgetService.updateExpense(updatedExpense)
        
        // Then
        let summary = try await budgetService.getBudgetSummary(for: tripId)
        XCTAssertEqual(summary.totalSpent, 75.0)
        XCTAssertEqual(summary.spendingByCategory[.food], 75.0)
        XCTAssertNil(summary.spendingByCategory[.fuel])
    }
    
    func testDeleteExpense() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await createTestTrip(id: tripId)
        
        let expense = Expense(
            amount: 50.0,
            category: .fuel,
            description: "Test expense",
            participantId: participantId
        )
        
        try await budgetService.addExpense(expense, to: tripId)
        
        // Verify expense was added
        var summary = try await budgetService.getBudgetSummary(for: tripId)
        XCTAssertEqual(summary.totalSpent, 50.0)
        
        // When
        try await budgetService.deleteExpense(expense.id, from: tripId)
        
        // Then
        summary = try await budgetService.getBudgetSummary(for: tripId)
        XCTAssertEqual(summary.totalSpent, 0.0)
        XCTAssertTrue(summary.spendingByCategory.isEmpty)
        XCTAssertTrue(summary.spendingByParticipant.isEmpty)
    }
    
    // MARK: - Budget Summary Tests
    
    func testGetBudgetSummary() async throws {
        // Given
        let tripId = UUID()
        let participantId1 = UUID()
        let participantId2 = UUID()
        
        try await createTestTrip(id: tripId, totalBudget: 1000.0)
        
        let expense1 = Expense(amount: 200.0, category: .fuel, description: "Fuel", participantId: participantId1)
        let expense2 = Expense(amount: 150.0, category: .food, description: "Food", participantId: participantId2)
        let expense3 = Expense(amount: 100.0, category: .fuel, description: "More fuel", participantId: participantId1)
        
        try await budgetService.addExpense(expense1, to: tripId)
        try await budgetService.addExpense(expense2, to: tripId)
        try await budgetService.addExpense(expense3, to: tripId)
        
        // When
        let summary = try await budgetService.getBudgetSummary(for: tripId)
        
        // Then
        XCTAssertEqual(summary.tripId, tripId)
        XCTAssertEqual(summary.totalBudget, 1000.0)
        XCTAssertEqual(summary.totalSpent, 450.0)
        XCTAssertEqual(summary.remainingBudget, 550.0)
        
        // Check category breakdown
        XCTAssertEqual(summary.spendingByCategory[.fuel], 300.0)
        XCTAssertEqual(summary.spendingByCategory[.food], 150.0)
        
        // Check participant breakdown
        XCTAssertEqual(summary.spendingByParticipant[participantId1], 300.0)
        XCTAssertEqual(summary.spendingByParticipant[participantId2], 150.0)
        
        // Check calculations
        XCTAssertGreaterThan(summary.averageSpendingPerDay, 0)
        XCTAssertGreaterThan(summary.projectedTotalSpending, summary.totalSpent)
    }
    
    func testGetBudgetSummaryForNonexistentTrip() async {
        // Given
        let nonexistentTripId = UUID()
        
        // When/Then
        do {
            _ = try await budgetService.getBudgetSummary(for: nonexistentTripId)
            XCTFail("Expected BudgetServiceError.budgetNotFound")
        } catch BudgetServiceError.budgetNotFound {
            // Expected error
        } catch {
            XCTFail("Unexpected error: \(error)")
        }
    }
    
    // MARK: - Budget Notifications Tests
    
    func testBudgetLimitNotifications() async throws {
        // Given
        let tripId = UUID()
        let participantId = UUID()
        try await createTestTrip(id: tripId, totalBudget: 100.0)
        
        // When - Add expense that reaches 80% of budget
        let expense80 = Expense(amount: 80.0, category: .fuel, description: "80% expense", participantId: participantId)
        try await budgetService.addExpense(expense80, to: tripId)
        
        // Then - Should trigger 80% notification
        XCTAssertEqual(mockNotificationService.sentNotifications.count, 1)
        XCTAssertTrue(mockNotificationService.sentNotifications[0].body.contains("80%"))
        
        // When - Add expense that reaches 90% of budget
        let expense10 = Expense(amount: 10.0, category: .food, description: "90% expense", participantId: participantId)
        try await budgetService.addExpense(expense10, to: tripId)
        
        // Then - Should trigger 90% notification
        XCTAssertEqual(mockNotificationService.sentNotifications.count, 2)
        XCTAssertTrue(mockNotificationService.sentNotifications[1].body.contains("90%"))
    }
    
    // MARK: - Helper Methods
    
    private func createTestTrip(id: UUID, totalBudget: Double = 0.0) async throws {
        let context = mockPersistenceController.container.viewContext
        
        try await context.perform {
            let cdTrip = CDTrip(context: context)
            cdTrip.id = id
            cdTrip.name = "Test Trip"
            cdTrip.code = "TEST123"
            cdTrip.createdBy = UUID()
            cdTrip.status = "planning"
            cdTrip.createdAt = Date()
            cdTrip.totalBudget = totalBudget
            
            try context.save()
        }
    }
}

// MARK: - Mock Notification Service

class MockNotificationService: NotificationServiceProtocol {
    struct SentNotification {
        let title: String
        let body: String
        let recipientIds: [UUID]
        let priority: NotificationPriority
    }
    
    var sentNotifications: [SentNotification] = []
    
    var notificationPermissionStatus: AnyPublisher<UNAuthorizationStatus, Never> {
        Just(.authorized).eraseToAnyPublisher()
    }
    
    func requestNotificationPermission() async throws -> Bool {
        return true
    }
    
    func scheduleLocalNotification(_ notification: LocalNotification) async throws {}
    
    func cancelNotification(withIdentifier identifier: String) async throws {}
    
    func cancelAllNotifications() async throws {}
    
    func sendPushNotification(_ notification: PushNotification) async throws {
        sentNotifications.append(SentNotification(
            title: notification.title,
            body: notification.body,
            recipientIds: notification.recipientIds,
            priority: notification.priority
        ))
    }
    
    func registerForRemoteNotifications() async throws -> Data {
        return Data()
    }
    
    func handleRemoteNotification(_ userInfo: [AnyHashable: Any]) async {}
}